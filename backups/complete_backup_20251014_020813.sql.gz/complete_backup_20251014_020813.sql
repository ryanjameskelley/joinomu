--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-10-14 08:52:12 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS postgres;
--
-- TOC entry 4806 (class 1262 OID 5)
-- Name: postgres; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = icu LOCALE = 'en_US.UTF-8' ICU_LOCALE = 'en-US';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4807 (class 0 OID 0)
-- Dependencies: 4806
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- TOC entry 4808 (class 0 OID 0)
-- Name: postgres; Type: DATABASE PROPERTIES; Schema: -; Owner: -
--

ALTER DATABASE postgres SET "app.settings.jwt_secret" TO 'super-secret-jwt-token-with-at-least-32-characters-long';
ALTER DATABASE postgres SET "app.settings.jwt_exp" TO '3600';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 33 (class 2615 OID 16457)
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- TOC entry 25 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- TOC entry 4809 (class 0 OID 0)
-- Dependencies: 25
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- TOC entry 22 (class 2615 OID 16605)
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA realtime;


--
-- TOC entry 34 (class 2615 OID 16505)
-- Name: storage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA storage;


--
-- TOC entry 16 (class 2615 OID 16750)
-- Name: supabase_functions; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA supabase_functions;


--
-- TOC entry 1263 (class 1247 OID 18016)
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


--
-- TOC entry 1287 (class 1247 OID 18157)
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


--
-- TOC entry 1260 (class 1247 OID 18010)
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


--
-- TOC entry 1257 (class 1247 OID 18005)
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


--
-- TOC entry 1299 (class 1247 OID 18238)
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


--
-- TOC entry 1293 (class 1247 OID 18199)
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


--
-- TOC entry 1203 (class 1247 OID 16890)
-- Name: action; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


--
-- TOC entry 1194 (class 1247 OID 16850)
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


--
-- TOC entry 1197 (class 1247 OID 16865)
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


--
-- TOC entry 1209 (class 1247 OID 16932)
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


--
-- TOC entry 1206 (class 1247 OID 16903)
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


--
-- TOC entry 1242 (class 1247 OID 17887)
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: -
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS'
);


--
-- TOC entry 517 (class 1255 OID 16503)
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


--
-- TOC entry 4810 (class 0 OID 0)
-- Dependencies: 517
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- TOC entry 389 (class 1255 OID 17987)
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


--
-- TOC entry 436 (class 1255 OID 16502)
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


--
-- TOC entry 4811 (class 0 OID 0)
-- Dependencies: 436
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- TOC entry 434 (class 1255 OID 16501)
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


--
-- TOC entry 4812 (class 0 OID 0)
-- Dependencies: 434
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- TOC entry 400 (class 1255 OID 18407)
-- Name: assign_patient_to_provider(uuid, uuid, text, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.assign_patient_to_provider(patient_profile_id uuid, provider_profile_id uuid, treatment_type_param text DEFAULT 'general_care'::text, is_primary_param boolean DEFAULT false) RETURNS TABLE(success boolean, message text, assignment_id uuid)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  patient_id_var UUID;
  provider_id_var UUID;
  assignment_id_var UUID;
BEGIN
  -- Get the patient ID from profile ID
  SELECT id INTO patient_id_var
  FROM patients
  WHERE profile_id = patient_profile_id;
  
  IF patient_id_var IS NULL THEN
    RETURN QUERY SELECT false, 'Patient not found', NULL::UUID;
    RETURN;
  END IF;
  
  -- Get the provider ID from profile ID
  SELECT id INTO provider_id_var
  FROM providers
  WHERE profile_id = provider_profile_id AND active = true;
  
  IF provider_id_var IS NULL THEN
    RETURN QUERY SELECT false, 'Provider not found or inactive', NULL::UUID;
    RETURN;
  END IF;
  
  -- Check if assignment already exists
  IF EXISTS (
    SELECT 1 FROM patient_assignments 
    WHERE patient_id = patient_id_var 
    AND provider_id = provider_id_var
    AND treatment_type = treatment_type_param
  ) THEN
    RETURN QUERY SELECT false, 'Patient is already assigned to this provider for this treatment type', NULL::UUID;
    RETURN;
  END IF;
  
  -- Create the assignment
  INSERT INTO patient_assignments (
    patient_id,
    provider_id,
    treatment_type,
    is_primary,
    assigned_date
  ) VALUES (
    patient_id_var,
    provider_id_var,
    treatment_type_param,
    is_primary_param,
    CURRENT_DATE
  ) RETURNING id INTO assignment_id_var;
  
  RETURN QUERY SELECT true, 'Patient successfully assigned to provider', assignment_id_var;
END;
$$;


--
-- TOC entry 377 (class 1255 OID 18660)
-- Name: book_appointment(uuid, uuid, date, time without time zone, text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text DEFAULT 'consultation'::text, p_booked_by text DEFAULT 'patient'::text, p_patient_notes text DEFAULT NULL::text) RETURNS TABLE(success boolean, appointment_id uuid, message text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  v_patient_id UUID;
  v_assignment_id UUID;
  v_duration_minutes INTEGER;
  v_end_time TIME;
  v_new_appointment_id UUID;
BEGIN
  -- Get patient ID from profile ID
  SELECT p.id INTO v_patient_id
  FROM patients p
  WHERE p.profile_id = p_patient_profile_id;
  
  IF v_patient_id IS NULL THEN
    success := false;
    appointment_id := NULL;
    message := 'Patient not found';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Verify patient-provider relationship exists
  SELECT pa.id INTO v_assignment_id
  FROM patient_assignments pa
  WHERE pa.patient_id = v_patient_id
    AND pa.provider_id = p_provider_id
    AND pa.active = true
  LIMIT 1;
  
  IF v_assignment_id IS NULL THEN
    success := false;
    appointment_id := NULL;
    message := 'No active assignment between patient and provider';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Check if the requested slot is available
  SELECT ps.slot_duration_minutes INTO v_duration_minutes
  FROM provider_schedules ps
  WHERE ps.provider_id = p_provider_id
    AND ps.day_of_week = EXTRACT(DOW FROM p_appointment_date)
    AND ps.start_time <= p_start_time
    AND ps.end_time >= p_start_time + INTERVAL '30 minutes' -- minimum slot
    AND ps.active = true
    AND (p_treatment_type = ANY(ps.treatment_types) OR array_length(ps.treatment_types, 1) IS NULL)
  LIMIT 1;
  
  IF v_duration_minutes IS NULL THEN
    success := false;
    appointment_id := NULL;
    message := 'Provider not available at requested time';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Calculate end time
  v_end_time := p_start_time + INTERVAL '1 minute' * v_duration_minutes;
  
  -- Check for scheduling conflicts
  IF EXISTS (
    SELECT 1 FROM appointments a
    WHERE a.provider_id = p_provider_id
      AND a.appointment_date = p_appointment_date
      AND a.start_time = p_start_time
      AND a.status NOT IN ('cancelled', 'no_show')
  ) THEN
    success := false;
    appointment_id := NULL;
    message := 'Time slot already booked';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Check for availability overrides
  IF EXISTS (
    SELECT 1 FROM provider_availability_overrides pao
    WHERE pao.provider_id = p_provider_id
      AND pao.date = p_appointment_date
      AND pao.available = false
      AND (pao.start_time IS NULL OR p_start_time >= pao.start_time)
      AND (pao.end_time IS NULL OR v_end_time <= pao.end_time)
  ) THEN
    success := false;
    appointment_id := NULL;
    message := 'Provider not available on requested date';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Create the appointment
  INSERT INTO appointments (
    patient_id,
    provider_id,
    assignment_id,
    appointment_date,
    start_time,
    end_time,
    duration_minutes,
    treatment_type,
    appointment_type,
    status,
    patient_notes,
    booked_by,
    booked_by_user_id
  ) VALUES (
    v_patient_id,
    p_provider_id,
    v_assignment_id,
    p_appointment_date,
    p_start_time,
    v_end_time,
    v_duration_minutes,
    p_treatment_type,
    p_appointment_type,
    'scheduled',
    p_patient_notes,
    p_booked_by,
    p_patient_profile_id
  ) RETURNING id INTO v_new_appointment_id;
  
  -- Return success
  success := true;
  appointment_id := v_new_appointment_id;
  message := 'Appointment booked successfully';
  RETURN NEXT;
  RETURN;
  
EXCEPTION
  WHEN OTHERS THEN
    success := false;
    appointment_id := NULL;
    message := 'Error booking appointment: ' || SQLERRM;
    RETURN NEXT;
    RETURN;
END;
$$;


--
-- TOC entry 4813 (class 0 OID 0)
-- Dependencies: 377
-- Name: FUNCTION book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text, p_booked_by text, p_patient_notes text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text, p_booked_by text, p_patient_notes text) IS 'Books a new appointment with full validation';


--
-- TOC entry 501 (class 1255 OID 19114)
-- Name: calculate_next_prescription_due(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.calculate_next_prescription_due() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_fax_date DATE;
    v_calculated_due_date DATE;
BEGIN
    -- Only proceed if supply_days was added/changed and we have an approved status
    IF NEW.supply_days IS NOT NULL 
       AND NEW.supply_days > 0 
       AND NEW.status = 'approved'
       AND (OLD.supply_days IS NULL OR OLD.supply_days != NEW.supply_days OR OLD.status != 'approved') THEN
        
        -- Use the faxed date from the preference itself
        IF NEW.faxed IS NOT NULL THEN
            v_fax_date := NEW.faxed::date;
            v_calculated_due_date := v_fax_date + NEW.supply_days;
            
            -- Update the next_prescription_due field
            NEW.next_prescription_due := v_calculated_due_date;
            
            -- Log the calculation for debugging (if logging table exists)
            BEGIN
                INSERT INTO auth_trigger_logs (
                    step, 
                    status, 
                    message, 
                    metadata
                ) VALUES (
                    'SUPPLY_CALCULATION', 
                    'SUCCESS', 
                    'Calculated next prescription due from preference update',
                    jsonb_build_object(
                        'preference_id', NEW.id,
                        'fax_date', v_fax_date,
                        'supply_days', NEW.supply_days,
                        'calculated_due_date', v_calculated_due_date
                    )
                );
            EXCEPTION WHEN OTHERS THEN
                -- Ignore logging errors, don't fail the main operation
                NULL;
            END;
        ELSE
            -- If no fax date, set the faxed date to now when approving with supply
            NEW.faxed := NOW();
            v_fax_date := NEW.faxed::date;
            v_calculated_due_date := v_fax_date + NEW.supply_days;
            NEW.next_prescription_due := v_calculated_due_date;
            
            -- Log that we set the fax date
            BEGIN
                INSERT INTO auth_trigger_logs (
                    step, 
                    status, 
                    message, 
                    metadata
                ) VALUES (
                    'SUPPLY_CALCULATION', 
                    'SUCCESS', 
                    'Set fax date to now and calculated next prescription due',
                    jsonb_build_object(
                        'preference_id', NEW.id,
                        'fax_date', v_fax_date,
                        'supply_days', NEW.supply_days,
                        'calculated_due_date', v_calculated_due_date
                    )
                );
            EXCEPTION WHEN OTHERS THEN
                -- Ignore logging errors, don't fail the main operation
                NULL;
            END;
        END IF;
    END IF;
    
    -- Reset refill_requested flag when status changes to approved
    IF NEW.status = 'approved' AND OLD.status != 'approved' THEN
        NEW.refill_requested := FALSE;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- TOC entry 4814 (class 0 OID 0)
-- Dependencies: 501
-- Name: FUNCTION calculate_next_prescription_due(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.calculate_next_prescription_due() IS 'Calculates next_prescription_due when supply_days is updated with approved status, and resets refill_requested flag on approval';


--
-- TOC entry 494 (class 1255 OID 19043)
-- Name: calculate_next_prescription_due(uuid, date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.calculate_next_prescription_due(p_preference_id uuid, p_delivery_date date, p_frequency text DEFAULT NULL::text) RETURNS date
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_supply_days INTEGER;
    v_frequency TEXT;
    v_next_due_date DATE;
BEGIN
    -- Get supply_days and frequency from the preference
    SELECT supply_days, frequency 
    INTO v_supply_days, v_frequency
    FROM patient_medication_preferences 
    WHERE id = p_preference_id;
    
    -- Use provided frequency if given, otherwise use the preference frequency
    IF p_frequency IS NOT NULL THEN
        v_frequency := p_frequency;
    END IF;
    
    -- If supply_days is set, use it directly
    IF v_supply_days IS NOT NULL AND v_supply_days > 0 THEN
        v_next_due_date := p_delivery_date + v_supply_days;
    ELSE
        -- Fall back to frequency-based calculation
        CASE 
            WHEN v_frequency = 'daily' THEN
                v_next_due_date := p_delivery_date + INTERVAL '30 days';
            WHEN v_frequency = 'weekly' THEN
                v_next_due_date := p_delivery_date + INTERVAL '12 weeks';
            WHEN v_frequency = 'monthly' THEN
                v_next_due_date := p_delivery_date + INTERVAL '3 months';
            WHEN v_frequency = 'quarterly' THEN
                v_next_due_date := p_delivery_date + INTERVAL '3 months';
            ELSE
                -- Default to 30 days if frequency not recognized
                v_next_due_date := p_delivery_date + INTERVAL '30 days';
        END CASE;
    END IF;
    
    RETURN v_next_due_date;
END;
$$;


--
-- TOC entry 4815 (class 0 OID 0)
-- Dependencies: 494
-- Name: FUNCTION calculate_next_prescription_due(p_preference_id uuid, p_delivery_date date, p_frequency text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.calculate_next_prescription_due(p_preference_id uuid, p_delivery_date date, p_frequency text) IS 'Calculate next prescription due date using supply_days from preferences if available, otherwise fall back to frequency-based calculation';


--
-- TOC entry 458 (class 1255 OID 18662)
-- Name: cancel_appointment(uuid, text, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text) RETURNS TABLE(success boolean, message text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  v_appointment RECORD;
BEGIN
  -- Get appointment details
  SELECT * INTO v_appointment
  FROM appointments
  WHERE id = p_appointment_id;
  
  IF NOT FOUND THEN
    success := false;
    message := 'Appointment not found';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Check if appointment can be cancelled
  IF v_appointment.status NOT IN ('scheduled', 'confirmed') THEN
    success := false;
    message := 'Appointment cannot be cancelled in current status: ' || v_appointment.status;
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Update appointment status
  UPDATE appointments
  SET 
    status = 'cancelled',
    cancelled_at = NOW(),
    cancelled_by = p_cancelled_by,
    cancelled_by_user_id = p_cancelled_by_user_id,
    cancellation_reason = p_cancellation_reason
  WHERE id = p_appointment_id;
  
  success := true;
  message := 'Appointment cancelled successfully';
  RETURN NEXT;
  RETURN;
  
EXCEPTION
  WHEN OTHERS THEN
    success := false;
    message := 'Error cancelling appointment: ' || SQLERRM;
    RETURN NEXT;
    RETURN;
END;
$$;


--
-- TOC entry 4816 (class 0 OID 0)
-- Dependencies: 458
-- Name: FUNCTION cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text) IS 'Cancels an existing appointment with audit trail';


--
-- TOC entry 396 (class 1255 OID 19102)
-- Name: check_approval_expiry_on_delivery(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_approval_expiry_on_delivery() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only proceed if fulfillment status changed to 'delivered' and estimated_delivery is set
    IF OLD.fulfillment_status != 'delivered' AND NEW.fulfillment_status = 'delivered' AND NEW.estimated_delivery IS NOT NULL THEN
        -- Check if this specific preference should be reset due to expiry
        UPDATE public.patient_medication_preferences 
        SET 
            status = 'pending',
            updated_at = NOW()
        FROM public.medication_approvals ma
        WHERE patient_medication_preferences.id = ma.preference_id
        AND ma.id = NEW.approval_id
        AND ma.status = 'approved'
        AND ma.supply_days IS NOT NULL
        AND (NEW.estimated_delivery::DATE + INTERVAL '1 day' * ma.supply_days) <= CURRENT_DATE;
        
        -- Also run the general daily check (but it will skip if already run today)
        PERFORM public.daily_approval_reset_check();
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- TOC entry 4817 (class 0 OID 0)
-- Dependencies: 396
-- Name: FUNCTION check_approval_expiry_on_delivery(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.check_approval_expiry_on_delivery() IS 'Check preference expiry when orders are delivered and reset to pending status';


--
-- TOC entry 463 (class 1255 OID 18859)
-- Name: check_auth_trigger_health(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_auth_trigger_health() RETURNS TABLE(metric text, value integer, status text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    auth_users_count INTEGER;
    profiles_count INTEGER;
    providers_count INTEGER;
    schedules_count INTEGER;
    recent_failures INTEGER;
    missing_profiles INTEGER;
BEGIN
    -- Get counts
    SELECT COUNT(*) INTO auth_users_count FROM auth.users;
    SELECT COUNT(*) INTO profiles_count FROM public.profiles;
    SELECT COUNT(*) INTO providers_count FROM public.providers;
    SELECT COUNT(*) INTO schedules_count FROM public.provider_schedules;
    
    -- Check for missing profiles
    SELECT COUNT(*) INTO missing_profiles 
    FROM auth.users u 
    LEFT JOIN public.profiles p ON u.id = p.id 
    WHERE p.id IS NULL;
    
    -- Check recent failures
    SELECT COUNT(*) INTO recent_failures 
    FROM public.auth_trigger_logs 
    WHERE success = false 
    AND created_at > NOW() - INTERVAL '1 hour';
    
    -- Return metrics
    RETURN QUERY VALUES 
        ('auth_users', auth_users_count, CASE WHEN auth_users_count > 0 THEN 'OK' ELSE 'EMPTY' END),
        ('profiles', profiles_count, CASE WHEN profiles_count >= auth_users_count THEN 'OK' ELSE 'MISSING' END),
        ('providers', providers_count, 'INFO'),
        ('schedules', schedules_count, 'INFO'),
        ('missing_profiles', missing_profiles, CASE WHEN missing_profiles = 0 THEN 'OK' ELSE 'NEEDS_REPAIR' END),
        ('recent_failures', recent_failures, CASE WHEN recent_failures = 0 THEN 'OK' ELSE 'ATTENTION' END);
END;
$$;


--
-- TOC entry 364 (class 1255 OID 19046)
-- Name: clear_overdue_faxed_status(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.clear_overdue_faxed_status() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    rows_updated INTEGER;
BEGIN
    UPDATE public.patient_medication_preferences 
    SET faxed = NULL
    WHERE faxed IS NOT NULL 
    AND next_prescription_due IS NOT NULL 
    AND next_prescription_due <= CURRENT_DATE;
    
    GET DIAGNOSTICS rows_updated = ROW_COUNT;
    RETURN rows_updated;
END;
$$;


--
-- TOC entry 4818 (class 0 OID 0)
-- Dependencies: 364
-- Name: FUNCTION clear_overdue_faxed_status(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.clear_overdue_faxed_status() IS 'Clears faxed status for preferences where prescription is now due';


--
-- TOC entry 461 (class 1255 OID 18830)
-- Name: create_default_provider_schedule(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_default_provider_schedule() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RAISE LOG 'Provider schedule trigger fired for provider ID: %', NEW.id;
    RAISE NOTICE 'Provider schedule trigger fired for provider ID: %', NEW.id;
    
    -- Add Monday-Friday 9 AM to 5 PM schedule for new provider
    INSERT INTO provider_schedules (provider_id, day_of_week, start_time, end_time, active, created_at) VALUES
    (NEW.id, 1, '09:00:00', '17:00:00', true, now()), -- Monday
    (NEW.id, 2, '09:00:00', '17:00:00', true, now()), -- Tuesday
    (NEW.id, 3, '09:00:00', '17:00:00', true, now()), -- Wednesday
    (NEW.id, 4, '09:00:00', '17:00:00', true, now()), -- Thursday
    (NEW.id, 5, '09:00:00', '17:00:00', true, now()); -- Friday
    
    RAISE LOG 'Created default schedule for provider %', NEW.id;
    RAISE NOTICE 'Created default schedule for provider %', NEW.id;
    
    RETURN NEW;
EXCEPTION
    WHEN OTHERS THEN
        -- Log error but don't fail the provider creation
        RAISE LOG 'Error creating default schedule for provider %: %', NEW.id, SQLERRM;
        RAISE NOTICE 'Error creating default schedule for provider %: %', NEW.id, SQLERRM;
        RETURN NEW;
END;
$$;


--
-- TOC entry 443 (class 1255 OID 19048)
-- Name: create_order_on_fax(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_order_on_fax() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only create order when a fax is inserted
    IF TG_OP = 'INSERT' THEN
        -- Insert medication order using profile IDs directly
        INSERT INTO public.medication_orders (
            approval_id,
            medication_id,
            patient_id,
            provider_profile_id,
            patient_profile_id,
            quantity,
            unit_price,
            total_amount
        )
        SELECT 
            NEW.approval_id,
            pmp.medication_id,
            (SELECT pt.id FROM public.patients pt WHERE pt.profile_id = NEW.patient_profile_id LIMIT 1),
            NEW.provider_profile_id,
            NEW.patient_profile_id,
            1, -- Default quantity
            COALESCE(m.unit_price, 0.00), -- Get price from medications table
            COALESCE(m.unit_price, 0.00) * 1 -- Total = unit_price * quantity
        FROM public.medication_approvals ma
        JOIN public.patient_medication_preferences pmp ON ma.preference_id = pmp.id
        JOIN public.medications m ON pmp.medication_id = m.id
        WHERE ma.id = NEW.approval_id;
        
        RETURN NEW;
    END IF;
    
    RETURN NULL;
END;
$$;


--
-- TOC entry 4819 (class 0 OID 0)
-- Dependencies: 443
-- Name: FUNCTION create_order_on_fax(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.create_order_on_fax() IS 'Creates medication order when prescription is faxed - uses profile IDs directly for simplicity';


--
-- TOC entry 354 (class 1255 OID 19101)
-- Name: daily_approval_reset_check(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.daily_approval_reset_check() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    last_run_date DATE;
    rows_reset INTEGER;
BEGIN
    -- Check when this was last run using correct column names
    SELECT (metadata->>'reset_date')::DATE 
    INTO last_run_date
    FROM public.auth_trigger_logs 
    WHERE trigger_stage = 'APPROVAL_RESET' 
    AND success = true
    ORDER BY created_at DESC 
    LIMIT 1;
    
    -- Only run if we haven't run today
    IF last_run_date IS NULL OR last_run_date < CURRENT_DATE THEN
        rows_reset := public.reset_expired_approvals();
        RETURN rows_reset;
    ELSE
        -- Log that we skipped because already ran today
        INSERT INTO public.auth_trigger_logs (trigger_stage, success, error_message, metadata, created_at)
        VALUES (
            'APPROVAL_RESET_SKIPPED', 
            true, 
            'Skipped approval reset - already ran today',
            jsonb_build_object('last_run_date', last_run_date, 'current_date', CURRENT_DATE),
            NOW()
        );
        RETURN 0;
    END IF;
END;
$$;


--
-- TOC entry 4820 (class 0 OID 0)
-- Dependencies: 354
-- Name: FUNCTION daily_approval_reset_check(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.daily_approval_reset_check() IS 'Daily check for expired approvals with duplicate run prevention (fixed to use trigger_stage and success columns)';


--
-- TOC entry 409 (class 1255 OID 19113)
-- Name: fix_existing_next_due_calculations(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fix_existing_next_due_calculations() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    preference_record RECORD;
    v_fax_date DATE;
    v_calculated_due_date DATE;
    v_updated_count INTEGER := 0;
BEGIN
    -- Loop through all preferences that have supply_days but no next_prescription_due
    FOR preference_record IN 
        SELECT id, supply_days, faxed
        FROM patient_medication_preferences 
        WHERE supply_days IS NOT NULL 
          AND supply_days > 0 
          AND (next_prescription_due IS NULL OR next_prescription_due < CURRENT_DATE)
          AND faxed IS NOT NULL
    LOOP
        -- Use the faxed date from the preference
        v_fax_date := preference_record.faxed::date;
        
        -- Calculate and update
        IF v_fax_date IS NOT NULL THEN
            v_calculated_due_date := v_fax_date + preference_record.supply_days;
            
            UPDATE patient_medication_preferences 
            SET 
                next_prescription_due = v_calculated_due_date,
                updated_at = NOW()
            WHERE id = preference_record.id;
            
            v_updated_count := v_updated_count + 1;
        END IF;
    END LOOP;
    
    RETURN v_updated_count;
END;
$$;


--
-- TOC entry 4821 (class 0 OID 0)
-- Dependencies: 409
-- Name: FUNCTION fix_existing_next_due_calculations(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.fix_existing_next_due_calculations() IS 'Fixes next_prescription_due for preferences with supply_days based on preference.faxed field';


--
-- TOC entry 348 (class 1255 OID 18663)
-- Name: get_admin_appointment_overview(date, date, uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_admin_appointment_overview(p_date_range_start date DEFAULT CURRENT_DATE, p_date_range_end date DEFAULT (CURRENT_DATE + '7 days'::interval), p_provider_id uuid DEFAULT NULL::uuid, p_patient_id uuid DEFAULT NULL::uuid) RETURNS TABLE(appointment_id uuid, patient_name text, provider_name text, appointment_date date, start_time time without time zone, end_time time without time zone, treatment_type text, appointment_type text, status text, last_updated timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    a.id as appointment_id,
    (patient_prof.first_name || ' ' || patient_prof.last_name) as patient_name,
    (provider_prof.first_name || ' ' || provider_prof.last_name) as provider_name,
    a.appointment_date,
    a.start_time,
    a.end_time,
    a.treatment_type,
    a.appointment_type,
    a.status,
    a.updated_at as last_updated
  FROM appointments a
  INNER JOIN patients p ON a.patient_id = p.id
  INNER JOIN profiles patient_prof ON p.profile_id = patient_prof.id
  INNER JOIN providers prov ON a.provider_id = prov.id
  INNER JOIN profiles provider_prof ON prov.profile_id = provider_prof.id
  WHERE a.appointment_date >= p_date_range_start
    AND a.appointment_date <= p_date_range_end
    AND (p_provider_id IS NULL OR a.provider_id = p_provider_id)
    AND (p_patient_id IS NULL OR a.patient_id = p_patient_id)
  ORDER BY a.appointment_date ASC, a.start_time ASC;
END;
$$;


--
-- TOC entry 4822 (class 0 OID 0)
-- Dependencies: 348
-- Name: FUNCTION get_admin_appointment_overview(p_date_range_start date, p_date_range_end date, p_provider_id uuid, p_patient_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_admin_appointment_overview(p_date_range_start date, p_date_range_end date, p_provider_id uuid, p_patient_id uuid) IS 'Admin dashboard view of appointments with filtering';


--
-- TOC entry 476 (class 1255 OID 18537)
-- Name: get_admin_fulfillment_queue(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_admin_fulfillment_queue() RETURNS TABLE(order_id uuid, patient_name text, medication_name text, quantity integer, total_amount numeric, payment_status text, fulfillment_status text, order_date timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    mo.id,
    CONCAT(pr.first_name, ' ', pr.last_name),
    m.name,
    mo.quantity,
    mo.total_amount,
    mo.payment_status,
    mo.fulfillment_status,
    mo.created_at
  FROM medication_orders mo
  JOIN medications m ON mo.medication_id = m.id
  JOIN patients pt ON mo.patient_id = pt.id
  JOIN profiles pr ON pt.profile_id = pr.id
  WHERE mo.fulfillment_status IN ('pending', 'processing')
  ORDER BY 
    CASE mo.payment_status 
      WHEN 'paid' THEN 1 
      ELSE 2 
    END,
    mo.created_at ASC;
END;
$$;


--
-- TOC entry 482 (class 1255 OID 18542)
-- Name: get_all_patients_for_admin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_all_patients_for_admin() RETURNS TABLE(patient_id uuid, profile_id uuid, first_name text, last_name text, email text, phone text, date_of_birth date, has_completed_intake boolean, assigned_providers text[], treatment_types text[], medications text[], created_at timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id as patient_id,
    p.profile_id,
    prof.first_name,
    prof.last_name,
    prof.email,
    p.phone,
    p.date_of_birth,
    p.has_completed_intake,
    COALESCE(
      ARRAY_AGG(
        DISTINCT CONCAT(prov_prof.first_name, ' ', prov_prof.last_name)
      ) FILTER (WHERE pa.id IS NOT NULL),
      '{}'::TEXT[]
    ) as assigned_providers,
    COALESCE(
      ARRAY_AGG(DISTINCT pa.treatment_type) FILTER (WHERE pa.treatment_type IS NOT NULL),
      '{}'::TEXT[]
    ) as treatment_types,
    COALESCE(
      ARRAY_AGG(DISTINCT m.name) FILTER (WHERE m.name IS NOT NULL),
      '{}'::TEXT[]
    ) as medications,
    p.created_at
  FROM patients p
  INNER JOIN profiles prof ON p.profile_id = prof.id
  LEFT JOIN patient_assignments pa ON p.profile_id = pa.patient_id
  LEFT JOIN providers prov ON pa.provider_id = prov.id
  LEFT JOIN profiles prov_prof ON prov.profile_id = prov_prof.id
  LEFT JOIN patient_medication_preferences pmp ON p.id = pmp.patient_id
  LEFT JOIN medications m ON pmp.medication_id = m.id
  WHERE prof.role = 'patient'  -- Only include users with patient role
  GROUP BY p.id, p.profile_id, prof.first_name, prof.last_name, prof.email, p.phone, p.date_of_birth, p.has_completed_intake, p.created_at
  ORDER BY prof.first_name, prof.last_name;
END;
$$;


--
-- TOC entry 430 (class 1255 OID 19094)
-- Name: get_approvals_due_for_renewal(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_approvals_due_for_renewal() RETURNS TABLE(approval_id uuid, patient_name text, medication_name text, supply_days integer, estimated_delivery date, days_since_delivery integer, expires_on date)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        ma.id as approval_id,
        (p.first_name || ' ' || p.last_name) as patient_name,
        m.name as medication_name,
        ma.supply_days,
        mo.estimated_delivery::DATE as estimated_delivery,
        (CURRENT_DATE - mo.estimated_delivery::DATE) as days_since_delivery,
        (mo.estimated_delivery::DATE + INTERVAL '1 day' * ma.supply_days)::DATE as expires_on
    FROM public.medication_approvals ma
    JOIN public.medication_orders mo ON ma.id = mo.approval_id
    JOIN public.patient_medication_preferences pmp ON ma.preference_id = pmp.id
    JOIN public.medications m ON pmp.medication_id = m.id
    JOIN public.patients pt ON pmp.patient_id = pt.id
    JOIN public.profiles p ON pt.profile_id = p.id
    WHERE ma.status = 'approved'
    AND ma.supply_days IS NOT NULL
    AND mo.estimated_delivery IS NOT NULL
    AND mo.fulfillment_status = 'delivered'
    AND (mo.estimated_delivery::DATE + INTERVAL '1 day' * ma.supply_days) <= CURRENT_DATE;
END;
$$;


--
-- TOC entry 4823 (class 0 OID 0)
-- Dependencies: 430
-- Name: FUNCTION get_approvals_due_for_renewal(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_approvals_due_for_renewal() IS 'Returns list of approvals that are due for renewal based on supply expiry';


--
-- TOC entry 421 (class 1255 OID 18543)
-- Name: get_assigned_patients_for_provider(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_assigned_patients_for_provider(provider_profile_id uuid) RETURNS TABLE(patient_id uuid, profile_id uuid, first_name text, last_name text, email text, phone text, date_of_birth date, treatment_type text, assigned_date date, is_primary boolean, has_completed_intake boolean, created_at timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id as patient_id,
    p.profile_id,
    prof.first_name,
    prof.last_name,
    prof.email,
    p.phone,
    p.date_of_birth,
    pa.treatment_type,
    pa.assigned_date::DATE,
    pa.is_primary,
    p.has_completed_intake,
    p.created_at
  FROM patients p
  INNER JOIN profiles prof ON p.profile_id = prof.id
  INNER JOIN patient_assignments pa ON p.id = pa.patient_id  -- Fixed: was p.profile_id = pa.patient_id
  INNER JOIN providers prov ON pa.provider_id = prov.id
  WHERE prov.profile_id = provider_profile_id
  ORDER BY pa.assigned_date DESC, prof.first_name, prof.last_name;
END;
$$;


--
-- TOC entry 427 (class 1255 OID 18965)
-- Name: get_available_slots_for_provider(uuid, date, date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text DEFAULT NULL::text) RETURNS TABLE(slot_date date, slot_start_time time without time zone, slot_end_time time without time zone, duration_minutes integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY
  WITH RECURSIVE date_series AS (
    SELECT p_start_date AS date
    UNION ALL
    SELECT date + 1
    FROM date_series
    WHERE date < p_end_date
  ),
  provider_daily_schedule AS (
    SELECT 
      ds.date,
      ps.start_time,
      ps.end_time,
      ps.slot_duration_minutes,
      ps.treatment_types
    FROM date_series ds
    CROSS JOIN provider_schedules ps
    WHERE ps.provider_id = p_provider_id
      AND ps.active = true
      AND ps.day_of_week = EXTRACT(DOW FROM ds.date)
      AND (
        p_treatment_type IS NULL 
        OR array_length(ps.treatment_types, 1) IS NULL 
        OR p_treatment_type = ANY(ps.treatment_types)
      )
  ),
  time_slots AS (
    SELECT 
      pds.date,
      slot_time::TIME AS start_time,
      (slot_time + (pds.slot_duration_minutes || ' minutes')::INTERVAL)::TIME AS end_time,
      pds.slot_duration_minutes
    FROM provider_daily_schedule pds
    CROSS JOIN LATERAL generate_series(
      pds.date + pds.start_time,
      pds.date + pds.end_time - (pds.slot_duration_minutes || ' minutes')::INTERVAL,
      (pds.slot_duration_minutes || ' minutes')::INTERVAL
    ) AS slot_time
  )
  SELECT 
    ts.date AS slot_date,
    ts.start_time AS slot_start_time,
    ts.end_time AS slot_end_time,
    ts.slot_duration_minutes AS duration_minutes
  FROM time_slots ts
  LEFT JOIN appointments a ON (
    a.provider_id = p_provider_id
    AND a.appointment_date = ts.date
    AND a.start_time = ts.start_time
    AND a.status IN ('scheduled', 'confirmed')
    AND (a.is_reschedule_source IS NULL OR a.is_reschedule_source = false)
  )
  WHERE a.id IS NULL  -- Only return slots that don't have existing appointments
  ORDER BY ts.date, ts.start_time;
END;
$$;


--
-- TOC entry 4824 (class 0 OID 0)
-- Dependencies: 427
-- Name: FUNCTION get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text) IS 'Returns available appointment slots for a provider excluding rescheduled appointments';


--
-- TOC entry 350 (class 1255 OID 18659)
-- Name: get_patient_appointments(uuid, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean DEFAULT false) RETURNS TABLE(appointment_id uuid, provider_name text, provider_specialty text, appointment_date date, start_time time without time zone, end_time time without time zone, treatment_type text, appointment_type text, status text, patient_notes text, provider_notes text, can_cancel boolean, can_reschedule boolean, created_at timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    a.id as appointment_id,
    (prof.first_name || ' ' || prof.last_name) as provider_name,
    prov.specialty as provider_specialty,
    a.appointment_date,
    a.start_time,
    a.end_time,
    a.treatment_type,
    a.appointment_type,
    a.status,
    a.patient_notes,
    a.provider_notes,
    -- Can cancel if appointment is scheduled/confirmed and at least 24 hours away
    CASE 
      WHEN a.status IN ('scheduled', 'confirmed') 
        AND (a.appointment_date > CURRENT_DATE + INTERVAL '1 day' 
             OR (a.appointment_date = CURRENT_DATE + INTERVAL '1 day' AND a.start_time > LOCALTIME))
      THEN true
      ELSE false
    END as can_cancel,
    -- Can reschedule if appointment is scheduled/confirmed and at least 48 hours away
    CASE 
      WHEN a.status IN ('scheduled', 'confirmed') 
        AND (a.appointment_date > CURRENT_DATE + INTERVAL '2 days'
             OR (a.appointment_date = CURRENT_DATE + INTERVAL '2 days' AND a.start_time > LOCALTIME))
      THEN true
      ELSE false
    END as can_reschedule,
    a.created_at
  FROM appointments a
  INNER JOIN patients p ON a.patient_id = p.id
  INNER JOIN providers prov ON a.provider_id = prov.id
  INNER JOIN profiles prof ON prov.profile_id = prof.id
  WHERE p.profile_id = p_patient_profile_id
    AND (p_include_past = true OR a.appointment_date >= CURRENT_DATE)
  ORDER BY a.appointment_date ASC, a.start_time ASC;
END;
$$;


--
-- TOC entry 4825 (class 0 OID 0)
-- Dependencies: 350
-- Name: FUNCTION get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean) IS 'Gets all appointments for a patient with cancellation/reschedule permissions';


--
-- TOC entry 495 (class 1255 OID 18535)
-- Name: get_patient_medication_overview(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_patient_medication_overview(patient_uuid uuid) RETURNS TABLE(medication_name text, category text, preference_status text, approval_status text, order_status text, payment_status text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    m.name,
    m.category,
    pmp.status as preference_status,
    COALESCE(ma.status, 'no_review') as approval_status,
    COALESCE(mo.fulfillment_status, 'no_order') as order_status,
    COALESCE(mo.payment_status, 'no_payment') as payment_status
  FROM patient_medication_preferences pmp
  JOIN medications m ON pmp.medication_id = m.id
  LEFT JOIN medication_approvals ma ON pmp.id = ma.preference_id
  LEFT JOIN medication_orders mo ON ma.id = mo.approval_id
  WHERE pmp.patient_id = patient_uuid
  ORDER BY pmp.created_at DESC;
END;
$$;


--
-- TOC entry 445 (class 1255 OID 18540)
-- Name: get_patient_medications_detailed(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_patient_medications_detailed(patient_uuid uuid) RETURNS TABLE(medication_id uuid, medication_name text, dosage text, supply text, status text, last_payment_date timestamp with time zone, sent_to_pharmacy_date timestamp with time zone, shipped_date timestamp with time zone, tracking_number text, order_id uuid)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        m.id as medication_id,
        m.name as medication_name,
        CONCAT(m.strength, ' ', m.dosage_form) as dosage,
        CASE 
            WHEN mo.quantity > 1 THEN CONCAT(mo.quantity::TEXT, ' units')
            ELSE '30 day supply'
        END as supply,
        mo.fulfillment_status as status,
        mo.payment_date as last_payment_date,
        mo.sent_to_pharmacy as sent_to_pharmacy_date,
        mo.shipped_date as shipped_date,
        mo.tracking_number as tracking_number,
        mo.id as order_id
    FROM medication_orders mo
    JOIN medications m ON mo.medication_id = m.id
    JOIN medication_approvals ma ON mo.approval_id = ma.id
    JOIN patient_medication_preferences pmp ON ma.preference_id = pmp.id
    WHERE mo.patient_id = patient_uuid
    AND pmp.status = 'approved'
    AND ma.status = 'approved'
    ORDER BY mo.created_at DESC;
END;
$$;


--
-- TOC entry 462 (class 1255 OID 19255)
-- Name: get_primary_shipping_address(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_primary_shipping_address(patient_profile_id uuid) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    patient_record_id UUID;
    address_record RECORD;
BEGIN
    -- Get patient record ID
    SELECT id INTO patient_record_id 
    FROM public.patients 
    WHERE profile_id = patient_profile_id;
    
    IF patient_record_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Patient not found');
    END IF;
    
    -- Get primary shipping address
    SELECT * INTO address_record
    FROM public.patient_addresses 
    WHERE patient_id = patient_record_id 
        AND address_type = 'shipping' 
        AND is_primary = true
    LIMIT 1;
    
    -- If no primary address, get the first shipping address
    IF address_record IS NULL THEN
        SELECT * INTO address_record
        FROM public.patient_addresses 
        WHERE patient_id = patient_record_id 
            AND address_type = 'shipping'
        ORDER BY created_at ASC
        LIMIT 1;
    END IF;
    
    IF address_record IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'No shipping address found');
    END IF;
    
    RETURN json_build_object(
        'success', true,
        'address', row_to_json(address_record)
    );
    
EXCEPTION 
    WHEN OTHERS THEN
        RETURN json_build_object('success', false, 'error', SQLERRM);
END;
$$;


--
-- TOC entry 353 (class 1255 OID 18403)
-- Name: get_provider_by_profile_id(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_provider_by_profile_id(provider_profile_id uuid) RETURNS TABLE(provider_id uuid, profile_id uuid, first_name text, last_name text, email text, specialty text, license_number text, phone text, active boolean)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    prov.id as provider_id,
    prov.profile_id,
    prof.first_name,
    prof.last_name,
    prof.email,
    prov.specialty,
    prov.license_number,
    prov.phone,
    prov.active
  FROM providers prov
  INNER JOIN profiles prof ON prov.profile_id = prof.id
  WHERE prov.profile_id = provider_profile_id
  AND prov.active = true;
END;
$$;


--
-- TOC entry 349 (class 1255 OID 18536)
-- Name: get_provider_pending_approvals(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_provider_pending_approvals(provider_uuid uuid) RETURNS TABLE(preference_id uuid, patient_name text, medication_name text, preferred_dosage text, frequency text, patient_notes text, requested_date timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    pmp.id,
    CONCAT(pr.first_name, ' ', pr.last_name),
    m.name,
    pmp.preferred_dosage,
    pmp.frequency,
    pmp.notes,
    pmp.requested_date
  FROM patient_medication_preferences pmp
  JOIN medications m ON pmp.medication_id = m.id
  JOIN patients pt ON pmp.patient_id = pt.id
  JOIN profiles pr ON pt.profile_id = pr.id
  JOIN patient_assignments pa ON pt.id = pa.patient_id
  JOIN providers prov ON pa.provider_id = prov.id
  LEFT JOIN medication_approvals ma ON pmp.id = ma.preference_id
  WHERE prov.profile_id = provider_uuid
  AND pmp.status = 'pending'
  AND ma.id IS NULL -- No approval exists yet
  ORDER BY pmp.requested_date ASC;
END;
$$;


--
-- TOC entry 504 (class 1255 OID 18396)
-- Name: get_user_role(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_user_role(user_id uuid DEFAULT auth.uid()) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN (
    SELECT role 
    FROM profiles 
    WHERE id = user_id
  );
END;
$$;


--
-- TOC entry 372 (class 1255 OID 18999)
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    user_role TEXT;
    first_name TEXT;
    last_name TEXT;
    phone_val TEXT;
    specialty_val TEXT;
    license_number_val TEXT;
    new_provider_id UUID;
BEGIN
    -- Extract data from raw_user_meta_data only
    user_role := COALESCE(NEW.raw_user_meta_data->>'role', 'patient');
    first_name := COALESCE(
        NEW.raw_user_meta_data->>'first_name',
        NEW.raw_user_meta_data->>'firstName', 
        'User'
    );
    last_name := COALESCE(
        NEW.raw_user_meta_data->>'last_name',
        NEW.raw_user_meta_data->>'lastName', 
        'Unknown'
    );
    phone_val := NEW.raw_user_meta_data->>'phone';
    specialty_val := NEW.raw_user_meta_data->>'specialty';
    license_number_val := COALESCE(
        NEW.raw_user_meta_data->>'license_number',
        NEW.raw_user_meta_data->>'licenseNumber'
    );

    -- Create profile first with explicit schema reference
    INSERT INTO public.profiles (id, email, first_name, last_name, role, created_at, updated_at)
    VALUES (NEW.id, NEW.email, first_name, last_name, user_role, NOW(), NOW());

    -- Create role-specific records with explicit schema references
    IF user_role = 'patient' THEN
        INSERT INTO public.patients (profile_id, phone, has_completed_intake, created_at, updated_at)
        VALUES (NEW.id, phone_val, false, NOW(), NOW());

    ELSIF user_role = 'provider' THEN
        -- Create provider record and capture the ID for schedule creation
        INSERT INTO public.providers (profile_id, specialty, license_number, phone, active, created_at, updated_at)
        VALUES (NEW.id, specialty_val, license_number_val, phone_val, true, NOW(), NOW())
        RETURNING id INTO new_provider_id;

        -- Create default provider schedule (Monday-Friday, 9 AM - 5 PM)
        INSERT INTO public.provider_schedules (provider_id, day_of_week, start_time, end_time, treatment_types, active, created_at, updated_at)
        VALUES
            (new_provider_id, 1, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 2, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 3, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 4, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 5, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW());

    ELSIF user_role = 'admin' THEN
        INSERT INTO public.admins (profile_id, permissions, active, created_at, updated_at)
        VALUES (NEW.id, ARRAY['dashboard', 'patients', 'providers', 'assignments'], true, NOW(), NOW());
    END IF;

    RETURN NEW;
EXCEPTION
    WHEN OTHERS THEN
        RAISE LOG 'Error in handle_new_user trigger for user %: % - %', NEW.id, SQLSTATE, SQLERRM;
        RAISE;
END;
$$;


--
-- TOC entry 498 (class 1255 OID 18655)
-- Name: log_appointment_changes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.log_appointment_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Insert into appointment_history
  INSERT INTO appointment_history (
    appointment_id,
    action,
    performed_by,
    performed_by_user_id,
    old_values,
    new_values,
    reason
  ) VALUES (
    COALESCE(NEW.id, OLD.id),
    CASE 
      WHEN TG_OP = 'INSERT' THEN 'created'
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'cancelled' AND OLD.status != 'cancelled' THEN 'cancelled'
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'completed' AND OLD.status != 'completed' THEN 'completed'  
      WHEN TG_OP = 'UPDATE' AND (NEW.appointment_date != OLD.appointment_date OR NEW.start_time != OLD.start_time) THEN 'rescheduled'
      WHEN TG_OP = 'UPDATE' THEN 'updated'
      WHEN TG_OP = 'DELETE' THEN 'deleted'
    END,
    COALESCE(
      current_setting('app.current_user_role', true),
      'system'
    ),
    CASE 
      WHEN current_setting('app.current_user_id', true) != '' 
      THEN current_setting('app.current_user_id', true)::UUID
      ELSE NULL
    END,
    CASE WHEN TG_OP != 'INSERT' THEN to_jsonb(OLD) ELSE NULL END,
    CASE WHEN TG_OP != 'DELETE' THEN to_jsonb(NEW) ELSE NULL END,
    CASE 
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'cancelled' THEN NEW.cancellation_reason
      ELSE NULL
    END
  );
  
  RETURN COALESCE(NEW, OLD);
END;
$$;


--
-- TOC entry 358 (class 1255 OID 18858)
-- Name: repair_missing_profiles(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.repair_missing_profiles() RETURNS TABLE(user_id uuid, action_taken text, success boolean, error_message text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    user_rec RECORD;
    new_provider_id UUID;
    schedule_count INTEGER;
BEGIN
    -- Find users without profiles
    FOR user_rec IN (
        SELECT u.id, u.email, u.created_at, u.raw_user_meta_data
        FROM auth.users u
        LEFT JOIN public.profiles p ON u.id = p.id
        WHERE p.id IS NULL
        ORDER BY u.created_at DESC
    ) LOOP
        BEGIN
            -- Extract role and create profile
            DECLARE
                user_role TEXT := COALESCE(user_rec.raw_user_meta_data->>'role', 'patient');
                first_name_val TEXT := COALESCE(
                    user_rec.raw_user_meta_data->>'firstName',
                    user_rec.raw_user_meta_data->>'first_name',
                    split_part(user_rec.email, '@', 1)
                );
                last_name_val TEXT := COALESCE(
                    user_rec.raw_user_meta_data->>'lastName',
                    user_rec.raw_user_meta_data->>'last_name',
                    'User'
                );
            BEGIN
                -- Create profile
                INSERT INTO public.profiles (id, email, role, first_name, last_name, created_at)
                VALUES (user_rec.id, user_rec.email, user_role, first_name_val, last_name_val, user_rec.created_at);
                
                -- Create role-specific records
                IF user_role = 'provider' THEN
                    INSERT INTO public.providers (profile_id, specialty, license_number, active, created_at)
                    VALUES (user_rec.id, 'General Practice', 'REPAIRED', true, user_rec.created_at)
                    RETURNING id INTO new_provider_id;
                    
                    -- Create schedules
                    INSERT INTO public.provider_schedules (provider_id, day_of_week, start_time, end_time, active, created_at)
                    SELECT new_provider_id, day_num, '09:00:00'::TIME, '17:00:00'::TIME, true, user_rec.created_at
                    FROM generate_series(1, 5) AS day_num;
                    
                    GET DIAGNOSTICS schedule_count = ROW_COUNT;
                    
                    RETURN QUERY SELECT 
                        user_rec.id,
                        format('Created profile, provider, and %s schedules', schedule_count),
                        true,
                        NULL::TEXT;
                        
                ELSIF user_role = 'patient' THEN
                    INSERT INTO public.patients (profile_id, has_completed_intake, created_at)
                    VALUES (user_rec.id, false, user_rec.created_at);
                    
                    RETURN QUERY SELECT 
                        user_rec.id,
                        'Created profile and patient record',
                        true,
                        NULL::TEXT;
                        
                ELSIF user_role = 'admin' THEN
                    INSERT INTO public.admins (profile_id, permissions, active, created_at)
                    VALUES (user_rec.id, ARRAY['dashboard', 'patients', 'providers'], true, user_rec.created_at);
                    
                    RETURN QUERY SELECT 
                        user_rec.id,
                        'Created profile and admin record',
                        true,
                        NULL::TEXT;
                ELSE
                    RETURN QUERY SELECT 
                        user_rec.id,
                        'Created profile only',
                        true,
                        NULL::TEXT;
                END IF;
                
            EXCEPTION WHEN OTHERS THEN
                RETURN QUERY SELECT 
                    user_rec.id,
                    'Failed to repair',
                    false,
                    SQLERRM;
            END;
        END;
    END LOOP;
END;
$$;


--
-- TOC entry 437 (class 1255 OID 19112)
-- Name: request_prescription_refill(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.request_prescription_refill(p_preference_id uuid, p_patient_profile_id uuid) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_preference_record RECORD;
    v_patient_id UUID;
    v_days_until_due INTEGER;
BEGIN
    -- Get patient ID from profile
    SELECT id INTO v_patient_id 
    FROM patients 
    WHERE profile_id = p_patient_profile_id;
    
    IF v_patient_id IS NULL THEN
        RETURN json_build_object(
            'success', false,
            'error', 'Patient not found'
        );
    END IF;
    
    -- Get the preference record
    SELECT 
        id, 
        patient_id, 
        status, 
        next_prescription_due,
        medication_id,
        preferred_dosage,
        frequency
    INTO v_preference_record
    FROM patient_medication_preferences 
    WHERE id = p_preference_id 
      AND patient_id = v_patient_id;
    
    IF v_preference_record.id IS NULL THEN
        RETURN json_build_object(
            'success', false,
            'error', 'Medication preference not found or access denied'
        );
    END IF;
    
    -- Check if preference is currently approved
    IF v_preference_record.status != 'approved' THEN
        RETURN json_build_object(
            'success', false,
            'error', 'Can only request refills for approved medications'
        );
    END IF;
    
    -- Check if next_prescription_due exists
    IF v_preference_record.next_prescription_due IS NULL THEN
        RETURN json_build_object(
            'success', false,
            'error', 'No prescription due date found'
        );
    END IF;
    
    -- Calculate days until due
    v_days_until_due := v_preference_record.next_prescription_due::date - CURRENT_DATE;
    
    -- Only allow refill requests within 3 days of due date (or past due)
    IF v_days_until_due > 3 THEN
        RETURN json_build_object(
            'success', false,
            'error', 'Refill can only be requested within 3 days of due date'
        );
    END IF;
    
    -- Update preference status to pending AND set refill_requested = TRUE with timestamp
    UPDATE patient_medication_preferences 
    SET 
        status = 'pending',
        refill_requested = TRUE,  -- Mark as patient-requested refill
        refill_requested_date = NOW(),  -- Track when refill was requested
        notes = COALESCE(notes, '') || 
                CASE 
                    WHEN notes IS NULL OR notes = '' THEN 
                        'Refill requested on ' || CURRENT_DATE::text
                    ELSE 
                        '; Refill requested on ' || CURRENT_DATE::text
                END,
        updated_at = NOW()
    WHERE id = p_preference_id;
    
    RETURN json_build_object(
        'success', true,
        'message', 'Refill request submitted successfully',
        'preference_id', p_preference_id,
        'new_status', 'pending',
        'refill_requested', true,
        'refill_requested_date', NOW(),
        'days_until_due', v_days_until_due
    );
    
EXCEPTION WHEN OTHERS THEN
    RETURN json_build_object(
        'success', false,
        'error', 'An error occurred while processing the refill request: ' || SQLERRM
    );
END;
$$;


--
-- TOC entry 4826 (class 0 OID 0)
-- Dependencies: 437
-- Name: FUNCTION request_prescription_refill(p_preference_id uuid, p_patient_profile_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.request_prescription_refill(p_preference_id uuid, p_patient_profile_id uuid) IS 'Allows patients to request prescription refills within 3 days of due date, sets refill_requested=TRUE for provider approval filtering';


--
-- TOC entry 481 (class 1255 OID 18939)
-- Name: reschedule_appointment(uuid, date, time without time zone, text, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text DEFAULT 'patient'::text, p_rescheduled_by_user_id uuid DEFAULT NULL::uuid, p_reason text DEFAULT NULL::text) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_old_appointment appointments%ROWTYPE;
  v_new_appointment_id UUID;
  v_new_end_time TIME;
  v_duration_minutes INTEGER;
BEGIN
  -- Get the original appointment
  SELECT * INTO v_old_appointment 
  FROM appointments 
  WHERE id = p_appointment_id AND status NOT IN ('cancelled', 'completed');
  
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Appointment not found or cannot be rescheduled'
    );
  END IF;
  
  -- Check if the new slot is available
  IF EXISTS (
    SELECT 1 FROM appointments a
    WHERE a.provider_id = v_old_appointment.provider_id
      AND a.appointment_date = p_new_date
      AND a.start_time = p_new_time
      AND a.status NOT IN ('cancelled', 'no_show')
      AND a.id != p_appointment_id
  ) THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Selected time slot is already booked'
    );
  END IF;
  
  -- Calculate new end time (preserve original duration)
  v_duration_minutes := COALESCE(v_old_appointment.duration_minutes, 30);
  v_new_end_time := p_new_time + (v_duration_minutes || ' minutes')::INTERVAL;
  
  -- Start transaction
  BEGIN
    -- Mark the original appointment as rescheduled
    UPDATE appointments 
    SET 
      status = 'rescheduled',
      updated_at = NOW()
    WHERE id = p_appointment_id;
    
    -- Create new appointment
    INSERT INTO appointments (
      patient_id,
      provider_id,
      assignment_id,
      appointment_date,
      start_time,
      end_time,
      duration_minutes,
      treatment_type,
      appointment_type,
      status,
      patient_notes,
      provider_notes,
      admin_notes,
      booked_by,
      booked_by_user_id
    ) VALUES (
      v_old_appointment.patient_id,
      v_old_appointment.provider_id,
      v_old_appointment.assignment_id,
      p_new_date,
      p_new_time,
      v_new_end_time,
      v_duration_minutes,
      v_old_appointment.treatment_type,
      v_old_appointment.appointment_type,
      'scheduled',
      v_old_appointment.patient_notes,
      v_old_appointment.provider_notes,
      'Rescheduled from ' || v_old_appointment.appointment_date || ' ' || v_old_appointment.start_time,
      p_rescheduled_by,
      p_rescheduled_by_user_id
    ) RETURNING id INTO v_new_appointment_id;
    
    -- Return success
    RETURN json_build_object(
      'success', true,
      'old_appointment_id', p_appointment_id,
      'new_appointment_id', v_new_appointment_id,
      'message', 'Appointment successfully rescheduled'
    );
    
  EXCEPTION WHEN OTHERS THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Failed to reschedule appointment: ' || SQLERRM
    );
  END;
END;
$$;


--
-- TOC entry 4827 (class 0 OID 0)
-- Dependencies: 481
-- Name: FUNCTION reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text, p_rescheduled_by_user_id uuid, p_reason text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text, p_rescheduled_by_user_id uuid, p_reason text) IS 'Reschedule an appointment to a new date and time';


--
-- TOC entry 368 (class 1255 OID 19093)
-- Name: reset_expired_approvals(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reset_expired_approvals() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    rows_updated INTEGER;
BEGIN
    -- Reset patient preferences to pending when supply period has elapsed
    -- This way they show up in the provider dashboard as new approval requests
    UPDATE public.patient_medication_preferences
    SET
        status = 'pending',
        updated_at = NOW()
    FROM public.medication_approvals ma
    JOIN public.medication_orders mo ON ma.id = mo.approval_id
    WHERE patient_medication_preferences.id = ma.preference_id
    AND ma.status = 'approved'
    AND ma.supply_days IS NOT NULL
    AND mo.estimated_delivery IS NOT NULL
    AND mo.fulfillment_status = 'delivered'
    AND (mo.estimated_delivery::DATE + INTERVAL '1 day' * ma.supply_days) <= CURRENT_DATE;

    GET DIAGNOSTICS rows_updated = ROW_COUNT;

    -- Log the action for debugging
    INSERT INTO public.auth_trigger_logs (trigger_stage, success, error_message, metadata, created_at)
    VALUES (
        'APPROVAL_RESET',
        true,
        format('Reset %s expired preferences to pending status', rows_updated),
        jsonb_build_object('reset_count', rows_updated, 'reset_date', CURRENT_DATE),
        NOW()
    );

    RETURN rows_updated;
END;
$$;


--
-- TOC entry 4828 (class 0 OID 0)
-- Dependencies: 368
-- Name: FUNCTION reset_expired_approvals(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.reset_expired_approvals() IS 'Reset expired patient preferences to pending status so they appear in provider dashboard';


--
-- TOC entry 429 (class 1255 OID 19104)
-- Name: run_daily_maintenance(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.run_daily_maintenance() RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    reset_count INTEGER;
    expired_count INTEGER;
    result JSONB;
BEGIN
    -- Run the daily approval reset check
    reset_count := public.daily_approval_reset_check();
    
    -- Get count of approvals that are currently expired but not yet reset
    SELECT COUNT(*)::INTEGER INTO expired_count
    FROM public.approval_renewal_status
    WHERE renewal_status = 'EXPIRED' AND status = 'approved';
    
    -- Return summary
    result := jsonb_build_object(
        'approvals_reset', reset_count,
        'approvals_still_expired', expired_count,
        'run_date', CURRENT_DATE,
        'run_time', NOW()
    );
    
    RETURN result;
END;
$$;


--
-- TOC entry 4829 (class 0 OID 0)
-- Dependencies: 429
-- Name: FUNCTION run_daily_maintenance(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.run_daily_maintenance() IS 'Main maintenance function to be called daily from application or cron';


--
-- TOC entry 384 (class 1255 OID 18664)
-- Name: set_appointment_context(text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_appointment_context(p_user_role text, p_user_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  PERFORM set_config('app.current_user_role', p_user_role, true);
  PERFORM set_config('app.current_user_id', p_user_id::TEXT, true);
END;
$$;


--
-- TOC entry 4830 (class 0 OID 0)
-- Dependencies: 384
-- Name: FUNCTION set_appointment_context(p_user_role text, p_user_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.set_appointment_context(p_user_role text, p_user_id uuid) IS 'Sets security context for appointment operations';


--
-- TOC entry 478 (class 1255 OID 19254)
-- Name: set_primary_address(uuid, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_primary_address(patient_profile_id uuid, address_id uuid, address_type_param text) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    patient_record_id UUID;
    address_exists BOOLEAN := false;
BEGIN
    -- Get patient record ID
    SELECT id INTO patient_record_id 
    FROM public.patients 
    WHERE profile_id = patient_profile_id;
    
    IF patient_record_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Patient not found');
    END IF;
    
    -- Check if address exists and belongs to patient
    SELECT EXISTS(
        SELECT 1 FROM public.patient_addresses 
        WHERE id = address_id 
            AND patient_id = patient_record_id
            AND address_type = address_type_param
    ) INTO address_exists;
    
    IF NOT address_exists THEN
        RETURN json_build_object('success', false, 'error', 'Address not found or access denied');
    END IF;
    
    -- Remove primary flag from other addresses of same type
    UPDATE public.patient_addresses 
    SET is_primary = false 
    WHERE patient_id = patient_record_id 
        AND address_type = address_type_param 
        AND id != address_id;
    
    -- Set the specified address as primary
    UPDATE public.patient_addresses 
    SET is_primary = true 
    WHERE id = address_id;
    
    RETURN json_build_object('success', true, 'message', 'Primary address updated');
    
EXCEPTION 
    WHEN OTHERS THEN
        RETURN json_build_object('success', false, 'error', SQLERRM);
END;
$$;


--
-- TOC entry 446 (class 1255 OID 19095)
-- Name: trigger_approval_reset(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trigger_approval_reset() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN public.reset_expired_approvals();
END;
$$;


--
-- TOC entry 4831 (class 0 OID 0)
-- Dependencies: 446
-- Name: FUNCTION trigger_approval_reset(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.trigger_approval_reset() IS 'Manually triggers the approval reset process for testing';


--
-- TOC entry 390 (class 1255 OID 19121)
-- Name: update_approval_date_on_status_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_approval_date_on_status_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- If status changed to 'approved', set approval_date
    IF NEW.status = 'approved' AND (OLD.status IS NULL OR OLD.status != 'approved') THEN
        NEW.approval_date = NOW();
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- TOC entry 4832 (class 0 OID 0)
-- Dependencies: 390
-- Name: FUNCTION update_approval_date_on_status_change(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.update_approval_date_on_status_change() IS 'Automatically sets approval_date when medication status changes to approved';


--
-- TOC entry 410 (class 1255 OID 18794)
-- Name: update_clinical_note_editor(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_clinical_note_editor() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Set last_updated_by to current user if available
  IF current_setting('app.current_user_id', true) != '' THEN
    NEW.last_updated_by = current_setting('app.current_user_id', true)::UUID;
  END IF;
  
  RETURN NEW;
END;
$$;


--
-- TOC entry 499 (class 1255 OID 19110)
-- Name: update_next_due_from_supply_and_fax(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_next_due_from_supply_and_fax() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    preference_record RECORD;
    v_calculated_due_date DATE;
    v_updated_count INTEGER := 0;
BEGIN
    -- Loop through all preferences that have supply_days and faxed date but no next_prescription_due
    FOR preference_record IN 
        SELECT id, supply_days, faxed::date as faxed_date
        FROM patient_medication_preferences 
        WHERE supply_days IS NOT NULL 
          AND supply_days > 0 
          AND faxed IS NOT NULL
          AND (next_prescription_due IS NULL OR next_prescription_due < CURRENT_DATE)
    LOOP
        -- Calculate next due date using faxed date from preferences
        v_calculated_due_date := preference_record.faxed_date + preference_record.supply_days;
        
        UPDATE patient_medication_preferences 
        SET 
            next_prescription_due = v_calculated_due_date,
            updated_at = NOW()
        WHERE id = preference_record.id;
        
        v_updated_count := v_updated_count + 1;
    END LOOP;
    
    RETURN v_updated_count;
END;
$$;


--
-- TOC entry 4833 (class 0 OID 0)
-- Dependencies: 499
-- Name: FUNCTION update_next_due_from_supply_and_fax(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.update_next_due_from_supply_and_fax() IS 'Updates next_prescription_due for preferences with supply_days based on faxed date from preferences table';


--
-- TOC entry 379 (class 1255 OID 19108)
-- Name: update_preference_on_medication_adjustment(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_preference_on_medication_adjustment() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_fax_date DATE;
    v_calculated_due_date DATE;
    v_preference_record RECORD;
BEGIN
    -- Only proceed if this is an approval (new_status = 'approved')
    IF NEW.new_status = 'approved' THEN
        -- Update the preference with the new values from the adjustment
        UPDATE patient_medication_preferences 
        SET 
            preferred_dosage = COALESCE(NEW.new_dosage, preferred_dosage),
            frequency = COALESCE(NEW.new_frequency, frequency),
            status = NEW.new_status,
            supply_days = COALESCE(NEW.new_supply_days, supply_days),
            notes = COALESCE(NEW.new_provider_notes, notes),
            updated_at = NOW()
        WHERE id = NEW.preference_id;
        
        -- If supply_days was provided, calculate and update next_prescription_due
        -- using the faxed field from the preference itself
        IF NEW.new_supply_days IS NOT NULL AND NEW.new_supply_days > 0 THEN
            -- Get the preference record to access the faxed field
            SELECT faxed::date
            INTO v_fax_date
            FROM patient_medication_preferences 
            WHERE id = NEW.preference_id;
            
            -- If we have a fax date, calculate next due date
            IF v_fax_date IS NOT NULL THEN
                v_calculated_due_date := v_fax_date + NEW.new_supply_days;
                
                -- Update the preference with the calculated due date
                UPDATE patient_medication_preferences 
                SET 
                    next_prescription_due = v_calculated_due_date,
                    updated_at = NOW()
                WHERE id = NEW.preference_id;
                
                -- Log the calculation for debugging (if logging table exists)
                BEGIN
                    INSERT INTO auth_trigger_logs (
                        step, 
                        status, 
                        message, 
                        metadata
                    ) VALUES (
                        'SUPPLY_CALCULATION', 
                        'SUCCESS', 
                        'Updated next prescription due based on preference fax date and supply',
                        jsonb_build_object(
                            'preference_id', NEW.preference_id,
                            'fax_date', v_fax_date,
                            'supply_days', NEW.new_supply_days,
                            'calculated_due_date', v_calculated_due_date
                        )
                    );
                EXCEPTION WHEN OTHERS THEN
                    -- Ignore logging errors, don't fail the main operation
                    NULL;
                END;
            ELSE
                -- Log that no fax date was found (if logging table exists)
                BEGIN
                    INSERT INTO auth_trigger_logs (
                        step, 
                        status, 
                        message, 
                        metadata
                    ) VALUES (
                        'SUPPLY_CALCULATION', 
                        'WARNING', 
                        'No fax date found in preference, cannot calculate next due date',
                        jsonb_build_object(
                            'preference_id', NEW.preference_id,
                            'supply_days', NEW.new_supply_days
                        )
                    );
                EXCEPTION WHEN OTHERS THEN
                    -- Ignore logging errors, don't fail the main operation
                    NULL;
                END;
            END IF;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- TOC entry 4834 (class 0 OID 0)
-- Dependencies: 379
-- Name: FUNCTION update_preference_on_medication_adjustment(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.update_preference_on_medication_adjustment() IS 'Updates patient_medication_preferences when medication adjustments are approved, using faxed date from preferences table for next_prescription_due calculation';


--
-- TOC entry 515 (class 1255 OID 19044)
-- Name: update_prescription_due_date(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_prescription_due_date() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    approval_record RECORD;
    preference_id UUID;
    approved_freq TEXT;
BEGIN
    -- Only proceed if delivery date was just set (order delivered)
    IF OLD.estimated_delivery IS NULL AND NEW.estimated_delivery IS NOT NULL THEN
        -- Get the approval and preference info
        SELECT ma.preference_id, ma.approved_frequency
        INTO preference_id, approved_freq
        FROM public.medication_approvals ma
        WHERE ma.id = NEW.approval_id;

        IF preference_id IS NOT NULL THEN
            -- Update the next prescription due date
            UPDATE public.patient_medication_preferences
            SET next_prescription_due = public.calculate_next_prescription_due(
                preference_id,
                NEW.estimated_delivery::DATE,
                approved_freq
            )
            WHERE id = preference_id;
        END IF;
    END IF;

    RETURN NEW;
END;
$$;


--
-- TOC entry 4835 (class 0 OID 0)
-- Dependencies: 515
-- Name: FUNCTION update_prescription_due_date(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.update_prescription_due_date() IS 'Updates prescription due date when medication order delivery date is set (fixed variable naming to avoid ambiguity)';


--
-- TOC entry 423 (class 1255 OID 18373)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only update if the table actually has an updated_at column
    IF TG_TABLE_NAME = 'clinical_notes' THEN
        NEW.updated_at = NOW();
    END IF;
    RETURN NEW;
EXCEPTION
    WHEN OTHERS THEN
        -- Don't fail the operation if there's an issue
        RETURN NEW;
END;
$$;


--
-- TOC entry 380 (class 1255 OID 19256)
-- Name: validate_address_format(text, text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_address_format(street_line_1_param text, city_param text, state_param text, postal_code_param text, country_param text DEFAULT 'US'::text) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    AS $_$
DECLARE
    errors TEXT[] := ARRAY[]::TEXT[];
BEGIN
    -- Validate required fields
    IF street_line_1_param IS NULL OR LENGTH(TRIM(street_line_1_param)) = 0 THEN
        errors := array_append(errors, 'Street address is required');
    END IF;
    
    IF city_param IS NULL OR LENGTH(TRIM(city_param)) = 0 THEN
        errors := array_append(errors, 'City is required');
    END IF;
    
    IF state_param IS NULL OR LENGTH(TRIM(state_param)) = 0 THEN
        errors := array_append(errors, 'State is required');
    END IF;
    
    IF postal_code_param IS NULL OR LENGTH(TRIM(postal_code_param)) = 0 THEN
        errors := array_append(errors, 'Postal code is required');
    END IF;
    
    -- Validate US postal code format
    IF country_param = 'US' AND postal_code_param IS NOT NULL THEN
        IF NOT postal_code_param ~ '^\d{5}(-\d{4})?$' THEN
            errors := array_append(errors, 'Invalid US postal code format (use 12345 or 12345-6789)');
        END IF;
    END IF;
    
    -- Validate US state format (2 letter abbreviation)
    IF country_param = 'US' AND state_param IS NOT NULL THEN
        IF LENGTH(state_param) != 2 OR state_param !~ '^[A-Z]{2}$' THEN
            errors := array_append(errors, 'State must be a 2-letter abbreviation (e.g., CA, NY, TX)');
        END IF;
    END IF;
    
    IF array_length(errors, 1) > 0 THEN
        RETURN json_build_object('valid', false, 'errors', errors);
    ELSE
        RETURN json_build_object('valid', true, 'message', 'Address format is valid');
    END IF;
END;
$_$;


--
-- TOC entry 422 (class 1255 OID 18688)
-- Name: validate_appointment_business_rules(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_appointment_business_rules() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Prevent booking conflicts
  IF EXISTS (
    SELECT 1 FROM appointments a
    WHERE a.provider_id = NEW.provider_id
      AND a.appointment_date = NEW.appointment_date
      AND a.start_time = NEW.start_time
      AND a.id != COALESCE(NEW.id, '00000000-0000-0000-0000-000000000000'::UUID)
      AND a.status NOT IN ('cancelled', 'no_show')
  ) THEN
    RAISE EXCEPTION 'Appointment slot already booked';
  END IF;
  
  -- Validate appointment is within provider's schedule
  IF NOT EXISTS (
    SELECT 1 FROM provider_schedules ps
    WHERE ps.provider_id = NEW.provider_id
      AND ps.day_of_week = EXTRACT(DOW FROM NEW.appointment_date)
      AND ps.start_time <= NEW.start_time
      AND ps.end_time >= NEW.end_time
      AND ps.active = true
  ) THEN
    RAISE EXCEPTION 'Appointment outside provider schedule';
  END IF;
  
  -- Check for availability overrides that block this time
  IF EXISTS (
    SELECT 1 FROM provider_availability_overrides pao
    WHERE pao.provider_id = NEW.provider_id
      AND pao.date = NEW.appointment_date
      AND pao.available = false
      AND (pao.start_time IS NULL OR NEW.start_time >= pao.start_time)
      AND (pao.end_time IS NULL OR NEW.end_time <= pao.end_time)
  ) THEN
    RAISE EXCEPTION 'Provider not available at requested time';
  END IF;
  
  RETURN NEW;
END;
$$;


--
-- TOC entry 508 (class 1255 OID 16925)
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_;

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


--
-- TOC entry 475 (class 1255 OID 17004)
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


--
-- TOC entry 393 (class 1255 OID 16937)
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


--
-- TOC entry 516 (class 1255 OID 16887)
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
    declare
      res jsonb;
    begin
      execute format('select to_jsonb(%L::'|| type_::text || ')', val)  into res;
      return res;
    end
    $$;


--
-- TOC entry 492 (class 1255 OID 16882)
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


--
-- TOC entry 455 (class 1255 OID 16933)
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


--
-- TOC entry 374 (class 1255 OID 16944)
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS SETOF realtime.wal_rls
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
      with pub as (
        select
          concat_ws(
            ',',
            case when bool_or(pubinsert) then 'insert' else null end,
            case when bool_or(pubupdate) then 'update' else null end,
            case when bool_or(pubdelete) then 'delete' else null end
          ) as w2j_actions,
          coalesce(
            string_agg(
              realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
              ','
            ) filter (where ppt.tablename is not null and ppt.tablename not like '% %'),
            ''
          ) w2j_add_tables
        from
          pg_publication pp
          left join pg_publication_tables ppt
            on pp.pubname = ppt.pubname
        where
          pp.pubname = publication
        group by
          pp.pubname
        limit 1
      ),
      w2j as (
        select
          x.*, pub.w2j_add_tables
        from
          pub,
          pg_logical_slot_get_changes(
            slot_name, null, max_changes,
            'include-pk', 'true',
            'include-transaction', 'false',
            'include-timestamp', 'true',
            'include-type-oids', 'true',
            'format-version', '2',
            'actions', pub.w2j_actions,
            'add-tables', pub.w2j_add_tables
          ) x
      )
      select
        xyz.wal,
        xyz.is_rls_enabled,
        xyz.subscription_ids,
        xyz.errors
      from
        w2j,
        realtime.apply_rls(
          wal := w2j.data::jsonb,
          max_record_bytes := max_record_bytes
        ) xyz(wal, is_rls_enabled, subscription_ids, errors)
      where
        w2j.w2j_add_tables <> ''
        and xyz.subscription_ids[1] is not null
    $$;


--
-- TOC entry 406 (class 1255 OID 16881)
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


--
-- TOC entry 510 (class 1255 OID 17003)
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  BEGIN
    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (payload, event, topic, private, extension)
    VALUES (payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      RAISE WARNING 'ErrorSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- TOC entry 507 (class 1255 OID 16879)
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


--
-- TOC entry 477 (class 1255 OID 16914)
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


--
-- TOC entry 352 (class 1255 OID 16997)
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


--
-- TOC entry 369 (class 1255 OID 17865)
-- Name: add_prefixes(text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.add_prefixes(_bucket_id text, _name text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    prefixes text[];
BEGIN
    prefixes := "storage"."get_prefixes"("_name");

    IF array_length(prefixes, 1) > 0 THEN
        INSERT INTO storage.prefixes (name, bucket_id)
        SELECT UNNEST(prefixes) as name, "_bucket_id" ON CONFLICT DO NOTHING;
    END IF;
END;
$$;


--
-- TOC entry 385 (class 1255 OID 17791)
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


--
-- TOC entry 470 (class 1255 OID 17866)
-- Name: delete_prefix(text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.delete_prefix(_bucket_id text, _name text) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    -- Check if we can delete the prefix
    IF EXISTS(
        SELECT FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name") + 1
          AND "prefixes"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    )
    OR EXISTS(
        SELECT FROM "storage"."objects"
        WHERE "objects"."bucket_id" = "_bucket_id"
          AND "storage"."get_level"("objects"."name") = "storage"."get_level"("_name") + 1
          AND "objects"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    ) THEN
    -- There are sub-objects, skip deletion
    RETURN false;
    ELSE
        DELETE FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name")
          AND "prefixes"."name" = "_name";
        RETURN true;
    END IF;
END;
$$;


--
-- TOC entry 459 (class 1255 OID 17869)
-- Name: delete_prefix_hierarchy_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.delete_prefix_hierarchy_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    prefix text;
BEGIN
    prefix := "storage"."get_prefix"(OLD."name");

    IF coalesce(prefix, '') != '' THEN
        PERFORM "storage"."delete_prefix"(OLD."bucket_id", prefix);
    END IF;

    RETURN OLD;
END;
$$;


--
-- TOC entry 416 (class 1255 OID 17884)
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


--
-- TOC entry 388 (class 1255 OID 17765)
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    SELECT _parts[array_length(_parts,1)] INTO _filename;
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


--
-- TOC entry 509 (class 1255 OID 17764)
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


--
-- TOC entry 387 (class 1255 OID 17763)
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


--
-- TOC entry 398 (class 1255 OID 17847)
-- Name: get_level(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_level(name text) RETURNS integer
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
SELECT array_length(string_to_array("name", '/'), 1);
$$;


--
-- TOC entry 397 (class 1255 OID 17863)
-- Name: get_prefix(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_prefix(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
SELECT
    CASE WHEN strpos("name", '/') > 0 THEN
             regexp_replace("name", '[\/]{1}[^\/]+\/?$', '')
         ELSE
             ''
        END;
$_$;


--
-- TOC entry 448 (class 1255 OID 17864)
-- Name: get_prefixes(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_prefixes(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $$
DECLARE
    parts text[];
    prefixes text[];
    prefix text;
BEGIN
    -- Split the name into parts by '/'
    parts := string_to_array("name", '/');
    prefixes := '{}';

    -- Construct the prefixes, stopping one level below the last part
    FOR i IN 1..array_length(parts, 1) - 1 LOOP
            prefix := array_to_string(parts[1:i], '/');
            prefixes := array_append(prefixes, prefix);
    END LOOP;

    RETURN prefixes;
END;
$$;


--
-- TOC entry 402 (class 1255 OID 17882)
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


--
-- TOC entry 456 (class 1255 OID 17830)
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


--
-- TOC entry 460 (class 1255 OID 17793)
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(name COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                        substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1)))
                    ELSE
                        name
                END AS name, id, metadata, updated_at
            FROM
                storage.objects
            WHERE
                bucket_id = $5 AND
                name ILIKE $1 || ''%'' AND
                CASE
                    WHEN $6 != '''' THEN
                    name COLLATE "C" > $6
                ELSE true END
                AND CASE
                    WHEN $4 != '''' THEN
                        CASE
                            WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                                substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                name COLLATE "C" > $4
                            END
                    ELSE
                        true
                END
            ORDER BY
                name COLLATE "C" ASC) as e order by name COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_token, bucket_id, start_after;
END;
$_$;


--
-- TOC entry 500 (class 1255 OID 17868)
-- Name: objects_insert_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.objects_insert_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    NEW.level := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


--
-- TOC entry 382 (class 1255 OID 17883)
-- Name: objects_update_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.objects_update_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    old_prefixes TEXT[];
BEGIN
    -- Ensure this is an update operation and the name has changed
    IF TG_OP = 'UPDATE' AND (NEW."name" <> OLD."name" OR NEW."bucket_id" <> OLD."bucket_id") THEN
        -- Retrieve old prefixes
        old_prefixes := "storage"."get_prefixes"(OLD."name");

        -- Remove old prefixes that are only used by this object
        WITH all_prefixes as (
            SELECT unnest(old_prefixes) as prefix
        ),
        can_delete_prefixes as (
             SELECT prefix
             FROM all_prefixes
             WHERE NOT EXISTS (
                 SELECT 1 FROM "storage"."objects"
                 WHERE "bucket_id" = OLD."bucket_id"
                   AND "name" <> OLD."name"
                   AND "name" LIKE (prefix || '%')
             )
         )
        DELETE FROM "storage"."prefixes" WHERE name IN (SELECT prefix FROM can_delete_prefixes);

        -- Add new prefixes
        PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    END IF;
    -- Set the new level
    NEW."level" := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


--
-- TOC entry 491 (class 1255 OID 17846)
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


--
-- TOC entry 454 (class 1255 OID 17867)
-- Name: prefixes_insert_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.prefixes_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    RETURN NEW;
END;
$$;


--
-- TOC entry 450 (class 1255 OID 17780)
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql
    AS $$
declare
    can_bypass_rls BOOLEAN;
begin
    SELECT rolbypassrls
    INTO can_bypass_rls
    FROM pg_roles
    WHERE rolname = coalesce(nullif(current_setting('role', true), 'none'), current_user);

    IF can_bypass_rls THEN
        RETURN QUERY SELECT * FROM storage.search_v1_optimised(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    ELSE
        RETURN QUERY SELECT * FROM storage.search_legacy_v1(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    END IF;
end;
$$;


--
-- TOC entry 493 (class 1255 OID 17880)
-- Name: search_legacy_v1(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_legacy_v1(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select path_tokens[$1] as folder
           from storage.objects
             where objects.name ilike $2 || $3 || ''%''
               and bucket_id = $4
               and array_length(objects.path_tokens, 1) <> $1
           group by folder
           order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(objects.path_tokens, 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


--
-- TOC entry 412 (class 1255 OID 17879)
-- Name: search_v1_optimised(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v1_optimised(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select (string_to_array(name, ''/''))[level] as name
           from storage.prefixes
             where lower(prefixes.name) like lower($2 || $3) || ''%''
               and bucket_id = $4
               and level = $1
           order by name ' || v_sort_order || '
     )
     (select name,
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[level] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where lower(objects.name) like lower($2 || $3) || ''%''
       and bucket_id = $4
       and level = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


--
-- TOC entry 487 (class 1255 OID 17874)
-- Name: search_v2(text, text, integer, integer, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
BEGIN
    RETURN query EXECUTE
        $sql$
        SELECT * FROM (
            (
                SELECT
                    split_part(name, '/', $4) AS key,
                    name || '/' AS name,
                    NULL::uuid AS id,
                    NULL::timestamptz AS updated_at,
                    NULL::timestamptz AS created_at,
                    NULL::jsonb AS metadata
                FROM storage.prefixes
                WHERE name COLLATE "C" LIKE $1 || '%'
                AND bucket_id = $2
                AND level = $4
                AND name COLLATE "C" > $5
                ORDER BY prefixes.name COLLATE "C" LIMIT $3
            )
            UNION ALL
            (SELECT split_part(name, '/', $4) AS key,
                name,
                id,
                updated_at,
                created_at,
                metadata
            FROM storage.objects
            WHERE name COLLATE "C" LIKE $1 || '%'
                AND bucket_id = $2
                AND level = $4
                AND name COLLATE "C" > $5
            ORDER BY name COLLATE "C" LIMIT $3)
        ) obj
        ORDER BY name COLLATE "C" LIMIT $3;
        $sql$
        USING prefix, bucket_name, limits, levels, start_after;
END;
$_$;


--
-- TOC entry 488 (class 1255 OID 17781)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


--
-- TOC entry 466 (class 1255 OID 16774)
-- Name: http_request(); Type: FUNCTION; Schema: supabase_functions; Owner: -
--

CREATE FUNCTION supabase_functions.http_request() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'supabase_functions'
    AS $$
  DECLARE
    request_id bigint;
    payload jsonb;
    url text := TG_ARGV[0]::text;
    method text := TG_ARGV[1]::text;
    headers jsonb DEFAULT '{}'::jsonb;
    params jsonb DEFAULT '{}'::jsonb;
    timeout_ms integer DEFAULT 1000;
  BEGIN
    IF url IS NULL OR url = 'null' THEN
      RAISE EXCEPTION 'url argument is missing';
    END IF;

    IF method IS NULL OR method = 'null' THEN
      RAISE EXCEPTION 'method argument is missing';
    END IF;

    IF TG_ARGV[2] IS NULL OR TG_ARGV[2] = 'null' THEN
      headers = '{"Content-Type": "application/json"}'::jsonb;
    ELSE
      headers = TG_ARGV[2]::jsonb;
    END IF;

    IF TG_ARGV[3] IS NULL OR TG_ARGV[3] = 'null' THEN
      params = '{}'::jsonb;
    ELSE
      params = TG_ARGV[3]::jsonb;
    END IF;

    IF TG_ARGV[4] IS NULL OR TG_ARGV[4] = 'null' THEN
      timeout_ms = 1000;
    ELSE
      timeout_ms = TG_ARGV[4]::integer;
    END IF;

    CASE
      WHEN method = 'GET' THEN
        SELECT http_get INTO request_id FROM net.http_get(
          url,
          params,
          headers,
          timeout_ms
        );
      WHEN method = 'POST' THEN
        payload = jsonb_build_object(
          'old_record', OLD,
          'record', NEW,
          'type', TG_OP,
          'table', TG_TABLE_NAME,
          'schema', TG_TABLE_SCHEMA
        );

        SELECT http_post INTO request_id FROM net.http_post(
          url,
          payload,
          params,
          headers,
          timeout_ms
        );
      ELSE
        RAISE EXCEPTION 'method argument % is invalid', method;
    END CASE;

    INSERT INTO supabase_functions.hooks
      (hook_table_id, hook_name, request_id)
    VALUES
      (TG_RELID, TG_NAME, request_id);

    RETURN NEW;
  END
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 265 (class 1259 OID 16488)
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


--
-- TOC entry 4836 (class 0 OID 0)
-- Dependencies: 265
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- TOC entry 313 (class 1259 OID 18161)
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text NOT NULL,
    code_challenge_method auth.code_challenge_method NOT NULL,
    code_challenge text NOT NULL,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone
);


--
-- TOC entry 4837 (class 0 OID 0)
-- Dependencies: 313
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.flow_state IS 'stores metadata for pkce logins';


--
-- TOC entry 304 (class 1259 OID 17959)
-- Name: identities; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 4838 (class 0 OID 0)
-- Dependencies: 304
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- TOC entry 4839 (class 0 OID 0)
-- Dependencies: 304
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- TOC entry 264 (class 1259 OID 16481)
-- Name: instances; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- TOC entry 4840 (class 0 OID 0)
-- Dependencies: 264
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- TOC entry 308 (class 1259 OID 18048)
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


--
-- TOC entry 4841 (class 0 OID 0)
-- Dependencies: 308
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- TOC entry 307 (class 1259 OID 18036)
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


--
-- TOC entry 4842 (class 0 OID 0)
-- Dependencies: 307
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- TOC entry 306 (class 1259 OID 18023)
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid
);


--
-- TOC entry 4843 (class 0 OID 0)
-- Dependencies: 306
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- TOC entry 315 (class 1259 OID 18243)
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_id text NOT NULL,
    client_secret_hash text NOT NULL,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048))
);


--
-- TOC entry 314 (class 1259 OID 18211)
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


--
-- TOC entry 263 (class 1259 OID 16470)
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


--
-- TOC entry 4844 (class 0 OID 0)
-- Dependencies: 263
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- TOC entry 262 (class 1259 OID 16469)
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: -
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4845 (class 0 OID 0)
-- Dependencies: 262
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: -
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- TOC entry 311 (class 1259 OID 18090)
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


--
-- TOC entry 4846 (class 0 OID 0)
-- Dependencies: 311
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- TOC entry 312 (class 1259 OID 18108)
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


--
-- TOC entry 4847 (class 0 OID 0)
-- Dependencies: 312
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- TOC entry 266 (class 1259 OID 16496)
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


--
-- TOC entry 4848 (class 0 OID 0)
-- Dependencies: 266
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- TOC entry 305 (class 1259 OID 17989)
-- Name: sessions; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text
);


--
-- TOC entry 4849 (class 0 OID 0)
-- Dependencies: 305
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- TOC entry 4850 (class 0 OID 0)
-- Dependencies: 305
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- TOC entry 310 (class 1259 OID 18075)
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


--
-- TOC entry 4851 (class 0 OID 0)
-- Dependencies: 310
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- TOC entry 309 (class 1259 OID 18066)
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


--
-- TOC entry 4852 (class 0 OID 0)
-- Dependencies: 309
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- TOC entry 4853 (class 0 OID 0)
-- Dependencies: 309
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- TOC entry 261 (class 1259 OID 16458)
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


--
-- TOC entry 4854 (class 0 OID 0)
-- Dependencies: 261
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- TOC entry 4855 (class 0 OID 0)
-- Dependencies: 261
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- TOC entry 320 (class 1259 OID 18320)
-- Name: admins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admins (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    permissions text[] DEFAULT ARRAY['dashboard'::text],
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 331 (class 1259 OID 18625)
-- Name: appointment_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointment_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    appointment_id uuid NOT NULL,
    action text NOT NULL,
    performed_by text NOT NULL,
    performed_by_user_id uuid,
    old_values jsonb,
    new_values jsonb,
    reason text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT appointment_history_action_check CHECK ((action = ANY (ARRAY['created'::text, 'updated'::text, 'cancelled'::text, 'completed'::text, 'no_show'::text, 'reschedule'::text, 'rescheduled'::text]))),
    CONSTRAINT appointment_history_performed_by_check CHECK ((performed_by = ANY (ARRAY['patient'::text, 'provider'::text, 'admin'::text, 'system'::text])))
);


--
-- TOC entry 4856 (class 0 OID 0)
-- Dependencies: 331
-- Name: TABLE appointment_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.appointment_history IS 'Complete audit trail of all appointment changes';


--
-- TOC entry 330 (class 1259 OID 18587)
-- Name: appointments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    assignment_id uuid,
    appointment_date date NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    duration_minutes integer NOT NULL,
    treatment_type text NOT NULL,
    appointment_type text DEFAULT 'consultation'::text NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    patient_notes text,
    provider_notes text,
    admin_notes text,
    booked_by text NOT NULL,
    booked_by_user_id uuid,
    booking_timestamp timestamp with time zone DEFAULT now(),
    cancelled_at timestamp with time zone,
    cancelled_by text,
    cancelled_by_user_id uuid,
    cancellation_reason text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    rescheduled_from_id uuid,
    rescheduled_to_id uuid,
    is_reschedule_source boolean DEFAULT false,
    reschedule_count integer DEFAULT 0,
    CONSTRAINT appointment_in_future CHECK (((appointment_date > CURRENT_DATE) OR ((appointment_date = CURRENT_DATE) AND (start_time >= LOCALTIME)))),
    CONSTRAINT appointments_appointment_type_check CHECK ((appointment_type = ANY (ARRAY['consultation'::text, 'follow_up'::text, 'treatment'::text, 'evaluation'::text, 'review'::text]))),
    CONSTRAINT appointments_booked_by_check CHECK ((booked_by = ANY (ARRAY['patient'::text, 'provider'::text, 'admin'::text]))),
    CONSTRAINT appointments_cancelled_by_check CHECK ((cancelled_by = ANY (ARRAY['patient'::text, 'provider'::text, 'admin'::text]))),
    CONSTRAINT appointments_duration_minutes_check CHECK ((duration_minutes > 0)),
    CONSTRAINT appointments_status_check CHECK ((status = ANY (ARRAY['scheduled'::text, 'confirmed'::text, 'completed'::text, 'cancelled'::text, 'no_show'::text, 'rescheduled'::text]))),
    CONSTRAINT valid_appointment_time CHECK ((end_time > start_time)),
    CONSTRAINT valid_cancellation CHECK (((status <> 'cancelled'::text) OR ((status = 'cancelled'::text) AND (cancelled_at IS NOT NULL) AND (cancelled_by IS NOT NULL))))
);


--
-- TOC entry 4857 (class 0 OID 0)
-- Dependencies: 330
-- Name: TABLE appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.appointments IS 'Core appointments between patients and providers';


--
-- TOC entry 4858 (class 0 OID 0)
-- Dependencies: 330
-- Name: COLUMN appointments.assignment_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.assignment_id IS 'Links appointment to specific patient-provider treatment assignment';


--
-- TOC entry 4859 (class 0 OID 0)
-- Dependencies: 330
-- Name: COLUMN appointments.booked_by_user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.booked_by_user_id IS 'Profile ID of the person who booked the appointment';


--
-- TOC entry 4860 (class 0 OID 0)
-- Dependencies: 330
-- Name: COLUMN appointments.rescheduled_from_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.rescheduled_from_id IS 'Points to original appointment if this is a rescheduled appointment';


--
-- TOC entry 4861 (class 0 OID 0)
-- Dependencies: 330
-- Name: COLUMN appointments.rescheduled_to_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.rescheduled_to_id IS 'Points to new appointment if this was rescheduled';


--
-- TOC entry 4862 (class 0 OID 0)
-- Dependencies: 330
-- Name: COLUMN appointments.is_reschedule_source; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.is_reschedule_source IS 'True if this appointment was rescheduled (original slot now available)';


--
-- TOC entry 4863 (class 0 OID 0)
-- Dependencies: 330
-- Name: COLUMN appointments.reschedule_count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.reschedule_count IS 'Number of times this appointment chain has been rescheduled';


--
-- TOC entry 326 (class 1259 OID 18455)
-- Name: medication_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medication_approvals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    preference_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    status text DEFAULT 'needs_review'::text NOT NULL,
    approved_dosage text,
    approved_frequency text,
    provider_notes text,
    contraindications text,
    approval_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    provider_profile_id uuid NOT NULL,
    supply_days integer,
    CONSTRAINT check_approval_status CHECK ((status = ANY (ARRAY['approved'::text, 'denied'::text, 'needs_review'::text])))
);


--
-- TOC entry 4864 (class 0 OID 0)
-- Dependencies: 326
-- Name: COLUMN medication_approvals.provider_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_approvals.provider_profile_id IS 'Direct reference to provider auth user ID';


--
-- TOC entry 4865 (class 0 OID 0)
-- Dependencies: 326
-- Name: COLUMN medication_approvals.supply_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_approvals.supply_days IS 'Number of days the prescription supply should last (e.g., 30, 60, 90 days)';


--
-- TOC entry 327 (class 1259 OID 18476)
-- Name: medication_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medication_orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    approval_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    medication_id uuid NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    payment_status text DEFAULT 'pending'::text NOT NULL,
    payment_method text,
    payment_date timestamp with time zone,
    fulfillment_status text DEFAULT 'pending'::text NOT NULL,
    tracking_number text,
    shipped_date timestamp with time zone,
    estimated_delivery timestamp with time zone,
    admin_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    sent_to_pharmacy timestamp with time zone,
    provider_profile_id uuid NOT NULL,
    patient_profile_id uuid NOT NULL,
    CONSTRAINT check_fulfillment_status CHECK ((fulfillment_status = ANY (ARRAY['pending'::text, 'processing'::text, 'pharmacy_fulfilled'::text, 'shipped'::text, 'delivered'::text]))),
    CONSTRAINT check_payment_status CHECK ((payment_status = ANY (ARRAY['pending'::text, 'paid'::text, 'failed'::text, 'refunded'::text]))),
    CONSTRAINT check_positive_amounts CHECK (((unit_price >= (0)::numeric) AND (total_amount >= (0)::numeric) AND (quantity > 0)))
);


--
-- TOC entry 4866 (class 0 OID 0)
-- Dependencies: 327
-- Name: COLUMN medication_orders.shipped_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_orders.shipped_date IS 'Date when medication was physically shipped to patient';


--
-- TOC entry 4867 (class 0 OID 0)
-- Dependencies: 327
-- Name: COLUMN medication_orders.sent_to_pharmacy; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_orders.sent_to_pharmacy IS 'Date when prescription was sent to pharmacy for processing';


--
-- TOC entry 4868 (class 0 OID 0)
-- Dependencies: 327
-- Name: COLUMN medication_orders.provider_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_orders.provider_profile_id IS 'Direct reference to provider auth user ID';


--
-- TOC entry 4869 (class 0 OID 0)
-- Dependencies: 327
-- Name: COLUMN medication_orders.patient_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_orders.patient_profile_id IS 'Direct reference to patient auth user ID';


--
-- TOC entry 4870 (class 0 OID 0)
-- Dependencies: 327
-- Name: CONSTRAINT check_fulfillment_status ON medication_orders; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT check_fulfillment_status ON public.medication_orders IS 'Ensures fulfillment_status is one of: pending, processing, pharmacy_fulfilled, shipped, delivered';


--
-- TOC entry 324 (class 1259 OID 18418)
-- Name: medications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    generic_name text,
    brand_name text,
    dosage_form text NOT NULL,
    strength text NOT NULL,
    description text,
    category text NOT NULL,
    unit_price numeric(10,2) DEFAULT 0 NOT NULL,
    requires_prescription boolean DEFAULT true,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 325 (class 1259 OID 18431)
-- Name: patient_medication_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patient_medication_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    medication_id uuid NOT NULL,
    preferred_dosage text,
    frequency text,
    notes text,
    status text DEFAULT 'pending'::text NOT NULL,
    requested_date timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    medication_dosage_id uuid,
    faxed timestamp with time zone,
    next_prescription_due date,
    supply_days integer,
    refill_requested boolean DEFAULT false,
    refill_requested_date timestamp with time zone,
    approval_date timestamp with time zone,
    CONSTRAINT check_preference_status CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'denied'::text, 'discontinued'::text])))
);


--
-- TOC entry 4871 (class 0 OID 0)
-- Dependencies: 325
-- Name: COLUMN patient_medication_preferences.medication_dosage_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.medication_dosage_id IS 'References the specific dosage selected by the patient. New preferred method over preferred_dosage text field.';


--
-- TOC entry 4872 (class 0 OID 0)
-- Dependencies: 325
-- Name: COLUMN patient_medication_preferences.faxed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.faxed IS 'Timestamp when prescription was last faxed to pharmacy';


--
-- TOC entry 4873 (class 0 OID 0)
-- Dependencies: 325
-- Name: COLUMN patient_medication_preferences.next_prescription_due; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.next_prescription_due IS 'Calculated date when next prescription should be due based on frequency and delivery';


--
-- TOC entry 4874 (class 0 OID 0)
-- Dependencies: 325
-- Name: COLUMN patient_medication_preferences.supply_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.supply_days IS 'Number of days of medication supply when approved via medication adjustments';


--
-- TOC entry 4875 (class 0 OID 0)
-- Dependencies: 325
-- Name: COLUMN patient_medication_preferences.refill_requested; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.refill_requested IS 'TRUE when patient has explicitly requested a refill, FALSE when preference was set to pending by admin/system';


--
-- TOC entry 4876 (class 0 OID 0)
-- Dependencies: 325
-- Name: COLUMN patient_medication_preferences.refill_requested_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.refill_requested_date IS 'Timestamp when patient last requested a refill for this medication';


--
-- TOC entry 4877 (class 0 OID 0)
-- Dependencies: 325
-- Name: COLUMN patient_medication_preferences.approval_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.approval_date IS 'Timestamp when provider last approved this medication/refill';


--
-- TOC entry 318 (class 1259 OID 18284)
-- Name: patients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    date_of_birth date,
    phone text,
    has_completed_intake boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    allergies text
);


--
-- TOC entry 4878 (class 0 OID 0)
-- Dependencies: 318
-- Name: COLUMN patients.allergies; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patients.allergies IS 'Patient allergy information stored as text';


--
-- TOC entry 317 (class 1259 OID 18267)
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL,
    email text NOT NULL,
    first_name text,
    last_name text,
    role text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT profiles_role_check CHECK ((role = ANY (ARRAY['patient'::text, 'admin'::text, 'provider'::text])))
);


--
-- TOC entry 342 (class 1259 OID 19096)
-- Name: approval_renewal_status; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.approval_renewal_status AS
 SELECT ma.id AS approval_id,
    ma.status,
    ma.supply_days,
    ((p.first_name || ' '::text) || p.last_name) AS patient_name,
    m.name AS medication_name,
    (mo.estimated_delivery)::date AS estimated_delivery,
    mo.fulfillment_status,
        CASE
            WHEN (ma.supply_days IS NULL) THEN NULL::date
            WHEN (mo.estimated_delivery IS NULL) THEN NULL::date
            ELSE (((mo.estimated_delivery)::date + ('1 day'::interval * (ma.supply_days)::double precision)))::date
        END AS expires_on,
        CASE
            WHEN ((ma.supply_days IS NULL) OR (mo.estimated_delivery IS NULL)) THEN 'N/A'::text
            WHEN (((mo.estimated_delivery)::date + ('1 day'::interval * (ma.supply_days)::double precision)) <= CURRENT_DATE) THEN 'EXPIRED'::text
            WHEN (((mo.estimated_delivery)::date + ('1 day'::interval * (ma.supply_days)::double precision)) <= (CURRENT_DATE + '7 days'::interval)) THEN 'EXPIRING_SOON'::text
            ELSE 'ACTIVE'::text
        END AS renewal_status
   FROM (((((public.medication_approvals ma
     JOIN public.medication_orders mo ON ((ma.id = mo.approval_id)))
     JOIN public.patient_medication_preferences pmp ON ((ma.preference_id = pmp.id)))
     JOIN public.medications m ON ((pmp.medication_id = m.id)))
     JOIN public.patients pt ON ((pmp.patient_id = pt.id)))
     JOIN public.profiles p ON ((pt.profile_id = p.id)))
  WHERE (ma.status = ANY (ARRAY['approved'::text, 'pending'::text]));


--
-- TOC entry 4879 (class 0 OID 0)
-- Dependencies: 342
-- Name: VIEW approval_renewal_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.approval_renewal_status IS 'View showing renewal status of all medication approvals';


--
-- TOC entry 323 (class 1259 OID 18409)
-- Name: assignment_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assignment_log (
    id integer NOT NULL,
    message text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- TOC entry 322 (class 1259 OID 18408)
-- Name: assignment_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assignment_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4880 (class 0 OID 0)
-- Dependencies: 322
-- Name: assignment_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assignment_log_id_seq OWNED BY public.assignment_log.id;


--
-- TOC entry 340 (class 1259 OID 18944)
-- Name: auth_trigger_debug_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_trigger_debug_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    step text,
    status text,
    error_message text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 337 (class 1259 OID 18839)
-- Name: auth_trigger_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_trigger_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    trigger_stage text NOT NULL,
    success boolean NOT NULL,
    error_message text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 334 (class 1259 OID 18702)
-- Name: clinical_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clinical_notes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    appointment_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    allergies text[] DEFAULT '{}'::text[],
    previous_medications text[] DEFAULT '{}'::text[],
    current_medications text[] DEFAULT '{}'::text[],
    clinical_note text DEFAULT ''::text,
    internal_note text DEFAULT ''::text,
    visit_summary text DEFAULT ''::text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    created_by uuid,
    last_updated_by uuid
);


--
-- TOC entry 4881 (class 0 OID 0)
-- Dependencies: 334
-- Name: TABLE clinical_notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.clinical_notes IS 'Clinical notes and medical information recorded during patient visits';


--
-- TOC entry 4882 (class 0 OID 0)
-- Dependencies: 334
-- Name: COLUMN clinical_notes.appointment_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.appointment_id IS 'Links clinical note to specific appointment';


--
-- TOC entry 4883 (class 0 OID 0)
-- Dependencies: 334
-- Name: COLUMN clinical_notes.allergies; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.allergies IS 'Array of patient allergies recorded during visit';


--
-- TOC entry 4884 (class 0 OID 0)
-- Dependencies: 334
-- Name: COLUMN clinical_notes.previous_medications; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.previous_medications IS 'Array of previous medications mentioned during visit';


--
-- TOC entry 4885 (class 0 OID 0)
-- Dependencies: 334
-- Name: COLUMN clinical_notes.current_medications; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.current_medications IS 'Array of current medications mentioned during visit';


--
-- TOC entry 4886 (class 0 OID 0)
-- Dependencies: 334
-- Name: COLUMN clinical_notes.clinical_note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.clinical_note IS 'Main clinical observations and notes';


--
-- TOC entry 4887 (class 0 OID 0)
-- Dependencies: 334
-- Name: COLUMN clinical_notes.internal_note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.internal_note IS 'Internal provider notes, not visible to patients';


--
-- TOC entry 4888 (class 0 OID 0)
-- Dependencies: 334
-- Name: COLUMN clinical_notes.visit_summary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.visit_summary IS 'Auto-generated or custom summary of the visit';


--
-- TOC entry 341 (class 1259 OID 19001)
-- Name: faxes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.faxes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    approval_id uuid NOT NULL,
    preference_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    fax_number text NOT NULL,
    fax_content text,
    fax_status text DEFAULT 'sent'::text NOT NULL,
    faxed_at timestamp with time zone DEFAULT now() NOT NULL,
    delivery_confirmation_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    provider_profile_id uuid NOT NULL,
    patient_profile_id uuid NOT NULL,
    CONSTRAINT faxes_fax_status_check CHECK ((fax_status = ANY (ARRAY['sent'::text, 'delivered'::text, 'failed'::text, 'pending'::text])))
);


--
-- TOC entry 4889 (class 0 OID 0)
-- Dependencies: 341
-- Name: TABLE faxes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.faxes IS 'Tracks all fax communications for medication prescriptions';


--
-- TOC entry 4890 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.approval_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.approval_id IS 'Reference to the medication approval that was faxed';


--
-- TOC entry 4891 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.preference_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.preference_id IS 'Reference to the patient medication preference';


--
-- TOC entry 4892 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.fax_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.fax_number IS 'Phone number or fax identifier where prescription was sent';


--
-- TOC entry 4893 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.fax_content; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.fax_content IS 'Content or description of what was faxed';


--
-- TOC entry 4894 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.fax_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.fax_status IS 'Status of the fax transmission';


--
-- TOC entry 4895 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.faxed_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.faxed_at IS 'When the fax was sent';


--
-- TOC entry 4896 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.delivery_confirmation_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.delivery_confirmation_at IS 'When delivery was confirmed';


--
-- TOC entry 4897 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.provider_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.provider_profile_id IS 'Direct reference to provider auth user ID';


--
-- TOC entry 4898 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.patient_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.patient_profile_id IS 'Direct reference to patient auth user ID';


--
-- TOC entry 338 (class 1259 OID 18867)
-- Name: medication_dosages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medication_dosages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    medication_id uuid NOT NULL,
    strength text NOT NULL,
    unit_price numeric(10,2) DEFAULT 0 NOT NULL,
    available boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 4899 (class 0 OID 0)
-- Dependencies: 338
-- Name: TABLE medication_dosages; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.medication_dosages IS 'Stores multiple dosage options for each medication. Replaces the single strength field in medications table.';


--
-- TOC entry 344 (class 1259 OID 19258)
-- Name: medication_tracking_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medication_tracking_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    medication_preference_id uuid NOT NULL,
    taken_date date NOT NULL,
    taken_time time without time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 343 (class 1259 OID 19221)
-- Name: patient_addresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patient_addresses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    address_type text NOT NULL,
    street_line_1 text NOT NULL,
    street_line_2 text,
    city text NOT NULL,
    state text NOT NULL,
    postal_code text NOT NULL,
    country text DEFAULT 'US'::text NOT NULL,
    is_primary boolean DEFAULT false,
    is_verified boolean DEFAULT false,
    verified_at timestamp with time zone,
    verification_method text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT patient_addresses_address_type_check CHECK ((address_type = ANY (ARRAY['shipping'::text, 'billing'::text, 'emergency'::text]))),
    CONSTRAINT patient_addresses_verification_method_check CHECK ((verification_method = ANY (ARRAY['usps'::text, 'ups'::text, 'fedex'::text, 'manual'::text, 'user_confirmed'::text])))
);


--
-- TOC entry 321 (class 1259 OID 18339)
-- Name: patient_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patient_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    treatment_type text DEFAULT 'general_care'::text,
    is_primary boolean DEFAULT false,
    assigned_date timestamp with time zone DEFAULT now(),
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 345 (class 1259 OID 19266)
-- Name: patient_health_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patient_health_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    metric_type text NOT NULL,
    value numeric NOT NULL,
    unit text NOT NULL,
    recorded_at timestamp with time zone DEFAULT now() NOT NULL,
    synced_from text DEFAULT 'manual'::text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT patient_health_metrics_metric_type_check CHECK ((metric_type = ANY (ARRAY['weight'::text, 'heart_rate'::text, 'blood_pressure'::text, 'steps'::text, 'sleep'::text, 'blood_glucose'::text, 'exercise_minutes'::text, 'calories'::text, 'protein'::text, 'sugar'::text, 'water'::text]))),
    CONSTRAINT patient_health_metrics_synced_from_check CHECK ((synced_from = ANY (ARRAY['healthkit'::text, 'manual'::text, 'device'::text, 'provider'::text]))),
    CONSTRAINT patient_health_metrics_value_check CHECK ((value >= (0)::numeric))
);


--
-- TOC entry 329 (class 1259 OID 18570)
-- Name: provider_availability_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provider_availability_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid NOT NULL,
    date date NOT NULL,
    start_time time without time zone,
    end_time time without time zone,
    available boolean NOT NULL,
    reason text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_override_time CHECK (((available = false) OR ((available = true) AND (start_time IS NOT NULL) AND (end_time IS NOT NULL) AND (end_time > start_time))))
);


--
-- TOC entry 4900 (class 0 OID 0)
-- Dependencies: 329
-- Name: TABLE provider_availability_overrides; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.provider_availability_overrides IS 'Date-specific availability changes (vacations, special hours, etc.)';


--
-- TOC entry 4901 (class 0 OID 0)
-- Dependencies: 329
-- Name: COLUMN provider_availability_overrides.available; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provider_availability_overrides.available IS 'false=unavailable, true=special availability override';


--
-- TOC entry 328 (class 1259 OID 18547)
-- Name: provider_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provider_schedules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid NOT NULL,
    day_of_week integer NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    slot_duration_minutes integer DEFAULT 30 NOT NULL,
    treatment_types text[] DEFAULT '{}'::text[],
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT provider_schedules_day_of_week_check CHECK (((day_of_week >= 0) AND (day_of_week <= 6))),
    CONSTRAINT provider_schedules_slot_duration_minutes_check CHECK ((slot_duration_minutes > 0)),
    CONSTRAINT valid_time_range CHECK ((end_time > start_time))
);


--
-- TOC entry 4902 (class 0 OID 0)
-- Dependencies: 328
-- Name: TABLE provider_schedules; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.provider_schedules IS 'Recurring weekly availability schedules for providers';


--
-- TOC entry 4903 (class 0 OID 0)
-- Dependencies: 328
-- Name: COLUMN provider_schedules.day_of_week; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provider_schedules.day_of_week IS '0=Sunday, 1=Monday, ..., 6=Saturday';


--
-- TOC entry 4904 (class 0 OID 0)
-- Dependencies: 328
-- Name: COLUMN provider_schedules.treatment_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provider_schedules.treatment_types IS 'Empty array means available for all treatment types';


--
-- TOC entry 319 (class 1259 OID 18302)
-- Name: providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    specialty text,
    license_number text,
    phone text,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 332 (class 1259 OID 18691)
-- Name: provider_availability_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.provider_availability_summary AS
 SELECT p.id AS provider_id,
    ((prof.first_name || ' '::text) || prof.last_name) AS provider_name,
    ps.day_of_week,
        CASE ps.day_of_week
            WHEN 0 THEN 'Sunday'::text
            WHEN 1 THEN 'Monday'::text
            WHEN 2 THEN 'Tuesday'::text
            WHEN 3 THEN 'Wednesday'::text
            WHEN 4 THEN 'Thursday'::text
            WHEN 5 THEN 'Friday'::text
            WHEN 6 THEN 'Saturday'::text
            ELSE NULL::text
        END AS day_name,
    ps.start_time,
    ps.end_time,
    ps.slot_duration_minutes,
    ps.treatment_types,
    ps.active
   FROM ((public.providers p
     JOIN public.profiles prof ON ((p.profile_id = prof.id)))
     JOIN public.provider_schedules ps ON ((p.id = ps.provider_id)))
  ORDER BY p.id, ps.day_of_week, ps.start_time;


--
-- TOC entry 4905 (class 0 OID 0)
-- Dependencies: 332
-- Name: VIEW provider_availability_summary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.provider_availability_summary IS 'Easy view of all provider schedules with readable day names';


--
-- TOC entry 333 (class 1259 OID 18696)
-- Name: upcoming_appointments_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.upcoming_appointments_summary AS
 SELECT a.id AS appointment_id,
    ((patient_prof.first_name || ' '::text) || patient_prof.last_name) AS patient_name,
    ((provider_prof.first_name || ' '::text) || provider_prof.last_name) AS provider_name,
    a.appointment_date,
    a.start_time,
    a.end_time,
    a.treatment_type,
    a.appointment_type,
    a.status,
    a.created_at
   FROM ((((public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
     JOIN public.profiles patient_prof ON ((p.profile_id = patient_prof.id)))
     JOIN public.providers prov ON ((a.provider_id = prov.id)))
     JOIN public.profiles provider_prof ON ((prov.profile_id = provider_prof.id)))
  WHERE (a.appointment_date >= CURRENT_DATE)
  ORDER BY a.appointment_date, a.start_time;


--
-- TOC entry 4906 (class 0 OID 0)
-- Dependencies: 333
-- Name: VIEW upcoming_appointments_summary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.upcoming_appointments_summary IS 'Overview of all upcoming appointments with patient and provider names';


--
-- TOC entry 339 (class 1259 OID 18897)
-- Name: visit_addendums; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visit_addendums (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    visit_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT visit_addendums_content_not_empty CHECK ((length(TRIM(BOTH FROM content)) > 0))
);


--
-- TOC entry 4907 (class 0 OID 0)
-- Dependencies: 339
-- Name: TABLE visit_addendums; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.visit_addendums IS 'Addendums to previous visits for additional notes or corrections';


--
-- TOC entry 4908 (class 0 OID 0)
-- Dependencies: 339
-- Name: COLUMN visit_addendums.visit_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_addendums.visit_id IS 'Links addendum to specific appointment/visit';


--
-- TOC entry 4909 (class 0 OID 0)
-- Dependencies: 339
-- Name: COLUMN visit_addendums.provider_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_addendums.provider_id IS 'Provider who created the addendum';


--
-- TOC entry 4910 (class 0 OID 0)
-- Dependencies: 339
-- Name: COLUMN visit_addendums.content; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_addendums.content IS 'Content of the addendum';


--
-- TOC entry 4911 (class 0 OID 0)
-- Dependencies: 339
-- Name: COLUMN visit_addendums.created_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_addendums.created_at IS 'When the addendum was created';


--
-- TOC entry 336 (class 1259 OID 18760)
-- Name: visit_interactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visit_interactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinical_note_id uuid NOT NULL,
    appointment_id uuid NOT NULL,
    interaction_type text NOT NULL,
    details text,
    provider_notes text,
    created_at timestamp with time zone DEFAULT now(),
    performed_by uuid NOT NULL,
    medication_id uuid,
    medication_name text,
    previous_dosage text,
    new_dosage text,
    previous_frequency text,
    new_frequency text,
    previous_status text,
    new_status text,
    CONSTRAINT visit_interactions_interaction_type_check CHECK ((interaction_type = ANY (ARRAY['treatment_plan_update'::text, 'follow_up_scheduled'::text, 'referral_made'::text, 'lab_ordered'::text, 'allergy_noted'::text, 'vital_signs_recorded'::text]))),
    CONSTRAINT visit_interactions_new_status_check CHECK (((new_status IS NULL) OR (new_status = ANY (ARRAY['pending'::text, 'approved'::text, 'denied'::text, 'discontinued'::text]))))
);


--
-- TOC entry 4912 (class 0 OID 0)
-- Dependencies: 336
-- Name: TABLE visit_interactions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.visit_interactions IS 'General interactions and activities during visits (non-medication)';


--
-- TOC entry 4913 (class 0 OID 0)
-- Dependencies: 336
-- Name: COLUMN visit_interactions.interaction_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_interactions.interaction_type IS 'Type of interaction: treatment_plan_update, follow_up_scheduled, etc.';


--
-- TOC entry 4914 (class 0 OID 0)
-- Dependencies: 336
-- Name: COLUMN visit_interactions.details; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_interactions.details IS 'General details about the interaction';


--
-- TOC entry 335 (class 1259 OID 18735)
-- Name: visit_medication_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visit_medication_adjustments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinical_note_id uuid NOT NULL,
    appointment_id uuid NOT NULL,
    preference_id uuid NOT NULL,
    previous_dosage text,
    previous_frequency text,
    previous_status text,
    previous_provider_notes text,
    new_dosage text,
    new_frequency text,
    new_status text,
    new_provider_notes text,
    adjustment_reason text,
    provider_notes text,
    created_at timestamp with time zone DEFAULT now(),
    performed_by uuid NOT NULL,
    new_supply_days integer,
    CONSTRAINT visit_medication_adjustments_new_status_check CHECK ((new_status = ANY (ARRAY['pending'::text, 'approved'::text, 'denied'::text, 'discontinued'::text])))
);


--
-- TOC entry 4915 (class 0 OID 0)
-- Dependencies: 335
-- Name: TABLE visit_medication_adjustments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.visit_medication_adjustments IS 'Medication adjustments made during visits, links to patient_medication_preferences';


--
-- TOC entry 4916 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN visit_medication_adjustments.preference_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_medication_adjustments.preference_id IS 'Links to existing patient_medication_preferences table';


--
-- TOC entry 4917 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN visit_medication_adjustments.adjustment_reason; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_medication_adjustments.adjustment_reason IS 'Reason for the medication adjustment';


--
-- TOC entry 4918 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN visit_medication_adjustments.new_supply_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_medication_adjustments.new_supply_days IS 'Number of days of medication supply when approved via medication adjustments';


--
-- TOC entry 292 (class 1259 OID 17007)
-- Name: messages; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
)
PARTITION BY RANGE (inserted_at);


--
-- TOC entry 293 (class 1259 OID 17024)
-- Name: messages_2025_10_13; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_10_13 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 294 (class 1259 OID 17036)
-- Name: messages_2025_10_14; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_10_14 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 295 (class 1259 OID 17048)
-- Name: messages_2025_10_15; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_10_15 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 296 (class 1259 OID 17060)
-- Name: messages_2025_10_16; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_10_16 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 297 (class 1259 OID 17072)
-- Name: messages_2025_10_17; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_10_17 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 286 (class 1259 OID 16844)
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


--
-- TOC entry 289 (class 1259 OID 16867)
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);


--
-- TOC entry 288 (class 1259 OID 16866)
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: -
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 267 (class 1259 OID 16509)
-- Name: buckets; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


--
-- TOC entry 4919 (class 0 OID 0)
-- Dependencies: 267
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 301 (class 1259 OID 17892)
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_analytics (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 302 (class 1259 OID 17903)
-- Name: iceberg_namespaces; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.iceberg_namespaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 303 (class 1259 OID 17919)
-- Name: iceberg_tables; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.iceberg_tables (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    namespace_id uuid NOT NULL,
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    location text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 269 (class 1259 OID 16551)
-- Name: migrations; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 268 (class 1259 OID 16524)
-- Name: objects; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb,
    level integer
);


--
-- TOC entry 4920 (class 0 OID 0)
-- Dependencies: 268
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 300 (class 1259 OID 17848)
-- Name: prefixes; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.prefixes (
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    level integer GENERATED ALWAYS AS (storage.get_level(name)) STORED NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 298 (class 1259 OID 17795)
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb
);


--
-- TOC entry 299 (class 1259 OID 17809)
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 282 (class 1259 OID 16763)
-- Name: hooks; Type: TABLE; Schema: supabase_functions; Owner: -
--

CREATE TABLE supabase_functions.hooks (
    id bigint NOT NULL,
    hook_table_id integer NOT NULL,
    hook_name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    request_id bigint
);


--
-- TOC entry 4921 (class 0 OID 0)
-- Dependencies: 282
-- Name: TABLE hooks; Type: COMMENT; Schema: supabase_functions; Owner: -
--

COMMENT ON TABLE supabase_functions.hooks IS 'Supabase Functions Hooks: Audit trail for triggered hooks.';


--
-- TOC entry 281 (class 1259 OID 16762)
-- Name: hooks_id_seq; Type: SEQUENCE; Schema: supabase_functions; Owner: -
--

CREATE SEQUENCE supabase_functions.hooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4922 (class 0 OID 0)
-- Dependencies: 281
-- Name: hooks_id_seq; Type: SEQUENCE OWNED BY; Schema: supabase_functions; Owner: -
--

ALTER SEQUENCE supabase_functions.hooks_id_seq OWNED BY supabase_functions.hooks.id;


--
-- TOC entry 280 (class 1259 OID 16754)
-- Name: migrations; Type: TABLE; Schema: supabase_functions; Owner: -
--

CREATE TABLE supabase_functions.migrations (
    version text NOT NULL,
    inserted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 3786 (class 0 OID 0)
-- Name: messages_2025_10_13; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_13 FOR VALUES FROM ('2025-10-13 00:00:00') TO ('2025-10-14 00:00:00');


--
-- TOC entry 3787 (class 0 OID 0)
-- Name: messages_2025_10_14; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_14 FOR VALUES FROM ('2025-10-14 00:00:00') TO ('2025-10-15 00:00:00');


--
-- TOC entry 3788 (class 0 OID 0)
-- Name: messages_2025_10_15; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_15 FOR VALUES FROM ('2025-10-15 00:00:00') TO ('2025-10-16 00:00:00');


--
-- TOC entry 3789 (class 0 OID 0)
-- Name: messages_2025_10_16; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_16 FOR VALUES FROM ('2025-10-16 00:00:00') TO ('2025-10-17 00:00:00');


--
-- TOC entry 3790 (class 0 OID 0)
-- Name: messages_2025_10_17; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_17 FOR VALUES FROM ('2025-10-17 00:00:00') TO ('2025-10-18 00:00:00');


--
-- TOC entry 3800 (class 2604 OID 16473)
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- TOC entry 3889 (class 2604 OID 18412)
-- Name: assignment_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assignment_log ALTER COLUMN id SET DEFAULT nextval('public.assignment_log_id_seq'::regclass);


--
-- TOC entry 3814 (class 2604 OID 16766)
-- Name: hooks id; Type: DEFAULT; Schema: supabase_functions; Owner: -
--

ALTER TABLE ONLY supabase_functions.hooks ALTER COLUMN id SET DEFAULT nextval('supabase_functions.hooks_id_seq'::regclass);


--
-- TOC entry 4741 (class 0 OID 16488)
-- Dependencies: 265
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
00000000-0000-0000-0000-000000000000	b391823f-5e51-4530-b079-4d1606d1b12a	{"action":"user_signedup","actor_id":"6a2ffaa8-318b-4888-a102-1277708d6b9a","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"team","traits":{"provider":"email"}}	2025-10-14 06:08:41.249894+00	
00000000-0000-0000-0000-000000000000	e7437b6e-8742-4a4a-a712-ee57044b424b	{"action":"login","actor_id":"6a2ffaa8-318b-4888-a102-1277708d6b9a","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-14 06:08:41.251614+00	
00000000-0000-0000-0000-000000000000	c3e9d17c-41c9-469d-823b-292d332c94b2	{"action":"logout","actor_id":"6a2ffaa8-318b-4888-a102-1277708d6b9a","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-14 06:08:47.48686+00	
00000000-0000-0000-0000-000000000000	751ba47b-d4cd-4820-89d9-fc295d9caa88	{"action":"user_signedup","actor_id":"ccabc2d7-037e-4410-ae15-8ad673f0f7e1","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"team","traits":{"provider":"email"}}	2025-10-14 06:09:21.671811+00	
00000000-0000-0000-0000-000000000000	22fdd174-f7a1-41cf-97fd-188fc93473b9	{"action":"login","actor_id":"ccabc2d7-037e-4410-ae15-8ad673f0f7e1","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-14 06:09:21.673854+00	
00000000-0000-0000-0000-000000000000	8fbb2de4-d99a-4850-a973-80d136d9ac0a	{"action":"logout","actor_id":"ccabc2d7-037e-4410-ae15-8ad673f0f7e1","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-14 06:09:24.658156+00	
00000000-0000-0000-0000-000000000000	e1d33e3a-5d41-4f59-b03d-2b283ab00496	{"action":"user_signedup","actor_id":"6f355179-913d-440e-acfa-0cf20c484804","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"team","traits":{"provider":"email"}}	2025-10-14 06:09:45.735864+00	
00000000-0000-0000-0000-000000000000	62b366be-e884-4d05-8a66-42ec3a127286	{"action":"login","actor_id":"6f355179-913d-440e-acfa-0cf20c484804","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-14 06:09:45.738015+00	
00000000-0000-0000-0000-000000000000	f6f39d3c-ed71-4d79-9855-4b1bfd4824f1	{"action":"logout","actor_id":"6f355179-913d-440e-acfa-0cf20c484804","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-14 06:09:48.178233+00	
00000000-0000-0000-0000-000000000000	77cd9bff-7d44-4e8c-bea6-2de2be6350c3	{"action":"login","actor_id":"6a2ffaa8-318b-4888-a102-1277708d6b9a","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-14 07:05:36.28864+00	
00000000-0000-0000-0000-000000000000	2ad9664e-4468-4f56-85ee-e02dae982958	{"action":"login","actor_id":"6a2ffaa8-318b-4888-a102-1277708d6b9a","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-14 07:13:22.513385+00	
00000000-0000-0000-0000-000000000000	325ece84-68a9-4f85-a171-523586c1de9c	{"action":"login","actor_id":"6a2ffaa8-318b-4888-a102-1277708d6b9a","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-14 07:18:32.66419+00	
\.


--
-- TOC entry 4772 (class 0 OID 18161)
-- Dependencies: 313
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at) FROM stdin;
\.


--
-- TOC entry 4763 (class 0 OID 17959)
-- Dependencies: 304
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
6a2ffaa8-318b-4888-a102-1277708d6b9a	6a2ffaa8-318b-4888-a102-1277708d6b9a	{"sub": "6a2ffaa8-318b-4888-a102-1277708d6b9a", "role": "patient", "email": "patientexample@test.com", "last_name": "example", "first_name": "patient", "email_verified": false, "phone_verified": false}	email	2025-10-14 06:08:41.248834+00	2025-10-14 06:08:41.24885+00	2025-10-14 06:08:41.24885+00	3cbf6eab-fcf3-4295-94fa-2c073e4174cc
ccabc2d7-037e-4410-ae15-8ad673f0f7e1	ccabc2d7-037e-4410-ae15-8ad673f0f7e1	{"sub": "ccabc2d7-037e-4410-ae15-8ad673f0f7e1", "role": "provider", "email": "providerexample@test.com", "phone": "", "last_name": "example", "specialty": "General Practice", "first_name": "provider", "email_verified": false, "license_number": "TBD", "phone_verified": false}	email	2025-10-14 06:09:21.67071+00	2025-10-14 06:09:21.670724+00	2025-10-14 06:09:21.670724+00	457d846f-498b-4b22-8c0d-a19126ef9d04
6f355179-913d-440e-acfa-0cf20c484804	6f355179-913d-440e-acfa-0cf20c484804	{"sub": "6f355179-913d-440e-acfa-0cf20c484804", "role": "admin", "email": "adminexample@test.com", "last_name": "example", "first_name": "admin", "email_verified": false, "phone_verified": false}	email	2025-10-14 06:09:45.735059+00	2025-10-14 06:09:45.735073+00	2025-10-14 06:09:45.735073+00	c3ec495f-f935-4792-8fda-536887315c1a
\.


--
-- TOC entry 4740 (class 0 OID 16481)
-- Dependencies: 264
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4767 (class 0 OID 18048)
-- Dependencies: 308
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
8888c345-3732-4b91-b7be-f11781e88556	2025-10-14 07:05:36.289975+00	2025-10-14 07:05:36.289975+00	password	4efc9656-6dc7-43b8-908a-c38c1476f043
ef297697-20cc-4889-afa7-0a0ab3eea018	2025-10-14 07:13:22.514816+00	2025-10-14 07:13:22.514816+00	password	51df2943-8365-4b22-9e0b-3c1895948246
7f84fa42-4449-42a5-b762-e3c2a865bb0a	2025-10-14 07:18:32.665607+00	2025-10-14 07:18:32.665607+00	password	55e7360e-45d8-4321-ad90-f775d72823f4
\.


--
-- TOC entry 4766 (class 0 OID 18036)
-- Dependencies: 307
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- TOC entry 4765 (class 0 OID 18023)
-- Dependencies: 306
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid) FROM stdin;
\.


--
-- TOC entry 4774 (class 0 OID 18243)
-- Dependencies: 315
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_clients (id, client_id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- TOC entry 4773 (class 0 OID 18211)
-- Dependencies: 314
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4739 (class 0 OID 16470)
-- Dependencies: 263
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
00000000-0000-0000-0000-000000000000	4	l7ltgqqt5plj	6a2ffaa8-318b-4888-a102-1277708d6b9a	f	2025-10-14 07:05:36.289439+00	2025-10-14 07:05:36.289439+00	\N	8888c345-3732-4b91-b7be-f11781e88556
00000000-0000-0000-0000-000000000000	5	f4tixyp7crg6	6a2ffaa8-318b-4888-a102-1277708d6b9a	f	2025-10-14 07:13:22.514292+00	2025-10-14 07:13:22.514292+00	\N	ef297697-20cc-4889-afa7-0a0ab3eea018
00000000-0000-0000-0000-000000000000	6	ftwu2ptb5u7w	6a2ffaa8-318b-4888-a102-1277708d6b9a	f	2025-10-14 07:18:32.664998+00	2025-10-14 07:18:32.664998+00	\N	7f84fa42-4449-42a5-b762-e3c2a865bb0a
\.


--
-- TOC entry 4770 (class 0 OID 18090)
-- Dependencies: 311
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- TOC entry 4771 (class 0 OID 18108)
-- Dependencies: 312
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- TOC entry 4742 (class 0 OID 16496)
-- Dependencies: 266
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
\.


--
-- TOC entry 4764 (class 0 OID 17989)
-- Dependencies: 305
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag) FROM stdin;
8888c345-3732-4b91-b7be-f11781e88556	6a2ffaa8-318b-4888-a102-1277708d6b9a	2025-10-14 07:05:36.289058+00	2025-10-14 07:05:36.289058+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
ef297697-20cc-4889-afa7-0a0ab3eea018	6a2ffaa8-318b-4888-a102-1277708d6b9a	2025-10-14 07:13:22.513867+00	2025-10-14 07:13:22.513867+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
7f84fa42-4449-42a5-b762-e3c2a865bb0a	6a2ffaa8-318b-4888-a102-1277708d6b9a	2025-10-14 07:18:32.664622+00	2025-10-14 07:18:32.664622+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
\.


--
-- TOC entry 4769 (class 0 OID 18075)
-- Dependencies: 310
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4768 (class 0 OID 18066)
-- Dependencies: 309
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- TOC entry 4737 (class 0 OID 16458)
-- Dependencies: 261
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\N	22222222-2222-2222-2222-222222222222	\N	\N	michael.r@test.com	$2a$10$dummyhashformichaelroberts	2025-10-14 05:59:17.235709+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	33333333-3333-3333-3333-333333333333	\N	\N	jennifer.m@test.com	$2a$10$dummyhashforjennifermartinez	2025-10-14 05:59:17.235709+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	44444444-4444-4444-4444-444444444444	\N	\N	david.a@test.com	$2a$10$dummyhashfordavidanderson	2025-10-14 05:59:17.235709+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb	\N	\N	dr.watson@test.com	$2a$10$dummyhashfordrwatson	2025-10-14 05:59:17.235709+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	cccccccc-cccc-cccc-cccc-cccccccccccc	\N	\N	dr.wilson@test.com	$2a$10$dummyhashfordrwilson	2025-10-14 05:59:17.235709+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa	\N	\N	admin@test.com	admin123	2025-10-14 05:59:17.243857+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"role": "admin", "last_name": "User", "first_name": "Admin"}	\N	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.243857+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	11111111-1111-1111-1111-111111111111	\N	\N	sarah.j@test.com	patient123	2025-10-14 05:59:17.243857+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"role": "patient", "last_name": "Johnson", "first_name": "Sarah"}	\N	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.243857+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	6f355179-913d-440e-acfa-0cf20c484804	authenticated	authenticated	adminexample@test.com	$2a$10$UlxKVnFXbdS28JeoFCAzHeRt.aWOjjxTLJ7f85hmorXe.Ku2a.T16	2025-10-14 06:09:45.736079+00	\N		\N		\N			\N	2025-10-14 06:09:45.738266+00	{"provider": "email", "providers": ["email"]}	{"sub": "6f355179-913d-440e-acfa-0cf20c484804", "role": "admin", "email": "adminexample@test.com", "last_name": "example", "first_name": "admin", "email_verified": true, "phone_verified": false}	\N	2025-10-14 06:09:45.733502+00	2025-10-14 06:09:45.738892+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	ccabc2d7-037e-4410-ae15-8ad673f0f7e1	authenticated	authenticated	providerexample@test.com	$2a$10$PzqEqWtPI16yZh/2e/WYK.pDVOGVucMCyK6W7IhWvnUlCBVxKmGF6	2025-10-14 06:09:21.672089+00	\N		\N		\N			\N	2025-10-14 06:09:21.674089+00	{"provider": "email", "providers": ["email"]}	{"sub": "ccabc2d7-037e-4410-ae15-8ad673f0f7e1", "role": "provider", "email": "providerexample@test.com", "phone": "", "last_name": "example", "specialty": "General Practice", "first_name": "provider", "email_verified": true, "license_number": "TBD", "phone_verified": false}	\N	2025-10-14 06:09:21.668914+00	2025-10-14 06:09:21.677135+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	6a2ffaa8-318b-4888-a102-1277708d6b9a	authenticated	authenticated	patientexample@test.com	$2a$10$0sd66ZtK7r/lPu3FvaqZcOZN7DpFEUEH1Ney7yEzKLnX7HUuiDMsy	2025-10-14 06:08:41.250297+00	\N		\N		\N			\N	2025-10-14 07:18:32.664595+00	{"provider": "email", "providers": ["email"]}	{"sub": "6a2ffaa8-318b-4888-a102-1277708d6b9a", "role": "patient", "email": "patientexample@test.com", "last_name": "example", "first_name": "patient", "email_verified": true, "phone_verified": false}	\N	2025-10-14 06:08:41.246572+00	2025-10-14 07:18:32.665457+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- TOC entry 4778 (class 0 OID 18320)
-- Dependencies: 320
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admins (id, profile_id, permissions, active, created_at, updated_at) FROM stdin;
5af8b8f3-69d1-4e3a-a803-afef23dfa9ce	6f355179-913d-440e-acfa-0cf20c484804	{dashboard,patients,providers,assignments}	t	2025-10-14 06:09:45.733303+00	2025-10-14 06:09:45.733303+00
\.


--
-- TOC entry 4789 (class 0 OID 18625)
-- Dependencies: 331
-- Data for Name: appointment_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appointment_history (id, appointment_id, action, performed_by, performed_by_user_id, old_values, new_values, reason, created_at) FROM stdin;
\.


--
-- TOC entry 4788 (class 0 OID 18587)
-- Dependencies: 330
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appointments (id, patient_id, provider_id, assignment_id, appointment_date, start_time, end_time, duration_minutes, treatment_type, appointment_type, status, patient_notes, provider_notes, admin_notes, booked_by, booked_by_user_id, booking_timestamp, cancelled_at, cancelled_by, cancelled_by_user_id, cancellation_reason, created_at, updated_at, rescheduled_from_id, rescheduled_to_id, is_reschedule_source, reschedule_count) FROM stdin;
\.


--
-- TOC entry 4781 (class 0 OID 18409)
-- Dependencies: 323
-- Data for Name: assignment_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assignment_log (id, message, created_at) FROM stdin;
1	Starting provider assignment process	2025-10-14 05:59:17.20671
2	Provider assignment process completed	2025-10-14 05:59:17.20671
\.


--
-- TOC entry 4796 (class 0 OID 18944)
-- Dependencies: 340
-- Data for Name: auth_trigger_debug_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_trigger_debug_log (id, user_id, step, status, error_message, metadata, created_at) FROM stdin;
\.


--
-- TOC entry 4793 (class 0 OID 18839)
-- Dependencies: 337
-- Data for Name: auth_trigger_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_trigger_logs (id, user_id, trigger_stage, success, error_message, metadata, created_at) FROM stdin;
\.


--
-- TOC entry 4790 (class 0 OID 18702)
-- Dependencies: 334
-- Data for Name: clinical_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clinical_notes (id, appointment_id, patient_id, provider_id, allergies, previous_medications, current_medications, clinical_note, internal_note, visit_summary, created_at, updated_at, created_by, last_updated_by) FROM stdin;
\.


--
-- TOC entry 4797 (class 0 OID 19001)
-- Dependencies: 341
-- Data for Name: faxes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.faxes (id, approval_id, preference_id, patient_id, provider_id, fax_number, fax_content, fax_status, faxed_at, delivery_confirmation_at, notes, created_at, updated_at, provider_profile_id, patient_profile_id) FROM stdin;
\.


--
-- TOC entry 4784 (class 0 OID 18455)
-- Dependencies: 326
-- Data for Name: medication_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medication_approvals (id, preference_id, provider_id, status, approved_dosage, approved_frequency, provider_notes, contraindications, approval_date, created_at, updated_at, provider_profile_id, supply_days) FROM stdin;
\.


--
-- TOC entry 4794 (class 0 OID 18867)
-- Dependencies: 338
-- Data for Name: medication_dosages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medication_dosages (id, medication_id, strength, unit_price, available, sort_order, created_at, updated_at) FROM stdin;
677b5031-2dbf-47b7-9474-c0428883634e	006501e8-52c6-450f-a4a4-875bbae3ab4a	20mg	99.99	t	1	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
21932f35-6a90-4438-ad68-5a6808a91b94	15eb40e5-18e0-45ac-aa5c-947679f0abc1	50mg	89.99	t	1	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
c1d88719-8bdc-4744-8562-14ea4935af8d	299d3e65-6bb2-46ca-b435-a8b59b98e9de	120mg	199.99	t	1	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
e26f5c3f-0ec3-4c80-9b20-1483a6e08753	3fc6da67-5413-46f9-b13d-49892a509670	250mg/ml	219.99	t	1	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
0e25ce34-380e-4c66-bcef-f46bc0d7a3eb	4866daf0-ef6b-4755-8861-a38d51497800	5000 IU	149.99	t	1	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
2d7655a6-3ec2-4e31-a388-f53a1dfd428a	4c7d767a-2b43-4f27-8d60-1cdebcfc22e9	200mg/ml	199.99	t	1	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
c97dea21-c9cd-44e9-8ded-5c2ec2dd64d6	713de44e-ca42-4ab5-880f-85a366e700ca	37.5mg	89.99	t	1	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
322c5203-e2f7-48ed-839a-9e0c11e13ecc	9163228e-9a74-44ff-af7a-41e6e5e331dc	1.62%	299.99	t	1	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
09278c54-2800-4a53-9042-9fe42bf7dd94	930081b0-00fc-4e25-ad97-7c1bd8e889ce	1.0mg	1299.99	t	1	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
d41fd4f1-3ccf-4e87-b49d-7042d1136595	a3368838-40b3-4409-b2e6-29c6d28d7213	3.0mg	1099.99	t	1	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
e424e6bd-acfc-4302-a055-449aec0ca9da	ee7bff67-0915-451f-acfe-1bc1efb8423c	1mg	79.99	t	1	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
606da480-fa41-4a24-9651-10ff9c43c026	eebf77f8-9411-4fe6-bae7-ff2d48ff367a	2.5mg	1199.99	t	1	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
edde56d4-7467-4b17-8fbe-6169876c2f86	f848e7b9-ff12-4165-a3db-475787a7b759	0.5mg	899.99	t	1	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
9a1070d6-a626-47c5-a5e8-012597cd1421	eebf77f8-9411-4fe6-bae7-ff2d48ff367a	5.0mg	1399.99	t	10	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
9a95a350-c23d-4323-8b2c-6da0ee03fdc5	eebf77f8-9411-4fe6-bae7-ff2d48ff367a	7.5mg	1599.99	t	20	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
9243aeed-2ba0-450d-85cc-e1d60ed37106	eebf77f8-9411-4fe6-bae7-ff2d48ff367a	10mg	1799.99	t	30	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
92ae5a5f-2035-49e0-bdad-126280fe301a	eebf77f8-9411-4fe6-bae7-ff2d48ff367a	12.5mg	1999.99	t	40	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
c9a89581-a621-45ab-af6b-68ba8850577c	eebf77f8-9411-4fe6-bae7-ff2d48ff367a	15mg	2199.99	t	50	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
32057b93-3113-45b3-b91d-ba3d55c0e19e	f848e7b9-ff12-4165-a3db-475787a7b759	0.25mg	799.99	t	1	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
e8d63667-42c4-4e6e-9c0d-a8981eaffe1f	f848e7b9-ff12-4165-a3db-475787a7b759	1.0mg	999.99	t	11	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
b279004b-9433-494f-9dd7-ab60e3ccf691	f848e7b9-ff12-4165-a3db-475787a7b759	2.0mg	1199.99	t	21	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
be0c17ce-bbe8-4433-a309-377e971196e3	4c7d767a-2b43-4f27-8d60-1cdebcfc22e9	100mg/ml	159.99	t	5	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
9f3d3a6d-2f9f-4327-8155-e48b701ff2a4	4c7d767a-2b43-4f27-8d60-1cdebcfc22e9	250mg/ml	239.99	t	15	2025-10-14 05:59:20.362628+00	2025-10-14 05:59:20.362628+00
\.


--
-- TOC entry 4785 (class 0 OID 18476)
-- Dependencies: 327
-- Data for Name: medication_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medication_orders (id, approval_id, patient_id, medication_id, quantity, unit_price, total_amount, payment_status, payment_method, payment_date, fulfillment_status, tracking_number, shipped_date, estimated_delivery, admin_notes, created_at, updated_at, sent_to_pharmacy, provider_profile_id, patient_profile_id) FROM stdin;
\.


--
-- TOC entry 4799 (class 0 OID 19258)
-- Dependencies: 344
-- Data for Name: medication_tracking_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medication_tracking_entries (id, patient_id, medication_preference_id, taken_date, taken_time, notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4782 (class 0 OID 18418)
-- Dependencies: 324
-- Data for Name: medications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medications (id, name, generic_name, brand_name, dosage_form, strength, description, category, unit_price, requires_prescription, active, created_at, updated_at) FROM stdin;
f848e7b9-ff12-4165-a3db-475787a7b759	Semaglutide	Semaglutide	Ozempic	injection	0.5mg	GLP-1 receptor agonist for weight management and diabetes	weight_loss	899.99	t	t	2025-10-14 05:59:17.228386+00	2025-10-14 05:59:17.228386+00
930081b0-00fc-4e25-ad97-7c1bd8e889ce	Semaglutide	Semaglutide	Wegovy	injection	1.0mg	GLP-1 receptor agonist specifically for chronic weight management	weight_loss	1299.99	t	t	2025-10-14 05:59:17.228386+00	2025-10-14 05:59:17.228386+00
eebf77f8-9411-4fe6-bae7-ff2d48ff367a	Tirzepatide	Tirzepatide	Mounjaro	injection	2.5mg	Dual GIP/GLP-1 receptor agonist for weight loss	weight_loss	1199.99	t	t	2025-10-14 05:59:17.228386+00	2025-10-14 05:59:17.228386+00
a3368838-40b3-4409-b2e6-29c6d28d7213	Liraglutide	Liraglutide	Saxenda	injection	3.0mg	GLP-1 receptor agonist for weight management	weight_loss	1099.99	t	t	2025-10-14 05:59:17.228386+00	2025-10-14 05:59:17.228386+00
299d3e65-6bb2-46ca-b435-a8b59b98e9de	Orlistat	Orlistat	Xenical	capsule	120mg	Lipase inhibitor for weight loss	weight_loss	199.99	t	t	2025-10-14 05:59:17.228386+00	2025-10-14 05:59:17.228386+00
713de44e-ca42-4ab5-880f-85a366e700ca	Phentermine	Phentermine	Adipex-P	tablet	37.5mg	Appetite suppressant for short-term weight loss	weight_loss	89.99	t	t	2025-10-14 05:59:17.228386+00	2025-10-14 05:59:17.228386+00
4c7d767a-2b43-4f27-8d60-1cdebcfc22e9	Testosterone Cypionate	Testosterone Cypionate	Depo-Testosterone	injection	200mg/ml	Testosterone replacement therapy for hypogonadism	mens_health	199.99	t	t	2025-10-14 05:59:17.228386+00	2025-10-14 05:59:17.228386+00
3fc6da67-5413-46f9-b13d-49892a509670	Testosterone Enanthate	Testosterone Enanthate	Delatestryl	injection	250mg/ml	Long-acting testosterone for hormone replacement	mens_health	219.99	t	t	2025-10-14 05:59:17.228386+00	2025-10-14 05:59:17.228386+00
9163228e-9a74-44ff-af7a-41e6e5e331dc	Testosterone Gel	Testosterone	AndroGel	gel	1.62%	Topical testosterone replacement therapy	mens_health	299.99	t	t	2025-10-14 05:59:17.228386+00	2025-10-14 05:59:17.228386+00
15eb40e5-18e0-45ac-aa5c-947679f0abc1	Sildenafil	Sildenafil	Viagra	tablet	50mg	PDE5 inhibitor for erectile dysfunction	mens_health	89.99	t	t	2025-10-14 05:59:17.228386+00	2025-10-14 05:59:17.228386+00
006501e8-52c6-450f-a4a4-875bbae3ab4a	Tadalafil	Tadalafil	Cialis	tablet	20mg	Long-acting PDE5 inhibitor for erectile dysfunction	mens_health	99.99	t	t	2025-10-14 05:59:17.228386+00	2025-10-14 05:59:17.228386+00
ee7bff67-0915-451f-acfe-1bc1efb8423c	Finasteride	Finasteride	Propecia	tablet	1mg	5-alpha reductase inhibitor for male pattern baldness	mens_health	79.99	t	t	2025-10-14 05:59:17.228386+00	2025-10-14 05:59:17.228386+00
4866daf0-ef6b-4755-8861-a38d51497800	HCG	Human Chorionic Gonadotropin	Pregnyl	injection	5000 IU	Hormone therapy to support testosterone production	mens_health	149.99	t	t	2025-10-14 05:59:17.228386+00	2025-10-14 05:59:17.228386+00
\.


--
-- TOC entry 4798 (class 0 OID 19221)
-- Dependencies: 343
-- Data for Name: patient_addresses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patient_addresses (id, patient_id, address_type, street_line_1, street_line_2, city, state, postal_code, country, is_primary, is_verified, verified_at, verification_method, notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4779 (class 0 OID 18339)
-- Dependencies: 321
-- Data for Name: patient_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patient_assignments (id, patient_id, provider_id, treatment_type, is_primary, assigned_date, active, created_at, updated_at) FROM stdin;
05a109e1-26c2-4c0f-8e62-f2d5c6663c75	419d8930-528f-4b7c-a2b0-3c62227c6bec	17101b03-1a63-4c59-a368-63d2bd026e3b	weight_loss	t	2025-10-14 06:19:12.21084+00	t	2025-10-14 06:19:12.21084+00	2025-10-14 06:19:12.21084+00
\.


--
-- TOC entry 4800 (class 0 OID 19266)
-- Dependencies: 345
-- Data for Name: patient_health_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patient_health_metrics (id, patient_id, metric_type, value, unit, recorded_at, synced_from, metadata, created_at, updated_at) FROM stdin;
69a510e9-c515-489d-9b45-d51ddfbb30a3	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	199.849447875914	lbs	2025-10-13 04:25:31.746113+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
6317e039-3f6c-422e-8c9a-8145554f6241	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	9362.63300531684	steps	2025-10-13 02:03:36.727776+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
d4c1e914-3f44-4f00-bc38-d5be66b637a2	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.90866305291828	hours	2025-10-13 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
ee2f8e1d-95b9-43e9-8975-45bcfa5013ef	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2669.25467855978	kcal	2025-10-13 08:19:19.547341+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
88531d5e-ac3c-4017-8217-e28608763fe4	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	114.805952723058	grams	2025-10-13 06:03:41.403926+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
c41a1de8-ca4b-4050-9e27-304746a5913f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	57.8548215981776	grams	2025-10-13 04:35:00.15197+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
1bbf2f66-e69f-4d1f-95bb-7299d1f3e45c	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	76.4608953476819	bpm	2025-10-13 05:16:08.68668+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
96caffdd-7523-46fd-9d11-fd153952e9b9	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	200.160739734224	lbs	2025-10-12 09:10:18.581377+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
94af7380-38bd-426c-9813-7b7c9047e7db	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	8141.75849087786	steps	2025-10-12 03:07:45.983855+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
e949e4c4-24e0-4c32-9a6d-8430a3b6d277	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.37410358430251	hours	2025-10-12 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
b5818ead-c831-4a4d-8809-a3da2e9da082	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2275.3882113861	kcal	2025-10-12 06:57:11.827133+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
c1217588-1499-4e5c-8a33-223d388f4afd	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	112.912916759695	grams	2025-10-12 01:56:46.748399+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
0571edea-9a3d-4f70-92df-d7d8a74abd84	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	33.8886239093033	grams	2025-10-12 07:29:05.29162+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
b6d5bb0e-3368-4354-8c12-c1cc559b427f	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	69.3801923954281	bpm	2025-10-12 06:20:38.888605+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
22393d97-c04f-4798-9ace-c4bd2679dd4a	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	199.083645065244	lbs	2025-10-11 03:21:57.47132+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
22aa251a-c157-4579-b1e3-008ecc111cc7	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6809.33783713334	steps	2025-10-11 06:46:08.507734+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
27f02a13-21d7-4858-93ab-4f1882ce2512	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.69430443281134	hours	2025-10-11 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
6ca9a5e0-b174-466b-a0e5-5a17b31372a1	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2766.83238740623	kcal	2025-10-11 02:30:55.605634+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
5b443155-1bae-4345-bf93-4f22f2dcfd90	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	117.229243063471	grams	2025-10-11 08:52:00.772622+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
328f4586-56f7-4eac-95fa-e86d9e793be9	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	63.934271808067	grams	2025-10-11 01:22:29.670113+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
c946adfa-785f-4a8d-8364-5c9579f7c2a8	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	70.79098155382	bpm	2025-10-11 01:49:51.010087+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
6b737db7-1d8f-42ad-8040-c864757b2b41	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	200.234896254642	lbs	2025-10-10 02:18:29.158999+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
5be20c72-1a40-4068-a6b7-98e126d21e47	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	11844.0207083558	steps	2025-10-10 11:50:55.629366+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
a3128a00-2003-41e9-8ea9-9e1f21f4352f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	6.88775716281163	hours	2025-10-10 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
7f1c6e49-fe34-4381-baf7-9e7b07996352	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2656.9437329533	kcal	2025-10-10 11:55:44.506356+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
7103d973-8c9e-4aca-8b41-b2a8fcc38c80	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	130.279503297368	grams	2025-10-10 04:26:32.558838+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
06a80b36-290c-42ce-839f-6a2b893aed21	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	45.8327397411541	grams	2025-10-10 11:54:56.676526+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
ab71270c-2103-4778-983e-033ae61f0888	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	82.5120937009514	bpm	2025-10-10 00:38:10.941224+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
cfa10596-d098-4b28-876c-2e963cf76267	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	200.319175480379	lbs	2025-10-09 01:16:40.082915+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
af621c4b-c94b-4467-87c0-207760681927	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	10033.2089650994	steps	2025-10-09 07:39:00.614942+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
4fef4b91-6a42-4380-a2a1-a1952e297399	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.9857481295129	hours	2025-10-09 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
22bb0a40-013d-455b-a1c3-228c7340d440	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2753.04602579682	kcal	2025-10-09 04:22:27.084775+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
ce384c7d-c4a2-4daa-9148-fb187e6c3929	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	104.460683819927	grams	2025-10-09 04:27:55.311981+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
7b8a0ab3-2575-46eb-839b-0c95e64a67fb	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	40.7670138869993	grams	2025-10-09 01:28:17.440418+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
5acb8117-237a-4835-b244-2e434a23b00b	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	67.0083731014463	bpm	2025-10-09 00:40:53.327791+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
1edf43f8-173b-4af5-aed8-536c42b17cfd	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	199.533909929007	lbs	2025-10-07 09:41:40.579305+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
360286c5-6c68-4ea0-8755-5455685610a2	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	14333.3917047055	steps	2025-10-07 05:58:02.75446+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
83a9a87c-306e-406c-b0f6-3be4fae1ed56	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.72062842249067	hours	2025-10-07 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
bdc8b0ff-021b-44de-9b85-6bddd8eb31e6	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2510.64112120456	kcal	2025-10-07 04:57:05.714088+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
172abe29-3cb4-4974-8490-37610632425a	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	93.4606765042337	grams	2025-10-07 06:23:21.165656+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
bbeecc97-3e36-4c8a-a5a2-6c3bc54d8042	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	57.9062509170216	grams	2025-10-07 07:31:38.201723+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
f1cca8c0-e393-4bb6-a4a9-19941b8c386a	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	70.0854749206054	bpm	2025-10-07 02:22:52.808248+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
d0ed7268-3c28-4ef0-a19a-5222a4942379	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	198.547162847337	lbs	2025-10-06 05:22:52.083066+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
34f3de5b-ceeb-4527-83f4-5b2d23263f29	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	12472.078095004	steps	2025-10-06 03:28:42.418084+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
69142fc5-5b2d-498d-870b-86bc4a45655e	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.91222438527177	hours	2025-10-06 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
05009758-2162-45cf-8e26-74582fed6b79	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2246.43886932311	kcal	2025-10-06 03:47:44.396017+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
21fcf2e8-47ac-4f3c-b7a8-ff6a6028c14a	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	111.600689356804	grams	2025-10-06 07:09:12.026805+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
150349c0-b6c1-47b2-a0dd-9846efc373bb	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	58.3506288115415	grams	2025-10-06 09:45:28.186684+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
6a170d03-30ef-4196-b729-a0e9d81c14ae	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	83.8598264013786	bpm	2025-10-06 08:59:06.529634+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
43c5010a-3eae-4929-b687-f7d505b83a93	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	198.974276150412	lbs	2025-10-05 04:45:42.357021+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
bcc2ac1a-6ddc-453b-a903-d8ab2d58d3bf	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	7431.87840628317	steps	2025-10-05 10:32:34.678619+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
0f7a66f1-ef1b-4bb8-943a-9b70a3af1bdb	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.90425060445208	hours	2025-10-05 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
4b1ab0f9-b515-45c6-b766-35e31bccde4f	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2767.46042108867	kcal	2025-10-05 04:29:50.73661+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
811e31db-2211-491b-a7ae-e4782f164112	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	112.403175334484	grams	2025-10-05 09:04:41.717315+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
3fc7a3cc-f40a-4c1a-af99-e21bbbcb000d	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	54.8256606842547	grams	2025-10-05 01:46:59.508931+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
aef77e44-c1e9-4a2b-a14a-a8b21cba6b30	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	74.3557465297832	bpm	2025-10-05 08:49:02.440177+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
b918a201-df8d-4ad2-80ba-0069b21b1998	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	199.653461038201	lbs	2025-10-04 01:59:36.676447+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
cc4b08e8-d2cd-4acc-8af7-231cb41322f9	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	7993.98002281986	steps	2025-10-04 04:48:48.624772+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
2c003637-3b97-4c1a-8d93-a092a1264066	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.06026328799554	hours	2025-10-04 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
45341bf1-e4b0-4236-9207-41b0a207e3f5	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2433.03855783409	kcal	2025-10-04 03:11:35.077209+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
b50123f6-38c1-44f3-acc3-be6f7182d898	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	84.7227596201853	grams	2025-10-04 07:19:40.732096+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
cfa8f53c-763b-475c-bfb8-8eadb4ab9d13	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	61.1631592174373	grams	2025-10-04 04:40:14.536348+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
a0c7f558-ec4a-441b-98b7-abb857840f9d	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	80.1037864410836	bpm	2025-10-04 09:30:36.736224+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
67b04ae1-436f-4602-8aa8-927db58b4e44	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	198.528507259474	lbs	2025-10-03 06:21:02.275293+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
6763769c-58c0-46d5-9e4d-4eb95de4c6eb	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	9526.3079370989	steps	2025-10-03 02:16:59.455744+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
07d8fc17-148d-4dd2-81b2-3519c6e297f3	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.99480654399871	hours	2025-10-03 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
c24790f3-b2f9-4368-80de-7ff2c3403d52	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2606.14069440683	kcal	2025-10-03 10:28:44.739066+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
6927979b-bbae-4fc4-8bbd-7a0f8ce4523b	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	86.634648220853	grams	2025-10-03 00:37:15.880659+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
0dcb79e4-ccb9-431b-82b2-ba987dd2b0c6	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	26.9218522736913	grams	2025-10-03 00:10:13.33414+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
71db4fd6-caf8-44f5-b86e-000935dc6d5a	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	69.2741847449494	bpm	2025-10-03 05:54:55.784849+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
a083f0c9-8b04-4fdc-8431-d0a6d35e7746	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	198.016064084794	lbs	2025-10-02 00:51:47.182428+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
777e6270-6bdc-4ed1-aa1b-aed240f1451f	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	12237.1990056281	steps	2025-10-02 09:46:06.541089+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
ad4d10a8-8880-4156-ab2b-0b9fd239ea3a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.21509138438886	hours	2025-10-02 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
a96f0438-1076-4bdc-a482-af531ee32f66	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2436.30950909822	kcal	2025-10-02 03:33:34.822149+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
872c5bac-f77d-4716-9177-511c16d70756	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	90.3592819665892	grams	2025-10-02 00:08:12.879731+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
e2e3d717-0951-45ad-b93b-100b1e1108df	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	27.657457292987	grams	2025-10-02 06:46:15.833263+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
da98ead6-8ce1-4d67-af80-10df06c3c4e0	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	71.625033400893	bpm	2025-10-02 02:57:19.308315+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
f532fe40-53fe-42ff-8c4a-29b6b4a65c4d	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	199.429568990953	lbs	2025-10-01 07:04:20.066361+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
967cc5a7-ee80-40e3-baa0-346c25e50e1e	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	11837.3224618335	steps	2025-10-01 04:11:30.681146+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
44319b92-7a95-411a-918b-207d08609ab6	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.76068064846887	hours	2025-10-01 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
22836a06-2172-46d5-8def-0c946367ebe1	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2732.54490146688	kcal	2025-10-01 09:07:37.351866+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
76b4e8b6-3066-4a6a-bd5a-91bea9190cca	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	116.823972408383	grams	2025-10-01 01:05:46.322354+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
bf2bad03-0651-4887-98eb-2955d778d8c1	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	50.8716115746604	grams	2025-10-01 05:15:01.987612+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
6d673bc8-1b68-4a6a-9dd9-1e4e7cdb241f	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	79.6059417757593	bpm	2025-10-01 08:37:35.573267+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
24b329c0-a214-468c-84a2-ab85d747e968	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.971467908607	lbs	2025-09-29 06:54:17.59827+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
d3587a41-0f84-4b0e-be5a-f867cfa5eb34	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	13153.351587452	steps	2025-09-29 03:20:12.37681+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
5a34aa2c-8e6a-4426-9342-d197a4272f5f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.0287231864117	hours	2025-09-29 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
94114552-e4a9-4da7-bafe-841bc221ce70	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2333.63510619392	kcal	2025-09-29 06:07:37.081482+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
a5716ae4-d68d-4d00-be01-4246de2f5dec	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	112.570054594667	grams	2025-09-29 03:28:42.636521+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
38e847e3-39bc-4e7d-8b17-d6ef65be2fa3	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	33.1298650785366	grams	2025-09-29 05:41:59.713621+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
9e1ca0aa-f4bc-4154-a7e9-7ad5d3b328f4	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	72.503679676624	bpm	2025-09-29 04:08:42.329085+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
eb36a4f2-760f-40df-888f-4c34bed21f1a	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	199.513159041148	lbs	2025-09-27 03:30:45.255008+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
a11dd359-fdcd-489b-a6c7-e2f337022039	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6044.89146294733	steps	2025-09-27 11:42:32.433685+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
9edb983e-fb38-4db2-acd2-1b6bc1bc425c	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.91630789272921	hours	2025-09-27 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
4ab17b7c-cb5d-4fdb-884d-6793b89ffec7	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2005.0618397112	kcal	2025-09-27 06:53:01.470412+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
9a7725e8-88c4-4816-982a-8c3d64749290	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	139.203363093415	grams	2025-09-27 11:55:55.875407+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
2b5cea4c-cbfd-440a-bccb-a9235c2aa54d	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	57.2426509682013	grams	2025-09-27 07:52:26.318371+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
7894242f-e852-4500-950d-aee3d1a02b2e	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	74.695333311055	bpm	2025-09-27 05:05:56.97874+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
81b7a66d-f980-4e6b-baa4-9a3f76101cb7	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	198.14578451943	lbs	2025-09-26 09:19:11.036789+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
0f093258-c773-4699-962c-fd0e6214b1ef	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	14625.9737164474	steps	2025-09-26 07:32:11.697721+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
edde5618-26b5-4150-a3d0-ebac43bab725	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.74072743177159	hours	2025-09-26 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
5ce5e3b1-2d0c-4b18-85f9-0e73619c401d	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2164.68307522749	kcal	2025-09-26 08:18:41.711285+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
39939035-80e8-4f29-a49e-399f6aea4856	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	124.722644243782	grams	2025-09-26 02:23:15.51095+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
9c886d4c-09ae-4c63-92da-99d74d486c1b	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	52.6659724694915	grams	2025-09-26 09:57:00.327869+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
6977294b-9aca-47d1-bb52-87f68842f63a	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	82.0301409423071	bpm	2025-09-26 00:55:37.470162+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
896dd1ff-4545-4c39-93cc-683aa964ea3c	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.830596876479	lbs	2025-09-25 06:14:12.158951+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
d06f0315-7a21-4ac0-ac8d-c588514c81bf	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	8430.16011228739	steps	2025-09-25 01:10:57.098369+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
4232c5b1-d7b0-467c-9473-cf5f8e947e28	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.95159354986894	hours	2025-09-25 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
8c056bb2-4f38-44f1-bfd4-4b704ffbe31a	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2094.19262885147	kcal	2025-09-25 10:21:28.87575+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
e7b17ebf-ccc3-4d00-9ec7-96c2b46719a7	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	116.337732366488	grams	2025-09-25 03:41:09.555912+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
770162ed-483a-45c3-aa4f-ff55ff5e0d29	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	48.2966370721122	grams	2025-09-25 04:34:25.582632+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
6cf97856-c7c9-4b25-8ab6-a7f19936273e	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	78.5760042258718	bpm	2025-09-25 10:57:42.161998+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
e1a5ce4b-124d-4e14-abb4-8038c378c8d1	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.850557218586	lbs	2025-09-24 07:51:35.937064+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
44ab6cba-8532-49b9-aca9-62ea4036c71f	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	11232.6506736746	steps	2025-09-24 07:16:45.742788+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
1587ffce-32bd-4d07-9a5d-c2c5dc78d302	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.94430045265381	hours	2025-09-24 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
56553b1c-be2a-4c47-ae08-24e78ddb6a28	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2561.4454048649	kcal	2025-09-24 04:36:53.103248+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
2b1bfca7-0220-444a-887d-45ff743ca961	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	125.806974463047	grams	2025-09-24 04:39:32.437442+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
e2a1967e-a011-4920-9836-6d9d548fa565	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	52.2368881626849	grams	2025-09-24 11:36:23.838582+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
7d9b5f2a-d947-4d55-af36-b7c302642fab	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	78.331365613701	bpm	2025-09-24 10:19:04.506837+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
0a184875-768f-425b-887f-c1fc67ec513b	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	198.943114046514	lbs	2025-09-23 04:17:54.105763+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
be51b3fd-6dca-4f59-90b3-fad6e8474c3e	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	9318.66935075295	steps	2025-09-23 03:43:04.512371+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
0a86ec80-fd22-4bb3-b6dc-2ddbe6f29026	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	6.54342875112867	hours	2025-09-23 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
11822fd8-f79f-40a7-9f36-18578c4b04e8	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2118.61152212543	kcal	2025-09-23 04:37:04.236187+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
e6b056b5-47d1-4eae-bbed-256bf641b037	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	82.9710322941607	grams	2025-09-23 08:02:55.471413+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
a0384865-5381-45e0-97ea-14eb1eba5fc9	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	27.7089333848073	grams	2025-09-23 02:00:06.054425+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
62021039-ec8f-40ac-919e-fcee14424317	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	67.890338088227	bpm	2025-09-23 01:31:32.854193+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
d9eab470-946a-477f-b205-7269e67c5f2c	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	198.503284863315	lbs	2025-09-22 07:17:19.094162+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
bad0fd6f-a5f0-4249-8a9a-7960af07eb91	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	14716.2346035477	steps	2025-09-22 04:00:59.381038+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
1113497a-d7a0-4f26-bdb0-acc96e97a6ad	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	6.88947546775493	hours	2025-09-22 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
f66f6eb3-4b2b-4923-baf6-680a9c1fad5f	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2095.63149311091	kcal	2025-09-22 06:14:14.412125+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
b289f5f8-05a5-4f1c-98b3-219342be10fa	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	93.0742216129949	grams	2025-09-22 01:29:32.680302+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
9bb62e96-6180-4f73-a7bd-2f65f0756661	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	64.6940928547623	grams	2025-09-22 00:00:07.634696+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
6f19ff33-c174-4af1-a59c-703693745cb0	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	77.9205330332263	bpm	2025-09-22 06:33:18.149874+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
a8d46842-b9b3-48c8-a079-d5c9bf51f09a	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.10857011396	lbs	2025-09-21 09:24:06.062291+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
b3f035d9-040d-4866-9ac0-b82653fd4360	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	7223.58313012453	steps	2025-09-21 02:45:26.401222+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
ce003abc-b321-4987-9299-7159999b54e3	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	6.55723468203489	hours	2025-09-21 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
674f818f-9be3-4918-b129-8b3c91701495	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2745.15633164466	kcal	2025-09-21 02:00:07.916652+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
99bfb5b8-d991-49f4-9c10-51f0c0abc48c	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	101.477420456322	grams	2025-09-21 03:46:55.578614+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
eb2aa782-8209-4e45-a600-2506b67f3e82	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	36.1538000202005	grams	2025-09-21 03:37:44.799472+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
4b43053f-8753-49e4-a4be-de998d090e6b	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	68.1382375800318	bpm	2025-09-21 07:21:03.293146+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
9b86af6e-62a4-42b0-962a-3604fa984fe3	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	198.881581105541	lbs	2025-09-20 00:43:43.832229+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
d988c0c4-b245-4fa1-9437-db6f4dcc0f99	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	8498.72936816012	steps	2025-09-20 11:17:25.737125+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
5bbbfd94-4bc4-4e31-bf5a-7b3100e65463	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.04219472445665	hours	2025-09-20 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
adf76155-b9bb-4ad2-b347-0ef7657b3ab7	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2524.7071899733	kcal	2025-09-20 00:16:40.625257+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
84d986ad-0c58-4ad6-9f8f-ce5ec799dac8	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	90.2925536308707	grams	2025-09-20 06:19:15.579651+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
fbd71c01-3556-4603-89a9-0c6a7d5fc1a0	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	62.153385198676	grams	2025-09-20 07:15:07.784299+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
c55f7c33-2340-4e36-87b3-24359ec38191	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	68.5915416757356	bpm	2025-09-20 10:37:29.936216+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
317c3194-1d38-46cc-8100-d575feac4be7	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	198.398399595124	lbs	2025-09-18 11:28:59.80125+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
83784000-dd46-4ee2-8ed4-753fa5a67f9f	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	11356.9192301783	steps	2025-09-18 10:46:40.437637+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
222f94ca-219c-4f30-a342-46be772c830a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.57509978397629	hours	2025-09-18 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
3e692a9a-cd30-40cb-ade3-e1258298dc89	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2594.61137326175	kcal	2025-09-18 04:27:30.100454+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
56aa1532-9f47-47d8-b94e-1b0b1182bac0	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	126.843627220787	grams	2025-09-18 02:53:36.04522+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
43bbb4d6-e6ed-492a-baea-2c6d4be55ced	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	38.1772358569054	grams	2025-09-18 10:15:29.893677+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
bc81701e-964d-4550-9249-6ba2b162a485	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	72.0429600567391	bpm	2025-09-18 06:58:31.756725+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
1bb4067c-3535-4752-8424-db860e6cc76b	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	198.286471635609	lbs	2025-09-17 11:15:55.730253+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
8a278afb-e510-44b0-937b-f986d66b9bcf	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	9791.79127632717	steps	2025-09-17 05:53:53.799354+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
fe121018-672e-455d-a1b5-94547c07682f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.30244807186265	hours	2025-09-17 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
a06e2a42-c2bc-4927-b478-301cb5086971	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2118.78323015288	kcal	2025-09-17 06:42:50.315391+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
2fff3aec-7101-40e7-8d5d-7136889149d6	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	115.922809929725	grams	2025-09-17 01:29:55.87254+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
38826a44-2d96-4ae3-9db2-5833f376d3dc	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	58.870691394872	grams	2025-09-17 04:51:39.801673+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
240b1631-b78d-47b2-9990-4adb949d027e	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	76.6597448709073	bpm	2025-09-17 11:45:52.991286+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
19b74ad8-894c-4c43-af89-5e5e929badf9	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.197478997783	lbs	2025-09-15 04:16:10.044702+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
e66b690a-310c-45f8-805e-b2b31e318cd5	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	13875.4281280718	steps	2025-09-15 05:26:44.990478+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
7d9bacf3-b198-4919-baa0-99a74d5cd50d	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.37991826812953	hours	2025-09-15 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
4db63f78-94c9-440b-b7c3-997e34ffbc6b	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2438.43561745468	kcal	2025-09-15 07:59:02.79512+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
ac00748f-526a-4b3b-9bed-1fdfc3fea55a	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	114.672263710972	grams	2025-09-15 08:36:48.518355+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
d664f8c9-c7c4-494e-9572-e2cea5bf4737	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	44.3249565348361	grams	2025-09-15 10:09:50.113476+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
41014be0-3459-4330-b0ae-f9ad9129dad1	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	70.9015812340247	bpm	2025-09-15 11:44:58.534287+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
197c605d-db26-48d8-8850-ec44a56c9a84	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	198.122644903351	lbs	2025-09-14 11:41:14.446224+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
109572b7-ee70-494e-8c3f-5d8e94fb880a	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	7714.63794196328	steps	2025-09-14 05:24:43.035476+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
964d2ce6-4dec-40fd-ad42-d51482ee5490	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.86764259794153	hours	2025-09-14 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
27c995e6-068f-4154-87e2-6fd7fd2b661f	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2668.35792435651	kcal	2025-09-14 01:39:50.948753+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
f5a3352f-7f2d-47e9-a62e-c730d406ad2b	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	93.917882828284	grams	2025-09-14 01:53:01.748576+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
5bf0cd55-ed5f-42fd-9121-45a8819e632e	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	44.5542074821593	grams	2025-09-14 00:51:24.609631+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
221f638d-171b-4757-8f25-26109f4d5e54	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	74.0471719132611	bpm	2025-09-14 01:38:01.507517+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
a69536bc-70eb-4c71-93c3-133d51609ed3	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.032714104222	lbs	2025-09-12 11:26:22.863368+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
3c8109f3-e8ac-425b-8b79-72f24c6da0f6	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	11486.6275875631	steps	2025-09-12 04:01:33.089397+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
663863d9-7d6b-449e-aa14-c61d307f54f5	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.89269099935388	hours	2025-09-12 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
604138df-25da-4c5c-a889-94f11c2c6b1f	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2335.59174576352	kcal	2025-09-12 05:34:57.911557+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
9dd7b704-331a-48e2-a839-d615046d90e7	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	120.480368660671	grams	2025-09-12 08:42:29.689163+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
4781bd9a-8c19-4240-9e48-c20ef43b532b	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	57.4232459468291	grams	2025-09-12 05:06:16.872249+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
09df7a47-4409-4fcb-8fc0-6026ed3843fd	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	72.6852146407593	bpm	2025-09-12 07:21:10.351492+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
774b4ffb-67a5-4089-a153-e32936e5b720	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	196.767568553245	lbs	2025-09-11 01:00:42.268742+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
d00f9bfe-4f6c-4ebe-9e2f-150f545b0d24	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	11708.8641182848	steps	2025-09-11 08:45:05.417367+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
551e08de-d97a-457e-9959-a766a919a0e6	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.34735632644446	hours	2025-09-11 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
9012ffce-9c8b-42ee-a23d-a5ceacf32f25	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2239.32610580214	kcal	2025-09-11 02:05:48.988666+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
8ef3b6ab-594c-4d7a-9342-adf4319c999a	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	95.5292863573688	grams	2025-09-11 05:45:00.283658+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
d76c595b-dab8-484a-8a64-41ad4426b9a0	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	49.595993273499	grams	2025-09-11 01:22:42.115062+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
67200f3b-1ca9-496a-9874-387cf311012a	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	71.8584074476088	bpm	2025-09-11 11:06:15.455574+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
61efc932-74ee-486e-8535-e9430c996fcb	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.153557487243	lbs	2025-09-10 11:41:03.016957+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
7a6e6d00-575a-4fcd-9de7-024b22c80b1f	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	9117.74748188022	steps	2025-09-10 07:50:15.604015+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
676eb3d8-649b-4852-ba58-8cc544a9fbac	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.61166824255188	hours	2025-09-10 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
2b24ef4d-6a7b-43e6-a7ea-7b961a3c2059	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2674.57693247769	kcal	2025-09-10 10:28:37.285763+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
36c54265-f63f-43d7-ae85-9f9a14b68ddf	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	90.2678360873023	grams	2025-09-10 01:30:16.817067+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
2664081a-ac21-4773-b2f5-ec17cd72c147	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	46.4039523242653	grams	2025-09-10 08:30:11.069221+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
465cda1c-dde1-42ba-8aee-c9fd92c2c898	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	75.3761288046793	bpm	2025-09-10 10:26:28.332258+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
492858c7-8266-4e8d-aff3-8a1cfdc60fb7	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.90457486488	lbs	2025-09-09 06:55:28.847099+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
0228dd02-0f43-4ae2-bf3e-6bdfa1d0ab14	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	13440.4243904371	steps	2025-09-09 03:22:40.765014+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
3c786cdc-2dc3-4b79-a245-64290db51dee	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.47489792966289	hours	2025-09-09 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
2056c577-ba7e-46f9-b741-46ad03fd863a	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2425.12981319419	kcal	2025-09-09 00:25:41.638649+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
3a2fc34b-7589-43cd-88c0-654fde8d936b	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	100.113782438837	grams	2025-09-09 11:38:23.835971+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
9c8c2c7b-b636-40c0-b6b1-07b0ee2f0d8a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	48.3403256964592	grams	2025-09-09 05:04:55.093967+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
09bb4a49-8de8-468c-9216-5582a4be51a7	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	84.1113066147971	bpm	2025-09-09 00:14:42.835883+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
8d65d158-8212-411b-9641-8af9015f49f8	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.410526519732	lbs	2025-09-08 05:04:43.069261+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
8cf5ffcd-f029-4e9c-a3a3-5d6df0a0a437	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	12654.5939938325	steps	2025-09-08 08:55:56.428317+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
bfd4c3d5-fe72-432c-bb6e-7e7dbe98b637	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	6.82862448755252	hours	2025-09-08 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
36c5008b-a74b-4146-a2b2-ed7124b5739c	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2586.7774894836	kcal	2025-09-08 02:30:35.177036+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
e5c2e32a-d91b-4ec9-9b07-aaa6b4dbabf3	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	134.608760651002	grams	2025-09-08 01:59:48.206026+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
61a86cb1-9691-479e-9d7d-0b27c6122e96	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	37.1973262964007	grams	2025-09-08 01:38:03.51879+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
0e60ca96-eaf6-4787-a879-080bb22f9594	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	80.7462870548641	bpm	2025-09-08 04:54:38.968799+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
82d20c83-0110-42e2-b3d7-77596df9462a	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.373983769458	lbs	2025-09-07 02:41:39.471541+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
84f1b32c-ada0-4f5c-ad02-a10cb268c66e	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	8719.63925363986	steps	2025-09-07 07:44:03.389432+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
164c48c5-d86c-48e7-87a5-4f4771368fff	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	6.54451938960182	hours	2025-09-07 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
0c0b9265-50af-4a45-a547-1698a9f995a2	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2753.03936181972	kcal	2025-09-07 01:27:07.645585+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
d50462c1-6a20-4666-a8b4-50e88ddafbb0	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	89.9836684037496	grams	2025-09-07 00:55:36.2707+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
92d959da-4068-4329-9621-9cf068d6edb5	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	38.2393172613918	grams	2025-09-07 11:17:01.145548+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
1f4d33c9-9575-4c33-b861-5a52e127e818	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	65.8511892640122	bpm	2025-09-07 10:08:38.965368+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
fad108c8-3fd1-4cab-b794-16ea34ac495d	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	196.346555424919	lbs	2025-09-05 11:53:35.909157+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
4f29260e-21ed-4e4c-9956-82cac577d685	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	11624.315054715	steps	2025-09-05 06:48:00.689395+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
aca28d9c-6efe-405d-a724-c8a88740ebbc	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.95339457365232	hours	2025-09-05 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
f4d5436a-9413-4a12-8a81-65adaf5553c2	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2217.14236875522	kcal	2025-09-05 02:34:43.539628+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
89d14c3c-74a1-4048-9474-a6695b4cde12	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	119.821649036676	grams	2025-09-05 06:47:28.318667+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
3c928f76-30b6-4691-a340-34b0ccaeda08	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	44.7957817313092	grams	2025-09-05 10:00:17.849089+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
f8f02b95-c578-4583-a09e-a79609243bec	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	74.3581594204922	bpm	2025-09-05 02:57:21.702397+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
3d361dfc-80eb-41c3-a796-b70730356c86	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.509121357267	lbs	2025-09-04 09:30:29.816969+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
966c1d01-7e92-43b9-9da0-f480e08d7dbd	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	9674.09953269481	steps	2025-09-04 04:57:37.506102+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
b528cbb2-f60e-4d0d-a02e-3c8b76def4ac	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.54567263508411	hours	2025-09-04 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
eca37d22-510d-48bf-b94d-294ab1f6765d	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2099.13341308285	kcal	2025-09-04 01:08:40.505549+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
07c870a4-2111-4eb8-b762-16a77483f179	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	83.9629478986996	grams	2025-09-04 10:11:31.413567+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
c9ac26d7-cb4c-4c99-a0ab-5531c6e3f4f6	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	40.0071266879962	grams	2025-09-04 04:30:59.453953+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
d28c4650-cb95-4a87-98c3-16996230ecae	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	83.1666060259084	bpm	2025-09-04 11:02:36.441987+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
b68765f9-da4f-4792-b4ba-be9c4661c803	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.471279395975	lbs	2025-09-03 05:44:17.482499+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
c6e26d76-45de-49ed-a584-9d4b4631cf32	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	8978.08655377005	steps	2025-09-03 07:20:30.721814+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
5a0b6394-7dca-4fff-a8bf-d5ad54e1a627	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.80697742121351	hours	2025-09-03 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
2728df19-fb5c-4ff7-91bc-afd5673c9503	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2692.29908514752	kcal	2025-09-03 07:08:05.557436+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
b6a9537a-cae5-4adb-b23d-83b48c7b03c2	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	133.156806774981	grams	2025-09-03 06:53:41.746044+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
03692eb2-6852-40dd-be49-a2a5258dac80	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	57.8326412467911	grams	2025-09-03 08:49:49.680695+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
83e506c9-9e91-4093-9f9c-281ad047d87c	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	71.8614660466351	bpm	2025-09-03 04:51:43.5383+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
efd16065-f5d6-442b-aaee-77c0fbedee51	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.417178416073	lbs	2025-09-02 05:38:46.590936+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
c9735bba-992c-4d94-85c9-93fa7db09d13	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	14973.7293366106	steps	2025-09-02 05:09:03.473346+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
3a4e3f15-b848-453d-abd7-721f15bb3f77	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.06819915422016	hours	2025-09-02 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
d9662fc1-e61e-474c-b0ed-963a4393d0df	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2416.39644380502	kcal	2025-09-02 01:48:58.687618+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
17772bc6-6f68-46dc-8e19-34d87e5a71b2	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	132.311925458604	grams	2025-09-02 05:30:13.587001+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
b447ce49-d254-49b6-9824-ecbf833deda1	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	27.0296680567078	grams	2025-09-02 01:42:09.240226+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
21103ff9-e3dd-44f0-a3bd-7e1a80b15b4d	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	81.1917817735335	bpm	2025-09-02 07:30:57.505881+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
b881a2b3-ca70-4ce1-bbd6-948fa4302731	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.182593816811	lbs	2025-08-31 05:58:36.365322+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
3e5090b1-398f-4f61-ab16-54224056304a	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	8567.1559415677	steps	2025-08-31 04:50:09.761711+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
02a25871-ecad-4b1f-b259-cf46f123bf84	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.49256714361505	hours	2025-08-31 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
ed6a21fb-1bfd-4096-8944-cc5ca656e705	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2532.31863488586	kcal	2025-08-31 02:57:34.605241+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
18c96b17-0ff5-4ddd-8ca8-edcf73331be2	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	92.8614783414515	grams	2025-08-31 05:21:02.109111+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
3279d214-63e5-4a7a-be80-4bf840c8027b	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	40.0567052580456	grams	2025-08-31 08:54:24.685839+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
55a52c39-d7a8-40af-b1c7-4c2c0920b9d6	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	73.1476956106279	bpm	2025-08-31 10:24:55.819951+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
cd5f1b2d-369d-4786-b82f-d436055c059b	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	196.492370365066	lbs	2025-08-30 11:42:12.02348+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
f7029e26-f367-463c-a987-347cce28a995	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	8757.02629332543	steps	2025-08-30 04:07:02.606797+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
11fd7519-91c8-4f26-a0c0-fd5a9d111fd3	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.80414509200161	hours	2025-08-30 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
a70c2bf6-5dea-410a-b1cb-c342bfcccd1e	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2043.60151872396	kcal	2025-08-30 06:27:09.412093+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
cceccf67-0481-4c19-bf6d-4697be135f24	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	86.3563634047282	grams	2025-08-30 01:02:17.22901+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
7cd1ed72-d54a-475b-8ae6-c93cd96df246	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	27.0632256464377	grams	2025-08-30 04:51:18.195425+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
d3c4c5ad-3f2b-46e5-9484-843422903e93	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	80.0476800447023	bpm	2025-08-30 11:44:46.766156+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
bf510713-2122-4ccc-979b-2ec6837b510d	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	195.56694687506	lbs	2025-08-29 00:15:41.013196+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
285ea78a-ecba-4797-ae41-b2e088464846	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	8657.87537522178	steps	2025-08-29 03:57:34.455111+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
31243342-ee95-4dad-b93a-d2bb2ff70e12	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.08575873925834	hours	2025-08-29 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
c6765fc7-af40-47e4-93fd-e71d7e17b923	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2020.5628391706	kcal	2025-08-29 01:29:56.979266+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
7ddea4b0-882b-49cd-8e2e-7dc6678f936f	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	85.8888466234692	grams	2025-08-29 10:19:19.194293+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
32180926-b14c-4542-8d51-b8c090b0b1ba	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	55.68585519617	grams	2025-08-29 09:11:53.572303+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
8f843750-6cf4-42af-a63e-f8cf470d2366	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	71.4353275581381	bpm	2025-08-29 10:59:35.958461+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
047860ae-e881-4c39-97e5-7ceadcc60f07	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	195.201849109903	lbs	2025-08-28 09:41:48.465734+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
2cd5665c-2b20-4a53-a0cd-07e372877da1	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	11224.2970232415	steps	2025-08-28 01:48:29.828604+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
01c88b6b-0484-4cf2-aad2-c8c1299a2072	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.87708914224292	hours	2025-08-28 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
14aa926b-225e-46ed-869d-639bba67c851	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2330.00771081546	kcal	2025-08-28 06:33:16.303871+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
e9ac76ba-d763-4530-997e-ff32dcfa24f4	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	119.203056221266	grams	2025-08-28 02:36:54.333624+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
e0c80efb-8f64-4fb1-891f-b9189b1394c2	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	25.1014489747929	grams	2025-08-28 09:14:21.829595+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
065d69d0-5449-45b1-9705-3439aed63f53	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	73.5656997187291	bpm	2025-08-28 05:59:18.255159+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
5d0da69c-18c6-4456-add3-355a8bb68672	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	195.81851950956	lbs	2025-08-27 04:12:16.469077+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
eb7bc63b-c1ff-4bcc-b31f-f9f1afd315f2	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	13819.1728264716	steps	2025-08-27 03:13:19.704933+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
e2bf3f28-f334-46de-b1a5-c5f7787a637a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.92881421080828	hours	2025-08-27 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
3f12d2ed-7f76-4599-847b-427945b88346	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2662.9359110129	kcal	2025-08-27 09:32:12.372053+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
73f019cf-0e42-4f22-b3cb-b4b8afc9a904	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	123.605915037808	grams	2025-08-27 03:07:18.648279+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
5da39f32-cebf-49f1-bbce-b249eefd4257	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	62.53756635631	grams	2025-08-27 03:34:00.798862+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
f6a3fc6e-5264-4a7a-b902-c49913f8da39	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	74.9873001504701	bpm	2025-08-27 03:57:17.638254+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
ea50de0a-8495-45ff-b777-f894e619e3ac	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	195.907199422927	lbs	2025-08-26 00:25:52.568287+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
d562745f-a21b-4c37-9c20-d0d8effe709f	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	11955.884567186	steps	2025-08-26 01:44:51.708254+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
c17fe926-6291-408f-a8cb-dba6e669ad11	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.04396957537093	hours	2025-08-26 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
7ea27440-c432-4b00-96f7-854779963eb3	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2367.92082577196	kcal	2025-08-26 03:10:37.152368+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
c3267cf1-be49-4b92-81dc-24491b2acbff	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	115.066081518974	grams	2025-08-26 03:00:03.017499+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
95356f2e-5ba7-4968-b09a-64b996794131	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	51.2549730819388	grams	2025-08-26 05:59:42.098124+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
a8c7bf83-5fa5-4134-a663-d8579f1fe5d8	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	81.4758438084765	bpm	2025-08-26 04:09:47.368215+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
12313d51-ef96-45ba-aa7c-321dcec83056	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	196.012406871671	lbs	2025-08-23 04:10:28.711731+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
72f63ed3-cfae-4beb-b8dd-4da7ebdc8139	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	7750.19946229646	steps	2025-08-23 02:54:46.041084+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
7db216bd-b0cb-413e-a3dd-9b590082bfce	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	6.68473660290776	hours	2025-08-23 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
34785467-5a62-4580-b5d7-e486f9cfd35c	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2531.45372889487	kcal	2025-08-23 00:44:44.293974+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
8d3a3854-6214-412b-b308-11e6e4ea326f	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	84.5559372500178	grams	2025-08-23 02:42:47.457388+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
29e640e4-5d34-4483-9835-981ef05a5920	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	37.2216908655423	grams	2025-08-23 09:59:28.666974+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
fbffd40d-ad07-41dd-b3ab-5b86fc57e435	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	75.2236870051069	bpm	2025-08-23 09:14:45.455595+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
f31158c2-1c98-4acc-896b-df6efcf71b39	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	195.751801392926	lbs	2025-08-22 01:59:27.362209+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
e5345d4e-4a07-40be-b2a7-e07880bb82a1	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	13412.8979162938	steps	2025-08-22 02:50:12.531545+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
7f576fa5-5c97-40ab-8611-387b736eb8ac	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.21811919635403	hours	2025-08-22 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
b7791bac-c8d0-484b-a641-42d692e39218	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2274.90869414475	kcal	2025-08-22 06:27:41.930354+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
303ed810-ee15-4fa7-98b6-c689bb291875	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	91.6722690361722	grams	2025-08-22 02:38:58.076408+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
5571e58d-12a9-436f-8935-c310460b6384	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	51.087603062827	grams	2025-08-22 11:26:44.363142+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
849026c4-d9e5-476b-a73a-198c4795e79f	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	68.0418227644245	bpm	2025-08-22 06:29:43.836193+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
fba3b7de-26fc-4ff4-86df-11154936de5b	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	195.039951935181	lbs	2025-08-21 10:36:05.623554+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
b9d4f3f1-f858-49cb-8746-b8a804df9ded	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	13916.2515486006	steps	2025-08-21 01:09:33.602585+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
76cda2be-08c5-45c6-89bd-ed6e504e451d	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.46135105976551	hours	2025-08-21 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
39839a85-8bc2-450d-a57b-e5743ccd1b55	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2302.67600384192	kcal	2025-08-21 08:14:16.309333+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
d952ffd0-5661-4c3a-818b-f09d903ca095	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	121.992779526116	grams	2025-08-21 02:18:13.253509+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
c965dc52-8f93-4ed7-a7bb-f44f5417dfd6	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	28.1746570726077	grams	2025-08-21 07:54:43.512585+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
a6ba7c3e-2e7b-47c7-9273-e8cd654b33f2	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	69.7514789006695	bpm	2025-08-21 01:51:20.158314+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
7bc7fc3e-392b-4376-92d2-8713966a31c4	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.78846378552	lbs	2025-08-20 11:00:40.22682+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
a9994fc7-f05b-4024-9f60-3b25f6dfd65c	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	8189.37600192442	steps	2025-08-20 10:09:05.898742+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
b2d426fc-d89c-41e9-858c-9442599a0464	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.34760332681564	hours	2025-08-20 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
63e17e7a-d8a0-4ef8-93d1-bcee9d493d7e	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2349.32345621323	kcal	2025-08-20 02:12:06.180753+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
b7e437b9-16ea-4771-9879-a508278b36b4	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	89.5996730029571	grams	2025-08-20 09:37:31.472621+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
c8802845-5b22-4a86-b1b8-ab44355cc5c0	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	46.8747390763522	grams	2025-08-20 03:42:57.064726+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
add14fc6-8a0a-4e54-9178-13be04bec82b	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	71.1695892337279	bpm	2025-08-20 09:46:32.162791+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
f5277a14-eb6a-41d7-b1f7-5a08b03ecd3e	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.646783896234	lbs	2025-08-19 10:11:39.688168+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
0c996654-5bd0-4a99-8436-b1029aab4548	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	13454.6238941255	steps	2025-08-19 08:00:44.130282+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
fc1402aa-2a0a-4578-b2a4-d9d95bd09134	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.25707010553068	hours	2025-08-19 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
029a23b0-145c-43d3-abf2-fe9ceef6717b	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2297.14404812498	kcal	2025-08-19 05:16:26.450581+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
b7a820aa-9d53-4802-8f0e-f73dc14d4ea6	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	83.4673111378248	grams	2025-08-19 11:29:59.526361+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
ab0c6d6d-fe19-448c-a219-50f6ccbf24e6	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	33.1167325167858	grams	2025-08-19 00:26:15.15669+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
5f3210ca-888c-47eb-9ed7-3336f6390c3d	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	82.4594775844297	bpm	2025-08-19 00:30:43.830522+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
5163055b-d356-414b-b23c-94246453f526	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	195.098013245646	lbs	2025-08-18 07:00:02.040464+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
ce10aaf2-75bf-4782-9607-74bfec72af24	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	14158.2250831588	steps	2025-08-18 00:25:36.902777+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
a63b14ac-c260-4383-a4a5-a9137f0bfd50	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.26047499434013	hours	2025-08-18 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
02847fba-306d-4899-9a76-b0ea05ec6d68	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2635.03157703301	kcal	2025-08-18 05:53:52.021495+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
b647a58d-21be-4d43-8494-f9e5d0c6fc51	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	134.836250881818	grams	2025-08-18 01:03:39.436933+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
6b64f749-dad3-4588-9c37-14a58c830561	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	26.9043776237361	grams	2025-08-18 02:04:04.468928+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
6610c2aa-6f5c-49e4-8ff3-da6d483a5095	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	72.0909552043657	bpm	2025-08-18 07:21:04.294368+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
1bc20435-04df-4a99-ba1c-21eb56e59f54	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.259028697863	lbs	2025-08-17 11:26:14.887326+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
483457f7-e6eb-4adf-9db7-15ff02852323	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	9367.10060889316	steps	2025-08-17 03:18:55.490018+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
972ec70f-cf7f-4bc4-94b0-c613ed69bca5	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.47504177649756	hours	2025-08-17 07:00:00+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
15bcb05e-b9a6-4bdd-8228-9dc9f7d81773	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	2129.53634674457	kcal	2025-08-17 11:01:43.874819+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
1ef73b96-ef87-45fc-801c-e114ba1694a3	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	121.402279923734	grams	2025-08-17 11:23:17.965228+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
22128250-be34-4f0b-8ce4-d69a7cf2d0c5	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	49.6755276527686	grams	2025-08-17 03:37:46.185032+00	manual	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
af5edcd6-b7e9-4089-a188-9368729cf259	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	70.236313301152	bpm	2025-08-17 11:44:17.91162+00	healthkit	{}	2025-10-14 07:09:15.931341+00	2025-10-14 07:09:15.931341+00
585de4ac-b151-4899-a919-63c653a09897	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	195.4899634318279	lbs	2025-10-14 15:59:22.322+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
8ed435a9-ff5e-46d7-925c-8c9e7cc254d2	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4417	steps	2025-10-14 17:53:56.882+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
51210d1a-a4b7-490f-bbec-29a802efd595	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6897	steps	2025-10-14 23:55:17.914+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
55c1bf00-e802-44c3-bf07-24229b9a56df	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	74	bpm	2025-10-14 14:54:55.845+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
2ab73eff-0f3c-4b38-99e1-c4eac52f6172	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	55	bpm	2025-10-14 18:44:46.084+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
f606fadb-8da5-4379-9624-9df04bfc5cd5	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	85	bpm	2025-10-14 20:20:56.312+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
b08c012d-c9ab-4405-a13f-c93fab093721	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	66	bpm	2025-10-15 00:02:48.75+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
6b6ecdc6-d437-4b0c-8cb3-864babce7e3e	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	70	bpm	2025-10-15 04:18:06.625+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
ffb6c427-9ba4-4523-8d19-848b75714099	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.895654816155078	hours	2025-10-14 15:37:23.718+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
9d1d7298-1059-40cc-9862-6fd200d2a919	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	632	kcal	2025-10-14 15:14:24.565+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
0382774d-12a6-40bd-b29f-7af9003a1b3e	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	853	kcal	2025-10-14 20:01:56.842+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
95aa9d18-5814-4338-8816-f9881651e611	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	810	kcal	2025-10-15 03:05:11.756+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
ee49d370-5f82-4309-852a-039f16a3bc5e	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	27	grams	2025-10-14 17:05:58.912+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
cce1d552-bb1d-45e2-a23d-917f8accce77	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	31	grams	2025-10-14 21:58:53.376+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
69c808cf-4317-4bbe-9a22-4f0adb18fd9b	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	25	grams	2025-10-15 01:49:02.877+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
77decb25-26d7-44db-bef3-94ce5d4f89cd	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	37	grams	2025-10-14 16:28:40.168+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
8cb95ad4-6cdb-4c17-ace6-60e17ab2db51	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	23	grams	2025-10-14 19:30:10.334+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
1f2a8f8a-9780-4747-b823-730553094974	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	30	grams	2025-10-15 00:49:42.989+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
1fc13079-eed2-41ad-82be-b4b59c704611	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	27	minutes	2025-10-15 01:46:03.539+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
cf0f6aa8-4654-4fb1-8385-82b7126711ff	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	196.7795742006914	lbs	2025-10-13 15:00:32.027+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
a4e65f16-d4d2-44e7-bbbd-40efd35162d0	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4689	steps	2025-10-13 16:29:32.845+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
a087fdb5-1729-4db2-aed1-af77881f5a83	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4157	steps	2025-10-13 22:20:22.304+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
4bdbd16e-eec8-460c-abd9-0bcdb97ea694	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	71	bpm	2025-10-13 14:22:54.35+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
8148c50f-3f38-4aaa-b229-14bd497f5f62	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	94	bpm	2025-10-13 20:55:03.787+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
827ae584-741e-4d3d-9960-f33ed39f866c	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	63	bpm	2025-10-14 04:34:57.223+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
282f6549-abc5-41d8-a880-1dfc40a431ab	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.2052379151919865	hours	2025-10-13 15:43:13.598+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
cbc1ef50-ea2b-44ed-b28d-77cd6877b9b5	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	829	kcal	2025-10-13 15:20:46.111+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
9c3628e0-80b6-4bc0-b21a-bf3f60988370	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	508	kcal	2025-10-13 21:45:06.066+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
19da27fe-c429-4678-94f1-60dccd889f9a	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	558	kcal	2025-10-14 03:04:49.903+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
36b9a253-76f4-4303-8e8b-4f5a1e962e57	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	48	grams	2025-10-13 14:36:00.036+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
ef34ead2-a119-4228-9ab8-8938552529c8	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	24	grams	2025-10-13 19:27:06.922+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
7af1bb43-21cb-4dca-83b0-a480bfa021f7	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	56	grams	2025-10-14 02:45:20.73+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
adcf7055-5208-4832-ba12-f69dd4ad6685	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	24	grams	2025-10-13 15:38:11.69+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
35da1c9b-a6ac-499c-9334-05c859d16ee6	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	30	grams	2025-10-13 19:42:10.494+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
5c3cb62d-66a7-42ee-9bfd-317a9988478c	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	20	grams	2025-10-13 23:18:10.825+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
7d2e5f9f-f7f2-481e-ad30-f76b9821c186	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	13	grams	2025-10-14 03:47:00.898+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
b8da752b-ad56-4a9a-943e-e423993cdd22	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.9743056612483	lbs	2025-10-11 15:50:11.861+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
83e3646b-36b0-4a52-8f67-7b62f190b6f7	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3440	steps	2025-10-11 17:57:38.45+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
558d46fd-4868-44c0-811a-1b5a8ea75ec4	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5022	steps	2025-10-11 21:35:32.099+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
8848e162-e935-4ff5-ad0e-2c3611bed8d4	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3142	steps	2025-10-12 06:42:06.593+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
245d5fd3-b5c4-474f-b25a-1084695e311e	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	56	bpm	2025-10-11 13:19:52.826+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
10f4ed46-d8d8-4bf4-b317-954bd6522f6b	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	80	bpm	2025-10-11 21:44:44.265+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
2bbcf59e-5a47-4ee3-96bc-e7b6997699c1	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	62	bpm	2025-10-12 05:16:16.144+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
6529cb5d-047b-40c0-89c0-92db746c226b	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.656531882132597	hours	2025-10-11 15:57:32.933+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
9ef27e03-cf7f-4e74-810a-faa82c586ebb	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	834	kcal	2025-10-11 16:57:13.465+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
269b3182-bbcb-40b9-a78f-f207d7a20ee6	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	864	kcal	2025-10-11 21:19:59.164+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
11382075-99bf-4e09-b456-3b9cc3975670	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	47	grams	2025-10-11 16:55:16.753+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
e56e4105-e8c8-4186-ae46-240f2688ea04	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	28	grams	2025-10-11 22:04:52.935+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
b45df5e5-7378-4429-90f6-31d23d2d4593	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	36	grams	2025-10-11 15:17:45.721+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
5322a59f-5a28-4a88-9505-8b71f0601bba	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	27	grams	2025-10-11 19:36:41.36+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
2c7789bf-bbf1-4b3b-bf1c-751924be8d4a	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	50	minutes	2025-10-12 01:02:20.253+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
bcf9ef34-b5a0-4eca-b037-2884b3addd7c	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.66398604995783	lbs	2025-10-10 14:29:14.323+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
f7cc910a-bf22-4ed2-99af-2b475bad809d	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3697	steps	2025-10-10 19:02:34.023+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
aaf9d013-6995-4b08-b545-1755bf3c9479	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4381	steps	2025-10-10 22:33:54.948+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
efa8b94b-e0f5-43c3-bc3c-b4e3a758d037	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	75	bpm	2025-10-10 14:05:02.762+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
8bae35cb-adde-4ec3-9cff-2e35b7a75fdb	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	69	bpm	2025-10-10 18:28:11.607+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
61137003-c7c1-49d4-b6b9-ec8c6c8328f5	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	80	bpm	2025-10-10 22:08:37.617+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
f2ed5213-b8ca-4121-a460-0020b8e6cccb	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	68	bpm	2025-10-10 23:47:35.03+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
780ca82c-3d9e-46ff-8457-e1a015d20983	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	72	bpm	2025-10-11 04:30:10.594+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
3ad7658f-0bef-4f91-9477-0b3b0891717a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	6.882201422215881	hours	2025-10-10 17:16:34.436+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
7afc691f-5d2d-4ee8-b3c3-9110d2e10db8	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	671	kcal	2025-10-10 16:46:41.641+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
2466b56f-79b7-4186-8d36-ff86d19951a1	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	463	kcal	2025-10-10 19:46:12.979+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
871250ca-1724-4a73-8dbc-08478d6f86d3	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	766	kcal	2025-10-11 02:10:56.282+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
719fc467-e9a9-400b-a98c-ebce3c896f97	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	54	grams	2025-10-10 15:47:10.938+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
3d4c9219-8efa-4a5f-b350-4c8712426fc1	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	26	grams	2025-10-10 19:28:13.881+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
8404385b-84b3-4dc0-b164-0092ac40d1f2	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	22	grams	2025-10-11 02:34:11.379+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
11358ea2-f534-4d8d-bfbf-2c25a7f5467a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	17	grams	2025-10-10 15:47:26.074+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
1734391a-066c-4bdf-a9bb-07947b1b85a5	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	40	grams	2025-10-10 20:06:01.923+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
c36f0b0c-c6d5-4aad-bec5-f45a0cbca4be	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	25	grams	2025-10-10 23:54:36.12+00	manual	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
c04f7c8c-1ac6-4fff-be3a-718184704175	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	21	minutes	2025-10-11 01:46:58.799+00	healthkit	{}	2025-10-14 07:17:06.318+00	2025-10-14 07:17:06.318+00
73955f9f-89ec-4e9a-b9f5-16ba27087e94	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	195.53983846282736	lbs	2025-10-09 15:52:36.234+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e72740da-035d-4e9f-9452-31d93726355f	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3949	steps	2025-10-09 17:27:04.027+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
424b759f-728b-4831-b9ff-dd5e5d2491e3	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6598	steps	2025-10-09 23:56:55.562+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3f9dc6fa-2f57-45ed-aabb-9bd2d7571011	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	57	bpm	2025-10-09 14:47:31.441+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
cf2269df-6fac-463b-b5f8-016fec328090	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	80	bpm	2025-10-09 18:56:13.68+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
07758fdb-77b7-41b7-8f37-9d8c6f9dc2bc	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	75	bpm	2025-10-09 23:37:36.061+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4e48b66b-0f7f-452f-9e79-69387541cca6	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	68	bpm	2025-10-10 04:08:20.094+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
067bd76e-f6da-47e1-9cae-8ace70930966	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.1223232147185	hours	2025-10-09 16:34:38.938+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f8ddcec5-7b94-468e-9ee4-a24851623ede	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	556	kcal	2025-10-09 14:25:43.436+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f102a526-72ed-48a7-bf9e-9ec15f20d831	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	819	kcal	2025-10-09 19:35:14.601+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
eaaaa489-e8be-4fa1-a512-bfbf9eea3c0b	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	468	kcal	2025-10-10 01:53:18.598+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9f55f12c-dfd7-4891-bd8b-537d96e9ed21	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	56	grams	2025-10-09 15:30:55.487+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1b508d61-d719-4868-9870-5f3273bbf32d	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	55	grams	2025-10-09 21:46:27.32+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d4ad93fc-2b4c-47c4-8925-108586d106c2	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	36	grams	2025-10-10 02:37:14.916+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5f156b21-ab78-470d-80ca-c56b2b10c132	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	32	grams	2025-10-09 16:40:13.159+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
cb2adf5b-286c-4e9b-9633-8a21aa294165	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	27	grams	2025-10-09 20:58:54.757+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f391d923-31c1-4bb8-ae24-608a7d6bc9b2	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	193.09666871513218	lbs	2025-10-08 15:38:55.909+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
08720ab0-47d3-4947-8c80-45eb8c35e001	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2025	steps	2025-10-08 16:35:52.26+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
37bf8f5a-8747-4afe-83a3-07f7a744e138	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2657	steps	2025-10-08 21:41:50.357+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5a626517-4d04-49be-a744-913d559187a0	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5852	steps	2025-10-09 06:57:55.86+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5854089c-1bc1-4d03-91ba-b0d481245a3d	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	62	bpm	2025-10-08 13:59:53.559+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
385eddb0-c32b-4aa8-a87d-d2ad1a69375b	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	93	bpm	2025-10-08 20:43:10.607+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d9d0a9ff-de41-4e1f-bd58-11ab932ce220	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	73	bpm	2025-10-09 03:27:42.385+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6947bc5c-e87e-438d-ad3a-7f981048279d	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.087068460100443	hours	2025-10-08 17:10:58.678+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b37064ff-9fc0-44e5-b31a-20b531c65c1f	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	672	kcal	2025-10-08 14:40:35.192+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
26fb05db-6e77-49fe-9d32-b967aba05073	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1189	kcal	2025-10-08 22:02:15.306+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
92d4793b-c88c-44c1-a6d8-591e4b19c05e	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1112	kcal	2025-10-09 02:00:15.203+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a6002c41-ec3a-4000-9e8f-fe795b61300d	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	48	grams	2025-10-08 14:53:27.327+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
188b1c3c-b4d8-4ac2-9ae5-b6349b5e0f66	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	38	grams	2025-10-08 19:26:29.014+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5a962f12-9aed-4e53-a19e-508b040914b7	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	35	grams	2025-10-09 03:06:16.831+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4cad7f3b-4dd8-4bd4-84e4-c5c4359126c6	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	17	grams	2025-10-08 15:36:54.182+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a7d4b4f9-74b6-467d-a0d3-bd12289d9cd0	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	39	grams	2025-10-08 20:17:00.767+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
61be3268-f6fa-430c-9811-f1c963101fb1	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	77	minutes	2025-10-09 00:23:54.125+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
75c75514-cada-4e65-a15a-cfdf97c657be	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.88456556546893	lbs	2025-10-07 16:01:12.501+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9d8d048c-c40d-4289-b9b8-0cc8960c098d	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5702	steps	2025-10-07 16:02:14.676+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8916c96f-fff2-4f26-bc6a-5cf7b7b15ba1	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2149	steps	2025-10-07 23:59:31.701+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4ee7b1c3-8038-46d7-938e-b122f3bbc430	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6996	steps	2025-10-08 03:58:43.969+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
cec8d041-8a92-4c11-b8f9-abaab86f87ea	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	70	bpm	2025-10-07 13:31:11.875+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d4302787-7a10-4607-8fe6-9eb8fe46156c	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	57	bpm	2025-10-07 17:07:39.505+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0f82f26a-c31e-459a-bdc0-a405259a3f11	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	92	bpm	2025-10-07 21:22:01.535+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5e458f75-ca45-4f0a-8264-3dc76df1ead8	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	62	bpm	2025-10-08 00:15:48.682+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
40abc84c-6dba-46d5-a7f6-8fb64b682deb	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	73	bpm	2025-10-08 04:07:42.028+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
aa46b1d6-a084-44de-a61e-9774dc28621a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.515573645750042	hours	2025-10-07 15:26:13.046+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
96dfbe75-ae84-41c0-a7e3-7b46ca7df448	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	929	kcal	2025-10-07 16:38:51.715+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
97124d4e-7451-400a-8217-81daba7f3092	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	967	kcal	2025-10-07 21:03:22.019+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1ae7b5fa-923b-4505-bb8e-c937bf20218a	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	42	grams	2025-10-07 16:04:46.792+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
babd071b-f3a7-433d-bd07-3a898ab6fa05	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	32	grams	2025-10-07 20:19:45.126+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f20e9824-c53b-4a31-a3c4-f087a502a96f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	33	grams	2025-10-07 16:05:37.338+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8fd2d4f9-746a-448b-b6c5-e179d1214048	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	26	grams	2025-10-07 20:21:56.336+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
7eaccb94-e8bf-454f-a65a-e15432c7dbd1	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	192.9487834001337	lbs	2025-10-06 16:09:40.026+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1a1212c2-0ca5-440a-8121-a8fca26255c2	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3946	steps	2025-10-06 15:31:24.309+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
20c3c4d7-dd85-472a-8875-4dfd3de2ac78	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5054	steps	2025-10-06 21:29:12.089+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e112f649-39a8-4919-8896-5f9d11cb06d5	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4640	steps	2025-10-07 03:36:47.744+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f62ced21-ff30-4e5d-80f3-a43604665497	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	67	bpm	2025-10-06 14:04:18.706+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
750a6daf-2739-41d8-bd54-7dccba3de217	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	81	bpm	2025-10-06 18:47:55.412+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
7e600ffc-8631-4ccc-b594-aec01203841b	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	92	bpm	2025-10-06 23:00:38.631+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a4d57bd8-5c6c-4286-9991-4c9aa2b9744c	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	75	bpm	2025-10-07 05:10:48.935+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
16391704-f56f-4e80-91f1-ba1b0416dc4f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.670779089206432	hours	2025-10-06 15:39:26.971+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4eb32389-ad96-4b78-be71-05157251f4ba	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	797	kcal	2025-10-06 14:43:07.853+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1d055f6c-8612-4abf-af8a-4ceca6ed667b	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	886	kcal	2025-10-06 19:29:46.878+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1b40a7cf-65da-4587-80c3-98a60fd35939	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	614	kcal	2025-10-07 01:49:52.933+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5d281833-18b3-45f4-b22c-fd62bb9fb5a9	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	57	grams	2025-10-06 17:01:00.262+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0d8dbb93-f002-41fe-8967-f58854f19471	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	50	grams	2025-10-06 21:44:15.108+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
40aa6179-07d7-47a2-89b0-70d016c89a21	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	32	grams	2025-10-07 00:33:44.338+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d40aaaea-1312-4a8f-9724-8ab28dcd4ec4	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	38	grams	2025-10-06 17:05:28.371+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
18a15377-1f16-427d-ae57-e7a308e37a15	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	28	grams	2025-10-06 20:59:49.865+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5461d08e-93f2-460a-b013-4c6dd1dcdd39	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	22	grams	2025-10-06 23:48:38.873+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
cf93d8b3-f2b1-4200-b628-0ac6d807d3c8	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	36	grams	2025-10-07 05:00:25.475+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a63580e6-df2b-4968-9546-3f7488e60f33	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	73	minutes	2025-10-07 03:24:27.294+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0ead4407-eadc-4040-982c-a20879707629	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	196.04676395719665	lbs	2025-10-05 15:32:46.738+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d7003f1b-f089-491b-a9ed-39cdff5fe20a	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6025	steps	2025-10-05 18:39:42.129+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a8e6a8f6-443b-468f-8410-f09db173593e	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4064	steps	2025-10-05 21:53:46.894+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
63ef8768-df59-407d-ab33-9b8d46736256	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2543	steps	2025-10-06 07:13:00.871+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
de401786-9a89-4eba-80e5-506164fec692	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	63	bpm	2025-10-05 13:43:00.599+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4f91ff4d-9f47-42f9-a2c3-e4ce1f551dac	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	92	bpm	2025-10-05 22:00:20.942+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
cc6acc7a-8df3-4854-adad-a39de7ccc8d4	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	78	bpm	2025-10-06 04:37:29.41+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5c238674-c289-44da-b25a-dd237aefa2a6	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.192467593348645	hours	2025-10-05 16:45:34.053+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
81a2d5a9-44cd-47e3-8496-8a3d1b6085a0	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	853	kcal	2025-10-05 16:21:15.547+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b9d1a0e4-5a45-4633-88b6-b05b6ba0ef5e	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1049	kcal	2025-10-05 21:54:23.62+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f3777a70-248f-437f-82df-31ad8f4d4c4f	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	568	kcal	2025-10-06 02:44:57.733+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b2a560b8-1ba1-41a7-aeca-425564a0a151	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	39	grams	2025-10-05 16:02:47.264+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
78b9878c-8acf-4e62-93f4-5c8b8599e5ea	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	40	grams	2025-10-05 19:31:02.099+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b84a70d8-cff8-4a22-9ade-2d2ffcac7aa4	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	25	grams	2025-10-06 00:59:36.444+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
96d11bf0-f494-48e2-925e-bbe5c0a03b0f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	16	grams	2025-10-05 17:11:29.625+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6615ffa9-5552-4e38-a8f7-de82d3d811fe	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	20	grams	2025-10-05 20:29:43.408+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
901509ca-d791-4426-b655-e8ac9b7fcad8	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	61	minutes	2025-10-06 01:52:14.032+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4f5e2805-1a3f-462f-9c49-b04919141e64	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.37329536132475	lbs	2025-10-04 15:27:09.195+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b205b89e-2fe9-4def-ad26-054c1a4ea46a	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2184	steps	2025-10-04 17:52:04.481+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
df72c4a0-c37b-4cfc-8964-ec7d02a91888	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3632	steps	2025-10-05 00:20:14.656+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0ae84734-30fe-4923-9465-e537be1329f5	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	67	bpm	2025-10-04 14:19:59.63+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8c98bf9a-ae26-40f9-a703-dbf3b8a271bc	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	81	bpm	2025-10-04 21:35:37.201+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
92085ea4-2c9b-4ddf-8b7c-bec23d5946dc	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	75	bpm	2025-10-05 03:37:22.303+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e6413f7c-7510-4bde-b2ab-b8857147b18f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.633880797840723	hours	2025-10-04 16:57:43.915+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
439d8051-eaf6-4f27-80ad-cdad640d8a56	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	683	kcal	2025-10-04 14:22:54.73+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0cb7ab90-6048-4eb7-bc85-c1d773db6743	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	865	kcal	2025-10-04 19:19:01.103+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0eabb10a-1c4f-48cc-966c-af5dfd938004	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	24	grams	2025-10-04 16:55:55.949+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
fcfde3ac-1c54-460e-b1c1-6ac57bdf1229	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	46	grams	2025-10-04 19:24:47.96+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f22abe31-e88b-4319-888f-10e1c3e63e38	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	30	grams	2025-10-04 17:03:45.127+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9ea478a2-eb37-4093-8bde-954215bc4cf8	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	39	grams	2025-10-04 20:17:22.437+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8a482364-9072-41df-b5c7-bd7dd3510f6c	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	26	grams	2025-10-05 00:51:45.7+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d067153e-3d25-4575-9b0b-23d24352fa71	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	17	grams	2025-10-05 03:37:24.385+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
50f59cfa-5032-44b3-8d0c-aa5893954553	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	54	minutes	2025-10-05 01:41:15.045+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4d706477-e307-496e-addd-990521bad35a	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	193.34210398386912	lbs	2025-10-03 15:34:08.612+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e9cac596-883e-41b1-98d6-1780abc0605b	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5033	steps	2025-10-03 17:41:08.707+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c2222f39-71c4-4fe9-9074-9d024b5d5ec0	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3442	steps	2025-10-03 22:30:39.231+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
601cd01c-433d-4482-b505-27ac7f40e72a	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2798	steps	2025-10-04 03:45:44.916+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ffc86311-e7b1-463d-86ff-92327c4fc1c6	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	59	bpm	2025-10-03 14:18:33.01+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
eab23279-9956-4bed-b351-d160e1f92da4	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	87	bpm	2025-10-03 20:31:16.196+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c83d3b13-a510-4923-bdd4-d17a21145a46	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	73	bpm	2025-10-04 05:02:36.319+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1f687016-fd83-4435-9bde-4e58ea4292e0	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	6.586965942788348	hours	2025-10-03 16:44:27.247+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4a843e2d-a576-4fc0-8d36-bd9af84ad29a	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1122	kcal	2025-10-03 16:54:17.8+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
999a1f3d-b32c-43e6-ae9a-1cf0e5752160	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	902	kcal	2025-10-03 20:48:31.017+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
27156926-0afd-47f1-8173-4e8808809681	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	28	grams	2025-10-03 16:52:58.238+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4463c61b-8c15-47c9-ae85-0aa886469abf	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	51	grams	2025-10-03 21:17:51.625+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
13f29bbf-acca-467a-899d-49d252235d4f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	30	grams	2025-10-03 16:33:00.751+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3f10be48-e749-41d4-b436-99be13fb9715	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	13	grams	2025-10-03 20:25:49.027+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ab649e9d-52cc-457b-a55a-b265a948b718	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	195.568385303263	lbs	2025-10-02 15:37:42.817+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
90c3a004-560a-442b-9b65-588de9e468be	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6735	steps	2025-10-02 15:49:48.708+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0bb297be-2269-4da9-831d-f5a7975c54ff	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6271	steps	2025-10-02 21:35:58.028+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a416447d-2f02-4b06-95b4-da8b7d235e07	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	71	bpm	2025-10-02 13:32:16.883+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
94162eb2-3125-4a8a-a326-11324616b97a	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	62	bpm	2025-10-02 18:12:38.68+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2f884d98-3277-4f30-923a-b170e10745a7	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	88	bpm	2025-10-02 21:43:14.866+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
de100096-1ae5-4ffa-871e-d4287a0af6c0	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	67	bpm	2025-10-02 23:48:12.283+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8b10c970-fada-4c72-b582-38de5c8863b1	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	64	bpm	2025-10-03 03:29:18.465+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5352d654-8ad2-4834-9d44-1ed7c88fa5af	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.909015544763173	hours	2025-10-02 16:45:06.651+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
31cbebda-ae37-4136-8b3f-2ce83d93a25a	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1164	kcal	2025-10-02 14:18:17.835+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c272542f-9bba-4da0-9e3b-cfef77f3eab3	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	757	kcal	2025-10-02 21:14:43.339+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
63081655-e09c-49fa-9132-57187ca4cba7	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	53	grams	2025-10-02 15:28:53.476+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b7aa7ddc-7cbc-44cb-bfd8-2ee4b1563712	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	24	grams	2025-10-02 19:50:48.244+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
08813c9e-ae6a-4553-a716-5389015ecb52	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	39	grams	2025-10-02 15:37:22.607+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
28d0fa5c-b54b-435e-be1a-3c01ea64a20e	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	18	grams	2025-10-02 21:04:24.903+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ed314036-e9dc-42b0-bbaf-8cb86e058b60	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	25	minutes	2025-10-03 02:16:21.916+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
430ec546-2482-4158-9ea5-10cec263aaa9	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	193.84184217594492	lbs	2025-09-30 14:31:26.707+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
37a4c999-c082-469c-91bf-79307ec0f3a2	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3993	steps	2025-09-30 16:22:49.162+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
93ed485c-7a18-4f9d-8d34-cb6d678d97e4	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3578	steps	2025-10-01 01:08:26.333+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d17e2b30-7f66-4aea-b98a-46ea2f365409	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	59	bpm	2025-09-30 14:57:23.959+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
482bf2ea-2fc8-4717-acb4-0010e1b09423	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	76	bpm	2025-09-30 19:18:42.342+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8214ffb0-2d2e-4e9c-8223-13b0302f7b6d	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	83	bpm	2025-09-30 23:22:28.238+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4f78ee11-658c-45fd-ba2e-04d9939d062a	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	77	bpm	2025-10-01 04:22:28.122+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
133e857f-f3e9-469b-9a9d-ac45a4e09a0f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.383361405447304	hours	2025-09-30 16:07:16.611+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6c563276-1589-4657-857c-624f8c0b060b	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	623	kcal	2025-09-30 17:11:51.117+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e5308113-92f2-4da7-a473-3ccb844cd3bb	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	621	kcal	2025-09-30 21:45:57.072+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
eaf285b5-d086-4cb0-a6c0-873c5c7ee2b7	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1189	kcal	2025-10-01 01:37:36.259+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3582c91c-a3f7-4891-9fe4-ca37f0928d13	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	57	grams	2025-09-30 14:37:35.802+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4d488fd7-0239-4df6-87ba-5bd9d60aa105	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	41	grams	2025-09-30 19:19:12.775+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b11a64ad-e91a-4add-a35b-df923145285e	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	48	grams	2025-10-01 00:56:44.704+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
41ebdf3f-2d20-43a5-aa52-b371c6cc8ed1	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	39	grams	2025-09-30 15:35:11.468+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
728f0ece-a3d9-4c44-a9e8-106bdf3c5777	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	17	grams	2025-09-30 21:15:27.161+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
cd3da6c8-852a-4d29-9879-eee7c1b6e248	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	27	grams	2025-09-30 23:53:31.249+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
455ffec6-669a-462c-a3bc-3628fa9b2d53	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.55611737805137	lbs	2025-09-29 15:34:59.018+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c1c37dcd-a18a-4b69-9877-6534550430d8	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5886	steps	2025-09-29 15:22:15.959+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6ab5528f-0fe6-49e4-a0e9-62e36a096c48	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3025	steps	2025-09-29 23:49:08.097+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ba817730-a7a3-4514-8a1b-820c6d1d3318	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4592	steps	2025-09-30 04:01:35.851+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
977a6a96-6937-4cc0-a398-2c59e3771563	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	63	bpm	2025-09-29 14:40:40.893+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9c313ef3-5b2e-4190-9a8f-c7d6bac36560	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	89	bpm	2025-09-29 19:44:46.434+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2e7cc145-9f30-47a7-bfd5-c068789dfe63	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	83	bpm	2025-09-30 00:01:34.997+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ee65bf75-c30a-4d1c-bd91-37fd578b17ee	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	70	bpm	2025-09-30 03:33:48.206+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9d8f9ad8-be47-4747-9ebd-2a125d1b6007	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.225321498121098	hours	2025-09-29 16:36:53.975+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b4c72c7a-b8e1-445a-ace4-690f0d473394	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	755	kcal	2025-09-29 16:07:41.35+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9b1d631c-e28f-44b7-b7dd-e6d5ab58744b	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	906	kcal	2025-09-29 21:35:07.047+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
69bb9b60-8037-4f0a-b5ac-67a41ccc004e	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	564	kcal	2025-09-30 00:31:05.729+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
eafab6ae-49b4-4917-b42e-0b1f36bda258	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	41	grams	2025-09-29 16:01:45.56+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5478afd1-b192-458a-b317-b0c54ec2eae0	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	22	grams	2025-09-29 19:38:14.675+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4db14069-060d-4bb6-bd5a-a725b609233b	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	29	grams	2025-09-30 00:30:27.175+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
975e4359-9ed4-47a7-9782-129ee410f94b	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	11	grams	2025-09-29 15:45:23.557+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0ae072d4-209f-4c65-8e51-c343df3349d1	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	32	grams	2025-09-29 19:39:15.436+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2b031863-d4fc-4100-b6dc-406a3235c824	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	25	grams	2025-09-30 00:35:30.494+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
aa212f6c-2f63-488a-a5a1-cec02bedda1b	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	196.36142658559274	lbs	2025-09-28 14:33:17.8+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
95ccd192-8506-4a9a-aa54-f7dc8661fd9c	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2550	steps	2025-09-28 15:40:38.663+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0e010fa7-bf6d-44a6-ad98-a9da760a40e0	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2766	steps	2025-09-28 23:52:32.427+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
98759061-9936-4747-b068-f119460fd060	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	72	bpm	2025-09-28 14:20:26.228+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
067c679a-2ad3-4b87-bf25-ec825fc34c8e	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	76	bpm	2025-09-28 18:45:39.448+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
91b81647-080a-4bf3-85c6-a7e7f79f0bfc	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	82	bpm	2025-09-28 23:13:21.853+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
7c917b60-2f3b-4fdd-a15d-91cb8ba2b7da	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	68	bpm	2025-09-29 03:47:41.579+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
283dacb4-cea7-4685-9c1d-3425f98611fe	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.147375999961444	hours	2025-09-28 16:23:04.276+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
50836a3e-e795-4e6d-b8e5-92ce95d2418e	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	586	kcal	2025-09-28 14:56:11.784+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
372c08b9-7528-4e10-92ca-4d138ded7e2d	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	496	kcal	2025-09-28 21:18:59.568+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2da8cbc3-3886-4833-a377-11b73be9d6da	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1139	kcal	2025-09-29 02:00:11.731+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
326364cc-c7af-4000-ade8-d77c46f19414	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	23	grams	2025-09-28 17:06:54.581+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
07569227-7d13-400e-8a81-f532de35a1a9	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	34	grams	2025-09-28 20:25:15.925+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
cb7138e6-9352-4a1a-8f71-387b0fee45f5	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	59	grams	2025-09-29 02:28:53.067+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
800690a5-ebbc-46eb-8ea3-5a3f8d54db3e	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	21	grams	2025-09-28 15:27:37.705+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8b346ba6-870f-4581-aa2c-102fb138c5c0	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	25	grams	2025-09-28 20:33:15.932+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
7fba2005-29fc-40b8-8725-f1929fe30e37	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.07894693489652	lbs	2025-09-27 14:49:37.628+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d21ebaa8-c32a-446c-a650-1857b678102c	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5584	steps	2025-09-27 16:22:18.082+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c0257722-0505-4115-9d16-707b82f551f3	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2544	steps	2025-09-27 22:13:45.708+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
cdc23c51-0f08-49ae-b196-175e88414668	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	67	bpm	2025-09-27 13:33:09.078+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d2f44705-4751-4048-9dba-886e86e8a556	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	84	bpm	2025-09-27 18:18:58.792+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
005e727c-d353-40a9-80ce-1580a6c63678	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	86	bpm	2025-09-27 23:40:08.11+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
58dab6c2-e7b5-4a1c-be67-603c102da6c2	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	74	bpm	2025-09-28 03:43:59.771+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5e450f6e-3c4f-4f75-be99-e2909c05c8f8	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.557733566921137	hours	2025-09-27 16:19:43.002+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b7e08882-ba83-42b4-a142-0a62eec863a5	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1192	kcal	2025-09-27 15:09:22.133+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9e543e64-ecc1-4607-81c1-3c05482017f2	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	704	kcal	2025-09-27 20:56:39.182+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a8bad1fc-cd47-4b30-bd7f-79f9e5c7508d	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	673	kcal	2025-09-28 01:15:17.208+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
001d332e-a33a-457c-87c0-b112f28f98cf	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	52	grams	2025-09-27 14:59:54.871+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
47fd87ef-9a33-4118-ac60-b4eaf3d17a96	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	21	grams	2025-09-27 19:17:16.817+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
7ed718c3-f5a4-449a-9522-7a9254824c4c	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	23	grams	2025-09-28 01:55:16.82+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6f03ac19-afa3-4060-9b18-209d4e94b717	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	14	grams	2025-09-27 15:59:55.289+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2db6cd84-05eb-47dc-a3e8-50b07bc0a85a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	39	grams	2025-09-27 20:24:21.227+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
12c5de9a-a783-41c4-b165-1968735d5004	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	13	grams	2025-09-27 23:23:18.466+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
7f16f4e7-c929-466f-830c-7c882964a2b4	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	33	grams	2025-09-28 04:23:55.611+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2fc2f9b1-c142-4fad-a3d5-1cd2f4463f52	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.31296054528087	lbs	2025-09-25 15:22:20.165+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
19bdbf5d-4888-4073-a000-72dbfb484bba	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6781	steps	2025-09-25 16:03:50.034+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
22e5945e-8416-4c6f-b5b0-1212cff421c6	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6362	steps	2025-09-26 00:43:26.011+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
43128a0c-7965-41ae-83de-13c2a884db4d	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5609	steps	2025-09-26 03:34:50.227+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9857d44c-fc59-43a7-ad20-72c1cfd12897	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	67	bpm	2025-09-25 13:54:22.175+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
bf30d132-b572-4110-ab99-c1fbd03ee8c2	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	72	bpm	2025-09-25 18:37:41.961+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e3e3395a-b40d-4483-ab09-beb00f1fa7d7	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	93	bpm	2025-09-25 21:56:22.632+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0974d266-ccba-4ddf-9550-d55d2b0cbae4	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	61	bpm	2025-09-26 01:28:28.398+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3140cde8-4963-434a-8413-6d43885cefdf	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	71	bpm	2025-09-26 05:11:43.465+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0b322a9c-bd23-48dd-9eb8-a303371f7a0d	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.2820663365862455	hours	2025-09-25 17:13:48.328+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
78c0a060-651e-4f82-98d9-0430614edcdb	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	907	kcal	2025-09-25 15:54:01.307+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3d36e2e1-87f0-4af7-b07a-778e0d8fac2c	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	893	kcal	2025-09-25 21:57:10.573+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6bc9f99e-c583-45c6-b8eb-96182302802a	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	783	kcal	2025-09-26 00:29:32.395+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d9b70b2b-fd78-493b-8e24-482b2d617c67	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	51	grams	2025-09-25 16:01:38.455+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
fe348fab-11ca-42da-b179-29cbc5201cef	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	34	grams	2025-09-25 20:18:00.248+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
cd6c8d7d-3fb8-4f69-a241-6bcd175bb8ec	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	57	grams	2025-09-26 01:27:29.454+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
bc45e765-61a8-4bda-b07d-095c369378a7	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	39	grams	2025-09-25 17:05:27.061+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1cd6d1db-3cbc-42d6-8dc4-fc9e21b97fb5	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	28	grams	2025-09-25 19:20:03.945+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8b0c2a39-46c8-48f3-bf17-9d3b3b1cff26	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	37	grams	2025-09-26 01:07:37.444+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2393f0df-7cfa-47db-aad1-cb3ff5c612be	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	35	grams	2025-09-26 04:19:15.142+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ab772c53-bf93-45a9-8128-d91ed7c3ed0f	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	48	minutes	2025-09-26 03:16:32.148+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4c5d224b-4196-4c60-83a3-37c5d41daa60	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.03892355522515	lbs	2025-09-23 15:19:11.494+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1f1df6ad-4a4f-4092-be4a-e0f61c677b6f	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2188	steps	2025-09-23 15:30:11.694+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
dc3abca2-36dc-4cb1-8182-6b0d2101a570	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2409	steps	2025-09-24 00:14:48.394+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c388c916-5dd8-4c40-b567-aad22d87c054	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	71	bpm	2025-09-23 13:37:53.489+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b8c45e84-dda8-4ab9-bd8a-a6005abdc018	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	61	bpm	2025-09-23 16:55:49.669+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9207bb48-1b35-418d-b990-9dfad301d237	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	78	bpm	2025-09-23 21:08:21.648+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
11c27019-a33d-449f-9fdd-9b1e0ab7252e	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	76	bpm	2025-09-24 01:28:16.03+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c49962f6-5695-4db1-9c2a-55466a3ef8d2	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	68	bpm	2025-09-24 04:25:12.381+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ef8244b8-d130-4e36-815a-b4ae0e2f5199	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.258970410154008	hours	2025-09-23 15:28:21.231+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a35d8b38-63ef-4005-b719-69dcc9afaeb5	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	536	kcal	2025-09-23 15:19:13.926+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ba05b164-411a-4d10-917a-f95b811e517b	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1139	kcal	2025-09-23 22:14:53.327+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0ddc3e2c-0beb-4d5b-8cd1-e6132f4d1cfa	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	55	grams	2025-09-23 14:51:05.069+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d85db72c-b158-48eb-99ff-b18ebae58b9c	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	39	grams	2025-09-23 21:48:38.475+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3bb7ed2f-0e1d-4310-8540-1039099cc5ea	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	21	grams	2025-09-23 15:59:16.723+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
99b3bcdd-84da-4b19-9292-27888fd90061	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	21	grams	2025-09-23 19:26:24.685+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
02345598-6bed-4d5c-afc8-cf5991d36317	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	33	minutes	2025-09-24 03:02:05.901+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
97bbe9f9-7fde-4598-80bd-080381430e04	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	196.04905608009918	lbs	2025-09-22 15:46:50.409+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
43ba6a83-1246-43cd-bf89-5111ae09a292	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2645	steps	2025-09-22 18:24:12.64+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
41174e5a-afc2-43d7-8a7b-b52a9904386e	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6696	steps	2025-09-22 22:39:04.92+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3fc9f436-abf8-4ad3-884a-9a772561583e	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	61	bpm	2025-09-22 14:23:27.744+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b1a3bbd0-03e4-4cbc-b8aa-11e5ff03f4f8	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	67	bpm	2025-09-22 16:54:49.31+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0e076a83-eac1-45fd-aad3-168c2614a13a	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	91	bpm	2025-09-22 22:06:52.643+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
77197b8b-2fb3-460b-a4bb-b427b83b4ef2	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	64	bpm	2025-09-23 00:22:44.379+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f5678c04-c305-440f-9c83-834655dfd201	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	65	bpm	2025-09-23 05:04:45.669+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
de718062-8d7e-4763-9b9f-cce075806c19	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.226478462486057	hours	2025-09-22 15:57:28.127+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f9688ef7-a043-485e-8e26-191ec65fd43e	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	759	kcal	2025-09-22 14:54:40.263+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9aaf7295-5749-42a2-97f3-0d06494d7436	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	416	kcal	2025-09-22 20:45:46.485+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9057c9ba-99dd-47cc-adda-bbd296516d9a	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	646	kcal	2025-09-23 00:24:47.61+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c9666a89-25be-439e-9ffa-f8904437e364	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	27	grams	2025-09-22 15:38:02.135+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
7b744776-6227-4663-a870-edb41613e974	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	26	grams	2025-09-22 19:26:31.289+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
49f99f1e-1664-44af-951f-076794b8b6f2	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	28	grams	2025-09-23 02:18:03.912+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d7d4c349-ff6e-4766-8147-2a10b6894370	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	10	grams	2025-09-22 16:34:16.853+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b46a28aa-b7fa-4d59-ae71-29a4316e695c	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	40	grams	2025-09-22 20:48:59.626+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
752acdba-c53f-4e95-8284-b8976afb9041	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	16	grams	2025-09-22 23:20:28.342+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a45aa091-38c9-4928-bc65-999ff7aaac2d	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	38	grams	2025-09-23 04:09:52.334+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b41cf0e9-5e38-4f58-b832-7ee17d733fbe	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	192.90220626191993	lbs	2025-09-21 15:12:12.298+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e6e30f07-da2a-4308-942a-ab2458e87028	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2693	steps	2025-09-21 15:46:18.246+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3624290a-d1bb-4ec8-a51e-8a42a9a9dd24	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6788	steps	2025-09-21 21:44:43.682+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4bb1c851-b2f9-473e-8402-5c91d4a2e809	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3257	steps	2025-09-22 06:28:07.426+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
661ae44f-42da-4df9-b9f0-cb92624021d2	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	74	bpm	2025-09-21 14:39:32.827+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ea787672-85aa-47db-8531-16b49f009e74	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	87	bpm	2025-09-21 21:51:37.19+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2316c6aa-eb7f-435c-bbb6-e13af76b458b	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	71	bpm	2025-09-22 03:27:22.231+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
692319a6-90ce-481e-9837-d278707c8b70	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.281197796850494	hours	2025-09-21 15:24:06.622+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
297473ec-edfc-4bb0-b7ef-58f9546291d4	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1061	kcal	2025-09-21 17:15:10.231+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d6f67676-6d40-422d-a6ac-01f615e21653	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1011	kcal	2025-09-21 21:59:16.198+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
14d29315-4176-44a2-a9b3-7dd9f6d7f957	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	463	kcal	2025-09-22 01:49:23.191+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
93bd6bc7-6e2b-4801-a898-b20fd7449213	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	44	grams	2025-09-21 14:19:27.631+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
97841914-a73b-44f9-95d9-f295fcf27d62	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	45	grams	2025-09-21 22:15:12.281+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
171d525e-b5bf-4052-826a-58daa4efc4bd	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	24	grams	2025-09-22 01:10:41.94+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4ed0d285-acac-421a-9730-70119f1ee50f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	30	grams	2025-09-21 16:03:00.507+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0e2e281b-13c8-419e-a0cc-dfb17b744fba	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	30	grams	2025-09-21 20:12:30.013+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ae6f9d69-b9c7-46db-b4e6-5917d2dfc5fe	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	31	grams	2025-09-21 23:55:38.519+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c4d20022-180d-4d8c-82eb-bee73db973a3	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	32	grams	2025-09-22 04:59:04.669+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
690241b1-0ab6-4633-bf32-f36f0e2df981	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	49	minutes	2025-09-22 01:36:48.833+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
99cd690a-d0c4-473a-9de2-8dba5ad9c647	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	196.31198583989905	lbs	2025-09-20 14:48:10.848+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
204a2a9a-2c86-4d87-8d76-81e42ef46c5c	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2471	steps	2025-09-20 16:36:31.296+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9f3cdde2-9499-4f63-a3d9-9332bf78e5c9	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3399	steps	2025-09-20 23:18:39.261+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e512b29e-b009-4b79-a0f5-7beeaafa58e4	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3029	steps	2025-09-21 04:47:29.33+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
55dfa198-6970-4afd-bae2-15f1e29c0a66	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	73	bpm	2025-09-20 14:22:23.701+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
23a642f2-ec09-4d50-91ac-992fead9db1f	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	88	bpm	2025-09-20 18:57:35.988+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a0510b10-6a07-4a30-8476-1ee78be893b4	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	91	bpm	2025-09-21 00:20:41.073+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4fdcb55f-bd80-4c80-a894-add6001b6e0c	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	78	bpm	2025-09-21 03:36:52.263+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
27d29265-16c8-4de7-987f-c5eac591f4d8	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.518874243772942	hours	2025-09-20 16:43:40.162+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6f69094c-753a-4273-9222-e810c9360158	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	592	kcal	2025-09-20 14:26:40.507+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
95742c91-54bf-4e64-b106-41a5f2d2db80	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	936	kcal	2025-09-20 21:02:51.01+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
bb949dae-4e91-4fcb-bc70-bd6969c327bd	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	481	kcal	2025-09-21 01:38:44.619+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1b84b323-7154-434a-ad77-c38952b48d84	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	24	grams	2025-09-20 17:15:41.735+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
59f71d38-aeb6-4a9a-bf81-ddb77018be25	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	46	grams	2025-09-20 20:04:28.528+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5caef1e4-b63a-4026-82ee-a99aee1eacde	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	30	grams	2025-09-21 02:07:03.953+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9f913200-8e7e-4159-9ad9-6d08fb9fd889	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	27	grams	2025-09-20 16:20:38.824+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a78203da-6e25-48f7-8027-0c224f36fe90	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	20	grams	2025-09-20 19:45:21.693+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9765448d-5805-4fff-963a-a1be2bc8bf7b	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	19	grams	2025-09-21 00:34:24.935+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1d40b00a-f814-42c9-93d0-627ec0ba23f5	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	20	grams	2025-09-21 04:17:15.856+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
51463477-915a-41c2-ba46-eb043a077bda	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.26686322030002	lbs	2025-09-19 15:15:16.584+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5c9c8b7c-e4dc-4373-b154-91c4c058d2e5	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5423	steps	2025-09-19 17:12:38.153+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
33faa41e-7b2e-4127-b6c7-dcd216e7f4de	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2739	steps	2025-09-19 23:36:48.707+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
558aa5bb-07f6-40e7-9340-eb61f301b57a	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2561	steps	2025-09-20 05:03:38.541+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f2ddded6-9955-48aa-850b-8ec7bb16cd2e	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	70	bpm	2025-09-19 13:43:50.829+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c9948855-4d9a-4374-9ab7-92f4c083c447	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	94	bpm	2025-09-19 18:38:17.062+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
cdee83ac-e74a-45f9-ae09-ea835f0c38fe	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	90	bpm	2025-09-19 23:59:51.513+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2b5b5edb-8e2e-4ac9-8646-1eebd3658c2f	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	75	bpm	2025-09-20 05:01:28.496+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
96abc6fc-5a1e-49c7-85cf-e3c4759b3622	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.600755164443216	hours	2025-09-19 16:18:52.732+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5d848708-442e-4935-818b-e04b21d92938	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1091	kcal	2025-09-19 15:14:21.018+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6de5fbb3-1b3b-4877-b460-f31ecc6d26ed	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	837	kcal	2025-09-19 19:55:36.247+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
da0bfdcd-f20b-46f8-8f39-fe4811e7328b	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	59	grams	2025-09-19 16:05:29.89+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b8c78733-4749-41a6-a147-545db85ecdbe	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	24	grams	2025-09-19 19:53:45.207+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
90e5a597-d351-43d6-8dd6-a6a18ec90dbe	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	23	grams	2025-09-19 16:48:57.348+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
abb41783-7dc9-4bc8-adf5-e60bf482e20a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	36	grams	2025-09-19 21:08:57.433+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1f991ab6-7431-4e43-b847-7c7d9289ecf2	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	196.67430294336384	lbs	2025-09-18 15:50:21.166+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
adc143fc-e9f2-414f-85e3-a633bbe027ce	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2010	steps	2025-09-18 18:07:39.616+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
34ed112e-8a26-4c07-b212-cdcdc1fc4586	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2068	steps	2025-09-19 00:49:49.343+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e99039a0-b636-49bc-a1bc-93917afa8a4e	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	58	bpm	2025-09-18 14:24:00.727+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
113eb323-088d-4f13-857c-aadac47d93c2	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	95	bpm	2025-09-18 20:55:04.522+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ad1454b2-5e68-42af-972e-bd31b90d9e05	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	63	bpm	2025-09-19 03:59:33.088+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
82af98d7-532a-4c06-b109-9215dd6c494e	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.374586867705478	hours	2025-09-18 15:41:19.891+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
84423aa2-e3f2-47c9-8aef-ce0c7cd3c7a8	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1167	kcal	2025-09-18 14:26:07.477+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ee28c806-c464-4ca7-acf1-2f583c9cc9c1	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	515	kcal	2025-09-18 22:15:36.61+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
11f3d3cb-cd7a-41e1-bdd7-823e598e558b	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	42	grams	2025-09-18 15:08:59.728+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
930983ae-55a1-45d4-83ce-9375ca706ebc	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	33	grams	2025-09-18 19:36:17.675+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
7be076b9-6954-45f1-8b3b-76a44fb76834	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	35	grams	2025-09-18 17:11:39.011+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3f1caaba-be64-4263-948d-76c31b82e622	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	26	grams	2025-09-18 19:43:02.175+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b4eb519d-bff8-4da6-a9c7-e24f0be9b42f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	32	grams	2025-09-18 23:29:38.921+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1d7e05ee-64f9-47aa-a787-677aa3ce2b03	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	27	minutes	2025-09-19 02:03:17.058+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6680321b-997a-44bf-887f-84fcdd0d105b	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.1568602770673	lbs	2025-09-17 14:25:32.384+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0616328d-5e0a-4bd9-870b-3b110d25f51a	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5432	steps	2025-09-17 15:20:20.844+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3aaa20bb-451d-437d-8e23-1631a4f420cb	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2988	steps	2025-09-17 23:04:22.351+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6176f076-4980-4647-8cad-8ea4d0d3273b	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	63	bpm	2025-09-17 14:38:17.202+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
7d912771-6342-466d-96e8-da17831e920e	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	75	bpm	2025-09-17 18:07:30.548+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ce6977f8-5df9-4aff-9c83-199f4f3cb115	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	93	bpm	2025-09-17 22:06:40.296+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8422de22-2dec-4219-b7c2-91e303b77695	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	65	bpm	2025-09-17 23:59:54.129+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
65170e3a-76dc-4e59-b832-0620897841f7	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	66	bpm	2025-09-18 03:55:52.533+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
32542387-1c42-4938-8ee4-4a1cabc81ffa	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	6.735022310590231	hours	2025-09-17 17:09:19.425+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
88be8767-8ae3-43df-96a3-53470f73e4f1	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	471	kcal	2025-09-17 15:07:20.574+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8d93dd42-06d2-4754-8ed7-156f6a433c97	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	834	kcal	2025-09-17 19:47:57.175+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
edbb9b0f-64a8-4835-b11a-ac3674920e2f	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	56	grams	2025-09-17 17:04:37.73+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4d629a87-58b7-471d-9d7e-b84b8a3fa7a2	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	46	grams	2025-09-17 20:02:13.984+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
95da4e5e-910f-474b-ae7b-3d69a6a775af	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	20	grams	2025-09-17 16:47:19.1+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0ac56e48-2644-4ebf-b516-e3d5f42695ac	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	15	grams	2025-09-17 21:03:35.962+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4ddbd483-dee6-4a3c-a2d1-7a2f92daa51c	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	28	grams	2025-09-18 00:56:50.152+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5fcb4293-c710-4372-b463-89af3e5ceea8	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	22	grams	2025-09-18 05:12:42.878+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1c1be4d4-a9ad-4534-aca9-bef2e0339291	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	56	minutes	2025-09-18 04:10:25.775+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4c8b3f42-e26d-4757-b4f5-50a74349533f	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	196.36310426096105	lbs	2025-09-16 14:55:01.252+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
01411d30-8f0c-4b0c-8f7b-592dd107982e	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5011	steps	2025-09-16 16:18:47.535+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
05016c81-6bee-4a5f-b3db-dc27d5999f8c	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4321	steps	2025-09-16 21:18:04.236+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
967c6b4d-ae75-47bc-adc3-79f7642c0a9d	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4516	steps	2025-09-17 03:42:05.436+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
cc2cf383-fee8-4e94-967d-c5fe8dd0b1b4	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	68	bpm	2025-09-16 14:43:37.833+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6bcf91f4-9cdb-4de9-b31a-bd99eda49a87	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	90	bpm	2025-09-16 20:28:42.627+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3b35ccd7-ffc4-45f4-a375-19ea45f187f7	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	78	bpm	2025-09-17 04:42:25.056+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
eea15f1a-ca32-483c-9b90-91e64401e124	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.426806936729319	hours	2025-09-16 16:41:52.302+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
12fe8421-43aa-4300-9df3-94d687492d61	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	855	kcal	2025-09-16 17:00:49.91+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a8f5631a-8fb4-4b70-b9a4-8f6b5b78d84e	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1183	kcal	2025-09-16 19:22:38.648+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
7f8ff18f-656b-4fa4-8a5e-5efa7180176d	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	28	grams	2025-09-16 16:57:53.22+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
72d40db2-8d03-4a48-b076-10edb7a13f0e	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	27	grams	2025-09-16 21:28:57.4+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
cddd2c41-ce95-467d-a54d-40323810f802	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	24	grams	2025-09-16 15:39:59.598+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d1e3f13b-f87c-47a1-9fa6-28ba63e2fbf1	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	25	grams	2025-09-16 19:46:24.626+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4b9903ca-edf5-41b8-8502-a104715c9417	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	193.31684721992144	lbs	2025-09-15 15:56:12.671+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
38ae8310-8e22-4288-9171-20b463b690f5	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4125	steps	2025-09-15 17:40:52.262+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b5a2cfe9-ff6a-4de7-ab62-95bcfa453541	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4018	steps	2025-09-16 01:13:38.369+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2d104603-d012-4a45-bb53-e98bc8e0e790	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5268	steps	2025-09-16 04:14:38.902+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1d0f3a29-4b60-49fe-92bc-b5dd8e57405e	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	71	bpm	2025-09-15 13:21:52.505+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
79574aeb-19cb-46e9-bc2f-4dacaec27132	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	93	bpm	2025-09-15 17:59:23.484+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
63226614-a920-41cc-839b-1b898abb9f57	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	80	bpm	2025-09-15 23:05:53.023+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f12d3712-b279-4eaa-8f49-3b1e28f7829a	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	71	bpm	2025-09-16 05:13:01.917+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4f9ab48e-7285-4425-a88c-f131e0e0ea0e	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.775621025664851	hours	2025-09-15 16:08:54.976+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ab8a3a69-6539-4293-8fe3-2c16bd871af8	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	824	kcal	2025-09-15 16:55:07.737+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
03c5ac6b-3a75-48fe-84e6-2e0e79e1f7de	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	972	kcal	2025-09-15 22:16:53.149+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a46628d1-dd74-4584-81aa-89c677768d07	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	27	grams	2025-09-15 16:27:42.407+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
019ce870-58dc-4903-aaad-680440654d80	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	25	grams	2025-09-15 20:49:48.281+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4632d429-3a59-4e35-a229-69c2d979f95a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	11	grams	2025-09-15 15:32:48.615+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
69646ede-959d-418e-8fbf-c2692c8f9712	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	17	grams	2025-09-15 20:29:14.582+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ed27b48c-5a34-454e-a160-409447214eb7	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	44	minutes	2025-09-16 00:37:17.455+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4dab84b7-0369-431b-bf5e-56e745df89d2	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.3381803061208	lbs	2025-09-14 14:48:54.688+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c1046d35-568f-495c-9bba-ff7b0c3867e0	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3392	steps	2025-09-14 16:14:38.426+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f109085e-e117-4313-9409-f928b6c5f613	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4629	steps	2025-09-14 23:31:15.691+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
df15d135-632b-41b1-b21d-5f84dc35c68d	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3849	steps	2025-09-15 03:48:41.366+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
89bb229f-cf40-475f-906d-e764ba428256	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	74	bpm	2025-09-14 13:54:46.037+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
dd6e3c24-d514-4a87-89cb-a1c3311a81b9	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	87	bpm	2025-09-14 18:03:43.647+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e38a3d46-2ca5-4d38-bc11-6bbdfb657186	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	94	bpm	2025-09-14 23:07:53.326+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
831dff1c-ca71-4e56-a22d-be2d806a331b	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	61	bpm	2025-09-15 03:44:50.691+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
24720e98-6a2d-4cf4-9c60-b7dc177e0b80	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.997338306240216	hours	2025-09-14 15:29:27.293+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1b9c2343-b727-4845-ae59-69966b1b7d60	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	447	kcal	2025-09-14 15:26:05.898+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
033986f1-bf36-4e04-bdd6-be6365af340b	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	711	kcal	2025-09-14 21:51:33.315+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
daa05e86-0590-4a36-a0dc-a8c11562eeb5	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	55	grams	2025-09-14 14:47:30.856+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f889d4fd-cade-4d4d-9b84-3c7f0f0acd1a	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	24	grams	2025-09-14 21:43:00.286+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0355e721-6325-4aa9-a51a-1396beed15cb	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	29	grams	2025-09-14 15:28:35.645+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
330b73b3-deb3-4443-914c-88db5d2dc4cd	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	15	grams	2025-09-14 19:56:53.636+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ab3432df-a90c-4e01-b50c-45c18d0edd48	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	19	grams	2025-09-15 00:15:43.654+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
dfea23bb-87fd-4f6a-8b3a-9c4101a17b1f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	32	grams	2025-09-15 04:44:31.765+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9fd85e8a-9af8-4440-abbb-8a3c1bba59d9	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	76	minutes	2025-09-15 02:59:22.965+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1149699a-8a1f-452e-9e2e-6d4e01cd06be	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	192.22412588169567	lbs	2025-09-13 15:53:25.467+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2947506b-5a5f-4e7f-ac36-3abd520ccede	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2023	steps	2025-09-13 17:42:57.781+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
fbc1f6d1-6105-4f2c-967c-cd489d89a456	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5043	steps	2025-09-14 01:06:25.205+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e2d59853-987b-4657-8b2a-7748b09cfd3c	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4996	steps	2025-09-14 03:53:10.343+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
56006337-1c71-4e1d-b022-8c86eabefeed	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	63	bpm	2025-09-13 15:03:36.115+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f69dabd7-394d-4b25-bc98-8fc1e6f57e47	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	67	bpm	2025-09-13 17:05:28.828+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4e7f68c1-7eb1-4ec4-a17e-aa3fca3df799	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	82	bpm	2025-09-13 20:59:34.367+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a48643e6-8ddd-4250-a708-77ff5af52dec	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	62	bpm	2025-09-14 01:04:26.106+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a6435e47-a238-4f03-a0f5-86b55347befa	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	70	bpm	2025-09-14 05:16:34.807+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
fa3ebc1f-543c-4aff-90d3-458bf16f42d6	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	6.892579339145892	hours	2025-09-13 16:57:37.116+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3e0347c0-c5d9-4b11-a529-7bac4c5cb433	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	698	kcal	2025-09-13 14:55:55.68+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
75265517-c8a9-4b69-9535-3213414568db	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1019	kcal	2025-09-13 20:15:37.277+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
76a064e6-cea5-47f5-8e55-9ee26566fefb	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	39	grams	2025-09-13 16:04:51.076+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0fa60e8a-87c5-496d-bfdb-7fb8197d7215	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	56	grams	2025-09-13 21:57:46.114+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
833e4834-42a2-4a9d-a98f-b1cd3ba93fdd	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	34	grams	2025-09-13 15:48:37.994+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
47fa2d80-45cb-44a7-99ac-4438be81fd53	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	24	grams	2025-09-13 19:43:45.815+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ef702d97-2b96-4323-aee3-f740b3477be5	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	15	grams	2025-09-13 23:37:57.649+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9d1684af-a791-4760-b217-a13809d792eb	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	28	grams	2025-09-14 05:01:40.833+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
cc916f80-9b75-4559-8d59-e282ef61e9a8	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	54	minutes	2025-09-14 00:39:53.54+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
706463b2-f26d-475d-8005-d2beb1fcb56a	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.51824669830177	lbs	2025-09-12 14:44:11.401+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
07eb5b5c-af34-4040-bf5f-40aecfb9351b	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6817	steps	2025-09-12 16:53:45.013+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
21ead6a4-2e7f-4137-a8c7-5cb17c95f04a	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5706	steps	2025-09-12 21:21:20.459+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
eaa8c549-25a3-439d-9365-0e6e693a62ee	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3838	steps	2025-09-13 04:31:03.239+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
16e6a9fb-3b9b-405e-bff8-5f86acdca6ed	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	64	bpm	2025-09-12 13:19:19.364+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
af8cafbd-65ac-4b64-b7f7-fe79bf6fbc36	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	76	bpm	2025-09-12 18:17:20.981+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
eb3da754-b549-4d57-9607-55c540edd3b0	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	86	bpm	2025-09-12 23:04:02.217+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
07b593f6-73db-429d-9c50-b310ab1d752b	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	80	bpm	2025-09-13 04:59:40.82+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
101fbcae-974e-4bf1-8fe4-f45e0a3f34e0	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.715851716632798	hours	2025-09-12 16:51:26.113+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8b7da9ca-bda5-4185-a44a-673a3dad9985	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	565	kcal	2025-09-12 14:54:43.898+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
50b75d15-2e29-4978-9642-ddb4c8afabba	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	841	kcal	2025-09-12 20:09:24.197+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2ab4c48a-9367-4e4b-b1a8-bd0159cf1dc0	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	58	grams	2025-09-12 16:33:03.345+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
34b83650-6e8f-4722-b207-c603d364997e	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	53	grams	2025-09-12 19:58:04.491+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
55f26578-6f2a-4e1c-b81e-52a34d0c4c31	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	25	grams	2025-09-12 15:28:15.39+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5bb92264-c4dd-424e-af97-a311eb7a709b	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	15	grams	2025-09-12 20:33:38.659+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0a35963f-e970-402e-a42a-b8557f4b6978	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	31	grams	2025-09-12 23:23:59.771+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
74ee4d71-b1bb-4e4d-aab6-369d17e0ad05	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	196.53149235540144	lbs	2025-09-11 16:00:54.96+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9214b625-8313-4a7f-930c-aebf0bb35ef9	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2978	steps	2025-09-11 15:32:36.301+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2c691975-0343-4f35-afe1-183c4c0077a5	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5879	steps	2025-09-11 21:35:20.224+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
816b30bb-02f0-48a0-93bd-7e6f81d61582	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6812	steps	2025-09-12 04:51:39.485+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4684a8c7-f5ad-4b59-9eda-67518a09e207	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	64	bpm	2025-09-11 14:24:40.09+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
46e67940-2e5d-4c33-a88e-db3e8e0e8067	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	94	bpm	2025-09-11 18:13:27.969+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a3713063-a68e-4e45-8aa1-67acf75f87ef	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	81	bpm	2025-09-12 00:19:03.131+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1ffcaf53-e5cb-4ce2-9006-22f2f0905fb7	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	73	bpm	2025-09-12 03:50:36.198+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b3ee6b61-18a6-43aa-aafc-f079cd17e1ab	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.951256423938953	hours	2025-09-11 15:48:20.307+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a208d190-998e-4d02-96cf-c10b4341d764	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	408	kcal	2025-09-11 15:08:31.205+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2645def6-3bf8-4e23-81af-945bb87386d3	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	403	kcal	2025-09-11 21:21:04.502+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8f2e5e44-e3b6-4526-ac9c-7382450349b4	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	422	kcal	2025-09-12 01:07:38.444+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a3fd52b9-d016-4b58-a8a8-018895cff448	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	22	grams	2025-09-11 16:51:56.237+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
87491774-bc5a-45f7-aeac-ee728a79d4a7	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	33	grams	2025-09-11 20:41:51.5+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c9a3944e-fa83-43be-829f-6cd6562cf97a	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	38	grams	2025-09-12 01:06:59.312+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9a5bde20-a466-4670-ad4f-cb0c50c329ab	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	19	grams	2025-09-11 15:30:56.653+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5a770562-a956-42a0-8a50-56baee34b48f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	39	grams	2025-09-11 20:52:56.19+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2d18ef6c-04c8-4be4-a816-c14ad9a8d23c	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	195.82392887026273	lbs	2025-09-10 15:42:24.602+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
525d8384-327c-4816-88f8-8fe25b1f0703	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6840	steps	2025-09-10 19:08:13.602+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
79a22023-9a0d-4aba-9fa7-2e8b3b1d0975	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3719	steps	2025-09-11 00:26:49.277+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
7ebf9b7f-7c5e-4644-b1d1-e9013819591e	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3519	steps	2025-09-11 05:23:51.988+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d2503fe3-74f1-4f97-af13-cea344d0e20b	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	74	bpm	2025-09-10 14:17:12.492+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ea4ab40e-c16c-47ab-abcf-3abec7bd0235	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	78	bpm	2025-09-10 21:43:31.3+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
823adc7e-ef75-4d05-bd23-28777dbbb645	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	78	bpm	2025-09-11 04:01:03.207+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
54fcafb0-552a-4829-9d01-824d1bcfce03	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	6.933317893713327	hours	2025-09-10 15:49:15.877+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
26acdf35-62e2-4792-afae-117def819c48	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	711	kcal	2025-09-10 16:53:15.334+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
596a3e5e-9170-4f49-ae2e-7b6beb4fed6e	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	683	kcal	2025-09-10 21:38:57.043+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b1083f2d-81c9-48bf-9da7-bfba4f4e9d4b	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	576	kcal	2025-09-11 01:15:38.032+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
baa05dd9-ebdd-412c-b8eb-fda2106c537e	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	48	grams	2025-09-10 16:37:27.848+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6a5f306d-cd93-4038-b9a3-9a3beaa9cde5	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	29	grams	2025-09-10 21:01:08.114+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a9eb5f63-553d-410e-b53c-a9bafcd34922	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	44	grams	2025-09-11 03:01:11.019+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e01cdbcf-c70f-4cf5-ae5b-b391196ca55b	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	11	grams	2025-09-10 16:04:55.367+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
923dffff-6b1c-4ab5-931f-1e87c23f9ca9	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	30	grams	2025-09-10 20:35:49.23+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
18c61721-4397-462e-bcad-b270a5254b50	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	192.13895684056027	lbs	2025-09-09 16:12:42.103+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
34e034ca-3166-4e20-ac16-49a0e0d5069e	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6975	steps	2025-09-09 15:20:31.231+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
fc6f9fa5-1f39-44bb-9169-4e784e30022f	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6980	steps	2025-09-09 22:09:28.79+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e52c134f-acee-4667-b160-172246e48b44	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6222	steps	2025-09-10 07:12:46.421+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1b84880a-8059-45ef-898f-006feee6e8e3	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	74	bpm	2025-09-09 14:36:13.32+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
03b268a5-f165-4e86-b8fe-37fd2134c00a	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	84	bpm	2025-09-09 19:25:04.404+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
73eb313f-c633-4265-ab02-72f404ebbf9c	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	89	bpm	2025-09-10 00:32:42.163+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
7748e050-5695-480e-93ea-c5a50066df07	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	72	bpm	2025-09-10 04:21:16.218+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ffb5beae-75a9-499e-b863-f39e0a84e4d1	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.301814033759248	hours	2025-09-09 16:01:53.803+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
97e06c13-edd9-4a59-921f-9ec43e8b6371	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	472	kcal	2025-09-09 16:21:18.808+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9fdd67df-ea6f-4516-86ec-3243605456b5	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	867	kcal	2025-09-09 21:49:26.915+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
98e84669-5c5e-4f7c-bf2f-e123d8e698c0	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	852	kcal	2025-09-10 01:18:11.945+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3b08a247-2f23-4ed5-aa63-59f69514b40d	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	54	grams	2025-09-09 15:08:17.271+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
96eecf93-28f7-406d-a4a1-c9924f829464	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	32	grams	2025-09-09 21:50:31.838+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9265899e-3f7f-4b32-979d-d7ead994c67e	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	38	grams	2025-09-10 02:55:05.202+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9cd338e7-5334-4bb1-ab10-57b97f9cd2d5	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	31	grams	2025-09-09 16:55:31.391+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
768eb418-d19b-41b8-a351-26e49f058804	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	15	grams	2025-09-09 21:13:09.142+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
dea8fa82-74ab-4aba-a680-b3e23cada972	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	195.1996712941337	lbs	2025-09-08 16:10:08.087+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b920c72a-62e2-405c-ae0e-58cba3c6bae8	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5899	steps	2025-09-08 18:15:50.451+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
01dacef6-9b0c-4349-8c52-bb9dc3b81d50	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4402	steps	2025-09-08 22:14:17.653+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3f7cda29-ea2b-49c8-bbea-67ca1762c745	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5375	steps	2025-09-09 04:49:50.925+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
735a4133-b61b-470a-b792-e3976964e9c6	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	68	bpm	2025-09-08 15:04:49.12+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c4c1c6fc-a9cf-4b8e-8de1-e87a6b938f85	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	86	bpm	2025-09-08 21:44:35.218+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3eaaed39-75d6-400d-8167-b31076410465	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	62	bpm	2025-09-09 05:13:34.084+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8bbb59c6-b91b-4d79-878b-73cd66f67318	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.337206449758189	hours	2025-09-08 16:45:13.65+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3781de04-e9fb-4994-97c6-8d3c9a457fa3	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	614	kcal	2025-09-08 16:33:30.089+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
85dd37eb-7e07-442a-8b08-0baa4a89f724	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1061	kcal	2025-09-08 20:17:52.87+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9ffdc33e-1925-44c4-b2d3-88e6bb5f76cb	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	32	grams	2025-09-08 14:46:38.399+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
289f4880-dca5-485a-a1be-83cf173fb7e7	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	31	grams	2025-09-08 21:06:06.391+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
64395b9c-f0dc-46ae-9808-76760002c831	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	12	grams	2025-09-08 16:12:19.418+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e573f10d-beaf-40d6-af15-53494c7c19cb	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	32	grams	2025-09-08 19:48:51.719+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
7529cb33-bbb4-4af2-b5e6-d4842328244b	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	22	minutes	2025-09-09 03:34:20.697+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
63194f38-e4c0-4e78-90e1-7f656e98fb74	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	195.47519963026562	lbs	2025-09-07 16:16:11.473+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
454c576e-28ae-4211-916b-329a77689edc	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4828	steps	2025-09-07 15:45:30.451+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
64cdc522-f40c-4290-b657-3eb3251c346b	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4215	steps	2025-09-07 22:12:22.083+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e1c29c01-ce20-44bc-9232-a0d18c91f3dd	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	62	bpm	2025-09-07 14:15:12.879+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ce9a9372-dff7-40f5-a537-de6ed3ca4c30	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	84	bpm	2025-09-07 21:24:43.303+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1b52378d-7043-4333-8a85-ab97d110d45a	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	70	bpm	2025-09-08 04:38:24.671+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0fe96844-9a42-4916-929c-f7f4c30d3212	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.364113340872814	hours	2025-09-07 17:08:47.939+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e3bbe06d-069b-4f35-9368-ea4c0bef1b34	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	634	kcal	2025-09-07 15:12:33.713+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9f56dd28-a134-4ff6-8e82-15bd9cc3119e	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	459	kcal	2025-09-07 19:34:46.066+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a90e4be7-d028-4757-bf7a-c982f23045de	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	529	kcal	2025-09-08 02:20:59.083+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b2cf608c-d55f-4009-9734-ba2ba6b37f23	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	40	grams	2025-09-07 16:22:08.07+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c731de22-f085-4b09-a947-056f9f9e4a0c	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	51	grams	2025-09-07 20:04:03.018+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0755f1d1-4b91-455d-80ab-2e6303cf821b	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	51	grams	2025-09-08 01:13:20.649+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a7d7b47b-22c9-4a15-a404-5eff73abc7f8	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	34	grams	2025-09-07 15:28:15.639+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0c419919-8c90-4bb4-84db-0d55253dd697	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	18	grams	2025-09-07 20:44:48.22+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
32275361-266c-43be-8e39-0f2daac3fe2a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	21	grams	2025-09-08 00:18:21.385+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4eae043f-c348-44e5-b578-c32eaa16f8d7	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	25	grams	2025-09-08 05:00:42.731+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
95396574-5a87-42b6-bb76-dc3ed1bc25d0	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	62	minutes	2025-09-08 04:06:43.575+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ab76c724-c69a-45b0-9ab3-9419effa85f3	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.41235600819263	lbs	2025-09-06 16:08:53.013+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
03b55bdd-1932-4e1e-9a9a-2770d9a0a60d	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6598	steps	2025-09-06 17:41:24.572+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
95e29e32-40de-4233-87ee-4d7319264530	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4086	steps	2025-09-06 23:49:51.443+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
089424d8-2bb0-4a3b-8530-7f78ac1f2c69	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3852	steps	2025-09-07 06:57:18.792+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
7fe8790f-0ddf-49f2-88da-f42ef22fa0d9	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	62	bpm	2025-09-06 13:57:08.566+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
54cb9979-ccb2-4b8f-9548-3945e7453417	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	86	bpm	2025-09-06 21:17:51.054+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c2d1f89e-4096-4169-a89b-5380559d102a	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	75	bpm	2025-09-07 04:16:16.236+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9c70d9c9-fcab-45ae-81a1-b0b69ebaedda	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.54904618378964	hours	2025-09-06 16:54:48.563+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
15f7dc17-5186-49d0-9007-23dfd4ea03e8	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	610	kcal	2025-09-06 15:42:48.382+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6efcba76-25bb-4503-9b81-80586861f961	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1078	kcal	2025-09-06 19:51:19.828+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2e6d7628-8cee-4e31-acba-4a93774035a7	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	692	kcal	2025-09-07 01:53:20.383+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
aad21220-6bc7-484e-b1b5-e2f6467dbe39	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	59	grams	2025-09-06 17:01:34.151+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
69f7fa9c-92b0-4404-a102-ba06c9535935	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	49	grams	2025-09-06 21:25:22.772+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1833d032-4d75-42fe-b20e-123a1620b688	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	32	grams	2025-09-07 01:23:52.662+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d040e5ed-0c6c-4cfc-a17c-18792a14f3b4	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	21	grams	2025-09-06 15:25:08.836+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ea3a6d8d-11d2-4253-91bf-daaa5e336417	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	12	grams	2025-09-06 20:40:12.275+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
73dab9e7-3c8c-4a38-a7bc-edc49c218c0a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	32	grams	2025-09-07 00:36:05.789+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
646dbad7-da08-4523-a492-acd7af302c0d	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	10	grams	2025-09-07 05:05:55.077+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f0fe0fd2-62a2-4324-b529-eb67546f635c	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	62	minutes	2025-09-07 03:21:48.332+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
7ed35ce0-67ee-413c-bdba-f0eac9c363e4	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	193.15974777467937	lbs	2025-09-05 15:56:01.286+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
78a940a7-8e71-47ff-84cb-6ab4156e50c6	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2637	steps	2025-09-05 19:15:01.428+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
974b1e9d-0c85-4d29-8404-f4de8940c250	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4053	steps	2025-09-06 00:26:27.986+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9a50a825-a6bd-440a-88c2-7d3acbdc652f	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3438	steps	2025-09-06 06:29:26.199+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
424cb137-0472-440d-a657-25c408c0c647	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	69	bpm	2025-09-05 13:50:35.362+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
fcc69093-6118-454f-a512-65ded199e992	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	78	bpm	2025-09-05 17:58:43.804+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c517a08f-85d5-4115-acee-5f7ff1a9e16c	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	87	bpm	2025-09-05 23:16:43.727+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5af95218-666e-46f6-9992-e8e29b2c9bbd	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	62	bpm	2025-09-06 04:20:54.236+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
168b75ee-b02d-4888-bca1-543ff79c112b	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.019531314824432	hours	2025-09-05 15:56:47.734+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
89ea8b5e-639d-438c-b40c-ee7473baac4d	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	700	kcal	2025-09-05 16:19:47.638+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9895e0e8-81ce-442a-86f7-993de7b6b75d	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1069	kcal	2025-09-05 20:27:01.15+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6c4bfabf-b935-400a-a8c5-43948c2323f5	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	39	grams	2025-09-05 16:39:59.024+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a4d92f36-28a6-45f6-b4c8-44097e881236	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	49	grams	2025-09-05 19:43:32.575+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1eb30814-2031-48c7-9764-c81bdf0c6b3c	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	32	grams	2025-09-05 16:48:52.779+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
bcab149a-986e-4a53-bc6b-edaa9d90c65e	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	33	grams	2025-09-05 19:36:42.547+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d60c896a-0d41-469f-ba77-e74c5731c284	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	36	grams	2025-09-05 23:22:35.418+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9bbbdfe0-c453-400b-adab-865e3b52da99	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	192.3174735577145	lbs	2025-09-04 15:20:52.34+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4e1ae4e7-2dee-4009-8882-e940ef25cf4b	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3385	steps	2025-09-04 15:20:19.823+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b49fe6b3-643c-4d0c-948b-4d54038f183d	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4985	steps	2025-09-04 21:25:18.69+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
42e41e12-e7e0-43b8-bce4-076b8aae5026	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6267	steps	2025-09-05 07:04:37.407+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4a3ad86f-af75-47e4-8550-fee73ee1367f	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	56	bpm	2025-09-04 14:01:57.193+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5efbfa38-56c1-477e-8a6d-16263af58840	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	80	bpm	2025-09-04 18:24:43.179+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2c28e924-e26a-4ab9-89da-ba3a517478ea	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	77	bpm	2025-09-04 23:31:08.945+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
49f1d553-1cd3-4d6a-921a-ef0737c7d5c8	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	79	bpm	2025-09-05 04:03:31.51+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d9f3dd27-b8ff-4414-959f-991c52fe83d4	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.968780641010277	hours	2025-09-04 16:41:42.682+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8b37d283-e7e7-4ba6-81c6-c00c4ac652a1	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	935	kcal	2025-09-04 15:50:38.373+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
32b6b70f-ac2f-4a0a-842e-d984ce033c7d	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	966	kcal	2025-09-04 20:12:18.177+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8f0c7c37-2284-44f6-ae1d-4be7e7f16684	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1198	kcal	2025-09-05 02:43:07.152+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
98d943bc-5e8d-4701-91b7-fd9c2d7f934f	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	26	grams	2025-09-04 15:40:27.735+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e4a589ec-d940-403c-9f92-2737a6922be9	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	56	grams	2025-09-04 20:48:44.792+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6a8b4e6b-6c23-447f-97cf-246d67930936	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	33	grams	2025-09-05 01:33:41.308+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1d758c5e-de6f-4cc9-8ea8-7b43e05be9b1	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	39	grams	2025-09-04 15:24:16.919+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
24a6598f-7d97-41e4-8048-73c5f9844dd1	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	37	grams	2025-09-04 21:13:52.672+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
fb28568c-7853-49a1-b1b6-deab504b53e5	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	26	grams	2025-09-05 01:06:18.332+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
baf62d4b-302a-43d4-b918-a720daae7493	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	63	minutes	2025-09-05 01:15:06.828+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
19f856d2-0eda-42ff-8300-1a2f86a14a76	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.0049948321118	lbs	2025-08-31 15:00:25.493+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b2157307-e64f-4b9c-bace-970f22efc3c5	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6836	steps	2025-08-31 16:32:03.166+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
06c29d44-efef-4196-b545-e04d63f5e109	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4202	steps	2025-08-31 21:59:59.884+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a07b9bd5-5297-4c37-844d-1ef409c8e628	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3073	steps	2025-09-01 03:20:40.798+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
04a2653f-1d0d-48e1-9c61-a642f3c1d2d9	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	65	bpm	2025-08-31 14:51:48.93+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c27ca45e-353f-402d-9f87-ecbd43e070e1	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	80	bpm	2025-08-31 20:19:41.869+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
92a25899-dbe4-4749-b7c9-da63bf82b5b5	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	77	bpm	2025-09-01 03:54:02.832+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1e6b7f39-00a4-4d04-8831-7541e4b5230f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.452178534087828	hours	2025-08-31 15:40:18.271+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
222391b7-c246-4e48-a5d3-1af89a4904eb	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	942	kcal	2025-08-31 14:25:21.654+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d1834543-60f4-4c30-a7b6-aa329596ffd6	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	838	kcal	2025-08-31 19:38:17.242+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
14ea3324-6114-4291-af67-419fe2d72504	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	788	kcal	2025-09-01 02:16:57.794+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
050ff2b4-8164-48fb-9022-d47d7818f393	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	26	grams	2025-08-31 15:33:48.586+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
88803a53-865b-4389-a17a-4941d4852d73	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	27	grams	2025-08-31 21:13:25.027+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5d779f3d-7d9b-4040-a3b2-eab4624a44ea	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	28	grams	2025-09-01 02:56:17.612+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
430174f5-d672-477c-b411-047588f772b3	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	19	grams	2025-08-31 15:29:37.798+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
fd085294-9cc6-4dac-b0ea-c029f4ff5703	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	25	grams	2025-08-31 19:30:34.65+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
213cd0de-0ab9-4281-9808-b34ff7b86b2e	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	193.6103636067434	lbs	2025-08-30 15:21:44.774+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f6432136-9395-459d-bd8b-a3db0e221cf2	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5129	steps	2025-08-30 18:51:05.685+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
87741b66-b434-4628-9efb-3c78578e540b	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2942	steps	2025-08-31 00:41:08.283+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
fea55c71-dbd8-4ef6-990e-e249dbeddca8	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2778	steps	2025-08-31 06:17:47.105+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
cda99531-6f71-4caa-95e2-e791c4bcaf14	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	73	bpm	2025-08-30 14:26:28.018+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
27749e35-0bb3-4c9c-ae12-fee25ca4f2ea	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	65	bpm	2025-08-30 18:09:46.942+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b2c45594-838c-4781-9f50-7068c161cf49	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	87	bpm	2025-08-30 22:05:50.744+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
db956f16-e053-471a-a9a0-ec8d5a5a0603	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	65	bpm	2025-08-31 01:41:31.701+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
07b20bab-f162-408f-aaa0-305e58632fa7	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	76	bpm	2025-08-31 04:54:29.69+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
835c086b-1094-4d03-82e2-a7f3d5ac5084	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	6.798332004623293	hours	2025-08-30 16:22:56.609+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a9dc4568-17be-4bfa-b99d-8428c3bcce8f	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	804	kcal	2025-08-30 14:18:52.363+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
617f681b-221c-46e3-bfe5-786ed8e07e90	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1033	kcal	2025-08-30 21:03:58.326+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e464745f-4f34-4be5-b9a6-c95c6d88b410	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	660	kcal	2025-08-31 02:23:50.833+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e2401038-e73c-4901-bd51-ce8426a2110f	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	23	grams	2025-08-30 17:08:16.738+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d81d2b67-b40b-4d89-bf69-6e9635bdf8a0	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	29	grams	2025-08-30 20:23:22.941+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
bb1e1fd8-b949-48cf-8ea4-77bdffd847a4	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	40	grams	2025-08-31 02:09:18.971+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0c017cc1-cbd5-4081-8836-8866719fd497	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	12	grams	2025-08-30 17:04:27.937+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ff52b54c-733a-4fda-9911-12b3fe4560f6	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	18	grams	2025-08-30 20:07:08.899+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
890598a9-4aa8-4ab1-8dbf-cf81d8e4a29a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	20	grams	2025-08-30 23:30:15.551+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f59126ee-efa7-420b-8cb5-37fa4c7dcbe0	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	67	minutes	2025-08-31 01:10:56.914+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
75a53758-60d9-4be7-827d-ad00a0bd71b9	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	193.61476722668215	lbs	2025-08-29 15:42:50.198+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
399e1221-1d09-4504-957e-e569582af345	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2212	steps	2025-08-29 16:46:28.55+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0354fc11-999b-45ce-9747-d79f05fc73f9	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2682	steps	2025-08-29 23:31:06.808+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
334e16ed-19c7-41ad-afc8-deb21d41d117	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	56	bpm	2025-08-29 14:59:07.01+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b763ffa0-c453-4ab0-a4c3-b868078e68c3	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	92	bpm	2025-08-29 21:57:47.078+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b394e1dc-7057-4f64-ab9a-1f65c5356fcc	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	71	bpm	2025-08-30 04:16:15.708+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1872b3ca-e3b9-4ee9-bedc-7d19cb9ddedf	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.252303318229524	hours	2025-08-29 15:38:44.475+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a26f2b62-691d-448b-8610-76348d890e77	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	654	kcal	2025-08-29 16:32:17.722+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ad3a932e-21dd-49e1-9bbc-218fc73759b4	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	497	kcal	2025-08-29 19:47:25.568+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
02b6bed6-ce67-4cdd-9cf1-6d8968d840e8	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1141	kcal	2025-08-30 03:14:12.975+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a10b6150-c6b4-4755-8158-557c414abe5f	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	22	grams	2025-08-29 16:01:17.977+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a322f17a-f8f6-40f1-abb4-824ec3fcaf55	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	28	grams	2025-08-29 21:01:02.988+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4f117c88-2016-4789-9d75-7957ae5299f8	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	40	grams	2025-08-30 02:22:11.173+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6002b067-d691-4a1f-b86a-08718e4aa729	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	40	grams	2025-08-29 16:12:55.038+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c8140df9-8d0a-4d1b-8404-19f6bf4137f6	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	27	grams	2025-08-29 21:15:07.19+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
ce8b1ae5-36a3-4702-b01d-3047605c24a5	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.47501560204	lbs	2025-08-28 14:51:00.667+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
469c84e1-13f9-4c0b-8de5-54f15e313753	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2895	steps	2025-08-28 17:16:46.499+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4b8286df-ec45-499c-91e1-20d4bdd57008	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5712	steps	2025-08-28 22:05:07.631+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
fd19956d-615e-480b-b4b0-41ebdadd8845	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6890	steps	2025-08-29 07:05:01.837+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
98b52e9a-2517-4060-a857-a4798fab7d24	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	62	bpm	2025-08-28 14:36:34.702+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
be10b02a-819f-446f-ba9d-0264a0233121	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	69	bpm	2025-08-28 18:33:56.505+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9a09f8ba-31e9-4243-96c2-603bfebaecf8	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	94	bpm	2025-08-28 21:08:16.964+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
cbe82c44-68f3-4273-8458-9a768a553301	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	67	bpm	2025-08-29 00:51:29.851+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a9cfb7c1-9a92-4c3e-a436-a89789bf4fb5	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	77	bpm	2025-08-29 03:37:56.092+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0ba9a360-dc3e-430c-bd76-fc5a8798de9e	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	6.634814368149595	hours	2025-08-28 16:15:18.206+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c09907e6-6e90-4428-be6d-6fd1db417085	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1149	kcal	2025-08-28 14:35:52.973+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6b11577d-0d81-468b-adbc-736e07484b64	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	981	kcal	2025-08-28 21:39:14.836+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6975c547-17e4-4668-9856-1a0da19d666c	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	727	kcal	2025-08-29 01:43:00.042+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6ad31107-86f6-4a79-a37c-b2eed1f3bc74	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	38	grams	2025-08-28 15:38:16.705+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
378a42fc-3294-4082-9afb-3b1a6dd20313	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	47	grams	2025-08-28 20:33:11.841+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b38ecfc2-9a1b-48a5-a70a-76fe59b5a8f6	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	27	grams	2025-08-29 01:18:11.988+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
755c2d1d-bf7f-41a9-a741-c965acd1e73a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	13	grams	2025-08-28 15:34:18.371+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0f7423a7-302a-43ab-a94b-3c3f03049d96	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	25	grams	2025-08-28 19:32:01.621+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8d2c2758-3aeb-49ad-86f8-18e9823a0620	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	29	grams	2025-08-29 00:08:00.867+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e458713c-4fcd-4a88-aa34-7bfcb7ee047d	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.18173830874716	lbs	2025-08-27 14:27:08.567+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f53addc9-d2aa-447e-8ed2-8da9727225a5	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4022	steps	2025-08-27 16:27:28.46+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
91e44b90-e16a-46a0-821b-7f8e783408a1	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4829	steps	2025-08-27 22:41:17.087+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b430cf71-2a0f-4fdb-95be-95286f16a46a	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6673	steps	2025-08-28 05:27:22.22+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
108cd147-aff8-4e31-9170-ce51cc7040a6	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	72	bpm	2025-08-27 15:10:34.39+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a03bf6e6-af89-476c-8630-6a6a89c7d3f4	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	85	bpm	2025-08-27 20:59:52.443+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1d60e48c-4bae-4225-82e2-3e92728be480	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	70	bpm	2025-08-28 03:26:45.832+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4976a50b-7316-4e7b-9363-cc005ffc2d48	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.119969368876472	hours	2025-08-27 16:30:13.637+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0e755890-d81a-47dc-93d4-47b738e2734b	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	770	kcal	2025-08-27 15:27:03.66+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
04cdeb12-ffb5-49c3-9a9d-319cd981f257	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	482	kcal	2025-08-27 21:04:49.689+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b7e2adab-8d1d-4716-8f44-a1a7e99bce5b	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	783	kcal	2025-08-28 02:13:25.348+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
158e135a-2ea4-4d17-96ad-eb97a6c06224	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	38	grams	2025-08-27 16:34:32.419+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4fb9cf55-f27d-4447-af0c-6970bd1f59ef	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	49	grams	2025-08-27 21:41:24.893+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4f91f3c5-954a-4d9c-b4ef-53f0e899eb09	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	26	grams	2025-08-28 03:08:08.14+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5fb597fb-c0f6-4e9b-94de-46687bdd21e1	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	18	grams	2025-08-27 16:37:09.57+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e2e1017b-8313-4b44-8b78-045a2b9bbeef	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	11	grams	2025-08-27 20:35:13.89+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b941b330-816f-47d4-8380-33e43b5ef461	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	19	grams	2025-08-28 00:14:50.58+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
6dc3d507-8a86-4481-8ef0-6281df726480	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	23	minutes	2025-08-28 03:18:31.049+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
7c9185c0-9738-4be7-a663-c9b776d76d2f	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.59413268289555	lbs	2025-08-26 15:32:01.667+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
afe43873-4d17-4ec7-99df-d28f39ec319a	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5575	steps	2025-08-26 19:16:26.238+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a96c472c-8d2c-429f-813a-a96cbc936f6b	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6779	steps	2025-08-26 22:55:06.903+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
91b2138d-3470-4a17-9cdc-c6dea68df416	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	55	bpm	2025-08-26 14:33:26.149+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9c39088b-71d1-4708-8089-745e569b8692	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	85	bpm	2025-08-26 20:30:56.775+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
70a59595-1c97-4d76-a20c-21cb70fa23a3	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	66	bpm	2025-08-27 03:22:10.486+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5e252551-012b-4f87-9e5c-893658e55326	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.386915029652272	hours	2025-08-26 16:52:17.082+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3be684e6-fdc7-4472-9eef-a5ce3a70a528	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	924	kcal	2025-08-26 16:09:03.103+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
32a290e6-d3ad-488f-8734-cd69484c5970	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	769	kcal	2025-08-26 20:05:49.662+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a300aa9c-a5e8-4344-ad18-8b085adb4bb3	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	648	kcal	2025-08-27 01:45:45.903+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
77bcb63a-9c1f-4dce-a6bd-b4380c1b1e30	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	36	grams	2025-08-26 16:59:41.787+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8a020475-48b0-4479-99d8-f23b2c7dd73a	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	32	grams	2025-08-26 20:33:42.113+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e40e49e9-178a-4383-b5f4-59ab85f4bf8b	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	55	grams	2025-08-27 02:44:59.152+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
47b61e3a-65aa-4323-9e45-8a718dc6b17b	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	20	grams	2025-08-26 16:06:07.08+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a25b109d-6d8e-4eea-b130-15c6c9f6c4fc	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	20	grams	2025-08-26 19:28:06.929+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e97087b2-a779-4f3b-98fc-f171c7aa3ed9	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	28	grams	2025-08-26 23:18:13.155+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
aed9a12f-c478-447e-9e6d-14fc793d3d97	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	60	minutes	2025-08-27 00:37:53.185+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
2cdfb729-42cd-43a2-98b1-5264bbf85aaf	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	195.005478575339	lbs	2025-08-25 16:06:14.75+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4aaf4c5d-c16a-42ca-ac6c-9477c7341fab	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3708	steps	2025-08-25 16:54:26.287+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
997f1c6e-2cbc-4182-bac0-db35981166ed	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2878	steps	2025-08-25 21:32:29.82+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d4de6331-2cde-4039-98a7-8625f27f810c	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	69	bpm	2025-08-25 14:59:41.025+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4f1ad2cd-a72a-4006-ae3e-c29a46f3d866	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	57	bpm	2025-08-25 18:43:17.92+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
879bb41c-e81e-4bd8-844b-8c34ba9e0ed7	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	76	bpm	2025-08-25 21:55:18.479+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a10e301b-f263-41a9-a7bd-b742d5c13f91	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	63	bpm	2025-08-25 23:58:26.415+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
13fe961d-dfd1-4579-9732-9fc2ba490592	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	63	bpm	2025-08-26 04:36:52.117+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
9bf059c9-5275-49df-b74f-26abde2c415a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.397002169968727	hours	2025-08-25 17:13:52.217+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f2e3f59b-eda2-4055-ba83-70f5a167b5c7	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	699	kcal	2025-08-25 14:35:00.513+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
986308ad-c26a-4298-815e-fa06ba0809f2	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1104	kcal	2025-08-25 21:13:25.755+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
fbaa4805-944f-4859-af9d-f49c7ad79380	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	25	grams	2025-08-25 14:45:59.555+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
356e3c71-66d0-4b6b-80c8-9e55c7cb8848	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	60	grams	2025-08-25 21:11:01.361+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
b508602c-5e88-428e-97ca-cd4efcbf8922	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	19	grams	2025-08-25 15:24:31.474+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
811712d4-2ee2-4cfa-b75b-bb896a151224	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	16	grams	2025-08-25 20:59:30.879+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e2948daf-2120-415a-a8c8-69e637238dc1	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	25	grams	2025-08-26 00:53:08.781+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
af809c1d-21b5-4c03-b24c-e16c20b3ff47	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	193.561053443995	lbs	2025-08-24 14:54:13.499+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e69dcbd2-1df9-4c56-b5a1-5d2fbd3daf9a	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2436	steps	2025-08-24 17:22:27.025+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
40f3e501-1cf5-4241-bb2d-ae1ff6df1c0d	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5118	steps	2025-08-25 00:49:04.599+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
c98d5b51-f541-4ccc-9a56-ff292b969c84	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	62	bpm	2025-08-24 15:11:19.474+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
d2e4399c-0498-4026-9903-1840d7b8daa3	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	95	bpm	2025-08-24 20:57:15.176+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
0ed6dba8-bb80-4b08-8a50-e50e44499d04	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	73	bpm	2025-08-25 03:30:48.895+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
cf2d8303-8096-4ab9-8ec8-70294734cbd9	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.072742795253397	hours	2025-08-24 15:29:37.829+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
35927c30-5771-4037-bbfb-c5a63de9f379	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1001	kcal	2025-08-24 17:03:19.918+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
8fc978c2-7a40-46c8-ad6f-abbf02ca0975	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	912	kcal	2025-08-24 22:11:12.291+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
f4545cff-2ffb-4bee-8035-05e3cad83383	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1167	kcal	2025-08-25 02:25:01.057+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
662846d2-f970-4b1f-bb14-c00951d2688e	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	39	grams	2025-08-24 16:58:36.061+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
143859da-d631-44bd-9793-8aa22addf781	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	56	grams	2025-08-24 20:30:55.569+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
4e43a4af-b61b-4b8f-9f0f-01adb9a3d3f5	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	24	grams	2025-08-25 03:10:14.167+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a819b408-a727-4512-9cf2-86858e6d0c88	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	36	grams	2025-08-24 16:54:32.38+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
5a82b2d2-c4cc-47ba-a307-ab6a5d089f04	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	19	grams	2025-08-24 19:37:50.498+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
a112c6a4-2144-41ca-9842-6e448264831b	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	39	grams	2025-08-25 00:38:43.114+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
e25d8dbc-adfa-460b-9a52-d7bbe07e5822	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.35317193153162	lbs	2025-08-23 15:43:08.569+00	manual	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
3b3e6c6f-9ffa-4d39-812c-d001418d7ac2	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5409	steps	2025-08-23 16:00:35.967+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
1dbb561e-a76b-4645-ba38-2d1e25ab48be	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3852	steps	2025-08-23 22:41:11.063+00	healthkit	{}	2025-10-14 07:17:06.319+00	2025-10-14 07:17:06.319+00
fe3fa75f-475c-43e4-9b35-7108826c0232	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6107	steps	2025-08-24 03:27:01.974+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
1f3ceefc-d757-48df-9de0-3cd4dbc8e593	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	63	bpm	2025-08-23 14:48:09.399+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2ba3c202-7ae0-4ae4-9d14-78a1d4d2d28b	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	93	bpm	2025-08-23 20:27:26.739+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
23a364a4-ba59-4124-ac1c-4893c5272f3d	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	78	bpm	2025-08-24 04:15:56.453+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
c80a26ed-c827-439d-9b1b-f37dcc5edc65	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.358855190706095	hours	2025-08-23 16:33:25.462+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e3754f9a-741b-489b-b84b-4dcdaaff26f4	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	560	kcal	2025-08-23 14:30:45.617+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
00dea318-2130-465e-928a-3a8135e42923	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	451	kcal	2025-08-23 20:28:47.714+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
9271449b-15ea-4f84-9479-2679b18667ce	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	49	grams	2025-08-23 16:40:22.833+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
800642a7-a181-44ec-9ac1-d7a0869d740f	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	40	grams	2025-08-23 20:20:48.983+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
54f4d17c-1c83-48b0-8c68-ae15c4a38e3e	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	21	grams	2025-08-23 16:43:59.535+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
7e8b163a-8960-4b41-9eca-8b66abc4d0f3	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	32	grams	2025-08-23 20:28:03.777+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6fab191b-a051-4cab-b5c9-0ee458e5cb04	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	25	grams	2025-08-23 23:36:38.095+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
dbf867cf-b652-443d-881b-990f7fd93c44	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	38	grams	2025-08-24 04:52:13.491+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
549ae96f-cb7e-4e28-85e2-2f8996ffc306	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	192.36969063018873	lbs	2025-08-21 14:40:28.587+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
4ba6596b-7454-47ec-8c4c-326fde385319	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2330	steps	2025-08-21 18:59:49.408+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b170b44f-178a-42eb-87f3-f3d58bcf42e2	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3198	steps	2025-08-21 23:33:34.272+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
89df4a4b-7d38-4ab0-a495-3f688c400b60	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5518	steps	2025-08-22 05:05:11.144+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
01dada60-9f9c-44fd-9fb3-faf3dcbe5560	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	74	bpm	2025-08-21 15:02:46.186+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
3c80b0d0-37f8-4165-9d64-aed29c7a686d	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	73	bpm	2025-08-21 17:42:44.107+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
c4737582-bb07-4715-a5ee-24302ed90662	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	76	bpm	2025-08-21 21:07:59.28+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
34676a24-1f63-4402-bae0-a67d82782d69	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	78	bpm	2025-08-22 01:01:48.674+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
65ae8911-cc99-447f-b650-46b1cf864e45	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	74	bpm	2025-08-22 03:55:50.468+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
c5e9c80d-2a49-40be-b109-fc7df8d51475	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.80977268522056	hours	2025-08-21 15:39:00.848+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
0aa67dfd-8550-42dd-b1ff-f3486e50c5fc	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	911	kcal	2025-08-21 16:27:24.074+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
da7896a3-f9a4-4cee-b43d-bf5dc3e28a84	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	850	kcal	2025-08-21 19:59:14.014+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
d3c71c5c-40a4-48f9-93cb-dad9c5b9d6a5	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	498	kcal	2025-08-22 02:53:12.094+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
370e4af5-f94b-4009-b431-e31e79881071	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	26	grams	2025-08-21 15:34:02.806+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
fb2ffd23-3155-4a7b-97f0-12782bb6e7ce	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	35	grams	2025-08-21 20:29:00.822+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
63681399-ecd4-45ac-8701-655bd8d0a830	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	53	grams	2025-08-22 00:35:30.449+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2bb300ff-6590-4e12-851b-0195891c1c60	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	13	grams	2025-08-21 15:52:38.129+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
eac6475b-9716-431a-a140-a4c9f9a6cb05	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	33	grams	2025-08-21 19:25:10.762+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e64472fc-689c-4e76-917f-06e80006e467	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	196.29823600733556	lbs	2025-08-20 14:57:52.807+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
0f9c054d-e971-45db-bdd2-ed4d31bcfbd7	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4127	steps	2025-08-20 18:45:55.793+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
44a703fd-0126-491b-83fb-6f36b4ea1cc5	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6179	steps	2025-08-20 23:20:47.384+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
cf896671-a059-4f7c-b974-0aba17949955	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5785	steps	2025-08-21 05:49:08.447+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
f672bcc0-cab6-432e-b6fb-970b786ab3ad	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	67	bpm	2025-08-20 13:36:49.74+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b0c76078-bf97-405f-9047-b6184cf5969b	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	92	bpm	2025-08-20 18:21:19.784+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b96d2a47-442d-42a3-b20f-e76499bc5922	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	94	bpm	2025-08-20 23:53:32.618+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
c97c6420-ee01-49a5-a1cf-8bd40271ec19	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	65	bpm	2025-08-21 04:58:40.812+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
42d5bfef-538d-413d-ac55-f2758f95f809	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.180576566908865	hours	2025-08-20 16:54:56.368+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
4e0be328-57e8-4a85-92ae-86b06fa787ea	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	804	kcal	2025-08-20 16:16:24.619+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
ac08a83c-5f74-4fa6-bd59-bc6b6f774304	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	419	kcal	2025-08-20 19:28:09.331+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2969e187-7ca9-4612-8f90-104a257b6f95	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	875	kcal	2025-08-21 02:49:45.67+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
c503c26a-f8d6-4204-a721-a305b4f3cf8e	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	29	grams	2025-08-20 17:13:17.298+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
9a0010bf-770a-4668-9aae-caf246933d25	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	59	grams	2025-08-20 19:49:33.223+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6090d34e-c435-4f1d-ba98-3683a9cedbe7	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	25	grams	2025-08-21 02:38:51.654+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
9cf4be7c-7d11-4faa-8677-a3c2a28bbd6a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	37	grams	2025-08-20 15:42:20.007+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
bf1624b4-42f7-4e89-a790-d3476423dab9	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	19	grams	2025-08-20 19:33:55.912+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
ada4639f-93ad-4954-b677-c4279c17bf26	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	32	grams	2025-08-21 00:58:35.36+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
945c13ef-5322-4e0f-85ab-2536b7ec80d2	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	24	grams	2025-08-21 04:20:22.941+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
c2480d62-1a38-4967-a955-a9dc4824e8d2	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	43	minutes	2025-08-21 00:36:34.472+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
8c5e0dd9-05d3-41a6-93cd-9c3080bd46bb	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	195.00917801115367	lbs	2025-08-19 15:37:15.174+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
ec78292f-89b9-4c48-88a6-783b605cb342	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3966	steps	2025-08-19 17:08:42.593+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
bc41275a-3793-49bc-afe2-75a9cbbf806b	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6298	steps	2025-08-19 23:15:44.969+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
581c9024-f288-4b86-b5ce-87e10029eda0	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	70	bpm	2025-08-19 13:36:50.186+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
69d96ff1-fc01-44ae-aa15-773e81268cbb	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	61	bpm	2025-08-19 18:35:18.827+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2121164c-fae7-49a4-aeeb-e67a62ca6e0b	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	87	bpm	2025-08-19 21:34:34.512+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
fe5fbe89-dc06-49b3-8db4-eb61e171d020	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	74	bpm	2025-08-19 23:56:02.569+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
962962c2-bd43-40b1-aaee-af0ee2669808	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	68	bpm	2025-08-20 04:48:26.459+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e5ad5214-5726-4fd7-98d3-c7edea662e33	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.9415294506624905	hours	2025-08-19 16:05:30.097+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
91a33ba7-abdf-4634-8016-ad4c12f1cb9d	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	615	kcal	2025-08-19 14:36:44.543+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
37a09633-22f8-4e0f-b66d-df9684ab82d6	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	565	kcal	2025-08-19 19:30:11.532+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
68d2bf1c-a6af-40e8-8524-9ab649b86029	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1009	kcal	2025-08-20 00:47:11.583+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
82ee8140-6915-4741-b938-1bad9f39e35a	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	26	grams	2025-08-19 14:18:04.596+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
93e5b489-d63c-4a8c-b7db-bd72fca184a8	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	57	grams	2025-08-19 19:24:32.491+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
618c2abb-77d3-4b04-a810-44a0eb52f345	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	51	grams	2025-08-20 00:57:37.623+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2dec5139-f3d8-42e7-b0b5-d62e13718b18	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	34	grams	2025-08-19 16:21:41.409+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a47f9df8-965e-4193-bfb3-b050ba01de7f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	17	grams	2025-08-19 20:24:43.715+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
c128b1fe-7871-449d-a9e1-b63602067e4b	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	34	grams	2025-08-20 01:03:05.631+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b3d9668f-950c-4ea8-8388-6fd6084af262	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	33	minutes	2025-08-20 01:22:51.541+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
367b7d87-9977-4dfd-ae6d-6053792cac37	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.45004788035314	lbs	2025-08-18 14:55:23.66+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
8426228e-8b0f-4542-8d60-578eecf356ad	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6244	steps	2025-08-18 17:28:47.934+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
74534994-e63a-4520-b637-1ca0f497eb3c	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3159	steps	2025-08-19 00:01:01.251+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
c9ce7f20-e978-4b80-a263-1b9cdbeed264	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	69	bpm	2025-08-18 13:54:53.109+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
d82c0e8e-7df8-4db4-b392-00ff8c9dc7b0	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	92	bpm	2025-08-18 19:06:53.73+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
56f54c14-6c14-4aa1-8854-eb2e1311d172	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	83	bpm	2025-08-18 22:53:33.883+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
161cb5bf-3280-4991-85c8-436cb6b2e39b	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	62	bpm	2025-08-19 04:37:32.96+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
3581ce03-ca44-40b0-9c11-3218fe39b3bf	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.383873968870221	hours	2025-08-18 15:26:11.461+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
1afbd99d-d55b-47a9-860b-5e62d5a68bd6	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1025	kcal	2025-08-18 14:40:30.504+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e1dd0dc0-1f25-4829-9407-1cbfa3127ae6	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1185	kcal	2025-08-18 20:43:17.529+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
204b3e1e-b3d5-4c1b-a1a1-b1d32040b544	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	39	grams	2025-08-18 16:22:48.276+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e42ad0a7-52ce-4646-afee-fda7dbe9ea1b	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	59	grams	2025-08-18 19:33:11.746+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
06f4b908-851f-42fa-a97a-fc948f262d8d	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	20	grams	2025-08-18 16:03:11.014+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
5bb2711e-5609-4492-b5b0-1c7883756cee	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	23	grams	2025-08-18 19:40:36.588+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e213a796-5d0a-467d-8e8a-52bae0e2b46e	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	28	grams	2025-08-19 01:02:40.251+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
aac551f1-8af8-460b-9bc1-fb801b4ecece	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	13	grams	2025-08-19 04:40:02.979+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
d4693eb0-a3e1-40a6-90bd-ea5cf17cbe27	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.95622886495616	lbs	2025-08-16 15:24:17.882+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
7cd3aaf7-a3f4-4e30-b735-af077c481212	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5425	steps	2025-08-16 17:23:37.241+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
4f3defa2-8b1f-4330-a23d-14a0568b3233	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3096	steps	2025-08-17 00:35:04.85+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
5372cedb-4547-44b7-b167-aada688de668	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3293	steps	2025-08-17 06:43:42.894+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e8175fcf-1762-47de-80d3-0afdc26b1184	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	58	bpm	2025-08-16 13:34:02.474+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
05b56b4d-65ac-46f8-abda-2f70b00a503e	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	61	bpm	2025-08-16 17:13:03.946+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
5d3e55b7-9035-4963-a30c-4cbbf7f690c9	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	82	bpm	2025-08-16 21:06:36.592+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
edf8dcd1-4e7f-45b0-b6c1-78bce7862175	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	75	bpm	2025-08-17 00:18:59.675+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
29d73651-5e6f-44d7-a30b-dd2843a4afb3	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	77	bpm	2025-08-17 03:35:38.448+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6417914e-9707-4fa8-8fdb-9f234f187fbb	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.695093543261219	hours	2025-08-16 16:18:21.133+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
17415f56-ae3a-4591-bc0b-eb837f5485d4	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	920	kcal	2025-08-16 17:14:46.206+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
351b0581-7f5c-4c5e-b8d3-f3129af27f28	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	404	kcal	2025-08-16 19:44:33.672+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
0da5f95a-a480-49b9-ba95-b296983de5e0	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	701	kcal	2025-08-17 01:14:32.382+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
f957254a-a1bf-4401-8935-cf9683df7eca	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	22	grams	2025-08-16 15:27:05.065+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
9c736e7f-9837-4978-8b74-240a012a6135	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	48	grams	2025-08-16 22:06:52.463+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
affeed97-c05f-420e-927c-eac5f55bc834	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	35	grams	2025-08-17 01:52:18.204+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
0bec2f14-2eec-4aeb-b7be-d98abccbba81	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	39	grams	2025-08-16 16:40:17.87+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
23f17908-c41a-43a2-903e-6215ba85897a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	14	grams	2025-08-16 20:16:57.988+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
439c44c5-8dbb-4820-ab81-ead41e493ad7	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.62706551909042	lbs	2025-08-15 14:30:52.483+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
cd46c18d-9a81-48c1-9b46-b7d126a02b33	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5656	steps	2025-08-15 17:00:20.975+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
247a0cca-7214-4c02-a7f5-9a03e56239fd	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3201	steps	2025-08-15 22:29:59.487+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
cfc34f4a-0b79-483c-9374-59b2756e58d8	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6115	steps	2025-08-16 03:29:43.81+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
f0a47fec-fc3f-442c-9d2b-2e378efbd648	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	60	bpm	2025-08-15 13:27:52.231+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
cfbdf2a6-f55a-4ea0-ba98-27db5508fea0	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	92	bpm	2025-08-15 21:12:14.158+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
42647a66-55f5-4ea0-9e95-25d28320982d	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	64	bpm	2025-08-16 05:08:59.141+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
58b5c5da-f085-4964-a767-e870dccef90b	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.960643999950232	hours	2025-08-15 16:03:28.222+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
04c26b8b-f2b8-4ae5-b9d2-d904fdd581a7	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1151	kcal	2025-08-15 16:59:14.327+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
770bbd5c-8217-4219-9520-f67a3839bb06	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	869	kcal	2025-08-15 20:19:16.443+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e82c4cb7-72f2-42f2-bca5-cad20f4b7421	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	58	grams	2025-08-15 14:31:56.891+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b88db8ce-e276-494b-a513-69911605111b	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	24	grams	2025-08-15 20:43:54.974+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
eb671dfb-2e64-4fa4-b65b-0f7786f2167c	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	24	grams	2025-08-15 15:28:10.665+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
10f2202f-2979-4ce2-bd36-a8b7b55ae64f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	32	grams	2025-08-15 20:14:10.625+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
58e018b1-7f55-4764-bc03-d04829d50fde	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	51	minutes	2025-08-16 02:35:00.451+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
995665a1-6a55-423e-ba58-1e187de6f1a0	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.79743634473948	lbs	2025-08-13 14:24:11.201+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a39ef8ff-9006-421b-96c1-74d1b8096108	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6637	steps	2025-08-13 15:22:32.697+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
f994f614-3ba4-4f7d-b2b9-d2301863a031	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5334	steps	2025-08-14 00:21:36.201+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
30669ca8-7185-4ca9-a7c4-a8ac6dc98dcd	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	62	bpm	2025-08-13 13:56:05.64+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
692ff115-7d84-4363-baf9-e6264b518b25	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	75	bpm	2025-08-13 21:24:11.371+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
acc3aa64-938f-4678-9b43-703c87eb4102	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	64	bpm	2025-08-14 03:58:14.196+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
827e3085-f09c-4f79-9d5a-afee0e6be562	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.970529420796486	hours	2025-08-13 15:49:29.997+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6dce4ff3-d7b7-4547-9f5b-8673075ce5b7	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	838	kcal	2025-08-13 15:50:36.25+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
696dad29-131f-4e75-840c-bb3e62bd020b	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	441	kcal	2025-08-13 19:27:01.958+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6fe8b7c8-18c0-4d29-a033-deb7a27b6c8f	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	832	kcal	2025-08-14 01:50:34.291+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
1a6289f9-ae9c-40c6-ac47-967d122babe3	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	56	grams	2025-08-13 16:08:07.816+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
5115d9f8-e1f1-4112-a545-81577357f8e0	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	22	grams	2025-08-13 20:11:10.609+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
5007aa58-0f9f-472d-9424-0e9bc61dbf35	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	46	grams	2025-08-14 00:22:21.014+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2793c65c-b993-40d8-bb44-e2cbece2a804	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	25	grams	2025-08-13 16:09:52.919+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a640eea6-144f-488f-b89b-25860848913f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	19	grams	2025-08-13 19:58:18.33+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6fbb4904-30f5-466b-9910-9a31ff313828	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	32	grams	2025-08-13 23:41:38.1+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
545493cd-2677-4100-9f95-b3444d5fd457	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.25020918765526	lbs	2025-08-12 15:09:18.766+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
54530a4d-a9f6-488a-a5c0-c2d8378dc51d	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4085	steps	2025-08-12 17:05:06.995+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
f6ad06c3-6b37-4f24-b7ba-8ac07edd41a0	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3803	steps	2025-08-12 23:05:14.936+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
031203cf-9b3e-45fb-9837-45ebc288c579	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3660	steps	2025-08-13 03:31:26.073+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
586800f4-41bf-440b-ae23-4aa9a6881147	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	70	bpm	2025-08-12 14:27:27.028+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b225b0b6-4612-4aac-90b7-c65d87706f7f	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	81	bpm	2025-08-12 19:36:54.823+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
64a4363b-e68f-4602-b4f3-019833dc5b44	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	82	bpm	2025-08-12 23:50:56.598+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6081dee1-acf8-40ab-a14b-6ad867c4b1f3	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	64	bpm	2025-08-13 03:22:42.341+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
c515a5a7-9100-44fe-9fd3-c6fa34a8a217	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	6.742074773359312	hours	2025-08-12 15:56:24.336+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
5ca6b39d-3623-408c-a28e-9561e9f27f93	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1190	kcal	2025-08-12 14:56:53.076+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
011ae5ca-4679-499e-9ed1-b01dc248dbb4	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	888	kcal	2025-08-12 19:45:14.664+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
33aae713-d7e2-4bba-bc00-51ee7e54ba24	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	550	kcal	2025-08-13 00:24:39.565+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2e8a6d85-db97-4e63-a00b-038327b4e415	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	48	grams	2025-08-12 15:53:07.982+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
06d09f14-e1ed-4f6c-b3c2-6ed3954f32ee	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	48	grams	2025-08-12 20:45:17.347+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
964b4408-b359-42ff-a40a-bc702bbada84	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	31	grams	2025-08-13 02:54:50.212+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
ebd75eef-af9f-46f3-81f6-150d225445f7	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	11	grams	2025-08-12 16:12:42.661+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
41fa77c5-2618-4ccd-b71d-8b15c9dc77af	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	38	grams	2025-08-12 21:15:32.041+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
f4dbfce6-f6b1-4231-b284-af840efba492	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	16	grams	2025-08-13 00:33:32.821+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
09156596-f5b1-42bc-ac14-d2f394337cbd	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	37	grams	2025-08-13 03:25:42.573+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
dc221681-c0f2-4c38-a61d-8daf2be36d8b	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	66	minutes	2025-08-13 00:27:10.383+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
9661897a-e029-482d-b62d-540cfa760363	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	196.9257047231085	lbs	2025-08-11 15:02:30.232+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
38ccc59e-6dca-4cd8-b346-478534d9deec	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3909	steps	2025-08-11 18:44:38.485+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
7a359751-5654-4779-bc08-6733b7911208	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5130	steps	2025-08-12 00:33:32.925+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
59aeffa6-aff8-463e-92e3-1e4e028c6b38	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3177	steps	2025-08-12 04:11:49.351+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
43f9157d-52eb-4933-8bef-ec4658e9bb53	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	73	bpm	2025-08-11 14:48:21.474+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
80099afb-4959-4100-8149-20e3d5a68dd9	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	61	bpm	2025-08-11 18:23:20.84+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
247eeb4d-a2bc-4603-9ef7-53293d69ad1e	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	79	bpm	2025-08-11 20:41:22.901+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
cf5020df-90ff-4c11-bfa4-fdf877e6fed2	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	72	bpm	2025-08-12 00:24:28.457+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
f499170e-f15d-4205-b828-26d9777c266d	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	74	bpm	2025-08-12 04:12:36.343+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a806bde4-4b52-40f7-a3ef-97323620fbc3	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.396313363427925	hours	2025-08-11 16:03:27.484+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a1bc10ca-66b7-4608-bbd9-651f31cf7df0	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	589	kcal	2025-08-11 16:17:20.55+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
df8e847a-5489-49ef-a0f3-71a633dfc866	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1179	kcal	2025-08-11 20:53:36.375+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
7b5aade7-2988-448a-a9db-dc502fc6b74e	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1120	kcal	2025-08-12 00:28:27.463+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
25f6b24f-cdc5-4814-9198-1da5c487e4aa	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	59	grams	2025-08-11 15:48:42.97+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
897e376c-81d7-4549-9054-861529b2d8bd	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	36	grams	2025-08-11 22:16:55.404+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6bf7725f-7a2d-469f-9412-5ae777df00ed	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	34	grams	2025-08-12 01:53:55.397+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
365542c9-9bcf-4877-bfab-5eedb752d5b3	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	39	grams	2025-08-11 16:45:55.652+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
68102b4c-cd82-43dd-837f-f9bb415d4a35	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	26	grams	2025-08-11 19:49:54.812+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
992c4187-cfc2-4e22-bacc-9f587bbf82c4	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	23	grams	2025-08-11 23:47:53.226+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
d58c533d-6972-412d-9a6c-91867bd3d0c0	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	192.8624241892502	lbs	2025-08-10 14:22:04.073+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
ba701be0-1eb7-476c-9309-3bf826b1b64c	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4112	steps	2025-08-10 18:40:52.867+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
494a0c89-15ca-4093-ba2b-80fae00994a1	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3833	steps	2025-08-11 00:49:13.639+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a88f7249-0b19-4b58-8c63-2850b6a6bd65	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4109	steps	2025-08-11 04:03:28.934+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
d0fbf444-973a-43fb-bdb0-7af2c1f2fdb9	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	67	bpm	2025-08-10 14:56:09.181+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a4ad4723-7474-420d-bc2f-5946b692477c	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	57	bpm	2025-08-10 17:45:29.547+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
d7941395-2979-4deb-8246-5b7675b92e89	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	85	bpm	2025-08-10 21:38:15.807+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
eae0371f-3183-40c0-9ab0-61192748af74	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	74	bpm	2025-08-11 00:06:06.087+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a5bec90b-e5d7-493d-99d1-769cbdbae940	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	64	bpm	2025-08-11 04:33:09.812+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
778176d7-8ade-4631-adc5-f76016b4e774	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.127628509556143	hours	2025-08-10 15:59:20.957+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
9c2475af-c54e-40c6-9694-53e998cf53e2	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	821	kcal	2025-08-10 14:48:30.609+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
7a1fa613-322e-4d98-abc3-d8c6a17bcbe5	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1187	kcal	2025-08-10 19:53:54.294+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
99ff1184-6146-4286-a1c4-181e30edddbc	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	978	kcal	2025-08-11 00:24:01.059+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
337a3779-ce60-4f93-aecc-71e84e88b4fc	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	20	grams	2025-08-10 16:01:16.799+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
fc98a074-4858-4954-95cb-589afdcf23dd	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	26	grams	2025-08-10 20:10:34.791+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
30348c2a-ad32-4c9d-b884-2dca814a5ae5	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	58	grams	2025-08-11 01:21:33.391+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
d3bf2ffc-20c7-4c02-b466-4f81deb48a7f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	27	grams	2025-08-10 16:19:01.612+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
c5e1ae47-51ac-429a-b4bf-c4f96442966b	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	24	grams	2025-08-10 20:38:12.848+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
14fb7ed5-56fb-4457-af3a-ccd0b4ed6df9	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	19	grams	2025-08-11 01:05:07.514+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
21547faf-d719-483c-a045-641b0404a7bc	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	58	minutes	2025-08-11 02:25:49.296+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
bd1c2aae-0998-4a21-975b-6f58de0ce48a	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	195.48552782073267	lbs	2025-08-08 15:36:10.038+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
8c1efed2-6c0e-4631-9fc2-c001506d5269	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3568	steps	2025-08-08 18:52:56.851+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
825e845a-8789-4199-a359-53c8ffc03d28	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5011	steps	2025-08-08 23:02:18.533+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b1c61f95-b6b9-4c4a-bda6-68663f9743ee	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	56	bpm	2025-08-08 13:47:26.113+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b061346d-9197-4c47-b0fd-d06e873d08a2	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	81	bpm	2025-08-08 22:13:52.361+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
84d16fc9-47d7-41c5-b001-ef85ff49b1cd	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	71	bpm	2025-08-09 03:25:04.997+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
596fadee-6431-4563-94b5-50493d53c961	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.134840391555724	hours	2025-08-08 17:00:07.607+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
7c7b477b-4029-4b1d-b8fc-5b3d88af6f9f	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	947	kcal	2025-08-08 17:05:49.178+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
d266b5dd-9508-43ad-957b-73248d35912c	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1123	kcal	2025-08-08 20:25:50.624+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e9c057ad-c1fa-47a8-b722-61ec297a8789	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	59	grams	2025-08-08 16:38:06.365+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b9ed5f89-2d8d-46a2-aa3f-8fe9139a83f2	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	60	grams	2025-08-08 22:05:28.576+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
f1eff772-a1f4-482a-9de2-4239a4f6b48c	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	22	grams	2025-08-08 16:54:50.807+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e02a85ba-6a06-4faf-bb7f-678ecf2816d8	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	17	grams	2025-08-08 20:17:50.41+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
15d4c005-9fca-4122-bc4c-1bff88c301be	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	34	minutes	2025-08-09 03:16:07.595+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2e37a24a-04b3-437a-a065-ff3a8063ee52	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	196.51662518501564	lbs	2025-08-04 14:45:43.829+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
58f0c5c7-a1b3-4dda-97b4-9a3dc3ce92bc	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6173	steps	2025-08-04 17:57:32.716+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
4f306446-4ee7-4fff-919b-8cf1dd4bbe4a	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3977	steps	2025-08-04 22:09:07.736+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
227472b5-d9b9-47f3-be01-b65cbf6a1ed5	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5719	steps	2025-08-05 06:20:16.826+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
aaf4c168-84eb-4ab4-9205-1260539bb3b1	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	67	bpm	2025-08-04 14:17:24.49+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e15b0597-5a29-4dbe-95e7-229f71264d06	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	79	bpm	2025-08-04 20:51:45.007+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
fb8edfa1-f498-4a5a-9ee5-07ec52f70032	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	78	bpm	2025-08-05 03:22:26.716+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
aa3e104a-b0aa-4e20-b0bd-06c83dfd6403	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.328765678502245	hours	2025-08-04 16:45:41.622+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
9144dd09-b68e-41b2-9c53-bf284f75fb07	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	822	kcal	2025-08-04 15:30:53.238+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
8766700e-2963-489d-8a90-f622a246ef8a	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1068	kcal	2025-08-04 19:26:42.31+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
352d9bd2-83d2-4d1e-a2c0-4404d2c6c91a	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	995	kcal	2025-08-05 01:35:13.21+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6ce0b710-d8d0-4e66-b892-a3e620103a5b	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	46	grams	2025-08-04 15:46:40.067+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
1678f06e-b9fe-4ad4-a56d-19f7ccfe73eb	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	31	grams	2025-08-04 21:27:37.736+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
ac01e5c3-1fe5-42ed-990d-338758a6e7a6	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	26	grams	2025-08-05 03:16:40.81+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
f9379e7e-d255-45ac-be58-016eade743ea	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	23	grams	2025-08-04 15:48:52.249+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
bd6cadd5-f1b6-4c31-898f-d09530a66055	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	12	grams	2025-08-04 20:46:09.049+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
47644e81-5c9b-4b10-9c27-7ddabd8ea08d	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	20	grams	2025-08-05 00:23:45.892+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
98ba2a0b-a2c2-43c1-8579-c98d35989bc4	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	193.40836271566573	lbs	2025-08-02 15:24:29.532+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b9b8c558-6a90-4ccc-a2e7-dae7fd4b7888	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3457	steps	2025-08-02 15:29:53.232+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
d84f8480-4ac1-4f4a-932a-3f7d45906f03	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4132	steps	2025-08-02 23:26:54.821+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
76aae35f-7e67-4ec0-9bd1-5cb3fe73bb35	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3380	steps	2025-08-03 04:27:08.422+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2bfdbdeb-339a-41f9-9d7d-65054d349163	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	59	bpm	2025-08-02 14:11:12.225+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
d10b57b2-d9b5-4304-acf6-77114e3f62cd	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	74	bpm	2025-08-02 18:19:02.824+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a748a29d-6180-4bfa-a4ef-765564bfbf64	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	92	bpm	2025-08-02 21:21:03.99+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
53a37fbe-2c5a-4f84-84ce-652bbeadc592	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	77	bpm	2025-08-02 23:55:52.281+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
4ee9f7d3-84de-4c2c-8da3-2aad28ee2ad1	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	69	bpm	2025-08-03 04:06:39.763+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b8420e46-e112-4b4c-af57-efaeb46b512c	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.204548451838321	hours	2025-08-02 17:06:12.863+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a66e4f64-6d07-497e-97c5-5053659ed991	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1084	kcal	2025-08-02 16:49:04.496+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
4d59c134-a7e8-4b37-8aec-b2ef76f5b13a	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	747	kcal	2025-08-02 20:52:03.887+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
9a8be9b5-dbde-4d75-8748-d11ae9687363	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	811	kcal	2025-08-03 02:26:23.197+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
44dc999a-0d43-4a30-9eaa-86edddb6b530	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	47	grams	2025-08-02 17:10:26.652+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
0b3da421-3675-4197-a462-03e64a66e1b4	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	46	grams	2025-08-02 20:15:33.047+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
0307c055-e8a8-48c5-a060-9fac701d836d	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	28	grams	2025-08-03 01:14:26.561+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b6bbaf6b-b74f-44d0-8e03-5b4b85b87269	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	13	grams	2025-08-02 15:31:57.423+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
0885ed9a-e016-45f5-86dd-ef9a9de5bd45	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	25	grams	2025-08-02 20:27:42.773+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
ebd7cc29-d4d6-4c0f-9ef5-7fbaa7eb2aee	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	32	grams	2025-08-02 23:19:03.287+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
7c3afce0-4420-4187-9ce7-244eb2511c1c	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	30	grams	2025-08-03 03:53:31.351+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
63de3765-06e5-490d-9123-91a4162feaec	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	69	minutes	2025-08-03 02:52:04.341+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
66f223e4-f066-4fea-8a61-2b270a1e60f4	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.69421078079475	lbs	2025-08-01 15:31:11.882+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
109f07cd-efae-4033-ba1c-e87d5d7b2b8a	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2450	steps	2025-08-01 16:26:22.842+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
ee069fa0-14a3-453a-aa3d-35dc1b530661	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4628	steps	2025-08-02 01:13:51.132+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
99a8ff25-d6e4-475c-93e2-15bb8db9812c	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2230	steps	2025-08-02 05:29:11.356+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6f1dd2ea-5e20-4f3b-b3d9-f507b734fad9	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	56	bpm	2025-08-01 14:55:53.043+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
09db5236-e44f-484c-8d14-8ae57ddbb38c	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	73	bpm	2025-08-01 17:40:22.987+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
4b3bba5f-3192-49df-a600-a4222e2b6c52	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	79	bpm	2025-08-01 21:43:53.774+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
c3ceecf5-7055-4587-a0fc-0a489863fb9d	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	71	bpm	2025-08-02 00:49:20.357+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
5a723069-d42e-4c85-97cd-9d5e1c5a6028	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	65	bpm	2025-08-02 03:24:41.962+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
cc5b5b6b-37d1-4033-b27f-d2fedc282575	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.952473620498327	hours	2025-08-01 15:41:24.341+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
59d5ea85-de06-453b-bd54-a191688ead01	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	447	kcal	2025-08-01 15:09:08.351+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
0e9cfcef-bf3c-4b34-bed4-7af47d3f11ad	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	773	kcal	2025-08-01 20:15:47.483+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
00e27bd2-a7f3-48e1-9ec1-24de356f1e2f	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	976	kcal	2025-08-02 01:50:55.84+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
d607f821-117b-4b45-9186-576766785da3	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	21	grams	2025-08-01 16:47:02.634+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b4bb1c33-9a2a-485d-863d-cc39fb63c6f0	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	38	grams	2025-08-01 20:14:12.869+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
d636ad41-b610-4d49-b9e5-db68a7365ca6	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	39	grams	2025-08-02 00:41:08.935+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
010557e3-4867-49c0-95ad-4ffd6de879b3	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	14	grams	2025-08-01 15:43:15.865+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a5dd8949-1da8-46ca-b4ce-4b0649857f07	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	15	grams	2025-08-01 20:11:37.15+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a1b5cd47-8655-4e82-9fc1-595d41fbfd68	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	35	grams	2025-08-01 23:52:44.513+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
252e4e65-1a1d-44db-a0db-a9e4943be92b	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	196.05253001356434	lbs	2025-07-31 15:41:05.274+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e722fe18-5718-4165-a033-7ed92f8eb2cf	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4951	steps	2025-07-31 18:24:56.259+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b6a62a08-8b93-48eb-a6b4-52e3b4f67cb1	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2649	steps	2025-08-01 01:16:10.129+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6d41d00a-7915-4e41-a66c-757120147e2f	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5914	steps	2025-08-01 05:23:20.801+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
34262df7-95ed-4978-a941-c62934ff80b3	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	65	bpm	2025-07-31 14:41:05.392+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
1478f34e-14e1-4a26-af14-b7e9e458ff71	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	88	bpm	2025-07-31 20:50:01.125+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a699d9c3-e0d4-4065-b341-bc0ddb2b6c50	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	76	bpm	2025-08-01 03:50:06.775+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a617bb62-9812-48a1-bf01-6ffac0884305	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.675777058644755	hours	2025-07-31 16:45:31.163+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2f86210b-d4a2-4d5e-9992-835ca3febd01	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	622	kcal	2025-07-31 14:55:44.337+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
cc7bb262-878a-478f-b9a3-666d48780f83	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	666	kcal	2025-07-31 20:38:04.419+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
4ca384dd-49f5-4e36-a316-3da25eedf643	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	901	kcal	2025-08-01 01:41:49.926+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
ebc11938-6c5f-45ef-a004-680b9626e12a	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	55	grams	2025-07-31 16:19:43.194+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
7c792854-ad21-4062-93ef-2db59bb08166	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	56	grams	2025-07-31 20:58:50.53+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
77043f60-4b8f-4bdc-be8c-bf514a3b3ebb	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	23	grams	2025-08-01 00:55:00.415+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
88949ee1-5159-4303-b511-6e033df6bee8	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	39	grams	2025-07-31 15:17:24.441+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
4dd95d93-96a1-45a4-abe8-515bc8fbfa6e	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	19	grams	2025-07-31 20:37:17.624+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
5d387caa-c3cb-4d31-8797-0a30a4634518	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.39479047442615	lbs	2025-07-30 16:08:26.182+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
25160c45-2b81-4c7c-aa6e-3be2dbd359f2	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2474	steps	2025-07-30 16:19:17.231+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
91d8852f-dd57-4767-b774-ebc6984847ba	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3673	steps	2025-07-31 01:05:14.767+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
cced9eb7-49d0-41e7-959f-5d033f07df55	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6554	steps	2025-07-31 04:05:16.664+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
86a5d888-9e11-4048-b7fb-e816cb4fd8cc	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	69	bpm	2025-07-30 13:49:53.532+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
8e4700f3-3232-49e1-9509-f0dee464846b	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	86	bpm	2025-07-30 19:15:45.392+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
99e607cd-79ce-4f5e-a24b-02a2a70e644f	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	88	bpm	2025-07-30 22:54:06.848+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
90aa63eb-94e8-4639-a3d6-021db588db28	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	72	bpm	2025-07-31 04:02:13.653+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
7cc97361-1742-47d0-a8f7-1a351d4e4048	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.698375985786261	hours	2025-07-30 15:40:34.004+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
87d0cd4a-648e-44a3-a2a3-bf02b45ce90f	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	572	kcal	2025-07-30 15:56:09.454+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
9aa4a220-eeb0-44ee-b163-e5e5d16fcbc3	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	825	kcal	2025-07-30 22:14:45.847+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a379a265-bfb3-44b3-a3b4-7cc6128a9a0f	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	748	kcal	2025-07-31 00:31:37.304+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b5392018-44ff-4edd-9fef-afebd388f287	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	54	grams	2025-07-30 16:38:16.468+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
8f0560ca-4539-4cff-9ac1-e076c94daf53	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	21	grams	2025-07-30 20:47:11.035+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
8028ac75-9df6-43f2-9d37-023eb8a90679	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	49	grams	2025-07-31 03:15:31.448+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
75ef2788-0e6b-4e5e-9838-47ac8293ca24	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	25	grams	2025-07-30 15:48:25.577+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
d4f03eaf-f239-4f4e-ad06-b34d4136c7a2	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	27	grams	2025-07-30 20:29:15.519+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
9a61e923-739c-4c6d-a508-2566669268e4	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	25	grams	2025-07-31 01:15:34.198+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e69671b8-00d7-4cdb-9b1b-57271fec9075	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	39	grams	2025-07-31 03:59:33.118+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
0a84bb50-e647-4d13-a281-6f2eeb826b4a	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	79	minutes	2025-07-31 03:24:23.996+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
254680e7-89fe-4603-ada8-7f53e106260f	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	197.8247988418293	lbs	2025-07-29 15:46:07.685+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
3958fedc-7e76-4660-9059-fb9b0ce327fe	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4300	steps	2025-07-29 19:09:17.572+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
63342956-8105-4c1b-a947-cc471330a541	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4154	steps	2025-07-30 00:05:41.293+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
998a5a8b-cfc9-444c-8053-d688f23322d4	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3720	steps	2025-07-30 05:57:57.476+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
76e93b38-5378-4e82-a4c1-bcd2a77001a9	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	63	bpm	2025-07-29 13:18:30.345+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2751c82e-c378-4f24-8f7c-ed956810d716	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	73	bpm	2025-07-29 18:24:22.561+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
abc13854-3a54-44ab-83b8-0370f7d4ea4e	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	84	bpm	2025-07-29 21:45:19.07+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
38e0bc8c-85c6-4c17-b393-f245919e2cd5	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	65	bpm	2025-07-30 01:35:17.975+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
8feb0a2a-037b-4714-ab59-c178bb0cc40f	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	62	bpm	2025-07-30 04:32:13.756+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2eb62c6f-becd-45de-a0d2-5e8c48eb7548	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.870635954808295	hours	2025-07-29 16:13:07.386+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
5431d829-a3e1-437a-bbbc-8da157bafe6e	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	422	kcal	2025-07-29 15:36:57.597+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2f458f19-b2af-43a8-b4e6-a3ed42944f40	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	497	kcal	2025-07-29 19:52:49.92+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b9fa47f4-f266-480c-8ec6-a1168da99e8b	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	984	kcal	2025-07-30 02:49:06.854+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
7747a107-2095-43ce-ab7a-6fa0d60da246	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	38	grams	2025-07-29 16:53:53.98+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b8235f32-0b61-4cc6-93bd-c341a81292ee	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	50	grams	2025-07-29 20:19:23.899+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
45acfa79-07de-458e-ac4d-7e1eed9376f8	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	55	grams	2025-07-30 02:41:46.567+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
12a27053-0ab9-4a9c-8711-ab8c1853191a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	14	grams	2025-07-29 17:13:10.056+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
4916577e-514d-4958-8ae4-5cb061cd55f2	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	37	grams	2025-07-29 20:32:01.86+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6bba5c82-96bf-4eed-a5b3-ab9361a930c2	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	24	grams	2025-07-29 23:52:58.467+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
0644a25c-e793-4983-9026-a8371b0c3346	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	22	grams	2025-07-30 04:34:12.287+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
ed6e4010-cf40-4f7b-8fda-7ccfbfca6154	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	193.4248504594576	lbs	2025-07-28 14:29:25.74+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
33b47d7c-bde3-47fd-8ce7-314a6d4ede47	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5516	steps	2025-07-28 15:39:56.131+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
649a9d14-244a-453a-a952-2f314c1b85dd	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5515	steps	2025-07-29 00:55:00.278+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6b92052e-e9a2-416e-8c61-4db679b5d41f	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4953	steps	2025-07-29 04:13:34.162+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
bb6fd145-0c89-4aad-b31a-a9865a9b46be	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	57	bpm	2025-07-28 13:55:02.631+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
17af4298-913e-4188-89b7-a6fa3812df72	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	82	bpm	2025-07-28 21:15:56.901+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
59e3d6e9-ee88-405b-8abd-9f46127411a6	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	75	bpm	2025-07-29 04:34:33.924+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2bf967a8-b942-4d49-9852-18e2a664ae69	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.300534244627458	hours	2025-07-28 15:25:22.684+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
bc9c58b7-8cf7-4935-8568-635aa99a24fd	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	811	kcal	2025-07-28 15:28:57.167+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
123ad754-d6e8-44b9-ab47-956f9143e1bf	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	886	kcal	2025-07-28 19:43:25.82+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6cce61fc-dac4-4cae-922d-19551f9213ea	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	40	grams	2025-07-28 15:16:21.132+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
39dcedd5-6425-4e5a-aaa1-a812f7ce565e	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	45	grams	2025-07-28 19:40:20.78+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b55284bd-1f6c-4fe4-8e41-cae29fba8081	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	26	grams	2025-07-28 16:34:43.032+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
b0a6febc-012c-406a-aee4-6b3f807c9fa7	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	14	grams	2025-07-28 20:54:28.716+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
57caf95b-994c-405e-838d-612576a64b21	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	26	grams	2025-07-29 00:13:16.471+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
5805ea6f-eb8f-4f8b-999b-1a0b407c22a7	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	13	grams	2025-07-29 03:22:46.33+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
915b442e-a57f-4d4b-a878-d8d755b399ab	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.9420147157978	lbs	2025-07-27 14:41:49.017+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
db75a7fb-21b5-4caa-857b-2aef4630be81	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2270	steps	2025-07-27 17:32:04.02+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
789d2e66-6394-4b99-bfa2-bc385c99f911	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6334	steps	2025-07-27 21:24:31.029+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
657136bb-7629-4601-9530-ab24a8f3cbbd	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	59	bpm	2025-07-27 13:28:20.646+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
4853228a-5b7d-4792-87f8-a2e1e617800e	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	77	bpm	2025-07-27 18:54:31.112+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
041fac20-709a-4e29-b746-85f3909ff991	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	83	bpm	2025-07-28 00:23:07.949+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e7d7dc88-3c67-45ce-860b-1d428bddc8cd	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	69	bpm	2025-07-28 05:14:23.119+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
834adee5-ab1c-4c10-8f99-9e518de42e12	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.19678870882473	hours	2025-07-27 15:51:18.234+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a44fafb3-0264-441f-88f1-85b7465a6408	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	771	kcal	2025-07-27 14:58:28.772+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
8eb5765b-ac8b-4484-96e0-4fb2ea57f82d	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	453	kcal	2025-07-27 20:06:32.116+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
729970ea-cd89-4b85-af65-62e8a03f5f64	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	54	grams	2025-07-27 17:01:05.22+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
09b7257a-c8a4-47a0-b388-5c15d2424c62	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	28	grams	2025-07-27 19:48:46.971+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
74bf7704-2535-42ee-90a0-9042b3641bd4	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	11	grams	2025-07-27 15:39:51.176+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
8addac8e-0c8e-4349-b949-7a1f0458a6be	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	20	grams	2025-07-27 19:59:58.975+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2775747d-7cbe-427d-ad79-70ce6cdbe3cf	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	33	minutes	2025-07-28 00:40:05.244+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
bb3ee39a-acea-47a0-a836-1e61f43d9cba	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	193.57824145446463	lbs	2025-07-26 14:18:25.976+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
3dd9640a-b154-407d-94cb-a38fcd4226cf	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5900	steps	2025-07-26 15:47:04.134+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
52c56034-686d-4137-a5b2-68b8eb87c843	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6791	steps	2025-07-26 22:05:22.523+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
d98dbe76-ede2-40f5-892e-adc013b25142	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	68	bpm	2025-07-26 15:04:05.178+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
19475b22-f14b-4afa-8b5a-ed489af59134	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	91	bpm	2025-07-26 18:03:07.159+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
940b32c0-ad5f-4d9b-b685-1456b23df263	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	76	bpm	2025-07-26 23:15:52.566+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
fd2cae80-c79f-4319-b19f-4a8169652b03	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	78	bpm	2025-07-27 03:24:45.764+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
7daf597e-74a5-4c28-9c4b-071e5a331c05	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.431218875942978	hours	2025-07-26 16:45:40.649+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
da4bf12e-3416-4da7-ac2c-44f8a02ba6e5	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1002	kcal	2025-07-26 15:01:25.548+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
943e2b9c-c78b-46a9-8c79-de622b96e85b	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1188	kcal	2025-07-26 21:09:26.68+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e115e661-80ca-43a1-a227-c5d1c48618c1	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	989	kcal	2025-07-27 01:49:06.405+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
73df16d8-f84d-49e9-af13-6bb00dd5332a	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	54	grams	2025-07-26 14:27:53.408+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
38bbc366-5232-4f80-8d77-ac54fc2cb0b4	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	37	grams	2025-07-26 21:26:39.597+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6d6e74ed-f10f-4f13-bab9-8e05c940291b	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	33	grams	2025-07-27 01:28:20.385+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
f13f2d86-2508-4aeb-a6ab-953b4fb297e3	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	12	grams	2025-07-26 15:51:39.734+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
209837e9-6a84-42ee-883b-afe0ba0d0a80	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	24	grams	2025-07-26 19:56:43.925+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
12696fad-d89a-44aa-aca1-5a724d3bfaf6	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	20	grams	2025-07-27 00:04:20.105+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2557ba53-2cbf-4124-99a1-d077c0b227c1	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	18	grams	2025-07-27 05:10:07.475+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
3e75bc9f-eba0-4347-a145-5b9c80e87c92	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	193.95424616337814	lbs	2025-07-25 15:41:59.524+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
4ffc98b9-0ae4-4562-a18d-d0baf659b940	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3750	steps	2025-07-25 17:26:22.894+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
34ddbae4-1c8a-4d12-b494-0f7c45d483fa	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6381	steps	2025-07-25 21:27:20.033+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
80150e3e-8a5e-4052-aed0-dff561a8195a	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6757	steps	2025-07-26 03:57:06.317+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
834ac414-5e48-4c52-8dea-ebeca04d386d	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	65	bpm	2025-07-25 14:51:08.187+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
7a39a32a-d5cf-47e3-a7b6-260c9d0cd4d0	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	86	bpm	2025-07-25 18:03:18.214+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
8c4849a8-f7fa-4b45-91f1-da15b43a3044	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	79	bpm	2025-07-26 00:10:49.832+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
ca06d608-ad23-4124-be8f-f73dcf65c43a	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	79	bpm	2025-07-26 03:46:41.506+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
7be26f84-2903-4f62-842c-076a8b9b7d42	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	6.7633776721357615	hours	2025-07-25 17:05:46.28+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
401bfd7e-6f83-4573-9bad-f7cfac6447b4	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	874	kcal	2025-07-25 16:16:49.382+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
48b76fd0-3646-4554-aad2-7800c3497edf	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	404	kcal	2025-07-25 20:40:50.532+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
845f87cb-bdb5-45b2-836d-8b84ed9d3049	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	854	kcal	2025-07-26 01:24:04.043+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
0cde3b3b-deb2-4b7e-b72c-b29c31f0fb5a	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	37	grams	2025-07-25 15:43:32.279+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
d2282850-7de9-40cd-82cf-db618572266a	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	60	grams	2025-07-25 20:30:02.152+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
3789beb7-5d2c-49ee-beb6-06297a7e97e6	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	38	grams	2025-07-26 01:14:12.787+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
f2161d50-0f8d-4fac-b24c-89a604d41b10	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	36	grams	2025-07-25 17:10:42.486+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
5afe9ef8-6249-4b93-a79d-b9cc7e0ea13b	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	32	grams	2025-07-25 20:36:17.642+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
c509d3a0-5f2b-4073-803e-9c70f2a78290	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	193.2848856001799	lbs	2025-07-23 14:21:06.813+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
0614c207-7098-4770-aab2-413151e24aee	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	6689	steps	2025-07-23 16:07:42.427+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
4faec25c-88dc-40d7-957f-c3ea9c9d1c89	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	4615	steps	2025-07-24 00:28:08.281+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
fc29fab3-963a-4566-a1c1-8d6eedb2c066	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3317	steps	2025-07-24 04:36:25.842+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
ae973180-00ce-40ae-b72f-34614d902f39	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	73	bpm	2025-07-23 13:17:42.261+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
c69d34ae-8430-4254-a485-d8706245e935	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	91	bpm	2025-07-23 18:30:24.327+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
bd8aad16-f487-4dac-b3f6-7257c748ad01	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	86	bpm	2025-07-23 22:47:20.237+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6e17c1b9-7cfa-4ef6-bec4-1bad87d7356d	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	66	bpm	2025-07-24 04:53:55.442+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
4dda52b2-cadf-45d5-a579-ce47c4905bfc	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.297827848283616	hours	2025-07-23 16:08:32.727+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
adeb8dda-c8a9-49cc-8cf7-5df67b1b591f	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	877	kcal	2025-07-23 16:57:12.436+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
c423c981-023c-4947-9551-81bb46144294	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1100	kcal	2025-07-23 20:05:27.127+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
61cdda8a-ec88-4ad3-95be-0c62e5e5b4c0	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	23	grams	2025-07-23 14:47:15.886+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e34ecf8f-254d-460e-a0a7-58b73744a178	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	31	grams	2025-07-23 19:57:16.874+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
88e388ba-504a-4ba1-9dd7-0e551eecb185	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	27	grams	2025-07-23 15:45:48.741+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
42f5ac0d-cfe4-45cc-b94e-8564198ee3a6	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	16	grams	2025-07-23 20:05:09.671+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
4c2fcfbb-3fbe-4cec-b328-561f28241458	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	13	grams	2025-07-24 00:23:33.119+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
263ef24a-638e-4255-8451-c4765cb11239	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	192.33404979179912	lbs	2025-07-21 15:45:40.637+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
56daedcc-13ef-4be8-8dca-978e13be4a16	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2058	steps	2025-07-21 15:57:37.709+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
84c86e7d-b516-404f-8239-d93f8f7bf35f	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2862	steps	2025-07-21 22:28:14.699+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e18d8a08-a810-41a5-a814-5c13e36eb4aa	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2984	steps	2025-07-22 04:07:39.694+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
71ab82b5-8269-471f-8a7f-1e374fb230e7	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	59	bpm	2025-07-21 15:16:28.663+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
c6502f12-3fc8-435f-a12e-f1a0374620f5	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	86	bpm	2025-07-21 19:11:20.183+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
aaec23f7-5a91-4acc-9451-13571aa698ef	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	83	bpm	2025-07-22 00:36:34.376+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
990b969f-3d98-4c04-9cd3-efee981b8992	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	77	bpm	2025-07-22 03:50:12.577+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
818f0d57-2411-4898-84f9-94ee6238ad96	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.307326118006706	hours	2025-07-21 15:44:05.964+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
fcbac1db-ee37-4584-bc7e-160153a7d2aa	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1108	kcal	2025-07-21 15:09:13.198+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
ec9f5ba2-5fc9-4841-be71-053bd9218393	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1028	kcal	2025-07-21 20:30:42.784+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
05f2e8ce-b6e9-4544-9af1-7194dc70e0d0	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	44	grams	2025-07-21 15:20:24.105+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
c63827d3-cad2-4e38-9564-deb25b55a8e8	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	38	grams	2025-07-21 20:50:15.442+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
24a08e9d-6c28-4173-8de3-ab8783b488b1	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	35	grams	2025-07-21 17:00:20.207+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a99431d0-bffc-467d-a961-08f56e9e462f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	30	grams	2025-07-21 20:27:11.178+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e6af817d-170c-41c7-b1fe-213d0c6c989b	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	13	grams	2025-07-22 00:04:28.457+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2a76ae15-42bb-4e16-a328-e830bab3673d	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	48	minutes	2025-07-22 00:31:35.052+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
fb72fe9c-80e0-41c4-986f-a51efdfed041	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	195.51629791929912	lbs	2025-07-20 16:16:08.952+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
2ddf12d8-a5d5-4d00-9a14-d13a6188867f	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	2067	steps	2025-07-20 16:17:01.031+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
03b8f92c-9203-4a23-959a-1636da65da8b	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5401	steps	2025-07-20 22:50:35.332+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
ab724c29-a97e-46a8-a2e0-0b3888f162aa	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	3613	steps	2025-07-21 03:34:10.204+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
8d2df787-f787-4d46-90ee-83c03e5c467b	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	72	bpm	2025-07-20 14:47:28.965+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
f83e0618-cf06-417c-85ea-b144739a10d7	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	86	bpm	2025-07-20 19:36:21.704+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a939afe2-0f68-4182-889e-f52e25b7e5f2	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	86	bpm	2025-07-20 22:37:53.534+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
f139b8f2-3473-4b9d-995a-47f822e966a1	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	61	bpm	2025-07-21 04:46:08.272+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
985987d4-1215-4f4f-8175-485c10104f33	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	7.226925414992205	hours	2025-07-20 16:50:42.436+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
88ad4f70-c7b3-420e-9d5c-4db1418b4042	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	761	kcal	2025-07-20 14:23:11.406+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
09e6dec9-8632-4a3a-90f8-d5f5d3c04a53	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	1008	kcal	2025-07-20 19:50:55.137+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
331b3b85-1724-4285-a35e-761916d20b8c	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	51	grams	2025-07-20 14:35:43.591+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
f64e8534-17cd-4c7b-a362-ce0bca23d00c	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	37	grams	2025-07-20 22:03:00.005+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6d666512-a757-4d51-83be-7deb2df5074f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	11	grams	2025-07-20 15:24:57.619+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
d91e2ecc-abc2-4104-add5-7632dd6d166a	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	32	grams	2025-07-20 19:40:23.001+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e1ab03e3-885b-4108-a4bb-ae8b380bcd71	419d8930-528f-4b7c-a2b0-3c62227c6bec	exercise_minutes	53	minutes	2025-07-21 02:57:24.407+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
0a5de53e-eb5e-4a3c-95e6-81227d3bf227	419d8930-528f-4b7c-a2b0-3c62227c6bec	weight	194.79691828576654	lbs	2025-07-18 15:45:00.699+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
47048de0-384c-4d93-b486-7619c7c5e06c	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5002	steps	2025-07-18 17:59:43.06+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
6d539389-b2e8-4b4c-986f-3ca1136cd5b7	419d8930-528f-4b7c-a2b0-3c62227c6bec	steps	5557	steps	2025-07-18 21:51:37.567+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
890c0210-ccfb-4e14-8a55-2a3e0160c924	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	69	bpm	2025-07-18 14:29:00.956+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
13fe2f0a-e3a1-4ed6-bf41-cd69990b9e3f	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	79	bpm	2025-07-18 20:37:25.305+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
db4caf95-52eb-4df6-9c0f-c2f671917d2f	419d8930-528f-4b7c-a2b0-3c62227c6bec	heart_rate	79	bpm	2025-07-19 04:53:31.152+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
e48494f8-2cb2-41ce-82f4-e882f757856f	419d8930-528f-4b7c-a2b0-3c62227c6bec	sleep	8.829506821359546	hours	2025-07-18 16:03:57.044+00	healthkit	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
59a21c8a-9a6b-40df-9177-6ff54b9f8d76	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	473	kcal	2025-07-18 15:19:08.77+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
8009e2cc-8924-41b6-ac04-8c66311ef878	419d8930-528f-4b7c-a2b0-3c62227c6bec	calories	788	kcal	2025-07-18 20:05:18.734+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
255e8845-5dd1-4a13-9906-72f55bc14b37	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	34	grams	2025-07-18 15:02:04.895+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
19558f60-ee58-4d64-8808-db8249fa4680	419d8930-528f-4b7c-a2b0-3c62227c6bec	protein	21	grams	2025-07-18 21:18:14.967+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
d2ed07bb-3490-449f-8df7-cf456cf84eae	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	13	grams	2025-07-18 17:11:02.549+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
a22f77f1-b728-40f7-ad2d-a5cd5d080bdb	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	23	grams	2025-07-18 21:04:54.659+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
73f93d6d-706c-4199-9547-72328d00364b	419d8930-528f-4b7c-a2b0-3c62227c6bec	sugar	30	grams	2025-07-18 23:23:00.314+00	manual	{}	2025-10-14 07:17:06.32+00	2025-10-14 07:17:06.32+00
\.


--
-- TOC entry 4783 (class 0 OID 18431)
-- Dependencies: 325
-- Data for Name: patient_medication_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patient_medication_preferences (id, patient_id, medication_id, preferred_dosage, frequency, notes, status, requested_date, created_at, updated_at, medication_dosage_id, faxed, next_prescription_due, supply_days, refill_requested, refill_requested_date, approval_date) FROM stdin;
06972a33-a409-40b0-bc4b-b47245d727e9	3d22617d-3bd5-47e2-b6ce-6e57bd0ff45b	930081b0-00fc-4e25-ad97-7c1bd8e889ce	1.0mg	weekly	Higher dose for weight loss	approved	2025-10-14 05:59:17.247334+00	2025-10-14 05:59:17.247334+00	2025-10-14 05:59:17.247334+00	09278c54-2800-4a53-9042-9fe42bf7dd94	\N	\N	\N	f	\N	2025-10-14 05:59:17.247334+00
baba6964-d96a-4364-8730-984fc47e66d1	b71a2179-f187-4e4e-beea-0459e55fd9a7	eebf77f8-9411-4fe6-bae7-ff2d48ff367a	2.4mg	weekly	Max dose for significant weight loss	approved	2025-10-14 05:59:17.247334+00	2025-10-14 05:59:17.247334+00	2025-10-14 05:59:17.247334+00	606da480-fa41-4a24-9651-10ff9c43c026	\N	\N	\N	f	\N	2025-10-14 05:59:17.247334+00
09041542-1c0b-4708-beaa-b80558b0237a	2e5c2201-d91e-4224-80c5-45c51b9ede08	f848e7b9-ff12-4165-a3db-475787a7b759	0.5mg	weekly	Starting dose for weight management	approved	2025-10-14 05:59:17.247334+00	2025-10-14 05:59:17.247334+00	2025-10-14 05:59:17.247334+00	edde56d4-7467-4b17-8fbe-6169876c2f86	2025-10-14 05:59:20.48218+00	2025-11-28	45	f	\N	2025-10-14 05:59:17.247334+00
1f63eef0-1aec-4849-83b5-338e2e5bf9b3	6de5961e-4566-4f6b-b6e3-e17a157e2759	f848e7b9-ff12-4165-a3db-475787a7b759	0.25mg	weekly	Starting with lowest dose	pending	2025-10-14 05:59:17.247334+00	2025-10-14 05:59:17.247334+00	2025-10-14 05:59:17.247334+00	edde56d4-7467-4b17-8fbe-6169876c2f86	\N	\N	\N	t	2025-10-14 05:59:17.247334+00	\N
\.


--
-- TOC entry 4776 (class 0 OID 18284)
-- Dependencies: 318
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patients (id, profile_id, date_of_birth, phone, has_completed_intake, created_at, updated_at, allergies) FROM stdin;
eb8aa8fb-5bd7-4ef1-adbe-ffc9ed8c2a20	aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa	\N	\N	f	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00	\N
29aabf74-7b74-4c57-a30e-cafe6eba396a	bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb	\N	\N	f	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00	\N
04a75560-bd1e-4fcc-9fa1-8136baa95b17	cccccccc-cccc-cccc-cccc-cccccccccccc	\N	\N	f	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00	\N
2e5c2201-d91e-4224-80c5-45c51b9ede08	11111111-1111-1111-1111-111111111111	\N	555-0101	t	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00	\N
3d22617d-3bd5-47e2-b6ce-6e57bd0ff45b	22222222-2222-2222-2222-222222222222	\N	555-0102	t	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00	\N
b71a2179-f187-4e4e-beea-0459e55fd9a7	33333333-3333-3333-3333-333333333333	\N	555-0103	t	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00	\N
6de5961e-4566-4f6b-b6e3-e17a157e2759	44444444-4444-4444-4444-444444444444	\N	555-0104	t	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00	\N
419d8930-528f-4b7c-a2b0-3c62227c6bec	6a2ffaa8-318b-4888-a102-1277708d6b9a	\N	\N	f	2025-10-14 06:08:41.246399+00	2025-10-14 06:08:41.246399+00	\N
\.


--
-- TOC entry 4775 (class 0 OID 18267)
-- Dependencies: 317
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (id, email, first_name, last_name, role, created_at, updated_at) FROM stdin;
11111111-1111-1111-1111-111111111111	sarah.j@test.com	Sarah	Johnson	patient	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00
22222222-2222-2222-2222-222222222222	michael.r@test.com	Michael	Roberts	patient	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00
33333333-3333-3333-3333-333333333333	jennifer.m@test.com	Jennifer	Martinez	patient	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00
44444444-4444-4444-4444-444444444444	david.a@test.com	David	Anderson	patient	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00
aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa	admin@test.com	Admin	User	admin	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00
bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb	dr.watson@test.com	Dr. Emily	Watson	provider	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00
cccccccc-cccc-cccc-cccc-cccccccccccc	dr.wilson@test.com	Dr. James	Wilson	provider	2025-10-14 05:59:17.235709+00	2025-10-14 05:59:17.235709+00
6a2ffaa8-318b-4888-a102-1277708d6b9a	patientexample@test.com	patient	example	patient	2025-10-14 06:08:41.246399+00	2025-10-14 06:08:41.246399+00
ccabc2d7-037e-4410-ae15-8ad673f0f7e1	providerexample@test.com	provider	example	provider	2025-10-14 06:09:21.668754+00	2025-10-14 06:09:21.668754+00
6f355179-913d-440e-acfa-0cf20c484804	adminexample@test.com	admin	example	admin	2025-10-14 06:09:45.733303+00	2025-10-14 06:09:45.733303+00
\.


--
-- TOC entry 4787 (class 0 OID 18570)
-- Dependencies: 329
-- Data for Name: provider_availability_overrides; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.provider_availability_overrides (id, provider_id, date, start_time, end_time, available, reason, created_at) FROM stdin;
\.


--
-- TOC entry 4786 (class 0 OID 18547)
-- Dependencies: 328
-- Data for Name: provider_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.provider_schedules (id, provider_id, day_of_week, start_time, end_time, slot_duration_minutes, treatment_types, active, created_at, updated_at) FROM stdin;
90744ac9-47f2-445a-95f4-bdf40c737563	17101b03-1a63-4c59-a368-63d2bd026e3b	1	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-10-14 06:09:21.668754+00	2025-10-14 06:09:21.668754+00
434cee17-c7db-4442-85ac-18d90ae7ecc7	17101b03-1a63-4c59-a368-63d2bd026e3b	2	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-10-14 06:09:21.668754+00	2025-10-14 06:09:21.668754+00
73eb3b8d-5942-413e-80fd-5d0ea31a9e5d	17101b03-1a63-4c59-a368-63d2bd026e3b	3	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-10-14 06:09:21.668754+00	2025-10-14 06:09:21.668754+00
94ef30bc-3f8d-43e6-8f7e-7a2b0246fde6	17101b03-1a63-4c59-a368-63d2bd026e3b	4	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-10-14 06:09:21.668754+00	2025-10-14 06:09:21.668754+00
ebfb6319-2678-4b06-9f5b-cd3d883c5169	17101b03-1a63-4c59-a368-63d2bd026e3b	5	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-10-14 06:09:21.668754+00	2025-10-14 06:09:21.668754+00
\.


--
-- TOC entry 4777 (class 0 OID 18302)
-- Dependencies: 319
-- Data for Name: providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.providers (id, profile_id, specialty, license_number, phone, active, created_at, updated_at) FROM stdin;
17101b03-1a63-4c59-a368-63d2bd026e3b	ccabc2d7-037e-4410-ae15-8ad673f0f7e1	General Practice	TBD		t	2025-10-14 06:09:21.668754+00	2025-10-14 06:09:21.668754+00
\.


--
-- TOC entry 4795 (class 0 OID 18897)
-- Dependencies: 339
-- Data for Name: visit_addendums; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visit_addendums (id, visit_id, provider_id, content, created_at) FROM stdin;
\.


--
-- TOC entry 4792 (class 0 OID 18760)
-- Dependencies: 336
-- Data for Name: visit_interactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visit_interactions (id, clinical_note_id, appointment_id, interaction_type, details, provider_notes, created_at, performed_by, medication_id, medication_name, previous_dosage, new_dosage, previous_frequency, new_frequency, previous_status, new_status) FROM stdin;
\.


--
-- TOC entry 4791 (class 0 OID 18735)
-- Dependencies: 335
-- Data for Name: visit_medication_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visit_medication_adjustments (id, clinical_note_id, appointment_id, preference_id, previous_dosage, previous_frequency, previous_status, previous_provider_notes, new_dosage, new_frequency, new_status, new_provider_notes, adjustment_reason, provider_notes, created_at, performed_by, new_supply_days) FROM stdin;
\.


--
-- TOC entry 4752 (class 0 OID 17024)
-- Dependencies: 293
-- Data for Name: messages_2025_10_13; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_10_13 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4753 (class 0 OID 17036)
-- Dependencies: 294
-- Data for Name: messages_2025_10_14; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_10_14 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4754 (class 0 OID 17048)
-- Dependencies: 295
-- Data for Name: messages_2025_10_15; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_10_15 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4755 (class 0 OID 17060)
-- Dependencies: 296
-- Data for Name: messages_2025_10_16; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_10_16 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4756 (class 0 OID 17072)
-- Dependencies: 297
-- Data for Name: messages_2025_10_17; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_10_17 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4749 (class 0 OID 16844)
-- Dependencies: 286
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2025-10-14 05:59:09
20211116045059	2025-10-14 05:59:09
20211116050929	2025-10-14 05:59:09
20211116051442	2025-10-14 05:59:09
20211116212300	2025-10-14 05:59:09
20211116213355	2025-10-14 05:59:09
20211116213934	2025-10-14 05:59:09
20211116214523	2025-10-14 05:59:09
20211122062447	2025-10-14 05:59:09
20211124070109	2025-10-14 05:59:09
20211202204204	2025-10-14 05:59:09
20211202204605	2025-10-14 05:59:09
20211210212804	2025-10-14 05:59:09
20211228014915	2025-10-14 05:59:09
20220107221237	2025-10-14 05:59:09
20220228202821	2025-10-14 05:59:09
20220312004840	2025-10-14 05:59:09
20220603231003	2025-10-14 05:59:09
20220603232444	2025-10-14 05:59:09
20220615214548	2025-10-14 05:59:09
20220712093339	2025-10-14 05:59:09
20220908172859	2025-10-14 05:59:09
20220916233421	2025-10-14 05:59:09
20230119133233	2025-10-14 05:59:09
20230128025114	2025-10-14 05:59:09
20230128025212	2025-10-14 05:59:09
20230227211149	2025-10-14 05:59:09
20230228184745	2025-10-14 05:59:09
20230308225145	2025-10-14 05:59:09
20230328144023	2025-10-14 05:59:09
20231018144023	2025-10-14 05:59:09
20231204144023	2025-10-14 05:59:09
20231204144024	2025-10-14 05:59:09
20231204144025	2025-10-14 05:59:09
20240108234812	2025-10-14 05:59:09
20240109165339	2025-10-14 05:59:09
20240227174441	2025-10-14 05:59:09
20240311171622	2025-10-14 05:59:09
20240321100241	2025-10-14 05:59:09
20240401105812	2025-10-14 05:59:09
20240418121054	2025-10-14 05:59:09
20240523004032	2025-10-14 05:59:09
20240618124746	2025-10-14 05:59:09
20240801235015	2025-10-14 05:59:09
20240805133720	2025-10-14 05:59:09
20240827160934	2025-10-14 05:59:09
20240919163303	2025-10-14 05:59:09
20240919163305	2025-10-14 05:59:09
20241019105805	2025-10-14 05:59:09
20241030150047	2025-10-14 05:59:09
20241108114728	2025-10-14 05:59:09
20241121104152	2025-10-14 05:59:09
20241130184212	2025-10-14 05:59:09
20241220035512	2025-10-14 05:59:09
20241220123912	2025-10-14 05:59:09
20241224161212	2025-10-14 05:59:09
20250107150512	2025-10-14 05:59:09
20250110162412	2025-10-14 05:59:09
20250123174212	2025-10-14 05:59:09
20250128220012	2025-10-14 05:59:09
20250506224012	2025-10-14 05:59:09
20250523164012	2025-10-14 05:59:09
20250714121412	2025-10-14 05:59:09
20250905041441	2025-10-14 05:59:09
\.


--
-- TOC entry 4751 (class 0 OID 16867)
-- Dependencies: 289
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at) FROM stdin;
\.


--
-- TOC entry 4743 (class 0 OID 16509)
-- Dependencies: 267
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
\.


--
-- TOC entry 4760 (class 0 OID 17892)
-- Dependencies: 301
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_analytics (id, type, format, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4761 (class 0 OID 17903)
-- Dependencies: 302
-- Data for Name: iceberg_namespaces; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.iceberg_namespaces (id, bucket_id, name, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4762 (class 0 OID 17919)
-- Dependencies: 303
-- Data for Name: iceberg_tables; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.iceberg_tables (id, namespace_id, bucket_id, name, location, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4745 (class 0 OID 16551)
-- Dependencies: 269
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2025-10-14 05:59:16.723386
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2025-10-14 05:59:16.724711
2	storage-schema	5c7968fd083fcea04050c1b7f6253c9771b99011	2025-10-14 05:59:16.725273
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2025-10-14 05:59:16.728037
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2025-10-14 05:59:16.730153
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2025-10-14 05:59:16.730773
6	change-column-name-in-get-size	f93f62afdf6613ee5e7e815b30d02dc990201044	2025-10-14 05:59:16.731732
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2025-10-14 05:59:16.73261
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2025-10-14 05:59:16.733358
9	fix-search-function	3a0af29f42e35a4d101c259ed955b67e1bee6825	2025-10-14 05:59:16.733953
10	search-files-search-function	68dc14822daad0ffac3746a502234f486182ef6e	2025-10-14 05:59:16.734785
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2025-10-14 05:59:16.735616
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2025-10-14 05:59:16.736421
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2025-10-14 05:59:16.736972
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2025-10-14 05:59:16.737634
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2025-10-14 05:59:16.741526
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2025-10-14 05:59:16.742217
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2025-10-14 05:59:16.742728
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2025-10-14 05:59:16.743391
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2025-10-14 05:59:16.744219
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2025-10-14 05:59:16.744794
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2025-10-14 05:59:16.745723
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2025-10-14 05:59:16.74808
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2025-10-14 05:59:16.749826
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2025-10-14 05:59:16.750586
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2025-10-14 05:59:16.751256
26	objects-prefixes	ef3f7871121cdc47a65308e6702519e853422ae2	2025-10-14 05:59:16.751838
27	search-v2	33b8f2a7ae53105f028e13e9fcda9dc4f356b4a2	2025-10-14 05:59:16.75455
28	object-bucket-name-sorting	ba85ec41b62c6a30a3f136788227ee47f311c436	2025-10-14 05:59:16.770523
29	create-prefixes	a7b1a22c0dc3ab630e3055bfec7ce7d2045c5b7b	2025-10-14 05:59:16.771532
30	update-object-levels	6c6f6cc9430d570f26284a24cf7b210599032db7	2025-10-14 05:59:16.772316
31	objects-level-index	33f1fef7ec7fea08bb892222f4f0f5d79bab5eb8	2025-10-14 05:59:16.773282
32	backward-compatible-index-on-objects	2d51eeb437a96868b36fcdfb1ddefdf13bef1647	2025-10-14 05:59:16.773975
33	backward-compatible-index-on-prefixes	fe473390e1b8c407434c0e470655945b110507bf	2025-10-14 05:59:16.774631
34	optimize-search-function-v1	82b0e469a00e8ebce495e29bfa70a0797f7ebd2c	2025-10-14 05:59:16.774775
35	add-insert-trigger-prefixes	63bb9fd05deb3dc5e9fa66c83e82b152f0caf589	2025-10-14 05:59:16.775909
36	optimise-existing-functions	81cf92eb0c36612865a18016a38496c530443899	2025-10-14 05:59:16.776385
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2025-10-14 05:59:16.777948
38	iceberg-catalog-flag-on-buckets	19a8bd89d5dfa69af7f222a46c726b7c41e462c5	2025-10-14 05:59:16.778586
\.


--
-- TOC entry 4744 (class 0 OID 16524)
-- Dependencies: 268
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata, level) FROM stdin;
\.


--
-- TOC entry 4759 (class 0 OID 17848)
-- Dependencies: 300
-- Data for Name: prefixes; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.prefixes (bucket_id, name, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4757 (class 0 OID 17795)
-- Dependencies: 298
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata) FROM stdin;
\.


--
-- TOC entry 4758 (class 0 OID 17809)
-- Dependencies: 299
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- TOC entry 4748 (class 0 OID 16763)
-- Dependencies: 282
-- Data for Name: hooks; Type: TABLE DATA; Schema: supabase_functions; Owner: -
--

COPY supabase_functions.hooks (id, hook_table_id, hook_name, created_at, request_id) FROM stdin;
\.


--
-- TOC entry 4746 (class 0 OID 16754)
-- Dependencies: 280
-- Data for Name: migrations; Type: TABLE DATA; Schema: supabase_functions; Owner: -
--

COPY supabase_functions.migrations (version, inserted_at) FROM stdin;
initial	2025-10-14 05:59:05.065307+00
20210809183423_update_grants	2025-10-14 05:59:05.065307+00
\.


--
-- TOC entry 4923 (class 0 OID 0)
-- Dependencies: 262
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 6, true);


--
-- TOC entry 4924 (class 0 OID 0)
-- Dependencies: 322
-- Name: assignment_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assignment_log_id_seq', 2, true);


--
-- TOC entry 4925 (class 0 OID 0)
-- Dependencies: 288
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: -
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- TOC entry 4926 (class 0 OID 0)
-- Dependencies: 281
-- Name: hooks_id_seq; Type: SEQUENCE SET; Schema: supabase_functions; Owner: -
--

SELECT pg_catalog.setval('supabase_functions.hooks_id_seq', 1, false);


--
-- TOC entry 4130 (class 2606 OID 18061)
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- TOC entry 4042 (class 2606 OID 16494)
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 4153 (class 2606 OID 18167)
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- TOC entry 4109 (class 2606 OID 18185)
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- TOC entry 4111 (class 2606 OID 18195)
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- TOC entry 4040 (class 2606 OID 16487)
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- TOC entry 4132 (class 2606 OID 18054)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- TOC entry 4128 (class 2606 OID 18042)
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- TOC entry 4120 (class 2606 OID 18235)
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- TOC entry 4122 (class 2606 OID 18029)
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- TOC entry 4163 (class 2606 OID 18256)
-- Name: oauth_clients oauth_clients_client_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_client_id_key UNIQUE (client_id);


--
-- TOC entry 4166 (class 2606 OID 18254)
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- TOC entry 4157 (class 2606 OID 18220)
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 4034 (class 2606 OID 16477)
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 4037 (class 2606 OID 17972)
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- TOC entry 4142 (class 2606 OID 18101)
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- TOC entry 4144 (class 2606 OID 18099)
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4149 (class 2606 OID 18115)
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- TOC entry 4045 (class 2606 OID 16500)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4115 (class 2606 OID 17993)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 4139 (class 2606 OID 18082)
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- TOC entry 4134 (class 2606 OID 18073)
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4027 (class 2606 OID 18155)
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- TOC entry 4029 (class 2606 OID 16464)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4184 (class 2606 OID 18331)
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- TOC entry 4186 (class 2606 OID 18333)
-- Name: admins admins_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_profile_id_key UNIQUE (profile_id);


--
-- TOC entry 4255 (class 2606 OID 18635)
-- Name: appointment_history appointment_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment_history
    ADD CONSTRAINT appointment_history_pkey PRIMARY KEY (id);


--
-- TOC entry 4242 (class 2606 OID 18607)
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- TOC entry 4196 (class 2606 OID 18417)
-- Name: assignment_log assignment_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assignment_log
    ADD CONSTRAINT assignment_log_pkey PRIMARY KEY (id);


--
-- TOC entry 4303 (class 2606 OID 18952)
-- Name: auth_trigger_debug_log auth_trigger_debug_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_trigger_debug_log
    ADD CONSTRAINT auth_trigger_debug_log_pkey PRIMARY KEY (id);


--
-- TOC entry 4289 (class 2606 OID 18847)
-- Name: auth_trigger_logs auth_trigger_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_trigger_logs
    ADD CONSTRAINT auth_trigger_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 4259 (class 2606 OID 18717)
-- Name: clinical_notes clinical_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_pkey PRIMARY KEY (id);


--
-- TOC entry 4305 (class 2606 OID 19013)
-- Name: faxes faxes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_pkey PRIMARY KEY (id);


--
-- TOC entry 4219 (class 2606 OID 18465)
-- Name: medication_approvals medication_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_pkey PRIMARY KEY (id);


--
-- TOC entry 4294 (class 2606 OID 18881)
-- Name: medication_dosages medication_dosages_medication_id_strength_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_dosages
    ADD CONSTRAINT medication_dosages_medication_id_strength_key UNIQUE (medication_id, strength);


--
-- TOC entry 4296 (class 2606 OID 18879)
-- Name: medication_dosages medication_dosages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_dosages
    ADD CONSTRAINT medication_dosages_pkey PRIMARY KEY (id);


--
-- TOC entry 4228 (class 2606 OID 18488)
-- Name: medication_orders medication_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_pkey PRIMARY KEY (id);


--
-- TOC entry 4326 (class 2606 OID 19285)
-- Name: medication_tracking_entries medication_tracking_entries_patient_id_medication_preferenc_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_tracking_entries
    ADD CONSTRAINT medication_tracking_entries_patient_id_medication_preferenc_key UNIQUE (patient_id, medication_preference_id, taken_date);


--
-- TOC entry 4328 (class 2606 OID 19281)
-- Name: medication_tracking_entries medication_tracking_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_tracking_entries
    ADD CONSTRAINT medication_tracking_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 4330 (class 2606 OID 19312)
-- Name: medication_tracking_entries medication_tracking_entries_unique_per_day; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_tracking_entries
    ADD CONSTRAINT medication_tracking_entries_unique_per_day UNIQUE (patient_id, medication_preference_id, taken_date);


--
-- TOC entry 4200 (class 2606 OID 18430)
-- Name: medications medications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medications
    ADD CONSTRAINT medications_pkey PRIMARY KEY (id);


--
-- TOC entry 4319 (class 2606 OID 19235)
-- Name: patient_addresses patient_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_addresses
    ADD CONSTRAINT patient_addresses_pkey PRIMARY KEY (id);


--
-- TOC entry 4192 (class 2606 OID 18352)
-- Name: patient_assignments patient_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT patient_assignments_pkey PRIMARY KEY (id);


--
-- TOC entry 4336 (class 2606 OID 19283)
-- Name: patient_health_metrics patient_health_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_health_metrics
    ADD CONSTRAINT patient_health_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 4211 (class 2606 OID 18444)
-- Name: patient_medication_preferences patient_medication_preferences_patient_id_medication_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_patient_id_medication_id_key UNIQUE (patient_id, medication_id);


--
-- TOC entry 4213 (class 2606 OID 18442)
-- Name: patient_medication_preferences patient_medication_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_pkey PRIMARY KEY (id);


--
-- TOC entry 4175 (class 2606 OID 18294)
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- TOC entry 4177 (class 2606 OID 18296)
-- Name: patients patients_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_profile_id_key UNIQUE (profile_id);


--
-- TOC entry 4170 (class 2606 OID 18278)
-- Name: profiles profiles_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_email_key UNIQUE (email);


--
-- TOC entry 4172 (class 2606 OID 18276)
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- TOC entry 4238 (class 2606 OID 18579)
-- Name: provider_availability_overrides provider_availability_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_availability_overrides
    ADD CONSTRAINT provider_availability_overrides_pkey PRIMARY KEY (id);


--
-- TOC entry 4232 (class 2606 OID 18562)
-- Name: provider_schedules provider_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_schedules
    ADD CONSTRAINT provider_schedules_pkey PRIMARY KEY (id);


--
-- TOC entry 4180 (class 2606 OID 18312)
-- Name: providers providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4182 (class 2606 OID 18314)
-- Name: providers providers_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_profile_id_key UNIQUE (profile_id);


--
-- TOC entry 4269 (class 2606 OID 18719)
-- Name: clinical_notes unique_appointment_clinical_note; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT unique_appointment_clinical_note UNIQUE (appointment_id);


--
-- TOC entry 4271 (class 2606 OID 18816)
-- Name: clinical_notes unique_clinical_note_per_appointment; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT unique_clinical_note_per_appointment UNIQUE (appointment_id);


--
-- TOC entry 4321 (class 2606 OID 19237)
-- Name: patient_addresses unique_primary_address; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_addresses
    ADD CONSTRAINT unique_primary_address EXCLUDE USING btree (patient_id WITH =, address_type WITH =) WHERE ((is_primary = true));


--
-- TOC entry 4194 (class 2606 OID 18354)
-- Name: patient_assignments unique_primary_assignment; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT unique_primary_assignment EXCLUDE USING btree (patient_id WITH =) WHERE (((is_primary = true) AND (active = true)));


--
-- TOC entry 4240 (class 2606 OID 18581)
-- Name: provider_availability_overrides unique_provider_override; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_availability_overrides
    ADD CONSTRAINT unique_provider_override UNIQUE (provider_id, date, start_time, end_time);


--
-- TOC entry 4234 (class 2606 OID 18564)
-- Name: provider_schedules unique_provider_schedule; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_schedules
    ADD CONSTRAINT unique_provider_schedule UNIQUE (provider_id, day_of_week, start_time, end_time);


--
-- TOC entry 4253 (class 2606 OID 18609)
-- Name: appointments unique_provider_slot; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT unique_provider_slot UNIQUE (provider_id, appointment_date, start_time);


--
-- TOC entry 4301 (class 2606 OID 18906)
-- Name: visit_addendums visit_addendums_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_addendums
    ADD CONSTRAINT visit_addendums_pkey PRIMARY KEY (id);


--
-- TOC entry 4287 (class 2606 OID 18769)
-- Name: visit_interactions visit_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_interactions
    ADD CONSTRAINT visit_interactions_pkey PRIMARY KEY (id);


--
-- TOC entry 4278 (class 2606 OID 18744)
-- Name: visit_medication_adjustments visit_medication_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_pkey PRIMARY KEY (id);


--
-- TOC entry 4075 (class 2606 OID 17021)
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4078 (class 2606 OID 17032)
-- Name: messages_2025_10_13 messages_2025_10_13_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_10_13
    ADD CONSTRAINT messages_2025_10_13_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4081 (class 2606 OID 17044)
-- Name: messages_2025_10_14 messages_2025_10_14_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_10_14
    ADD CONSTRAINT messages_2025_10_14_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4084 (class 2606 OID 17056)
-- Name: messages_2025_10_15 messages_2025_10_15_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_10_15
    ADD CONSTRAINT messages_2025_10_15_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4087 (class 2606 OID 17068)
-- Name: messages_2025_10_16 messages_2025_10_16_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_10_16
    ADD CONSTRAINT messages_2025_10_16_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4090 (class 2606 OID 17080)
-- Name: messages_2025_10_17 messages_2025_10_17_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_10_17
    ADD CONSTRAINT messages_2025_10_17_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4071 (class 2606 OID 16875)
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- TOC entry 4068 (class 2606 OID 16848)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4100 (class 2606 OID 17902)
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- TOC entry 4048 (class 2606 OID 16517)
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- TOC entry 4102 (class 2606 OID 17912)
-- Name: iceberg_namespaces iceberg_namespaces_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_namespaces
    ADD CONSTRAINT iceberg_namespaces_pkey PRIMARY KEY (id);


--
-- TOC entry 4105 (class 2606 OID 17928)
-- Name: iceberg_tables iceberg_tables_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_pkey PRIMARY KEY (id);


--
-- TOC entry 4058 (class 2606 OID 16558)
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- TOC entry 4060 (class 2606 OID 16556)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 4056 (class 2606 OID 16534)
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- TOC entry 4098 (class 2606 OID 17857)
-- Name: prefixes prefixes_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT prefixes_pkey PRIMARY KEY (bucket_id, level, name);


--
-- TOC entry 4095 (class 2606 OID 17818)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- TOC entry 4093 (class 2606 OID 17803)
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- TOC entry 4064 (class 2606 OID 16771)
-- Name: hooks hooks_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: -
--

ALTER TABLE ONLY supabase_functions.hooks
    ADD CONSTRAINT hooks_pkey PRIMARY KEY (id);


--
-- TOC entry 4062 (class 2606 OID 16761)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: -
--

ALTER TABLE ONLY supabase_functions.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4043 (class 1259 OID 16495)
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- TOC entry 4017 (class 1259 OID 17982)
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4018 (class 1259 OID 17984)
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4019 (class 1259 OID 17985)
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4118 (class 1259 OID 18063)
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- TOC entry 4151 (class 1259 OID 18171)
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- TOC entry 4107 (class 1259 OID 18151)
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- TOC entry 4927 (class 0 OID 0)
-- Dependencies: 4107
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- TOC entry 4112 (class 1259 OID 17979)
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- TOC entry 4154 (class 1259 OID 18168)
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- TOC entry 4155 (class 1259 OID 18169)
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- TOC entry 4126 (class 1259 OID 18174)
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- TOC entry 4123 (class 1259 OID 18035)
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- TOC entry 4124 (class 1259 OID 18180)
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- TOC entry 4161 (class 1259 OID 18257)
-- Name: oauth_clients_client_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_client_id_idx ON auth.oauth_clients USING btree (client_id);


--
-- TOC entry 4164 (class 1259 OID 18258)
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- TOC entry 4158 (class 1259 OID 18227)
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- TOC entry 4159 (class 1259 OID 18226)
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- TOC entry 4160 (class 1259 OID 18228)
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- TOC entry 4020 (class 1259 OID 17986)
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4021 (class 1259 OID 17983)
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4030 (class 1259 OID 16478)
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- TOC entry 4031 (class 1259 OID 16479)
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- TOC entry 4032 (class 1259 OID 17978)
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- TOC entry 4035 (class 1259 OID 18065)
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- TOC entry 4038 (class 1259 OID 18170)
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- TOC entry 4145 (class 1259 OID 18107)
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- TOC entry 4146 (class 1259 OID 18172)
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- TOC entry 4147 (class 1259 OID 18122)
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- TOC entry 4150 (class 1259 OID 18121)
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- TOC entry 4113 (class 1259 OID 18173)
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- TOC entry 4116 (class 1259 OID 18064)
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- TOC entry 4137 (class 1259 OID 18089)
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- TOC entry 4140 (class 1259 OID 18088)
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- TOC entry 4135 (class 1259 OID 18074)
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- TOC entry 4136 (class 1259 OID 18236)
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- TOC entry 4125 (class 1259 OID 18233)
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- TOC entry 4117 (class 1259 OID 18062)
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- TOC entry 4022 (class 1259 OID 18142)
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- TOC entry 4928 (class 0 OID 0)
-- Dependencies: 4022
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- TOC entry 4023 (class 1259 OID 17980)
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- TOC entry 4024 (class 1259 OID 16468)
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- TOC entry 4025 (class 1259 OID 18197)
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- TOC entry 4187 (class 1259 OID 18369)
-- Name: idx_admins_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admins_profile_id ON public.admins USING btree (profile_id);


--
-- TOC entry 4256 (class 1259 OID 18651)
-- Name: idx_appointment_history_appointment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointment_history_appointment ON public.appointment_history USING btree (appointment_id);


--
-- TOC entry 4257 (class 1259 OID 18652)
-- Name: idx_appointment_history_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointment_history_created ON public.appointment_history USING btree (created_at);


--
-- TOC entry 4243 (class 1259 OID 18650)
-- Name: idx_appointments_assignment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_assignment ON public.appointments USING btree (assignment_id);


--
-- TOC entry 4244 (class 1259 OID 18647)
-- Name: idx_appointments_date_range; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_date_range ON public.appointments USING btree (appointment_date);


--
-- TOC entry 4245 (class 1259 OID 18645)
-- Name: idx_appointments_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_patient_id ON public.appointments USING btree (patient_id);


--
-- TOC entry 4246 (class 1259 OID 18648)
-- Name: idx_appointments_provider_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_provider_date ON public.appointments USING btree (provider_id, appointment_date);


--
-- TOC entry 4247 (class 1259 OID 18646)
-- Name: idx_appointments_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_provider_id ON public.appointments USING btree (provider_id);


--
-- TOC entry 4248 (class 1259 OID 18938)
-- Name: idx_appointments_reschedule_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_reschedule_source ON public.appointments USING btree (is_reschedule_source);


--
-- TOC entry 4249 (class 1259 OID 18936)
-- Name: idx_appointments_rescheduled_from; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_rescheduled_from ON public.appointments USING btree (rescheduled_from_id);


--
-- TOC entry 4250 (class 1259 OID 18937)
-- Name: idx_appointments_rescheduled_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_rescheduled_to ON public.appointments USING btree (rescheduled_to_id);


--
-- TOC entry 4251 (class 1259 OID 18649)
-- Name: idx_appointments_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_status ON public.appointments USING btree (status);


--
-- TOC entry 4260 (class 1259 OID 18780)
-- Name: idx_clinical_notes_appointment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_appointment ON public.clinical_notes USING btree (appointment_id);


--
-- TOC entry 4261 (class 1259 OID 18809)
-- Name: idx_clinical_notes_appointment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_appointment_id ON public.clinical_notes USING btree (appointment_id);


--
-- TOC entry 4262 (class 1259 OID 18783)
-- Name: idx_clinical_notes_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_created_at ON public.clinical_notes USING btree (created_at);


--
-- TOC entry 4263 (class 1259 OID 18781)
-- Name: idx_clinical_notes_patient; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_patient ON public.clinical_notes USING btree (patient_id);


--
-- TOC entry 4264 (class 1259 OID 18810)
-- Name: idx_clinical_notes_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_patient_id ON public.clinical_notes USING btree (patient_id);


--
-- TOC entry 4265 (class 1259 OID 18782)
-- Name: idx_clinical_notes_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_provider ON public.clinical_notes USING btree (provider_id);


--
-- TOC entry 4266 (class 1259 OID 18811)
-- Name: idx_clinical_notes_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_provider_id ON public.clinical_notes USING btree (provider_id);


--
-- TOC entry 4267 (class 1259 OID 18784)
-- Name: idx_clinical_notes_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_updated_at ON public.clinical_notes USING btree (updated_at);


--
-- TOC entry 4306 (class 1259 OID 19034)
-- Name: idx_faxes_approval_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_approval_id ON public.faxes USING btree (approval_id);


--
-- TOC entry 4307 (class 1259 OID 19038)
-- Name: idx_faxes_faxed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_faxed_at ON public.faxes USING btree (faxed_at);


--
-- TOC entry 4308 (class 1259 OID 19036)
-- Name: idx_faxes_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_patient_id ON public.faxes USING btree (patient_id);


--
-- TOC entry 4309 (class 1259 OID 19089)
-- Name: idx_faxes_patient_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_patient_profile_id ON public.faxes USING btree (patient_profile_id);


--
-- TOC entry 4310 (class 1259 OID 19035)
-- Name: idx_faxes_preference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_preference_id ON public.faxes USING btree (preference_id);


--
-- TOC entry 4311 (class 1259 OID 19037)
-- Name: idx_faxes_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_provider_id ON public.faxes USING btree (provider_id);


--
-- TOC entry 4312 (class 1259 OID 19088)
-- Name: idx_faxes_provider_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_provider_profile_id ON public.faxes USING btree (provider_profile_id);


--
-- TOC entry 4313 (class 1259 OID 19039)
-- Name: idx_faxes_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_status ON public.faxes USING btree (fax_status);


--
-- TOC entry 4214 (class 1259 OID 18508)
-- Name: idx_medication_approvals_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_approvals_provider_id ON public.medication_approvals USING btree (provider_id);


--
-- TOC entry 4215 (class 1259 OID 19087)
-- Name: idx_medication_approvals_provider_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_approvals_provider_profile_id ON public.medication_approvals USING btree (provider_profile_id);


--
-- TOC entry 4216 (class 1259 OID 18509)
-- Name: idx_medication_approvals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_approvals_status ON public.medication_approvals USING btree (status);


--
-- TOC entry 4217 (class 1259 OID 19092)
-- Name: idx_medication_approvals_supply_days; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_approvals_supply_days ON public.medication_approvals USING btree (supply_days);


--
-- TOC entry 4290 (class 1259 OID 18888)
-- Name: idx_medication_dosages_available; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_dosages_available ON public.medication_dosages USING btree (available);


--
-- TOC entry 4291 (class 1259 OID 18887)
-- Name: idx_medication_dosages_medication_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_dosages_medication_id ON public.medication_dosages USING btree (medication_id);


--
-- TOC entry 4292 (class 1259 OID 18889)
-- Name: idx_medication_dosages_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_dosages_sort_order ON public.medication_dosages USING btree (sort_order);


--
-- TOC entry 4220 (class 1259 OID 18512)
-- Name: idx_medication_orders_fulfillment_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_fulfillment_status ON public.medication_orders USING btree (fulfillment_status);


--
-- TOC entry 4221 (class 1259 OID 18541)
-- Name: idx_medication_orders_patient_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_patient_created ON public.medication_orders USING btree (patient_id, created_at DESC);


--
-- TOC entry 4222 (class 1259 OID 18510)
-- Name: idx_medication_orders_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_patient_id ON public.medication_orders USING btree (patient_id);


--
-- TOC entry 4223 (class 1259 OID 19091)
-- Name: idx_medication_orders_patient_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_patient_profile_id ON public.medication_orders USING btree (patient_profile_id);


--
-- TOC entry 4224 (class 1259 OID 18511)
-- Name: idx_medication_orders_payment_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_payment_status ON public.medication_orders USING btree (payment_status);


--
-- TOC entry 4225 (class 1259 OID 19090)
-- Name: idx_medication_orders_provider_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_provider_profile_id ON public.medication_orders USING btree (provider_profile_id);


--
-- TOC entry 4226 (class 1259 OID 18539)
-- Name: idx_medication_orders_sent_to_pharmacy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_sent_to_pharmacy ON public.medication_orders USING btree (sent_to_pharmacy);


--
-- TOC entry 4322 (class 1259 OID 19301)
-- Name: idx_medication_tracking_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_tracking_patient_id ON public.medication_tracking_entries USING btree (patient_id);


--
-- TOC entry 4323 (class 1259 OID 19302)
-- Name: idx_medication_tracking_preference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_tracking_preference_id ON public.medication_tracking_entries USING btree (medication_preference_id);


--
-- TOC entry 4324 (class 1259 OID 19303)
-- Name: idx_medication_tracking_taken_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_tracking_taken_date ON public.medication_tracking_entries USING btree (taken_date);


--
-- TOC entry 4197 (class 1259 OID 18505)
-- Name: idx_medications_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medications_active ON public.medications USING btree (active);


--
-- TOC entry 4198 (class 1259 OID 18504)
-- Name: idx_medications_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medications_category ON public.medications USING btree (category);


--
-- TOC entry 4314 (class 1259 OID 19243)
-- Name: idx_patient_addresses_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_addresses_patient_id ON public.patient_addresses USING btree (patient_id);


--
-- TOC entry 4315 (class 1259 OID 19245)
-- Name: idx_patient_addresses_primary; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_addresses_primary ON public.patient_addresses USING btree (patient_id, address_type) WHERE (is_primary = true);


--
-- TOC entry 4316 (class 1259 OID 19244)
-- Name: idx_patient_addresses_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_addresses_type ON public.patient_addresses USING btree (address_type);


--
-- TOC entry 4317 (class 1259 OID 19246)
-- Name: idx_patient_addresses_verified; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_addresses_verified ON public.patient_addresses USING btree (is_verified);


--
-- TOC entry 4188 (class 1259 OID 18372)
-- Name: idx_patient_assignments_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_assignments_active ON public.patient_assignments USING btree (active);


--
-- TOC entry 4189 (class 1259 OID 18370)
-- Name: idx_patient_assignments_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_assignments_patient_id ON public.patient_assignments USING btree (patient_id);


--
-- TOC entry 4190 (class 1259 OID 18371)
-- Name: idx_patient_assignments_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_assignments_provider_id ON public.patient_assignments USING btree (provider_id);


--
-- TOC entry 4331 (class 1259 OID 19305)
-- Name: idx_patient_health_metrics_metric_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_health_metrics_metric_type ON public.patient_health_metrics USING btree (metric_type);


--
-- TOC entry 4332 (class 1259 OID 19304)
-- Name: idx_patient_health_metrics_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_health_metrics_patient_id ON public.patient_health_metrics USING btree (patient_id);


--
-- TOC entry 4333 (class 1259 OID 19307)
-- Name: idx_patient_health_metrics_patient_metric_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_health_metrics_patient_metric_date ON public.patient_health_metrics USING btree (patient_id, metric_type, recorded_at);


--
-- TOC entry 4334 (class 1259 OID 19306)
-- Name: idx_patient_health_metrics_recorded_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_health_metrics_recorded_at ON public.patient_health_metrics USING btree (recorded_at);


--
-- TOC entry 4201 (class 1259 OID 19120)
-- Name: idx_patient_medication_preferences_approval_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_approval_date ON public.patient_medication_preferences USING btree (approval_date);


--
-- TOC entry 4202 (class 1259 OID 19040)
-- Name: idx_patient_medication_preferences_faxed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_faxed ON public.patient_medication_preferences USING btree (faxed);


--
-- TOC entry 4203 (class 1259 OID 19041)
-- Name: idx_patient_medication_preferences_next_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_next_due ON public.patient_medication_preferences USING btree (next_prescription_due);


--
-- TOC entry 4204 (class 1259 OID 18506)
-- Name: idx_patient_medication_preferences_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_patient_id ON public.patient_medication_preferences USING btree (patient_id);


--
-- TOC entry 4205 (class 1259 OID 19117)
-- Name: idx_patient_medication_preferences_refill_requested; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_refill_requested ON public.patient_medication_preferences USING btree (refill_requested);


--
-- TOC entry 4206 (class 1259 OID 19119)
-- Name: idx_patient_medication_preferences_refill_requested_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_refill_requested_date ON public.patient_medication_preferences USING btree (refill_requested_date);


--
-- TOC entry 4207 (class 1259 OID 18507)
-- Name: idx_patient_medication_preferences_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_status ON public.patient_medication_preferences USING btree (status);


--
-- TOC entry 4208 (class 1259 OID 19106)
-- Name: idx_patient_medication_preferences_supply_days; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_supply_days ON public.patient_medication_preferences USING btree (supply_days);


--
-- TOC entry 4173 (class 1259 OID 18367)
-- Name: idx_patients_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patients_profile_id ON public.patients USING btree (profile_id);


--
-- TOC entry 4209 (class 1259 OID 19118)
-- Name: idx_preferences_provider_approval; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_preferences_provider_approval ON public.patient_medication_preferences USING btree (status, refill_requested) WHERE ((status = 'pending'::text) AND (refill_requested = true));


--
-- TOC entry 4167 (class 1259 OID 18366)
-- Name: idx_profiles_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_email ON public.profiles USING btree (email);


--
-- TOC entry 4168 (class 1259 OID 18365)
-- Name: idx_profiles_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_role ON public.profiles USING btree (role);


--
-- TOC entry 4235 (class 1259 OID 18644)
-- Name: idx_provider_overrides_date_range; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provider_overrides_date_range ON public.provider_availability_overrides USING btree (date);


--
-- TOC entry 4236 (class 1259 OID 18643)
-- Name: idx_provider_overrides_provider_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provider_overrides_provider_date ON public.provider_availability_overrides USING btree (provider_id, date);


--
-- TOC entry 4229 (class 1259 OID 18642)
-- Name: idx_provider_schedules_day_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provider_schedules_day_active ON public.provider_schedules USING btree (day_of_week, active);


--
-- TOC entry 4230 (class 1259 OID 18641)
-- Name: idx_provider_schedules_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provider_schedules_provider_id ON public.provider_schedules USING btree (provider_id);


--
-- TOC entry 4178 (class 1259 OID 18368)
-- Name: idx_providers_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_providers_profile_id ON public.providers USING btree (profile_id);


--
-- TOC entry 4297 (class 1259 OID 18919)
-- Name: idx_visit_addendums_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_addendums_created_at ON public.visit_addendums USING btree (created_at);


--
-- TOC entry 4298 (class 1259 OID 18918)
-- Name: idx_visit_addendums_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_addendums_provider_id ON public.visit_addendums USING btree (provider_id);


--
-- TOC entry 4299 (class 1259 OID 18917)
-- Name: idx_visit_addendums_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_addendums_visit_id ON public.visit_addendums USING btree (visit_id);


--
-- TOC entry 4279 (class 1259 OID 18790)
-- Name: idx_visit_interactions_appointment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_appointment ON public.visit_interactions USING btree (appointment_id);


--
-- TOC entry 4280 (class 1259 OID 18813)
-- Name: idx_visit_interactions_appointment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_appointment_id ON public.visit_interactions USING btree (appointment_id);


--
-- TOC entry 4281 (class 1259 OID 18789)
-- Name: idx_visit_interactions_clinical_note; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_clinical_note ON public.visit_interactions USING btree (clinical_note_id);


--
-- TOC entry 4282 (class 1259 OID 18812)
-- Name: idx_visit_interactions_clinical_note_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_clinical_note_id ON public.visit_interactions USING btree (clinical_note_id);


--
-- TOC entry 4283 (class 1259 OID 18792)
-- Name: idx_visit_interactions_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_created_at ON public.visit_interactions USING btree (created_at);


--
-- TOC entry 4284 (class 1259 OID 18814)
-- Name: idx_visit_interactions_medication_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_medication_id ON public.visit_interactions USING btree (medication_id);


--
-- TOC entry 4285 (class 1259 OID 18791)
-- Name: idx_visit_interactions_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_type ON public.visit_interactions USING btree (interaction_type);


--
-- TOC entry 4272 (class 1259 OID 18786)
-- Name: idx_visit_medication_adjustments_appointment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_appointment ON public.visit_medication_adjustments USING btree (appointment_id);


--
-- TOC entry 4273 (class 1259 OID 18785)
-- Name: idx_visit_medication_adjustments_clinical_note; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_clinical_note ON public.visit_medication_adjustments USING btree (clinical_note_id);


--
-- TOC entry 4274 (class 1259 OID 18788)
-- Name: idx_visit_medication_adjustments_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_created_at ON public.visit_medication_adjustments USING btree (created_at);


--
-- TOC entry 4275 (class 1259 OID 18787)
-- Name: idx_visit_medication_adjustments_preference; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_preference ON public.visit_medication_adjustments USING btree (preference_id);


--
-- TOC entry 4276 (class 1259 OID 19107)
-- Name: idx_visit_medication_adjustments_supply_days; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_supply_days ON public.visit_medication_adjustments USING btree (new_supply_days);


--
-- TOC entry 4069 (class 1259 OID 17022)
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- TOC entry 4073 (class 1259 OID 17023)
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4076 (class 1259 OID 17033)
-- Name: messages_2025_10_13_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_10_13_inserted_at_topic_idx ON realtime.messages_2025_10_13 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4079 (class 1259 OID 17045)
-- Name: messages_2025_10_14_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_10_14_inserted_at_topic_idx ON realtime.messages_2025_10_14 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4082 (class 1259 OID 17057)
-- Name: messages_2025_10_15_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_10_15_inserted_at_topic_idx ON realtime.messages_2025_10_15 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4085 (class 1259 OID 17069)
-- Name: messages_2025_10_16_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_10_16_inserted_at_topic_idx ON realtime.messages_2025_10_16 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4088 (class 1259 OID 17081)
-- Name: messages_2025_10_17_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_10_17_inserted_at_topic_idx ON realtime.messages_2025_10_17 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4072 (class 1259 OID 16924)
-- Name: subscription_subscription_id_entity_filters_key; Type: INDEX; Schema: realtime; Owner: -
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_key ON realtime.subscription USING btree (subscription_id, entity, filters);


--
-- TOC entry 4046 (class 1259 OID 16523)
-- Name: bname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- TOC entry 4049 (class 1259 OID 16545)
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- TOC entry 4103 (class 1259 OID 17918)
-- Name: idx_iceberg_namespaces_bucket_id; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX idx_iceberg_namespaces_bucket_id ON storage.iceberg_namespaces USING btree (bucket_id, name);


--
-- TOC entry 4106 (class 1259 OID 17939)
-- Name: idx_iceberg_tables_namespace_id; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX idx_iceberg_tables_namespace_id ON storage.iceberg_tables USING btree (namespace_id, name);


--
-- TOC entry 4091 (class 1259 OID 17829)
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- TOC entry 4050 (class 1259 OID 17875)
-- Name: idx_name_bucket_level_unique; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX idx_name_bucket_level_unique ON storage.objects USING btree (name COLLATE "C", bucket_id, level);


--
-- TOC entry 4051 (class 1259 OID 17794)
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- TOC entry 4052 (class 1259 OID 17877)
-- Name: idx_objects_lower_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_lower_name ON storage.objects USING btree ((path_tokens[level]), lower(name) text_pattern_ops, bucket_id, level);


--
-- TOC entry 4096 (class 1259 OID 17878)
-- Name: idx_prefixes_lower_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_prefixes_lower_name ON storage.prefixes USING btree (bucket_id, level, ((string_to_array(name, '/'::text))[level]), lower(name) text_pattern_ops);


--
-- TOC entry 4053 (class 1259 OID 16546)
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- TOC entry 4054 (class 1259 OID 17876)
-- Name: objects_bucket_id_level_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX objects_bucket_id_level_idx ON storage.objects USING btree (bucket_id, level, name COLLATE "C");


--
-- TOC entry 4065 (class 1259 OID 16773)
-- Name: supabase_functions_hooks_h_table_id_h_name_idx; Type: INDEX; Schema: supabase_functions; Owner: -
--

CREATE INDEX supabase_functions_hooks_h_table_id_h_name_idx ON supabase_functions.hooks USING btree (hook_table_id, hook_name);


--
-- TOC entry 4066 (class 1259 OID 16772)
-- Name: supabase_functions_hooks_request_id_idx; Type: INDEX; Schema: supabase_functions; Owner: -
--

CREATE INDEX supabase_functions_hooks_request_id_idx ON supabase_functions.hooks USING btree (request_id);


--
-- TOC entry 4337 (class 0 OID 0)
-- Name: messages_2025_10_13_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_13_inserted_at_topic_idx;


--
-- TOC entry 4338 (class 0 OID 0)
-- Name: messages_2025_10_13_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_13_pkey;


--
-- TOC entry 4339 (class 0 OID 0)
-- Name: messages_2025_10_14_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_14_inserted_at_topic_idx;


--
-- TOC entry 4340 (class 0 OID 0)
-- Name: messages_2025_10_14_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_14_pkey;


--
-- TOC entry 4341 (class 0 OID 0)
-- Name: messages_2025_10_15_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_15_inserted_at_topic_idx;


--
-- TOC entry 4342 (class 0 OID 0)
-- Name: messages_2025_10_15_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_15_pkey;


--
-- TOC entry 4343 (class 0 OID 0)
-- Name: messages_2025_10_16_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_16_inserted_at_topic_idx;


--
-- TOC entry 4344 (class 0 OID 0)
-- Name: messages_2025_10_16_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_16_pkey;


--
-- TOC entry 4345 (class 0 OID 0)
-- Name: messages_2025_10_17_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_17_inserted_at_topic_idx;


--
-- TOC entry 4346 (class 0 OID 0)
-- Name: messages_2025_10_17_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_17_pkey;


--
-- TOC entry 4413 (class 2620 OID 19000)
-- Name: users on_auth_user_created; Type: TRIGGER; Schema: auth; Owner: -
--

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();


--
-- TOC entry 4436 (class 2620 OID 18656)
-- Name: appointments appointment_audit_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER appointment_audit_trigger AFTER INSERT OR DELETE OR UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.log_appointment_changes();


--
-- TOC entry 4437 (class 2620 OID 18689)
-- Name: appointments appointment_business_rules_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER appointment_business_rules_trigger BEFORE INSERT OR UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.validate_appointment_business_rules();


--
-- TOC entry 4428 (class 2620 OID 19115)
-- Name: patient_medication_preferences calculate_next_due_on_supply_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER calculate_next_due_on_supply_update BEFORE UPDATE ON public.patient_medication_preferences FOR EACH ROW EXECUTE FUNCTION public.calculate_next_prescription_due();


--
-- TOC entry 4929 (class 0 OID 0)
-- Dependencies: 4428
-- Name: TRIGGER calculate_next_due_on_supply_update ON patient_medication_preferences; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TRIGGER calculate_next_due_on_supply_update ON public.patient_medication_preferences IS 'Calculates next_prescription_due when supply_days is updated with approved status';


--
-- TOC entry 4432 (class 2620 OID 19103)
-- Name: medication_orders check_approval_expiry_on_delivery_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER check_approval_expiry_on_delivery_trigger AFTER UPDATE ON public.medication_orders FOR EACH ROW EXECUTE FUNCTION public.check_approval_expiry_on_delivery();


--
-- TOC entry 4443 (class 2620 OID 19049)
-- Name: faxes create_order_on_fax_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER create_order_on_fax_trigger AFTER INSERT ON public.faxes FOR EACH ROW EXECUTE FUNCTION public.create_order_on_fax();


--
-- TOC entry 4930 (class 0 OID 0)
-- Dependencies: 4443
-- Name: TRIGGER create_order_on_fax_trigger ON faxes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TRIGGER create_order_on_fax_trigger ON public.faxes IS 'Trigger to create medication order when fax is sent';


--
-- TOC entry 4429 (class 2620 OID 19122)
-- Name: patient_medication_preferences trigger_update_approval_date; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_update_approval_date BEFORE UPDATE ON public.patient_medication_preferences FOR EACH ROW EXECUTE FUNCTION public.update_approval_date_on_status_change();


--
-- TOC entry 4425 (class 2620 OID 18377)
-- Name: admins update_admins_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_admins_updated_at BEFORE UPDATE ON public.admins FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4438 (class 2620 OID 18654)
-- Name: appointments update_appointments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_appointments_updated_at BEFORE UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4439 (class 2620 OID 18795)
-- Name: clinical_notes update_clinical_note_editor_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_clinical_note_editor_trigger BEFORE UPDATE ON public.clinical_notes FOR EACH ROW EXECUTE FUNCTION public.update_clinical_note_editor();


--
-- TOC entry 4440 (class 2620 OID 18807)
-- Name: clinical_notes update_clinical_notes_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_clinical_notes_updated_at BEFORE UPDATE ON public.clinical_notes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4444 (class 2620 OID 19042)
-- Name: faxes update_faxes_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_faxes_updated_at BEFORE UPDATE ON public.faxes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4431 (class 2620 OID 18515)
-- Name: medication_approvals update_medication_approvals_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medication_approvals_updated_at BEFORE UPDATE ON public.medication_approvals FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4442 (class 2620 OID 18890)
-- Name: medication_dosages update_medication_dosages_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medication_dosages_updated_at BEFORE UPDATE ON public.medication_dosages FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4433 (class 2620 OID 18516)
-- Name: medication_orders update_medication_orders_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medication_orders_updated_at BEFORE UPDATE ON public.medication_orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4446 (class 2620 OID 19308)
-- Name: medication_tracking_entries update_medication_tracking_entries_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medication_tracking_entries_updated_at BEFORE UPDATE ON public.medication_tracking_entries FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4427 (class 2620 OID 18513)
-- Name: medications update_medications_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medications_updated_at BEFORE UPDATE ON public.medications FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4445 (class 2620 OID 19247)
-- Name: patient_addresses update_patient_addresses_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patient_addresses_updated_at BEFORE UPDATE ON public.patient_addresses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4426 (class 2620 OID 18378)
-- Name: patient_assignments update_patient_assignments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patient_assignments_updated_at BEFORE UPDATE ON public.patient_assignments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4447 (class 2620 OID 19309)
-- Name: patient_health_metrics update_patient_health_metrics_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patient_health_metrics_updated_at BEFORE UPDATE ON public.patient_health_metrics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4430 (class 2620 OID 18514)
-- Name: patient_medication_preferences update_patient_medication_preferences_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patient_medication_preferences_updated_at BEFORE UPDATE ON public.patient_medication_preferences FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4423 (class 2620 OID 18375)
-- Name: patients update_patients_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patients_updated_at BEFORE UPDATE ON public.patients FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4441 (class 2620 OID 19109)
-- Name: visit_medication_adjustments update_preference_on_adjustment_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_preference_on_adjustment_trigger AFTER INSERT ON public.visit_medication_adjustments FOR EACH ROW EXECUTE FUNCTION public.update_preference_on_medication_adjustment();


--
-- TOC entry 4931 (class 0 OID 0)
-- Dependencies: 4441
-- Name: TRIGGER update_preference_on_adjustment_trigger ON visit_medication_adjustments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TRIGGER update_preference_on_adjustment_trigger ON public.visit_medication_adjustments IS 'Updates patient_medication_preferences when medication adjustments are approved, including supply_days and next_prescription_due calculation';


--
-- TOC entry 4434 (class 2620 OID 19045)
-- Name: medication_orders update_prescription_due_date_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_prescription_due_date_trigger AFTER UPDATE ON public.medication_orders FOR EACH ROW EXECUTE FUNCTION public.update_prescription_due_date();


--
-- TOC entry 4422 (class 2620 OID 18374)
-- Name: profiles update_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4435 (class 2620 OID 18653)
-- Name: provider_schedules update_provider_schedules_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_provider_schedules_updated_at BEFORE UPDATE ON public.provider_schedules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4424 (class 2620 OID 18376)
-- Name: providers update_providers_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_providers_updated_at BEFORE UPDATE ON public.providers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4419 (class 2620 OID 16880)
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: -
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- TOC entry 4414 (class 2620 OID 17885)
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- TOC entry 4415 (class 2620 OID 17873)
-- Name: objects objects_delete_delete_prefix; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER objects_delete_delete_prefix AFTER DELETE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- TOC entry 4416 (class 2620 OID 17871)
-- Name: objects objects_insert_create_prefix; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER objects_insert_create_prefix BEFORE INSERT ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.objects_insert_prefix_trigger();


--
-- TOC entry 4417 (class 2620 OID 17872)
-- Name: objects objects_update_create_prefix; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER objects_update_create_prefix BEFORE UPDATE ON storage.objects FOR EACH ROW WHEN (((new.name <> old.name) OR (new.bucket_id <> old.bucket_id))) EXECUTE FUNCTION storage.objects_update_prefix_trigger();


--
-- TOC entry 4420 (class 2620 OID 17881)
-- Name: prefixes prefixes_create_hierarchy; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER prefixes_create_hierarchy BEFORE INSERT ON storage.prefixes FOR EACH ROW WHEN ((pg_trigger_depth() < 1)) EXECUTE FUNCTION storage.prefixes_insert_trigger();


--
-- TOC entry 4421 (class 2620 OID 17870)
-- Name: prefixes prefixes_delete_hierarchy; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER prefixes_delete_hierarchy AFTER DELETE ON storage.prefixes FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- TOC entry 4418 (class 2620 OID 17782)
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- TOC entry 4356 (class 2606 OID 17966)
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4360 (class 2606 OID 18055)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4359 (class 2606 OID 18043)
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- TOC entry 4358 (class 2606 OID 18030)
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4365 (class 2606 OID 18221)
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4347 (class 2606 OID 17999)
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4362 (class 2606 OID 18102)
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4363 (class 2606 OID 18175)
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- TOC entry 4364 (class 2606 OID 18116)
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4357 (class 2606 OID 17994)
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4361 (class 2606 OID 18083)
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4369 (class 2606 OID 18334)
-- Name: admins admins_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4390 (class 2606 OID 18636)
-- Name: appointment_history appointment_history_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment_history
    ADD CONSTRAINT appointment_history_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4385 (class 2606 OID 18620)
-- Name: appointments appointments_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.patient_assignments(id);


--
-- TOC entry 4386 (class 2606 OID 18610)
-- Name: appointments appointments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4387 (class 2606 OID 18615)
-- Name: appointments appointments_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4388 (class 2606 OID 18926)
-- Name: appointments appointments_rescheduled_from_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_rescheduled_from_id_fkey FOREIGN KEY (rescheduled_from_id) REFERENCES public.appointments(id);


--
-- TOC entry 4389 (class 2606 OID 18931)
-- Name: appointments appointments_rescheduled_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_rescheduled_to_id_fkey FOREIGN KEY (rescheduled_to_id) REFERENCES public.appointments(id);


--
-- TOC entry 4399 (class 2606 OID 18848)
-- Name: auth_trigger_logs auth_trigger_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_trigger_logs
    ADD CONSTRAINT auth_trigger_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- TOC entry 4391 (class 2606 OID 18720)
-- Name: clinical_notes clinical_notes_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4392 (class 2606 OID 18725)
-- Name: clinical_notes clinical_notes_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4393 (class 2606 OID 18730)
-- Name: clinical_notes clinical_notes_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4403 (class 2606 OID 19014)
-- Name: faxes faxes_approval_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_approval_id_fkey FOREIGN KEY (approval_id) REFERENCES public.medication_approvals(id) ON DELETE CASCADE;


--
-- TOC entry 4404 (class 2606 OID 19024)
-- Name: faxes faxes_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4405 (class 2606 OID 19072)
-- Name: faxes faxes_patient_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_patient_profile_id_fkey FOREIGN KEY (patient_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4406 (class 2606 OID 19019)
-- Name: faxes faxes_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_preference_id_fkey FOREIGN KEY (preference_id) REFERENCES public.patient_medication_preferences(id) ON DELETE CASCADE;


--
-- TOC entry 4407 (class 2606 OID 19029)
-- Name: faxes faxes_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4408 (class 2606 OID 19067)
-- Name: faxes faxes_provider_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_provider_profile_id_fkey FOREIGN KEY (provider_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4375 (class 2606 OID 18466)
-- Name: medication_approvals medication_approvals_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_preference_id_fkey FOREIGN KEY (preference_id) REFERENCES public.patient_medication_preferences(id) ON DELETE CASCADE;


--
-- TOC entry 4376 (class 2606 OID 18471)
-- Name: medication_approvals medication_approvals_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4377 (class 2606 OID 19062)
-- Name: medication_approvals medication_approvals_provider_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_provider_profile_id_fkey FOREIGN KEY (provider_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4400 (class 2606 OID 18882)
-- Name: medication_dosages medication_dosages_medication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_dosages
    ADD CONSTRAINT medication_dosages_medication_id_fkey FOREIGN KEY (medication_id) REFERENCES public.medications(id) ON DELETE CASCADE;


--
-- TOC entry 4378 (class 2606 OID 18489)
-- Name: medication_orders medication_orders_approval_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_approval_id_fkey FOREIGN KEY (approval_id) REFERENCES public.medication_approvals(id) ON DELETE CASCADE;


--
-- TOC entry 4379 (class 2606 OID 18499)
-- Name: medication_orders medication_orders_medication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_medication_id_fkey FOREIGN KEY (medication_id) REFERENCES public.medications(id) ON DELETE CASCADE;


--
-- TOC entry 4380 (class 2606 OID 18494)
-- Name: medication_orders medication_orders_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4381 (class 2606 OID 19082)
-- Name: medication_orders medication_orders_patient_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_patient_profile_id_fkey FOREIGN KEY (patient_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4382 (class 2606 OID 19077)
-- Name: medication_orders medication_orders_provider_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_provider_profile_id_fkey FOREIGN KEY (provider_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4410 (class 2606 OID 19291)
-- Name: medication_tracking_entries medication_tracking_entries_medication_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_tracking_entries
    ADD CONSTRAINT medication_tracking_entries_medication_preference_id_fkey FOREIGN KEY (medication_preference_id) REFERENCES public.patient_medication_preferences(id) ON DELETE CASCADE;


--
-- TOC entry 4411 (class 2606 OID 19286)
-- Name: medication_tracking_entries medication_tracking_entries_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_tracking_entries
    ADD CONSTRAINT medication_tracking_entries_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4409 (class 2606 OID 19238)
-- Name: patient_addresses patient_addresses_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_addresses
    ADD CONSTRAINT patient_addresses_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4370 (class 2606 OID 18355)
-- Name: patient_assignments patient_assignments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT patient_assignments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4371 (class 2606 OID 18360)
-- Name: patient_assignments patient_assignments_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT patient_assignments_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4412 (class 2606 OID 19296)
-- Name: patient_health_metrics patient_health_metrics_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_health_metrics
    ADD CONSTRAINT patient_health_metrics_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4372 (class 2606 OID 18891)
-- Name: patient_medication_preferences patient_medication_preferences_medication_dosage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_medication_dosage_id_fkey FOREIGN KEY (medication_dosage_id) REFERENCES public.medication_dosages(id) ON DELETE SET NULL;


--
-- TOC entry 4373 (class 2606 OID 18450)
-- Name: patient_medication_preferences patient_medication_preferences_medication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_medication_id_fkey FOREIGN KEY (medication_id) REFERENCES public.medications(id) ON DELETE CASCADE;


--
-- TOC entry 4374 (class 2606 OID 18445)
-- Name: patient_medication_preferences patient_medication_preferences_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4367 (class 2606 OID 18297)
-- Name: patients patients_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4366 (class 2606 OID 18279)
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4384 (class 2606 OID 18582)
-- Name: provider_availability_overrides provider_availability_overrides_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_availability_overrides
    ADD CONSTRAINT provider_availability_overrides_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4383 (class 2606 OID 18565)
-- Name: provider_schedules provider_schedules_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_schedules
    ADD CONSTRAINT provider_schedules_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4368 (class 2606 OID 18315)
-- Name: providers providers_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4401 (class 2606 OID 18912)
-- Name: visit_addendums visit_addendums_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_addendums
    ADD CONSTRAINT visit_addendums_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4402 (class 2606 OID 18907)
-- Name: visit_addendums visit_addendums_visit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_addendums
    ADD CONSTRAINT visit_addendums_visit_id_fkey FOREIGN KEY (visit_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4397 (class 2606 OID 18775)
-- Name: visit_interactions visit_interactions_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_interactions
    ADD CONSTRAINT visit_interactions_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4398 (class 2606 OID 18770)
-- Name: visit_interactions visit_interactions_clinical_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_interactions
    ADD CONSTRAINT visit_interactions_clinical_note_id_fkey FOREIGN KEY (clinical_note_id) REFERENCES public.clinical_notes(id) ON DELETE CASCADE;


--
-- TOC entry 4394 (class 2606 OID 18750)
-- Name: visit_medication_adjustments visit_medication_adjustments_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4395 (class 2606 OID 18745)
-- Name: visit_medication_adjustments visit_medication_adjustments_clinical_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_clinical_note_id_fkey FOREIGN KEY (clinical_note_id) REFERENCES public.clinical_notes(id) ON DELETE CASCADE;


--
-- TOC entry 4396 (class 2606 OID 18755)
-- Name: visit_medication_adjustments visit_medication_adjustments_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_preference_id_fkey FOREIGN KEY (preference_id) REFERENCES public.patient_medication_preferences(id) ON DELETE CASCADE;


--
-- TOC entry 4353 (class 2606 OID 17913)
-- Name: iceberg_namespaces iceberg_namespaces_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_namespaces
    ADD CONSTRAINT iceberg_namespaces_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_analytics(id) ON DELETE CASCADE;


--
-- TOC entry 4354 (class 2606 OID 17934)
-- Name: iceberg_tables iceberg_tables_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_analytics(id) ON DELETE CASCADE;


--
-- TOC entry 4355 (class 2606 OID 17929)
-- Name: iceberg_tables iceberg_tables_namespace_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES storage.iceberg_namespaces(id) ON DELETE CASCADE;


--
-- TOC entry 4348 (class 2606 OID 16535)
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4352 (class 2606 OID 17858)
-- Name: prefixes prefixes_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT "prefixes_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4349 (class 2606 OID 17804)
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4350 (class 2606 OID 17824)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4351 (class 2606 OID 17819)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- TOC entry 4602 (class 0 OID 16488)
-- Dependencies: 265
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4623 (class 0 OID 18161)
-- Dependencies: 313
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4614 (class 0 OID 17959)
-- Dependencies: 304
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4601 (class 0 OID 16481)
-- Dependencies: 264
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4618 (class 0 OID 18048)
-- Dependencies: 308
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4617 (class 0 OID 18036)
-- Dependencies: 307
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4616 (class 0 OID 18023)
-- Dependencies: 306
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4624 (class 0 OID 18211)
-- Dependencies: 314
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4600 (class 0 OID 16470)
-- Dependencies: 263
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4621 (class 0 OID 18090)
-- Dependencies: 311
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4622 (class 0 OID 18108)
-- Dependencies: 312
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4603 (class 0 OID 16496)
-- Dependencies: 266
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4615 (class 0 OID 17989)
-- Dependencies: 305
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4620 (class 0 OID 18075)
-- Dependencies: 310
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4619 (class 0 OID 18066)
-- Dependencies: 309
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4599 (class 0 OID 16458)
-- Dependencies: 261
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4723 (class 3256 OID 19055)
-- Name: medication_approvals Admins can manage all approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all approvals" ON public.medication_approvals USING ((auth.uid() IN ( SELECT a.profile_id
   FROM public.admins a
  WHERE (a.active = true))));


--
-- TOC entry 4656 (class 3256 OID 18395)
-- Name: patient_assignments Admins can manage all assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all assignments" ON public.patient_assignments USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4728 (class 3256 OID 19060)
-- Name: faxes Admins can manage all faxes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all faxes" ON public.faxes USING ((auth.uid() IN ( SELECT a.profile_id
   FROM public.admins a
  WHERE (a.active = true))));


--
-- TOC entry 4667 (class 3256 OID 18533)
-- Name: medication_orders Admins can manage all medication orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all medication orders" ON public.medication_orders USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4658 (class 3256 OID 18524)
-- Name: medications Admins can manage all medications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all medications" ON public.medications USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4735 (class 3256 OID 19253)
-- Name: patient_addresses Admins can manage all patient addresses; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all patient addresses" ON public.patient_addresses USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4648 (class 3256 OID 18387)
-- Name: patients Admins can manage all patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all patients" ON public.patients USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4651 (class 3256 OID 18390)
-- Name: providers Admins can manage all providers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all providers" ON public.providers USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4653 (class 3256 OID 18392)
-- Name: admins Admins can update own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can update own data" ON public.admins FOR UPDATE USING ((profile_id = auth.uid()));


--
-- TOC entry 4689 (class 3256 OID 18798)
-- Name: clinical_notes Admins can view all clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all clinical notes" ON public.clinical_notes FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))));


--
-- TOC entry 4665 (class 3256 OID 18531)
-- Name: medication_approvals Admins can view all medication approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all medication approvals" ON public.medication_approvals FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4661 (class 3256 OID 18527)
-- Name: patient_medication_preferences Admins can view all medication preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all medication preferences" ON public.patient_medication_preferences FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4644 (class 3256 OID 18383)
-- Name: profiles Admins can view all profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all profiles" ON public.profiles USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4707 (class 3256 OID 18923)
-- Name: visit_addendums Admins can view all visit addendums; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all visit addendums" ON public.visit_addendums FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))));


--
-- TOC entry 4692 (class 3256 OID 18803)
-- Name: visit_interactions Admins can view all visit interactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all visit interactions" ON public.visit_interactions FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))));


--
-- TOC entry 4652 (class 3256 OID 18391)
-- Name: admins Admins can view own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view own data" ON public.admins FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4704 (class 3256 OID 18854)
-- Name: auth_trigger_logs Allow admins to read logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow admins to read logs" ON public.auth_trigger_logs FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.profiles p
  WHERE ((p.id = auth.uid()) AND (p.role = 'admin'::text)))));


--
-- TOC entry 4700 (class 3256 OID 18835)
-- Name: profiles Allow auth trigger and service role; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow auth trigger and service role" ON public.profiles USING (true);


--
-- TOC entry 4702 (class 3256 OID 18837)
-- Name: provider_schedules Allow auth trigger and service role; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow auth trigger and service role" ON public.provider_schedules USING (true);


--
-- TOC entry 4701 (class 3256 OID 18836)
-- Name: providers Allow auth trigger and service role; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow auth trigger and service role" ON public.providers USING (true);


--
-- TOC entry 4703 (class 3256 OID 18853)
-- Name: auth_trigger_logs Allow trigger function to write logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow trigger function to write logs" ON public.auth_trigger_logs FOR INSERT WITH CHECK (true);


--
-- TOC entry 4657 (class 3256 OID 18523)
-- Name: medications Anyone can view active medications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can view active medications" ON public.medications FOR SELECT USING ((active = true));


--
-- TOC entry 4733 (class 3256 OID 19251)
-- Name: patient_addresses Patients can delete their own addresses; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can delete their own addresses" ON public.patient_addresses FOR DELETE USING ((patient_id IN ( SELECT patients.id
   FROM public.patients
  WHERE (patients.profile_id = auth.uid()))));


--
-- TOC entry 4731 (class 3256 OID 19249)
-- Name: patient_addresses Patients can insert their own addresses; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can insert their own addresses" ON public.patient_addresses FOR INSERT WITH CHECK ((patient_id IN ( SELECT patients.id
   FROM public.patients
  WHERE (patients.profile_id = auth.uid()))));


--
-- TOC entry 4659 (class 3256 OID 18525)
-- Name: patient_medication_preferences Patients can manage own medication preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can manage own medication preferences" ON public.patient_medication_preferences USING ((EXISTS ( SELECT 1
   FROM public.patients
  WHERE ((patients.profile_id = auth.uid()) AND (patients.id = patient_medication_preferences.patient_id)))));


--
-- TOC entry 4646 (class 3256 OID 18385)
-- Name: patients Patients can update own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can update own data" ON public.patients FOR UPDATE USING ((profile_id = auth.uid()));


--
-- TOC entry 4732 (class 3256 OID 19250)
-- Name: patient_addresses Patients can update their own addresses; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can update their own addresses" ON public.patient_addresses FOR UPDATE USING ((patient_id IN ( SELECT patients.id
   FROM public.patients
  WHERE (patients.profile_id = auth.uid()))));


--
-- TOC entry 4654 (class 3256 OID 18393)
-- Name: patient_assignments Patients can view own assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view own assignments" ON public.patient_assignments FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.patients
  WHERE ((patients.id = patient_assignments.patient_id) AND (patients.profile_id = auth.uid())))));


--
-- TOC entry 4645 (class 3256 OID 18384)
-- Name: patients Patients can view own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view own data" ON public.patients FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4664 (class 3256 OID 18530)
-- Name: medication_approvals Patients can view own medication approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view own medication approvals" ON public.medication_approvals FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patients pt
     JOIN public.patient_medication_preferences pmp ON ((pt.id = pmp.patient_id)))
  WHERE ((pt.profile_id = auth.uid()) AND (pmp.id = medication_approvals.preference_id)))));


--
-- TOC entry 4666 (class 3256 OID 18532)
-- Name: medication_orders Patients can view own medication orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view own medication orders" ON public.medication_orders FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.patients
  WHERE ((patients.profile_id = auth.uid()) AND (patients.id = medication_orders.patient_id)))));


--
-- TOC entry 4688 (class 3256 OID 18797)
-- Name: clinical_notes Patients can view their clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their clinical notes" ON public.clinical_notes FOR SELECT TO authenticated USING ((patient_id IN ( SELECT p.id
   FROM (public.patients p
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4730 (class 3256 OID 19248)
-- Name: patient_addresses Patients can view their own addresses; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their own addresses" ON public.patient_addresses FOR SELECT USING ((patient_id IN ( SELECT patients.id
   FROM public.patients
  WHERE (patients.profile_id = auth.uid()))));


--
-- TOC entry 4722 (class 3256 OID 19054)
-- Name: medication_approvals Patients can view their own approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their own approvals" ON public.medication_approvals FOR SELECT USING ((preference_id IN ( SELECT pmp.id
   FROM (public.patient_medication_preferences pmp
     JOIN public.patients pat ON ((pmp.patient_id = pat.id)))
  WHERE (pat.profile_id = auth.uid()))));


--
-- TOC entry 4932 (class 0 OID 0)
-- Dependencies: 4722
-- Name: POLICY "Patients can view their own approvals" ON medication_approvals; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Patients can view their own approvals" ON public.medication_approvals IS 'Allows patients to view approvals for their medication preferences';


--
-- TOC entry 4696 (class 3256 OID 18820)
-- Name: clinical_notes Patients can view their own clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their own clinical notes" ON public.clinical_notes FOR SELECT USING ((patient_id IN ( SELECT p.id
   FROM public.patients p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4727 (class 3256 OID 19059)
-- Name: faxes Patients can view their own faxes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their own faxes" ON public.faxes FOR SELECT USING ((patient_id IN ( SELECT pat.id
   FROM public.patients pat
  WHERE (pat.profile_id = auth.uid()))));


--
-- TOC entry 4933 (class 0 OID 0)
-- Dependencies: 4727
-- Name: POLICY "Patients can view their own faxes" ON faxes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Patients can view their own faxes" ON public.faxes IS 'Allows patients to view faxes related to their medications';


--
-- TOC entry 4699 (class 3256 OID 18825)
-- Name: visit_interactions Patients can view their own visit interactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their own visit interactions" ON public.visit_interactions FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4706 (class 3256 OID 18921)
-- Name: visit_addendums Patients can view their visit addendums; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their visit addendums" ON public.visit_addendums FOR SELECT TO authenticated USING ((visit_id IN ( SELECT a.id
   FROM ((public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4691 (class 3256 OID 18801)
-- Name: visit_interactions Patients can view their visit interactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their visit interactions" ON public.visit_interactions FOR SELECT TO authenticated USING ((appointment_id IN ( SELECT a.id
   FROM ((public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4720 (class 3256 OID 19051)
-- Name: medication_approvals Providers can create approvals for assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create approvals for assigned patients" ON public.medication_approvals FOR INSERT WITH CHECK (((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))) AND (preference_id IN ( SELECT pmp.id
   FROM ((public.patient_medication_preferences pmp
     JOIN public.patients pat ON ((pmp.patient_id = pat.id)))
     JOIN public.patient_assignments pa ON ((pat.id = pa.patient_id)))
  WHERE ((pa.provider_id IN ( SELECT p.id
           FROM public.providers p
          WHERE (p.profile_id = auth.uid()))) AND (pa.active = true))))));


--
-- TOC entry 4934 (class 0 OID 0)
-- Dependencies: 4720
-- Name: POLICY "Providers can create approvals for assigned patients" ON medication_approvals; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Providers can create approvals for assigned patients" ON public.medication_approvals IS 'Allows providers to create approvals only for patients assigned to them';


--
-- TOC entry 4694 (class 3256 OID 18818)
-- Name: clinical_notes Providers can create clinical notes for their patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create clinical notes for their patients" ON public.clinical_notes FOR INSERT WITH CHECK ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4725 (class 3256 OID 19057)
-- Name: faxes Providers can create faxes for assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create faxes for assigned patients" ON public.faxes FOR INSERT WITH CHECK (((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))) AND (patient_id IN ( SELECT pa.patient_id
   FROM public.patient_assignments pa
  WHERE ((pa.provider_id IN ( SELECT p.id
           FROM public.providers p
          WHERE (p.profile_id = auth.uid()))) AND (pa.active = true))))));


--
-- TOC entry 4935 (class 0 OID 0)
-- Dependencies: 4725
-- Name: POLICY "Providers can create faxes for assigned patients" ON faxes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Providers can create faxes for assigned patients" ON public.faxes IS 'Allows providers to create faxes only for patients assigned to them';


--
-- TOC entry 4669 (class 3256 OID 18544)
-- Name: medication_orders Providers can create orders for assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create orders for assigned patients" ON public.medication_orders FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = medication_orders.patient_id)))));


--
-- TOC entry 4698 (class 3256 OID 18823)
-- Name: visit_interactions Providers can create visit interactions for their appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create visit interactions for their appointments" ON public.visit_interactions FOR INSERT WITH CHECK ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.providers p ON ((a.provider_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4705 (class 3256 OID 18920)
-- Name: visit_addendums Providers can manage addendums for their patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can manage addendums for their patients" ON public.visit_addendums TO authenticated USING ((provider_id IN ( SELECT p.id
   FROM (public.providers p
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4662 (class 3256 OID 18528)
-- Name: medication_approvals Providers can manage approvals for assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can manage approvals for assigned patients" ON public.medication_approvals USING ((EXISTS ( SELECT 1
   FROM ((public.providers p
     JOIN public.patient_assignments pa ON ((p.id = pa.provider_id)))
     JOIN public.patient_medication_preferences pmp ON ((pa.patient_id = pmp.patient_id)))
  WHERE ((p.profile_id = auth.uid()) AND (pmp.id = medication_approvals.preference_id)))));


--
-- TOC entry 4687 (class 3256 OID 18796)
-- Name: clinical_notes Providers can manage clinical notes for their patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can manage clinical notes for their patients" ON public.clinical_notes TO authenticated USING ((provider_id IN ( SELECT p.id
   FROM (public.providers p
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4690 (class 3256 OID 18799)
-- Name: visit_interactions Providers can manage visit interactions for their patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can manage visit interactions for their patients" ON public.visit_interactions TO authenticated USING ((appointment_id IN ( SELECT a.id
   FROM ((public.appointments a
     JOIN public.providers p ON ((a.provider_id = p.id)))
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4670 (class 3256 OID 18545)
-- Name: medication_orders Providers can update assigned patient orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update assigned patient orders" ON public.medication_orders FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = medication_orders.patient_id)))));


--
-- TOC entry 4671 (class 3256 OID 18546)
-- Name: patient_medication_preferences Providers can update assigned patient preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update assigned patient preferences" ON public.patient_medication_preferences FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = patient_medication_preferences.patient_id)))));


--
-- TOC entry 4650 (class 3256 OID 18389)
-- Name: providers Providers can update own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update own data" ON public.providers FOR UPDATE USING ((profile_id = auth.uid()));


--
-- TOC entry 4721 (class 3256 OID 19053)
-- Name: medication_approvals Providers can update their own approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update their own approvals" ON public.medication_approvals FOR UPDATE USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4695 (class 3256 OID 18819)
-- Name: clinical_notes Providers can update their own clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update their own clinical notes" ON public.clinical_notes FOR UPDATE USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4726 (class 3256 OID 19058)
-- Name: faxes Providers can update their own faxes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update their own faxes" ON public.faxes FOR UPDATE USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4734 (class 3256 OID 19252)
-- Name: patient_addresses Providers can view assigned patient addresses; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view assigned patient addresses" ON public.patient_addresses FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((p.id = pa.provider_id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = patient_addresses.patient_id) AND (pa.active = true)))));


--
-- TOC entry 4668 (class 3256 OID 18534)
-- Name: medication_orders Providers can view assigned patient orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view assigned patient orders" ON public.medication_orders FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = medication_orders.patient_id)))));


--
-- TOC entry 4660 (class 3256 OID 18526)
-- Name: patient_medication_preferences Providers can view assigned patient preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view assigned patient preferences" ON public.patient_medication_preferences FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = patient_medication_preferences.patient_id)))));


--
-- TOC entry 4647 (class 3256 OID 18386)
-- Name: patients Providers can view assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view assigned patients" ON public.patients FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((p.id = pa.provider_id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = patients.id) AND (pa.active = true)))));


--
-- TOC entry 4649 (class 3256 OID 18388)
-- Name: providers Providers can view own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view own data" ON public.providers FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4655 (class 3256 OID 18394)
-- Name: patient_assignments Providers can view their assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their assignments" ON public.patient_assignments FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.providers
  WHERE ((providers.id = patient_assignments.provider_id) AND (providers.profile_id = auth.uid())))));


--
-- TOC entry 4719 (class 3256 OID 19050)
-- Name: medication_approvals Providers can view their own approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their own approvals" ON public.medication_approvals FOR SELECT USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4936 (class 0 OID 0)
-- Dependencies: 4719
-- Name: POLICY "Providers can view their own approvals" ON medication_approvals; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Providers can view their own approvals" ON public.medication_approvals IS 'Allows providers to view medication approvals they created';


--
-- TOC entry 4693 (class 3256 OID 18817)
-- Name: clinical_notes Providers can view their own clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their own clinical notes" ON public.clinical_notes FOR SELECT USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4724 (class 3256 OID 19056)
-- Name: faxes Providers can view their own faxes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their own faxes" ON public.faxes FOR SELECT USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4937 (class 0 OID 0)
-- Dependencies: 4724
-- Name: POLICY "Providers can view their own faxes" ON faxes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Providers can view their own faxes" ON public.faxes IS 'Allows providers to view faxes they sent';


--
-- TOC entry 4729 (class 3256 OID 19061)
-- Name: providers Providers can view their own record; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their own record" ON public.providers FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4938 (class 0 OID 0)
-- Dependencies: 4729
-- Name: POLICY "Providers can view their own record" ON providers; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Providers can view their own record" ON public.providers IS 'Allows providers to view their own provider record when authenticated';


--
-- TOC entry 4697 (class 3256 OID 18821)
-- Name: visit_interactions Providers can view their own visit interactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their own visit interactions" ON public.visit_interactions FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.providers p ON ((a.provider_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4713 (class 3256 OID 18985)
-- Name: admins Service role can manage admins; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage admins" ON public.admins USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = profile_id)));


--
-- TOC entry 4718 (class 3256 OID 18998)
-- Name: admins Service role can manage all admins; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage all admins" ON public.admins USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4716 (class 3256 OID 18996)
-- Name: patients Service role can manage all patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage all patients" ON public.patients USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4715 (class 3256 OID 18995)
-- Name: profiles Service role can manage all profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage all profiles" ON public.profiles USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4717 (class 3256 OID 18997)
-- Name: providers Service role can manage all providers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage all providers" ON public.providers USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4711 (class 3256 OID 18983)
-- Name: patients Service role can manage patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage patients" ON public.patients USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = profile_id)));


--
-- TOC entry 4709 (class 3256 OID 18981)
-- Name: profiles Service role can manage profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage profiles" ON public.profiles USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = id)));


--
-- TOC entry 4712 (class 3256 OID 18984)
-- Name: providers Service role can manage providers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage providers" ON public.providers USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = profile_id)));


--
-- TOC entry 4714 (class 3256 OID 18986)
-- Name: provider_schedules Service role can manage schedules; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage schedules" ON public.provider_schedules USING ((current_setting('role'::text) = 'service_role'::text));


--
-- TOC entry 4708 (class 3256 OID 18975)
-- Name: profiles Users can update own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING ((auth.uid() = id));


--
-- TOC entry 4710 (class 3256 OID 18982)
-- Name: profiles Users can view own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING ((auth.uid() = id));


--
-- TOC entry 4683 (class 3256 OID 18681)
-- Name: appointments admin_full_appointments_access; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_full_appointments_access ON public.appointments USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4939 (class 0 OID 0)
-- Dependencies: 4683
-- Name: POLICY admin_full_appointments_access ON appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY admin_full_appointments_access ON public.appointments IS 'Admins have full access to all appointment data';


--
-- TOC entry 4685 (class 3256 OID 18686)
-- Name: appointment_history admin_view_all_appointment_history; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_view_all_appointment_history ON public.appointment_history USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4677 (class 3256 OID 18674)
-- Name: provider_availability_overrides admin_view_all_overrides; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_view_all_overrides ON public.provider_availability_overrides USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4663 (class 3256 OID 18670)
-- Name: provider_schedules admin_view_all_schedules; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_view_all_schedules ON public.provider_schedules USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4628 (class 0 OID 18320)
-- Dependencies: 320
-- Name: admins; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.admins ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4686 (class 3256 OID 18687)
-- Name: appointment_history appointment_history_readonly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY appointment_history_readonly ON public.appointment_history FOR INSERT WITH CHECK (false);


--
-- TOC entry 4940 (class 0 OID 0)
-- Dependencies: 4686
-- Name: POLICY appointment_history_readonly ON appointment_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY appointment_history_readonly ON public.appointment_history IS 'History is maintained by system triggers only';


--
-- TOC entry 4637 (class 0 OID 18839)
-- Dependencies: 337
-- Name: auth_trigger_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.auth_trigger_logs ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4635 (class 0 OID 18702)
-- Dependencies: 334
-- Name: clinical_notes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.clinical_notes ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4640 (class 0 OID 19001)
-- Dependencies: 341
-- Name: faxes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.faxes ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4631 (class 0 OID 18455)
-- Dependencies: 326
-- Name: medication_approvals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medication_approvals ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4638 (class 0 OID 18867)
-- Dependencies: 338
-- Name: medication_dosages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medication_dosages ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4632 (class 0 OID 18476)
-- Dependencies: 327
-- Name: medication_orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medication_orders ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4642 (class 0 OID 19258)
-- Dependencies: 344
-- Name: medication_tracking_entries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medication_tracking_entries ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4629 (class 0 OID 18418)
-- Dependencies: 324
-- Name: medications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medications ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4641 (class 0 OID 19221)
-- Dependencies: 343
-- Name: patient_addresses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.patient_addresses ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4679 (class 3256 OID 18676)
-- Name: appointments patient_booking_restrictions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_booking_restrictions ON public.appointments FOR INSERT WITH CHECK (((patient_id IN ( SELECT p.id
   FROM public.patients p
  WHERE (p.profile_id = auth.uid()))) AND (provider_id IN ( SELECT pa.provider_id
   FROM (public.patient_assignments pa
     JOIN public.patients p ON ((pa.patient_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.active = true)))) AND ((appointment_date > CURRENT_DATE) OR ((appointment_date = CURRENT_DATE) AND (start_time > LOCALTIME))) AND (appointment_date <= (CURRENT_DATE + '90 days'::interval)) AND (booked_by = 'patient'::text)));


--
-- TOC entry 4941 (class 0 OID 0)
-- Dependencies: 4679
-- Name: POLICY patient_booking_restrictions ON appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY patient_booking_restrictions ON public.appointments IS 'Enforces business rules for patient appointment booking';


--
-- TOC entry 4643 (class 0 OID 19266)
-- Dependencies: 345
-- Name: patient_health_metrics; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.patient_health_metrics ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4630 (class 0 OID 18431)
-- Dependencies: 325
-- Name: patient_medication_preferences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.patient_medication_preferences ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4680 (class 3256 OID 18678)
-- Name: appointments patient_no_delete_appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_no_delete_appointments ON public.appointments FOR DELETE USING (false);


--
-- TOC entry 4678 (class 3256 OID 18675)
-- Name: appointments patient_own_appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_own_appointments ON public.appointments USING ((patient_id IN ( SELECT p.id
   FROM public.patients p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4942 (class 0 OID 0)
-- Dependencies: 4678
-- Name: POLICY patient_own_appointments ON appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY patient_own_appointments ON public.appointments IS 'Patients can only access their own appointments';


--
-- TOC entry 4684 (class 3256 OID 18682)
-- Name: appointment_history patient_view_own_appointment_history; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_view_own_appointment_history ON public.appointment_history FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4676 (class 3256 OID 18672)
-- Name: provider_availability_overrides patient_view_provider_overrides; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_view_provider_overrides ON public.provider_availability_overrides FOR SELECT USING ((provider_id IN ( SELECT pa.provider_id
   FROM (public.patient_assignments pa
     JOIN public.patients p ON ((pa.patient_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.active = true)))));


--
-- TOC entry 4673 (class 3256 OID 18668)
-- Name: provider_schedules patient_view_provider_schedules; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_view_provider_schedules ON public.provider_schedules FOR SELECT USING ((provider_id IN ( SELECT pa.provider_id
   FROM (public.patient_assignments pa
     JOIN public.patients p ON ((pa.patient_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.active = true)))));


--
-- TOC entry 4626 (class 0 OID 18284)
-- Dependencies: 318
-- Name: patients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4625 (class 0 OID 18267)
-- Dependencies: 317
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4634 (class 0 OID 18570)
-- Dependencies: 329
-- Name: provider_availability_overrides; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.provider_availability_overrides ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4682 (class 3256 OID 18680)
-- Name: appointments provider_no_delete_appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_no_delete_appointments ON public.appointments FOR DELETE USING (false);


--
-- TOC entry 4681 (class 3256 OID 18679)
-- Name: appointments provider_own_appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_own_appointments ON public.appointments USING ((provider_id IN ( SELECT pr.id
   FROM public.providers pr
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4943 (class 0 OID 0)
-- Dependencies: 4681
-- Name: POLICY provider_own_appointments ON appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY provider_own_appointments ON public.appointments IS 'Providers can manage appointments with their patients';


--
-- TOC entry 4675 (class 3256 OID 18671)
-- Name: provider_availability_overrides provider_own_overrides_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_own_overrides_policy ON public.provider_availability_overrides USING ((provider_id IN ( SELECT pr.id
   FROM public.providers pr
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4672 (class 3256 OID 18667)
-- Name: provider_schedules provider_own_schedule_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_own_schedule_policy ON public.provider_schedules USING ((provider_id IN ( SELECT pr.id
   FROM public.providers pr
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4633 (class 0 OID 18547)
-- Dependencies: 328
-- Name: provider_schedules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.provider_schedules ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4674 (class 3256 OID 18684)
-- Name: appointment_history provider_view_appointment_history; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_view_appointment_history ON public.appointment_history FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.providers pr ON ((a.provider_id = pr.id)))
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4627 (class 0 OID 18302)
-- Dependencies: 319
-- Name: providers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4639 (class 0 OID 18897)
-- Dependencies: 339
-- Name: visit_addendums; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.visit_addendums ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4636 (class 0 OID 18760)
-- Dependencies: 336
-- Name: visit_interactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.visit_interactions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4607 (class 0 OID 17007)
-- Dependencies: 292
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4604 (class 0 OID 16509)
-- Dependencies: 267
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4611 (class 0 OID 17892)
-- Dependencies: 301
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4612 (class 0 OID 17903)
-- Dependencies: 302
-- Name: iceberg_namespaces; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.iceberg_namespaces ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4613 (class 0 OID 17919)
-- Dependencies: 303
-- Name: iceberg_tables; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.iceberg_tables ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4606 (class 0 OID 16551)
-- Dependencies: 269
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4605 (class 0 OID 16524)
-- Dependencies: 268
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4610 (class 0 OID 17848)
-- Dependencies: 300
-- Name: prefixes; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.prefixes ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4608 (class 0 OID 17795)
-- Dependencies: 298
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4609 (class 0 OID 17809)
-- Dependencies: 299
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

-- Completed on 2025-10-14 08:52:12 UTC

--
-- PostgreSQL database dump complete
--

