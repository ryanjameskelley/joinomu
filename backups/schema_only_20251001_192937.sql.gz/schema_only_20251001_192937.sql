--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-10-02 02:29:38 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 27 (class 2615 OID 16457)
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO supabase_admin;

--
-- TOC entry 18 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- TOC entry 4458 (class 0 OID 0)
-- Dependencies: 18
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- TOC entry 1211 (class 1247 OID 18016)
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE auth.aal_level OWNER TO supabase_auth_admin;

--
-- TOC entry 1235 (class 1247 OID 18157)
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


ALTER TYPE auth.code_challenge_method OWNER TO supabase_auth_admin;

--
-- TOC entry 1208 (class 1247 OID 18010)
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE auth.factor_status OWNER TO supabase_auth_admin;

--
-- TOC entry 1205 (class 1247 OID 18005)
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE auth.factor_type OWNER TO supabase_auth_admin;

--
-- TOC entry 1247 (class 1247 OID 18238)
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE auth.oauth_registration_type OWNER TO supabase_auth_admin;

--
-- TOC entry 1241 (class 1247 OID 18199)
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE auth.one_time_token_type OWNER TO supabase_auth_admin;

--
-- TOC entry 489 (class 1255 OID 16503)
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION auth.email() OWNER TO supabase_auth_admin;

--
-- TOC entry 4460 (class 0 OID 0)
-- Dependencies: 489
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- TOC entry 364 (class 1255 OID 17987)
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION auth.jwt() OWNER TO supabase_auth_admin;

--
-- TOC entry 410 (class 1255 OID 16502)
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION auth.role() OWNER TO supabase_auth_admin;

--
-- TOC entry 4463 (class 0 OID 0)
-- Dependencies: 410
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- TOC entry 408 (class 1255 OID 16501)
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION auth.uid() OWNER TO supabase_auth_admin;

--
-- TOC entry 4465 (class 0 OID 0)
-- Dependencies: 408
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- TOC entry 375 (class 1255 OID 18407)
-- Name: assign_patient_to_provider(uuid, uuid, text, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.assign_patient_to_provider(patient_profile_id uuid, provider_profile_id uuid, treatment_type_param text DEFAULT 'general_care'::text, is_primary_param boolean DEFAULT false) RETURNS TABLE(success boolean, message text, assignment_id uuid)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  patient_id_var UUID;
  provider_id_var UUID;
  assignment_id_var UUID;
BEGIN
  -- Get the patient ID from profile ID
  SELECT id INTO patient_id_var
  FROM patients
  WHERE profile_id = patient_profile_id;
  
  IF patient_id_var IS NULL THEN
    RETURN QUERY SELECT false, 'Patient not found', NULL::UUID;
    RETURN;
  END IF;
  
  -- Get the provider ID from profile ID
  SELECT id INTO provider_id_var
  FROM providers
  WHERE profile_id = provider_profile_id AND active = true;
  
  IF provider_id_var IS NULL THEN
    RETURN QUERY SELECT false, 'Provider not found or inactive', NULL::UUID;
    RETURN;
  END IF;
  
  -- Check if assignment already exists
  IF EXISTS (
    SELECT 1 FROM patient_assignments 
    WHERE patient_id = patient_id_var 
    AND provider_id = provider_id_var
    AND treatment_type = treatment_type_param
  ) THEN
    RETURN QUERY SELECT false, 'Patient is already assigned to this provider for this treatment type', NULL::UUID;
    RETURN;
  END IF;
  
  -- Create the assignment
  INSERT INTO patient_assignments (
    patient_id,
    provider_id,
    treatment_type,
    is_primary,
    assigned_date
  ) VALUES (
    patient_id_var,
    provider_id_var,
    treatment_type_param,
    is_primary_param,
    CURRENT_DATE
  ) RETURNING id INTO assignment_id_var;
  
  RETURN QUERY SELECT true, 'Patient successfully assigned to provider', assignment_id_var;
END;
$$;


ALTER FUNCTION public.assign_patient_to_provider(patient_profile_id uuid, provider_profile_id uuid, treatment_type_param text, is_primary_param boolean) OWNER TO postgres;

--
-- TOC entry 350 (class 1255 OID 18660)
-- Name: book_appointment(uuid, uuid, date, time without time zone, text, text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text DEFAULT 'consultation'::text, p_booked_by text DEFAULT 'patient'::text, p_patient_notes text DEFAULT NULL::text) RETURNS TABLE(success boolean, appointment_id uuid, message text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  v_patient_id UUID;
  v_assignment_id UUID;
  v_duration_minutes INTEGER;
  v_end_time TIME;
  v_new_appointment_id UUID;
BEGIN
  -- Get patient ID from profile ID
  SELECT p.id INTO v_patient_id
  FROM patients p
  WHERE p.profile_id = p_patient_profile_id;
  
  IF v_patient_id IS NULL THEN
    success := false;
    appointment_id := NULL;
    message := 'Patient not found';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Verify patient-provider relationship exists
  SELECT pa.id INTO v_assignment_id
  FROM patient_assignments pa
  WHERE pa.patient_id = v_patient_id
    AND pa.provider_id = p_provider_id
    AND pa.active = true
  LIMIT 1;
  
  IF v_assignment_id IS NULL THEN
    success := false;
    appointment_id := NULL;
    message := 'No active assignment between patient and provider';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Check if the requested slot is available
  SELECT ps.slot_duration_minutes INTO v_duration_minutes
  FROM provider_schedules ps
  WHERE ps.provider_id = p_provider_id
    AND ps.day_of_week = EXTRACT(DOW FROM p_appointment_date)
    AND ps.start_time <= p_start_time
    AND ps.end_time >= p_start_time + INTERVAL '30 minutes' -- minimum slot
    AND ps.active = true
    AND (p_treatment_type = ANY(ps.treatment_types) OR array_length(ps.treatment_types, 1) IS NULL)
  LIMIT 1;
  
  IF v_duration_minutes IS NULL THEN
    success := false;
    appointment_id := NULL;
    message := 'Provider not available at requested time';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Calculate end time
  v_end_time := p_start_time + INTERVAL '1 minute' * v_duration_minutes;
  
  -- Check for scheduling conflicts
  IF EXISTS (
    SELECT 1 FROM appointments a
    WHERE a.provider_id = p_provider_id
      AND a.appointment_date = p_appointment_date
      AND a.start_time = p_start_time
      AND a.status NOT IN ('cancelled', 'no_show')
  ) THEN
    success := false;
    appointment_id := NULL;
    message := 'Time slot already booked';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Check for availability overrides
  IF EXISTS (
    SELECT 1 FROM provider_availability_overrides pao
    WHERE pao.provider_id = p_provider_id
      AND pao.date = p_appointment_date
      AND pao.available = false
      AND (pao.start_time IS NULL OR p_start_time >= pao.start_time)
      AND (pao.end_time IS NULL OR v_end_time <= pao.end_time)
  ) THEN
    success := false;
    appointment_id := NULL;
    message := 'Provider not available on requested date';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Create the appointment
  INSERT INTO appointments (
    patient_id,
    provider_id,
    assignment_id,
    appointment_date,
    start_time,
    end_time,
    duration_minutes,
    treatment_type,
    appointment_type,
    status,
    patient_notes,
    booked_by,
    booked_by_user_id
  ) VALUES (
    v_patient_id,
    p_provider_id,
    v_assignment_id,
    p_appointment_date,
    p_start_time,
    v_end_time,
    v_duration_minutes,
    p_treatment_type,
    p_appointment_type,
    'scheduled',
    p_patient_notes,
    p_booked_by,
    p_patient_profile_id
  ) RETURNING id INTO v_new_appointment_id;
  
  -- Return success
  success := true;
  appointment_id := v_new_appointment_id;
  message := 'Appointment booked successfully';
  RETURN NEXT;
  RETURN;
  
EXCEPTION
  WHEN OTHERS THEN
    success := false;
    appointment_id := NULL;
    message := 'Error booking appointment: ' || SQLERRM;
    RETURN NEXT;
    RETURN;
END;
$$;


ALTER FUNCTION public.book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text, p_booked_by text, p_patient_notes text) OWNER TO postgres;

--
-- TOC entry 4468 (class 0 OID 0)
-- Dependencies: 350
-- Name: FUNCTION book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text, p_booked_by text, p_patient_notes text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text, p_booked_by text, p_patient_notes text) IS 'Books a new appointment with full validation';


--
-- TOC entry 407 (class 1255 OID 19137)
-- Name: calculate_next_prescription_due(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calculate_next_prescription_due() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_fax_date DATE;
    v_calculated_due_date DATE;
BEGIN
    -- Only proceed if supply_days was added/changed and we have an approved status
    IF NEW.supply_days IS NOT NULL 
       AND NEW.supply_days > 0 
       AND NEW.status = 'approved'
       AND (OLD.supply_days IS NULL OR OLD.supply_days != NEW.supply_days OR OLD.status != 'approved') THEN
        
        -- Use the faxed date from the preference itself
        IF NEW.faxed IS NOT NULL THEN
            v_fax_date := NEW.faxed::date;
            v_calculated_due_date := v_fax_date + NEW.supply_days;
            
            -- Update the next_prescription_due field
            NEW.next_prescription_due := v_calculated_due_date;
            
            -- Log the calculation for debugging (if logging table exists)
            BEGIN
                INSERT INTO auth_trigger_logs (
                    step, 
                    status, 
                    message, 
                    metadata
                ) VALUES (
                    'SUPPLY_CALCULATION', 
                    'SUCCESS', 
                    'Calculated next prescription due from preference update',
                    jsonb_build_object(
                        'preference_id', NEW.id,
                        'fax_date', v_fax_date,
                        'supply_days', NEW.supply_days,
                        'calculated_due_date', v_calculated_due_date
                    )
                );
            EXCEPTION WHEN OTHERS THEN
                -- Ignore logging errors, don't fail the main operation
                NULL;
            END;
        ELSE
            -- If no fax date, set the faxed date to now when approving with supply
            NEW.faxed := NOW();
            v_fax_date := NEW.faxed::date;
            v_calculated_due_date := v_fax_date + NEW.supply_days;
            NEW.next_prescription_due := v_calculated_due_date;
            
            -- Log that we set the fax date
            BEGIN
                INSERT INTO auth_trigger_logs (
                    step, 
                    status, 
                    message, 
                    metadata
                ) VALUES (
                    'SUPPLY_CALCULATION', 
                    'SUCCESS', 
                    'Set fax date to now and calculated next prescription due',
                    jsonb_build_object(
                        'preference_id', NEW.id,
                        'fax_date', v_fax_date,
                        'supply_days', NEW.supply_days,
                        'calculated_due_date', v_calculated_due_date
                    )
                );
            EXCEPTION WHEN OTHERS THEN
                -- Ignore logging errors, don't fail the main operation
                NULL;
            END;
        END IF;
    END IF;
    
    -- Reset refill_requested flag when status changes to approved
    IF NEW.status = 'approved' AND OLD.status != 'approved' THEN
        NEW.refill_requested := FALSE;
    END IF;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.calculate_next_prescription_due() OWNER TO postgres;

--
-- TOC entry 4470 (class 0 OID 0)
-- Dependencies: 407
-- Name: FUNCTION calculate_next_prescription_due(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.calculate_next_prescription_due() IS 'Calculates next_prescription_due when supply_days is updated with approved status, and resets refill_requested flag on approval';


--
-- TOC entry 435 (class 1255 OID 19066)
-- Name: calculate_next_prescription_due(uuid, date, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calculate_next_prescription_due(p_preference_id uuid, p_delivery_date date, p_frequency text DEFAULT NULL::text) RETURNS date
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_supply_days INTEGER;
    v_frequency TEXT;
    v_next_due_date DATE;
BEGIN
    -- Get supply_days and frequency from the preference
    SELECT supply_days, frequency 
    INTO v_supply_days, v_frequency
    FROM patient_medication_preferences 
    WHERE id = p_preference_id;
    
    -- Use provided frequency if given, otherwise use the preference frequency
    IF p_frequency IS NOT NULL THEN
        v_frequency := p_frequency;
    END IF;
    
    -- If supply_days is set, use it directly
    IF v_supply_days IS NOT NULL AND v_supply_days > 0 THEN
        v_next_due_date := p_delivery_date + v_supply_days;
    ELSE
        -- Fall back to frequency-based calculation
        CASE 
            WHEN v_frequency = 'daily' THEN
                v_next_due_date := p_delivery_date + INTERVAL '30 days';
            WHEN v_frequency = 'weekly' THEN
                v_next_due_date := p_delivery_date + INTERVAL '12 weeks';
            WHEN v_frequency = 'monthly' THEN
                v_next_due_date := p_delivery_date + INTERVAL '3 months';
            WHEN v_frequency = 'quarterly' THEN
                v_next_due_date := p_delivery_date + INTERVAL '3 months';
            ELSE
                -- Default to 30 days if frequency not recognized
                v_next_due_date := p_delivery_date + INTERVAL '30 days';
        END CASE;
    END IF;
    
    RETURN v_next_due_date;
END;
$$;


ALTER FUNCTION public.calculate_next_prescription_due(p_preference_id uuid, p_delivery_date date, p_frequency text) OWNER TO postgres;

--
-- TOC entry 4472 (class 0 OID 0)
-- Dependencies: 435
-- Name: FUNCTION calculate_next_prescription_due(p_preference_id uuid, p_delivery_date date, p_frequency text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.calculate_next_prescription_due(p_preference_id uuid, p_delivery_date date, p_frequency text) IS 'Calculate next prescription due date using supply_days from preferences if available, otherwise fall back to frequency-based calculation';


--
-- TOC entry 434 (class 1255 OID 18662)
-- Name: cancel_appointment(uuid, text, uuid, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text) RETURNS TABLE(success boolean, message text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  v_appointment RECORD;
BEGIN
  -- Get appointment details
  SELECT * INTO v_appointment
  FROM appointments
  WHERE id = p_appointment_id;
  
  IF NOT FOUND THEN
    success := false;
    message := 'Appointment not found';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Check if appointment can be cancelled
  IF v_appointment.status NOT IN ('scheduled', 'confirmed') THEN
    success := false;
    message := 'Appointment cannot be cancelled in current status: ' || v_appointment.status;
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Update appointment status
  UPDATE appointments
  SET 
    status = 'cancelled',
    cancelled_at = NOW(),
    cancelled_by = p_cancelled_by,
    cancelled_by_user_id = p_cancelled_by_user_id,
    cancellation_reason = p_cancellation_reason
  WHERE id = p_appointment_id;
  
  success := true;
  message := 'Appointment cancelled successfully';
  RETURN NEXT;
  RETURN;
  
EXCEPTION
  WHEN OTHERS THEN
    success := false;
    message := 'Error cancelling appointment: ' || SQLERRM;
    RETURN NEXT;
    RETURN;
END;
$$;


ALTER FUNCTION public.cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text) OWNER TO postgres;

--
-- TOC entry 4474 (class 0 OID 0)
-- Dependencies: 434
-- Name: FUNCTION cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text) IS 'Cancels an existing appointment with audit trail';


--
-- TOC entry 480 (class 1255 OID 19125)
-- Name: check_approval_expiry_on_delivery(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.check_approval_expiry_on_delivery() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only proceed if fulfillment status changed to 'delivered' and estimated_delivery is set
    IF OLD.fulfillment_status != 'delivered' AND NEW.fulfillment_status = 'delivered' AND NEW.estimated_delivery IS NOT NULL THEN
        -- Check if this specific preference should be reset due to expiry
        UPDATE public.patient_medication_preferences 
        SET 
            status = 'pending',
            updated_at = NOW()
        FROM public.medication_approvals ma
        WHERE patient_medication_preferences.id = ma.preference_id
        AND ma.id = NEW.approval_id
        AND ma.status = 'approved'
        AND ma.supply_days IS NOT NULL
        AND (NEW.estimated_delivery::DATE + INTERVAL '1 day' * ma.supply_days) <= CURRENT_DATE;
        
        -- Also run the general daily check (but it will skip if already run today)
        PERFORM public.daily_approval_reset_check();
    END IF;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.check_approval_expiry_on_delivery() OWNER TO postgres;

--
-- TOC entry 4476 (class 0 OID 0)
-- Dependencies: 480
-- Name: FUNCTION check_approval_expiry_on_delivery(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.check_approval_expiry_on_delivery() IS 'Check preference expiry when orders are delivered and reset to pending status';


--
-- TOC entry 438 (class 1255 OID 18859)
-- Name: check_auth_trigger_health(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.check_auth_trigger_health() RETURNS TABLE(metric text, value integer, status text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    auth_users_count INTEGER;
    profiles_count INTEGER;
    providers_count INTEGER;
    schedules_count INTEGER;
    recent_failures INTEGER;
    missing_profiles INTEGER;
BEGIN
    -- Get counts
    SELECT COUNT(*) INTO auth_users_count FROM auth.users;
    SELECT COUNT(*) INTO profiles_count FROM public.profiles;
    SELECT COUNT(*) INTO providers_count FROM public.providers;
    SELECT COUNT(*) INTO schedules_count FROM public.provider_schedules;
    
    -- Check for missing profiles
    SELECT COUNT(*) INTO missing_profiles 
    FROM auth.users u 
    LEFT JOIN public.profiles p ON u.id = p.id 
    WHERE p.id IS NULL;
    
    -- Check recent failures
    SELECT COUNT(*) INTO recent_failures 
    FROM public.auth_trigger_logs 
    WHERE success = false 
    AND created_at > NOW() - INTERVAL '1 hour';
    
    -- Return metrics
    RETURN QUERY VALUES 
        ('auth_users', auth_users_count, CASE WHEN auth_users_count > 0 THEN 'OK' ELSE 'EMPTY' END),
        ('profiles', profiles_count, CASE WHEN profiles_count >= auth_users_count THEN 'OK' ELSE 'MISSING' END),
        ('providers', providers_count, 'INFO'),
        ('schedules', schedules_count, 'INFO'),
        ('missing_profiles', missing_profiles, CASE WHEN missing_profiles = 0 THEN 'OK' ELSE 'NEEDS_REPAIR' END),
        ('recent_failures', recent_failures, CASE WHEN recent_failures = 0 THEN 'OK' ELSE 'ATTENTION' END);
END;
$$;


ALTER FUNCTION public.check_auth_trigger_health() OWNER TO postgres;

--
-- TOC entry 487 (class 1255 OID 19069)
-- Name: clear_overdue_faxed_status(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.clear_overdue_faxed_status() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    rows_updated INTEGER;
BEGIN
    UPDATE public.patient_medication_preferences 
    SET faxed = NULL
    WHERE faxed IS NOT NULL 
    AND next_prescription_due IS NOT NULL 
    AND next_prescription_due <= CURRENT_DATE;
    
    GET DIAGNOSTICS rows_updated = ROW_COUNT;
    RETURN rows_updated;
END;
$$;


ALTER FUNCTION public.clear_overdue_faxed_status() OWNER TO postgres;

--
-- TOC entry 4479 (class 0 OID 0)
-- Dependencies: 487
-- Name: FUNCTION clear_overdue_faxed_status(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.clear_overdue_faxed_status() IS 'Clears faxed status for preferences where prescription is now due';


--
-- TOC entry 437 (class 1255 OID 18830)
-- Name: create_default_provider_schedule(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_default_provider_schedule() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RAISE LOG 'Provider schedule trigger fired for provider ID: %', NEW.id;
    RAISE NOTICE 'Provider schedule trigger fired for provider ID: %', NEW.id;
    
    -- Add Monday-Friday 9 AM to 5 PM schedule for new provider
    INSERT INTO provider_schedules (provider_id, day_of_week, start_time, end_time, active, created_at) VALUES
    (NEW.id, 1, '09:00:00', '17:00:00', true, now()), -- Monday
    (NEW.id, 2, '09:00:00', '17:00:00', true, now()), -- Tuesday
    (NEW.id, 3, '09:00:00', '17:00:00', true, now()), -- Wednesday
    (NEW.id, 4, '09:00:00', '17:00:00', true, now()), -- Thursday
    (NEW.id, 5, '09:00:00', '17:00:00', true, now()); -- Friday
    
    RAISE LOG 'Created default schedule for provider %', NEW.id;
    RAISE NOTICE 'Created default schedule for provider %', NEW.id;
    
    RETURN NEW;
EXCEPTION
    WHEN OTHERS THEN
        -- Log error but don't fail the provider creation
        RAISE LOG 'Error creating default schedule for provider %: %', NEW.id, SQLERRM;
        RAISE NOTICE 'Error creating default schedule for provider %: %', NEW.id, SQLERRM;
        RETURN NEW;
END;
$$;


ALTER FUNCTION public.create_default_provider_schedule() OWNER TO postgres;

--
-- TOC entry 458 (class 1255 OID 19071)
-- Name: create_order_on_fax(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_order_on_fax() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only create order when a fax is inserted
    IF TG_OP = 'INSERT' THEN
        -- Insert medication order using profile IDs directly
        INSERT INTO public.medication_orders (
            approval_id,
            medication_id,
            patient_id,
            provider_profile_id,
            patient_profile_id,
            quantity,
            unit_price,
            total_amount
        )
        SELECT 
            NEW.approval_id,
            pmp.medication_id,
            (SELECT pt.id FROM public.patients pt WHERE pt.profile_id = NEW.patient_profile_id LIMIT 1),
            NEW.provider_profile_id,
            NEW.patient_profile_id,
            1, -- Default quantity
            COALESCE(m.unit_price, 0.00), -- Get price from medications table
            COALESCE(m.unit_price, 0.00) * 1 -- Total = unit_price * quantity
        FROM public.medication_approvals ma
        JOIN public.patient_medication_preferences pmp ON ma.preference_id = pmp.id
        JOIN public.medications m ON pmp.medication_id = m.id
        WHERE ma.id = NEW.approval_id;
        
        RETURN NEW;
    END IF;
    
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.create_order_on_fax() OWNER TO postgres;

--
-- TOC entry 4482 (class 0 OID 0)
-- Dependencies: 458
-- Name: FUNCTION create_order_on_fax(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.create_order_on_fax() IS 'Creates medication order when prescription is faxed - uses profile IDs directly for simplicity';


--
-- TOC entry 420 (class 1255 OID 19124)
-- Name: daily_approval_reset_check(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.daily_approval_reset_check() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    last_run_date DATE;
    rows_reset INTEGER;
BEGIN
    -- Check when this was last run using correct column names
    SELECT (metadata->>'reset_date')::DATE 
    INTO last_run_date
    FROM public.auth_trigger_logs 
    WHERE trigger_stage = 'APPROVAL_RESET' 
    AND success = true
    ORDER BY created_at DESC 
    LIMIT 1;
    
    -- Only run if we haven't run today
    IF last_run_date IS NULL OR last_run_date < CURRENT_DATE THEN
        rows_reset := public.reset_expired_approvals();
        RETURN rows_reset;
    ELSE
        -- Log that we skipped because already ran today
        INSERT INTO public.auth_trigger_logs (trigger_stage, success, error_message, metadata, created_at)
        VALUES (
            'APPROVAL_RESET_SKIPPED', 
            true, 
            'Skipped approval reset - already ran today',
            jsonb_build_object('last_run_date', last_run_date, 'current_date', CURRENT_DATE),
            NOW()
        );
        RETURN 0;
    END IF;
END;
$$;


ALTER FUNCTION public.daily_approval_reset_check() OWNER TO postgres;

--
-- TOC entry 4484 (class 0 OID 0)
-- Dependencies: 420
-- Name: FUNCTION daily_approval_reset_check(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.daily_approval_reset_check() IS 'Daily check for expired approvals with duplicate run prevention (fixed to use trigger_stage and success columns)';


--
-- TOC entry 488 (class 1255 OID 19136)
-- Name: fix_existing_next_due_calculations(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fix_existing_next_due_calculations() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    preference_record RECORD;
    v_fax_date DATE;
    v_calculated_due_date DATE;
    v_updated_count INTEGER := 0;
BEGIN
    -- Loop through all preferences that have supply_days but no next_prescription_due
    FOR preference_record IN 
        SELECT id, supply_days, faxed
        FROM patient_medication_preferences 
        WHERE supply_days IS NOT NULL 
          AND supply_days > 0 
          AND (next_prescription_due IS NULL OR next_prescription_due < CURRENT_DATE)
          AND faxed IS NOT NULL
    LOOP
        -- Use the faxed date from the preference
        v_fax_date := preference_record.faxed::date;
        
        -- Calculate and update
        IF v_fax_date IS NOT NULL THEN
            v_calculated_due_date := v_fax_date + preference_record.supply_days;
            
            UPDATE patient_medication_preferences 
            SET 
                next_prescription_due = v_calculated_due_date,
                updated_at = NOW()
            WHERE id = preference_record.id;
            
            v_updated_count := v_updated_count + 1;
        END IF;
    END LOOP;
    
    RETURN v_updated_count;
END;
$$;


ALTER FUNCTION public.fix_existing_next_due_calculations() OWNER TO postgres;

--
-- TOC entry 4486 (class 0 OID 0)
-- Dependencies: 488
-- Name: FUNCTION fix_existing_next_due_calculations(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.fix_existing_next_due_calculations() IS 'Fixes next_prescription_due for preferences with supply_days based on preference.faxed field';


--
-- TOC entry 326 (class 1255 OID 18663)
-- Name: get_admin_appointment_overview(date, date, uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_admin_appointment_overview(p_date_range_start date DEFAULT CURRENT_DATE, p_date_range_end date DEFAULT (CURRENT_DATE + '7 days'::interval), p_provider_id uuid DEFAULT NULL::uuid, p_patient_id uuid DEFAULT NULL::uuid) RETURNS TABLE(appointment_id uuid, patient_name text, provider_name text, appointment_date date, start_time time without time zone, end_time time without time zone, treatment_type text, appointment_type text, status text, last_updated timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    a.id as appointment_id,
    (patient_prof.first_name || ' ' || patient_prof.last_name) as patient_name,
    (provider_prof.first_name || ' ' || provider_prof.last_name) as provider_name,
    a.appointment_date,
    a.start_time,
    a.end_time,
    a.treatment_type,
    a.appointment_type,
    a.status,
    a.updated_at as last_updated
  FROM appointments a
  INNER JOIN patients p ON a.patient_id = p.id
  INNER JOIN profiles patient_prof ON p.profile_id = patient_prof.id
  INNER JOIN providers prov ON a.provider_id = prov.id
  INNER JOIN profiles provider_prof ON prov.profile_id = provider_prof.id
  WHERE a.appointment_date >= p_date_range_start
    AND a.appointment_date <= p_date_range_end
    AND (p_provider_id IS NULL OR a.provider_id = p_provider_id)
    AND (p_patient_id IS NULL OR a.patient_id = p_patient_id)
  ORDER BY a.appointment_date ASC, a.start_time ASC;
END;
$$;


ALTER FUNCTION public.get_admin_appointment_overview(p_date_range_start date, p_date_range_end date, p_provider_id uuid, p_patient_id uuid) OWNER TO postgres;

--
-- TOC entry 4488 (class 0 OID 0)
-- Dependencies: 326
-- Name: FUNCTION get_admin_appointment_overview(p_date_range_start date, p_date_range_end date, p_provider_id uuid, p_patient_id uuid); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.get_admin_appointment_overview(p_date_range_start date, p_date_range_end date, p_provider_id uuid, p_patient_id uuid) IS 'Admin dashboard view of appointments with filtering';


--
-- TOC entry 452 (class 1255 OID 18537)
-- Name: get_admin_fulfillment_queue(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_admin_fulfillment_queue() RETURNS TABLE(order_id uuid, patient_name text, medication_name text, quantity integer, total_amount numeric, payment_status text, fulfillment_status text, order_date timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    mo.id,
    CONCAT(pr.first_name, ' ', pr.last_name),
    m.name,
    mo.quantity,
    mo.total_amount,
    mo.payment_status,
    mo.fulfillment_status,
    mo.created_at
  FROM medication_orders mo
  JOIN medications m ON mo.medication_id = m.id
  JOIN patients pt ON mo.patient_id = pt.id
  JOIN profiles pr ON pt.profile_id = pr.id
  WHERE mo.fulfillment_status IN ('pending', 'processing')
  ORDER BY 
    CASE mo.payment_status 
      WHEN 'paid' THEN 1 
      ELSE 2 
    END,
    mo.created_at ASC;
END;
$$;


ALTER FUNCTION public.get_admin_fulfillment_queue() OWNER TO postgres;

--
-- TOC entry 456 (class 1255 OID 18542)
-- Name: get_all_patients_for_admin(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_all_patients_for_admin() RETURNS TABLE(patient_id uuid, profile_id uuid, first_name text, last_name text, email text, phone text, date_of_birth date, has_completed_intake boolean, assigned_providers text[], treatment_types text[], medications text[], created_at timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id as patient_id,
    p.profile_id,
    prof.first_name,
    prof.last_name,
    prof.email,
    p.phone,
    p.date_of_birth,
    p.has_completed_intake,
    COALESCE(
      ARRAY_AGG(
        DISTINCT CONCAT(prov_prof.first_name, ' ', prov_prof.last_name)
      ) FILTER (WHERE pa.id IS NOT NULL),
      '{}'::TEXT[]
    ) as assigned_providers,
    COALESCE(
      ARRAY_AGG(DISTINCT pa.treatment_type) FILTER (WHERE pa.treatment_type IS NOT NULL),
      '{}'::TEXT[]
    ) as treatment_types,
    COALESCE(
      ARRAY_AGG(DISTINCT m.name) FILTER (WHERE m.name IS NOT NULL),
      '{}'::TEXT[]
    ) as medications,
    p.created_at
  FROM patients p
  INNER JOIN profiles prof ON p.profile_id = prof.id
  LEFT JOIN patient_assignments pa ON p.profile_id = pa.patient_id
  LEFT JOIN providers prov ON pa.provider_id = prov.id
  LEFT JOIN profiles prov_prof ON prov.profile_id = prov_prof.id
  LEFT JOIN patient_medication_preferences pmp ON p.id = pmp.patient_id
  LEFT JOIN medications m ON pmp.medication_id = m.id
  WHERE prof.role = 'patient'  -- Only include users with patient role
  GROUP BY p.id, p.profile_id, prof.first_name, prof.last_name, prof.email, p.phone, p.date_of_birth, p.has_completed_intake, p.created_at
  ORDER BY prof.first_name, prof.last_name;
END;
$$;


ALTER FUNCTION public.get_all_patients_for_admin() OWNER TO postgres;

--
-- TOC entry 324 (class 1255 OID 19117)
-- Name: get_approvals_due_for_renewal(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_approvals_due_for_renewal() RETURNS TABLE(approval_id uuid, patient_name text, medication_name text, supply_days integer, estimated_delivery date, days_since_delivery integer, expires_on date)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        ma.id as approval_id,
        (p.first_name || ' ' || p.last_name) as patient_name,
        m.name as medication_name,
        ma.supply_days,
        mo.estimated_delivery::DATE as estimated_delivery,
        (CURRENT_DATE - mo.estimated_delivery::DATE) as days_since_delivery,
        (mo.estimated_delivery::DATE + INTERVAL '1 day' * ma.supply_days)::DATE as expires_on
    FROM public.medication_approvals ma
    JOIN public.medication_orders mo ON ma.id = mo.approval_id
    JOIN public.patient_medication_preferences pmp ON ma.preference_id = pmp.id
    JOIN public.medications m ON pmp.medication_id = m.id
    JOIN public.patients pt ON pmp.patient_id = pt.id
    JOIN public.profiles p ON pt.profile_id = p.id
    WHERE ma.status = 'approved'
    AND ma.supply_days IS NOT NULL
    AND mo.estimated_delivery IS NOT NULL
    AND mo.fulfillment_status = 'delivered'
    AND (mo.estimated_delivery::DATE + INTERVAL '1 day' * ma.supply_days) <= CURRENT_DATE;
END;
$$;


ALTER FUNCTION public.get_approvals_due_for_renewal() OWNER TO postgres;

--
-- TOC entry 4492 (class 0 OID 0)
-- Dependencies: 324
-- Name: FUNCTION get_approvals_due_for_renewal(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.get_approvals_due_for_renewal() IS 'Returns list of approvals that are due for renewal based on supply expiry';


--
-- TOC entry 397 (class 1255 OID 18543)
-- Name: get_assigned_patients_for_provider(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_assigned_patients_for_provider(provider_profile_id uuid) RETURNS TABLE(patient_id uuid, profile_id uuid, first_name text, last_name text, email text, phone text, date_of_birth date, treatment_type text, assigned_date date, is_primary boolean, has_completed_intake boolean, created_at timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id as patient_id,
    p.profile_id,
    prof.first_name,
    prof.last_name,
    prof.email,
    p.phone,
    p.date_of_birth,
    pa.treatment_type,
    pa.assigned_date::DATE,
    pa.is_primary,
    p.has_completed_intake,
    p.created_at
  FROM patients p
  INNER JOIN profiles prof ON p.profile_id = prof.id
  INNER JOIN patient_assignments pa ON p.id = pa.patient_id  -- Fixed: was p.profile_id = pa.patient_id
  INNER JOIN providers prov ON pa.provider_id = prov.id
  WHERE prov.profile_id = provider_profile_id
  ORDER BY pa.assigned_date DESC, prof.first_name, prof.last_name;
END;
$$;


ALTER FUNCTION public.get_assigned_patients_for_provider(provider_profile_id uuid) OWNER TO postgres;

--
-- TOC entry 415 (class 1255 OID 18988)
-- Name: get_available_slots_for_provider(uuid, date, date, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text DEFAULT NULL::text) RETURNS TABLE(slot_date date, slot_start_time time without time zone, slot_end_time time without time zone, duration_minutes integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY
  WITH RECURSIVE date_series AS (
    SELECT p_start_date AS date
    UNION ALL
    SELECT date + 1
    FROM date_series
    WHERE date < p_end_date
  ),
  provider_daily_schedule AS (
    SELECT 
      ds.date,
      ps.start_time,
      ps.end_time,
      ps.slot_duration_minutes,
      ps.treatment_types
    FROM date_series ds
    CROSS JOIN provider_schedules ps
    WHERE ps.provider_id = p_provider_id
      AND ps.active = true
      AND ps.day_of_week = EXTRACT(DOW FROM ds.date)
      AND (
        p_treatment_type IS NULL 
        OR array_length(ps.treatment_types, 1) IS NULL 
        OR p_treatment_type = ANY(ps.treatment_types)
      )
  ),
  time_slots AS (
    SELECT 
      pds.date,
      slot_time::TIME AS start_time,
      (slot_time + (pds.slot_duration_minutes || ' minutes')::INTERVAL)::TIME AS end_time,
      pds.slot_duration_minutes
    FROM provider_daily_schedule pds
    CROSS JOIN LATERAL generate_series(
      pds.date + pds.start_time,
      pds.date + pds.end_time - (pds.slot_duration_minutes || ' minutes')::INTERVAL,
      (pds.slot_duration_minutes || ' minutes')::INTERVAL
    ) AS slot_time
  )
  SELECT 
    ts.date AS slot_date,
    ts.start_time AS slot_start_time,
    ts.end_time AS slot_end_time,
    ts.slot_duration_minutes AS duration_minutes
  FROM time_slots ts
  LEFT JOIN appointments a ON (
    a.provider_id = p_provider_id
    AND a.appointment_date = ts.date
    AND a.start_time = ts.start_time
    AND a.status IN ('scheduled', 'confirmed')
    AND (a.is_reschedule_source IS NULL OR a.is_reschedule_source = false)
  )
  WHERE a.id IS NULL  -- Only return slots that don't have existing appointments
  ORDER BY ts.date, ts.start_time;
END;
$$;


ALTER FUNCTION public.get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text) OWNER TO postgres;

--
-- TOC entry 4495 (class 0 OID 0)
-- Dependencies: 415
-- Name: FUNCTION get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text) IS 'Returns available appointment slots for a provider excluding rescheduled appointments';


--
-- TOC entry 329 (class 1255 OID 18659)
-- Name: get_patient_appointments(uuid, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean DEFAULT false) RETURNS TABLE(appointment_id uuid, provider_name text, provider_specialty text, appointment_date date, start_time time without time zone, end_time time without time zone, treatment_type text, appointment_type text, status text, patient_notes text, provider_notes text, can_cancel boolean, can_reschedule boolean, created_at timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    a.id as appointment_id,
    (prof.first_name || ' ' || prof.last_name) as provider_name,
    prov.specialty as provider_specialty,
    a.appointment_date,
    a.start_time,
    a.end_time,
    a.treatment_type,
    a.appointment_type,
    a.status,
    a.patient_notes,
    a.provider_notes,
    -- Can cancel if appointment is scheduled/confirmed and at least 24 hours away
    CASE 
      WHEN a.status IN ('scheduled', 'confirmed') 
        AND (a.appointment_date > CURRENT_DATE + INTERVAL '1 day' 
             OR (a.appointment_date = CURRENT_DATE + INTERVAL '1 day' AND a.start_time > LOCALTIME))
      THEN true
      ELSE false
    END as can_cancel,
    -- Can reschedule if appointment is scheduled/confirmed and at least 48 hours away
    CASE 
      WHEN a.status IN ('scheduled', 'confirmed') 
        AND (a.appointment_date > CURRENT_DATE + INTERVAL '2 days'
             OR (a.appointment_date = CURRENT_DATE + INTERVAL '2 days' AND a.start_time > LOCALTIME))
      THEN true
      ELSE false
    END as can_reschedule,
    a.created_at
  FROM appointments a
  INNER JOIN patients p ON a.patient_id = p.id
  INNER JOIN providers prov ON a.provider_id = prov.id
  INNER JOIN profiles prof ON prov.profile_id = prof.id
  WHERE p.profile_id = p_patient_profile_id
    AND (p_include_past = true OR a.appointment_date >= CURRENT_DATE)
  ORDER BY a.appointment_date ASC, a.start_time ASC;
END;
$$;


ALTER FUNCTION public.get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean) OWNER TO postgres;

--
-- TOC entry 4497 (class 0 OID 0)
-- Dependencies: 329
-- Name: FUNCTION get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean) IS 'Gets all appointments for a patient with cancellation/reschedule permissions';


--
-- TOC entry 468 (class 1255 OID 18535)
-- Name: get_patient_medication_overview(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_patient_medication_overview(patient_uuid uuid) RETURNS TABLE(medication_name text, category text, preference_status text, approval_status text, order_status text, payment_status text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    m.name,
    m.category,
    pmp.status as preference_status,
    COALESCE(ma.status, 'no_review') as approval_status,
    COALESCE(mo.fulfillment_status, 'no_order') as order_status,
    COALESCE(mo.payment_status, 'no_payment') as payment_status
  FROM patient_medication_preferences pmp
  JOIN medications m ON pmp.medication_id = m.id
  LEFT JOIN medication_approvals ma ON pmp.id = ma.preference_id
  LEFT JOIN medication_orders mo ON ma.id = mo.approval_id
  WHERE pmp.patient_id = patient_uuid
  ORDER BY pmp.created_at DESC;
END;
$$;


ALTER FUNCTION public.get_patient_medication_overview(patient_uuid uuid) OWNER TO postgres;

--
-- TOC entry 419 (class 1255 OID 18540)
-- Name: get_patient_medications_detailed(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_patient_medications_detailed(patient_uuid uuid) RETURNS TABLE(medication_id uuid, medication_name text, dosage text, supply text, status text, last_payment_date timestamp with time zone, sent_to_pharmacy_date timestamp with time zone, shipped_date timestamp with time zone, tracking_number text, order_id uuid)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        m.id as medication_id,
        m.name as medication_name,
        CONCAT(m.strength, ' ', m.dosage_form) as dosage,
        CASE 
            WHEN mo.quantity > 1 THEN CONCAT(mo.quantity::TEXT, ' units')
            ELSE '30 day supply'
        END as supply,
        mo.fulfillment_status as status,
        mo.payment_date as last_payment_date,
        mo.sent_to_pharmacy as sent_to_pharmacy_date,
        mo.shipped_date as shipped_date,
        mo.tracking_number as tracking_number,
        mo.id as order_id
    FROM medication_orders mo
    JOIN medications m ON mo.medication_id = m.id
    JOIN medication_approvals ma ON mo.approval_id = ma.id
    JOIN patient_medication_preferences pmp ON ma.preference_id = pmp.id
    WHERE mo.patient_id = patient_uuid
    AND pmp.status = 'approved'
    AND ma.status = 'approved'
    ORDER BY mo.created_at DESC;
END;
$$;


ALTER FUNCTION public.get_patient_medications_detailed(patient_uuid uuid) OWNER TO postgres;

--
-- TOC entry 331 (class 1255 OID 18403)
-- Name: get_provider_by_profile_id(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_provider_by_profile_id(provider_profile_id uuid) RETURNS TABLE(provider_id uuid, profile_id uuid, first_name text, last_name text, email text, specialty text, license_number text, phone text, active boolean)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    prov.id as provider_id,
    prov.profile_id,
    prof.first_name,
    prof.last_name,
    prof.email,
    prov.specialty,
    prov.license_number,
    prov.phone,
    prov.active
  FROM providers prov
  INNER JOIN profiles prof ON prov.profile_id = prof.id
  WHERE prov.profile_id = provider_profile_id
  AND prov.active = true;
END;
$$;


ALTER FUNCTION public.get_provider_by_profile_id(provider_profile_id uuid) OWNER TO postgres;

--
-- TOC entry 328 (class 1255 OID 18536)
-- Name: get_provider_pending_approvals(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_provider_pending_approvals(provider_uuid uuid) RETURNS TABLE(preference_id uuid, patient_name text, medication_name text, preferred_dosage text, frequency text, patient_notes text, requested_date timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    pmp.id,
    CONCAT(pr.first_name, ' ', pr.last_name),
    m.name,
    pmp.preferred_dosage,
    pmp.frequency,
    pmp.notes,
    pmp.requested_date
  FROM patient_medication_preferences pmp
  JOIN medications m ON pmp.medication_id = m.id
  JOIN patients pt ON pmp.patient_id = pt.id
  JOIN profiles pr ON pt.profile_id = pr.id
  JOIN patient_assignments pa ON pt.id = pa.patient_id
  JOIN providers prov ON pa.provider_id = prov.id
  LEFT JOIN medication_approvals ma ON pmp.id = ma.preference_id
  WHERE prov.profile_id = provider_uuid
  AND pmp.status = 'pending'
  AND ma.id IS NULL -- No approval exists yet
  ORDER BY pmp.requested_date ASC;
END;
$$;


ALTER FUNCTION public.get_provider_pending_approvals(provider_uuid uuid) OWNER TO postgres;

--
-- TOC entry 476 (class 1255 OID 18396)
-- Name: get_user_role(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_role(user_id uuid DEFAULT auth.uid()) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN (
    SELECT role 
    FROM profiles 
    WHERE id = user_id
  );
END;
$$;


ALTER FUNCTION public.get_user_role(user_id uuid) OWNER TO postgres;

--
-- TOC entry 425 (class 1255 OID 19022)
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    user_role TEXT;
    first_name TEXT;
    last_name TEXT;
    phone_val TEXT;
    specialty_val TEXT;
    license_number_val TEXT;
    new_provider_id UUID;
BEGIN
    -- Extract data from raw_user_meta_data only
    user_role := COALESCE(NEW.raw_user_meta_data->>'role', 'patient');
    first_name := COALESCE(
        NEW.raw_user_meta_data->>'first_name',
        NEW.raw_user_meta_data->>'firstName', 
        'User'
    );
    last_name := COALESCE(
        NEW.raw_user_meta_data->>'last_name',
        NEW.raw_user_meta_data->>'lastName', 
        'Unknown'
    );
    phone_val := NEW.raw_user_meta_data->>'phone';
    specialty_val := NEW.raw_user_meta_data->>'specialty';
    license_number_val := COALESCE(
        NEW.raw_user_meta_data->>'license_number',
        NEW.raw_user_meta_data->>'licenseNumber'
    );

    -- Create profile first with explicit schema reference
    INSERT INTO public.profiles (id, email, first_name, last_name, role, created_at, updated_at)
    VALUES (NEW.id, NEW.email, first_name, last_name, user_role, NOW(), NOW());

    -- Create role-specific records with explicit schema references
    IF user_role = 'patient' THEN
        INSERT INTO public.patients (profile_id, phone, has_completed_intake, created_at, updated_at)
        VALUES (NEW.id, phone_val, false, NOW(), NOW());

    ELSIF user_role = 'provider' THEN
        -- Create provider record and capture the ID for schedule creation
        INSERT INTO public.providers (profile_id, specialty, license_number, phone, active, created_at, updated_at)
        VALUES (NEW.id, specialty_val, license_number_val, phone_val, true, NOW(), NOW())
        RETURNING id INTO new_provider_id;

        -- Create default provider schedule (Monday-Friday, 9 AM - 5 PM)
        INSERT INTO public.provider_schedules (provider_id, day_of_week, start_time, end_time, treatment_types, active, created_at, updated_at)
        VALUES
            (new_provider_id, 1, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 2, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 3, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 4, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 5, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW());

    ELSIF user_role = 'admin' THEN
        INSERT INTO public.admins (profile_id, permissions, active, created_at, updated_at)
        VALUES (NEW.id, ARRAY['dashboard', 'patients', 'providers', 'assignments'], true, NOW(), NOW());
    END IF;

    RETURN NEW;
EXCEPTION
    WHEN OTHERS THEN
        RAISE LOG 'Error in handle_new_user trigger for user %: % - %', NEW.id, SQLSTATE, SQLERRM;
        RAISE;
END;
$$;


ALTER FUNCTION public.handle_new_user() OWNER TO postgres;

--
-- TOC entry 471 (class 1255 OID 18655)
-- Name: log_appointment_changes(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.log_appointment_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Insert into appointment_history
  INSERT INTO appointment_history (
    appointment_id,
    action,
    performed_by,
    performed_by_user_id,
    old_values,
    new_values,
    reason
  ) VALUES (
    COALESCE(NEW.id, OLD.id),
    CASE 
      WHEN TG_OP = 'INSERT' THEN 'created'
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'cancelled' AND OLD.status != 'cancelled' THEN 'cancelled'
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'completed' AND OLD.status != 'completed' THEN 'completed'  
      WHEN TG_OP = 'UPDATE' AND (NEW.appointment_date != OLD.appointment_date OR NEW.start_time != OLD.start_time) THEN 'rescheduled'
      WHEN TG_OP = 'UPDATE' THEN 'updated'
      WHEN TG_OP = 'DELETE' THEN 'deleted'
    END,
    COALESCE(
      current_setting('app.current_user_role', true),
      'system'
    ),
    CASE 
      WHEN current_setting('app.current_user_id', true) != '' 
      THEN current_setting('app.current_user_id', true)::UUID
      ELSE NULL
    END,
    CASE WHEN TG_OP != 'INSERT' THEN to_jsonb(OLD) ELSE NULL END,
    CASE WHEN TG_OP != 'DELETE' THEN to_jsonb(NEW) ELSE NULL END,
    CASE 
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'cancelled' THEN NEW.cancellation_reason
      ELSE NULL
    END
  );
  
  RETURN COALESCE(NEW, OLD);
END;
$$;


ALTER FUNCTION public.log_appointment_changes() OWNER TO postgres;

--
-- TOC entry 335 (class 1255 OID 18858)
-- Name: repair_missing_profiles(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.repair_missing_profiles() RETURNS TABLE(user_id uuid, action_taken text, success boolean, error_message text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    user_rec RECORD;
    new_provider_id UUID;
    schedule_count INTEGER;
BEGIN
    -- Find users without profiles
    FOR user_rec IN (
        SELECT u.id, u.email, u.created_at, u.raw_user_meta_data
        FROM auth.users u
        LEFT JOIN public.profiles p ON u.id = p.id
        WHERE p.id IS NULL
        ORDER BY u.created_at DESC
    ) LOOP
        BEGIN
            -- Extract role and create profile
            DECLARE
                user_role TEXT := COALESCE(user_rec.raw_user_meta_data->>'role', 'patient');
                first_name_val TEXT := COALESCE(
                    user_rec.raw_user_meta_data->>'firstName',
                    user_rec.raw_user_meta_data->>'first_name',
                    split_part(user_rec.email, '@', 1)
                );
                last_name_val TEXT := COALESCE(
                    user_rec.raw_user_meta_data->>'lastName',
                    user_rec.raw_user_meta_data->>'last_name',
                    'User'
                );
            BEGIN
                -- Create profile
                INSERT INTO public.profiles (id, email, role, first_name, last_name, created_at)
                VALUES (user_rec.id, user_rec.email, user_role, first_name_val, last_name_val, user_rec.created_at);
                
                -- Create role-specific records
                IF user_role = 'provider' THEN
                    INSERT INTO public.providers (profile_id, specialty, license_number, active, created_at)
                    VALUES (user_rec.id, 'General Practice', 'REPAIRED', true, user_rec.created_at)
                    RETURNING id INTO new_provider_id;
                    
                    -- Create schedules
                    INSERT INTO public.provider_schedules (provider_id, day_of_week, start_time, end_time, active, created_at)
                    SELECT new_provider_id, day_num, '09:00:00'::TIME, '17:00:00'::TIME, true, user_rec.created_at
                    FROM generate_series(1, 5) AS day_num;
                    
                    GET DIAGNOSTICS schedule_count = ROW_COUNT;
                    
                    RETURN QUERY SELECT 
                        user_rec.id,
                        format('Created profile, provider, and %s schedules', schedule_count),
                        true,
                        NULL::TEXT;
                        
                ELSIF user_role = 'patient' THEN
                    INSERT INTO public.patients (profile_id, has_completed_intake, created_at)
                    VALUES (user_rec.id, false, user_rec.created_at);
                    
                    RETURN QUERY SELECT 
                        user_rec.id,
                        'Created profile and patient record',
                        true,
                        NULL::TEXT;
                        
                ELSIF user_role = 'admin' THEN
                    INSERT INTO public.admins (profile_id, permissions, active, created_at)
                    VALUES (user_rec.id, ARRAY['dashboard', 'patients', 'providers'], true, user_rec.created_at);
                    
                    RETURN QUERY SELECT 
                        user_rec.id,
                        'Created profile and admin record',
                        true,
                        NULL::TEXT;
                ELSE
                    RETURN QUERY SELECT 
                        user_rec.id,
                        'Created profile only',
                        true,
                        NULL::TEXT;
                END IF;
                
            EXCEPTION WHEN OTHERS THEN
                RETURN QUERY SELECT 
                    user_rec.id,
                    'Failed to repair',
                    false,
                    SQLERRM;
            END;
        END;
    END LOOP;
END;
$$;


ALTER FUNCTION public.repair_missing_profiles() OWNER TO postgres;

--
-- TOC entry 355 (class 1255 OID 19135)
-- Name: request_prescription_refill(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.request_prescription_refill(p_preference_id uuid, p_patient_profile_id uuid) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_preference_record RECORD;
    v_patient_id UUID;
    v_days_until_due INTEGER;
BEGIN
    -- Get patient ID from profile
    SELECT id INTO v_patient_id 
    FROM patients 
    WHERE profile_id = p_patient_profile_id;
    
    IF v_patient_id IS NULL THEN
        RETURN json_build_object(
            'success', false,
            'error', 'Patient not found'
        );
    END IF;
    
    -- Get the preference record
    SELECT 
        id, 
        patient_id, 
        status, 
        next_prescription_due,
        medication_id,
        preferred_dosage,
        frequency
    INTO v_preference_record
    FROM patient_medication_preferences 
    WHERE id = p_preference_id 
      AND patient_id = v_patient_id;
    
    IF v_preference_record.id IS NULL THEN
        RETURN json_build_object(
            'success', false,
            'error', 'Medication preference not found or access denied'
        );
    END IF;
    
    -- Check if preference is currently approved
    IF v_preference_record.status != 'approved' THEN
        RETURN json_build_object(
            'success', false,
            'error', 'Can only request refills for approved medications'
        );
    END IF;
    
    -- Check if next_prescription_due exists
    IF v_preference_record.next_prescription_due IS NULL THEN
        RETURN json_build_object(
            'success', false,
            'error', 'No prescription due date found'
        );
    END IF;
    
    -- Calculate days until due
    v_days_until_due := v_preference_record.next_prescription_due::date - CURRENT_DATE;
    
    -- Only allow refill requests within 3 days of due date (or past due)
    IF v_days_until_due > 3 THEN
        RETURN json_build_object(
            'success', false,
            'error', 'Refill can only be requested within 3 days of due date'
        );
    END IF;
    
    -- Update preference status to pending AND set refill_requested = TRUE
    UPDATE patient_medication_preferences 
    SET 
        status = 'pending',
        refill_requested = TRUE,  -- Mark as patient-requested refill
        notes = COALESCE(notes, '') || 
                CASE 
                    WHEN notes IS NULL OR notes = '' THEN 
                        'Refill requested on ' || CURRENT_DATE::text
                    ELSE 
                        '; Refill requested on ' || CURRENT_DATE::text
                END,
        updated_at = NOW()
    WHERE id = p_preference_id;
    
    RETURN json_build_object(
        'success', true,
        'message', 'Refill request submitted successfully',
        'preference_id', p_preference_id,
        'new_status', 'pending',
        'refill_requested', true,
        'days_until_due', v_days_until_due
    );
    
EXCEPTION WHEN OTHERS THEN
    RETURN json_build_object(
        'success', false,
        'error', 'An error occurred while processing the refill request: ' || SQLERRM
    );
END;
$$;


ALTER FUNCTION public.request_prescription_refill(p_preference_id uuid, p_patient_profile_id uuid) OWNER TO postgres;

--
-- TOC entry 4507 (class 0 OID 0)
-- Dependencies: 355
-- Name: FUNCTION request_prescription_refill(p_preference_id uuid, p_patient_profile_id uuid); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.request_prescription_refill(p_preference_id uuid, p_patient_profile_id uuid) IS 'Allows patients to request prescription refills within 3 days of due date, sets refill_requested=TRUE for provider approval filtering';


--
-- TOC entry 354 (class 1255 OID 18962)
-- Name: reschedule_appointment(uuid, date, time without time zone, text, uuid, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text DEFAULT 'patient'::text, p_rescheduled_by_user_id uuid DEFAULT NULL::uuid, p_reason text DEFAULT NULL::text) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_old_appointment appointments%ROWTYPE;
  v_new_appointment_id UUID;
  v_new_end_time TIME;
  v_duration_minutes INTEGER;
BEGIN
  -- Get the original appointment
  SELECT * INTO v_old_appointment 
  FROM appointments 
  WHERE id = p_appointment_id AND status NOT IN ('cancelled', 'completed');
  
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Appointment not found or cannot be rescheduled'
    );
  END IF;
  
  -- Check if the new slot is available
  IF EXISTS (
    SELECT 1 FROM appointments a
    WHERE a.provider_id = v_old_appointment.provider_id
      AND a.appointment_date = p_new_date
      AND a.start_time = p_new_time
      AND a.status NOT IN ('cancelled', 'no_show')
      AND a.id != p_appointment_id
  ) THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Selected time slot is already booked'
    );
  END IF;
  
  -- Calculate new end time (preserve original duration)
  v_duration_minutes := COALESCE(v_old_appointment.duration_minutes, 30);
  v_new_end_time := p_new_time + (v_duration_minutes || ' minutes')::INTERVAL;
  
  -- Start transaction
  BEGIN
    -- Mark the original appointment as rescheduled
    UPDATE appointments 
    SET 
      status = 'rescheduled',
      updated_at = NOW()
    WHERE id = p_appointment_id;
    
    -- Create new appointment
    INSERT INTO appointments (
      patient_id,
      provider_id,
      assignment_id,
      appointment_date,
      start_time,
      end_time,
      duration_minutes,
      treatment_type,
      appointment_type,
      status,
      patient_notes,
      provider_notes,
      admin_notes,
      booked_by,
      booked_by_user_id
    ) VALUES (
      v_old_appointment.patient_id,
      v_old_appointment.provider_id,
      v_old_appointment.assignment_id,
      p_new_date,
      p_new_time,
      v_new_end_time,
      v_duration_minutes,
      v_old_appointment.treatment_type,
      v_old_appointment.appointment_type,
      'scheduled',
      v_old_appointment.patient_notes,
      v_old_appointment.provider_notes,
      'Rescheduled from ' || v_old_appointment.appointment_date || ' ' || v_old_appointment.start_time,
      p_rescheduled_by,
      p_rescheduled_by_user_id
    ) RETURNING id INTO v_new_appointment_id;
    
    -- Return success
    RETURN json_build_object(
      'success', true,
      'old_appointment_id', p_appointment_id,
      'new_appointment_id', v_new_appointment_id,
      'message', 'Appointment successfully rescheduled'
    );
    
  EXCEPTION WHEN OTHERS THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Failed to reschedule appointment: ' || SQLERRM
    );
  END;
END;
$$;


ALTER FUNCTION public.reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text, p_rescheduled_by_user_id uuid, p_reason text) OWNER TO postgres;

--
-- TOC entry 4509 (class 0 OID 0)
-- Dependencies: 354
-- Name: FUNCTION reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text, p_rescheduled_by_user_id uuid, p_reason text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text, p_rescheduled_by_user_id uuid, p_reason text) IS 'Reschedule an appointment to a new date and time';


--
-- TOC entry 477 (class 1255 OID 19116)
-- Name: reset_expired_approvals(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.reset_expired_approvals() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    rows_updated INTEGER;
BEGIN
    -- Reset patient preferences to pending when supply period has elapsed
    -- This way they show up in the provider dashboard as new approval requests
    UPDATE public.patient_medication_preferences
    SET
        status = 'pending',
        updated_at = NOW()
    FROM public.medication_approvals ma
    JOIN public.medication_orders mo ON ma.id = mo.approval_id
    WHERE patient_medication_preferences.id = ma.preference_id
    AND ma.status = 'approved'
    AND ma.supply_days IS NOT NULL
    AND mo.estimated_delivery IS NOT NULL
    AND mo.fulfillment_status = 'delivered'
    AND (mo.estimated_delivery::DATE + INTERVAL '1 day' * ma.supply_days) <= CURRENT_DATE;

    GET DIAGNOSTICS rows_updated = ROW_COUNT;

    -- Log the action for debugging
    INSERT INTO public.auth_trigger_logs (trigger_stage, success, error_message, metadata, created_at)
    VALUES (
        'APPROVAL_RESET',
        true,
        format('Reset %s expired preferences to pending status', rows_updated),
        jsonb_build_object('reset_count', rows_updated, 'reset_date', CURRENT_DATE),
        NOW()
    );

    RETURN rows_updated;
END;
$$;


ALTER FUNCTION public.reset_expired_approvals() OWNER TO postgres;

--
-- TOC entry 4511 (class 0 OID 0)
-- Dependencies: 477
-- Name: FUNCTION reset_expired_approvals(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.reset_expired_approvals() IS 'Reset expired patient preferences to pending status so they appear in provider dashboard';


--
-- TOC entry 464 (class 1255 OID 19127)
-- Name: run_daily_maintenance(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.run_daily_maintenance() RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    reset_count INTEGER;
    expired_count INTEGER;
    result JSONB;
BEGIN
    -- Run the daily approval reset check
    reset_count := public.daily_approval_reset_check();
    
    -- Get count of approvals that are currently expired but not yet reset
    SELECT COUNT(*)::INTEGER INTO expired_count
    FROM public.approval_renewal_status
    WHERE renewal_status = 'EXPIRED' AND status = 'approved';
    
    -- Return summary
    result := jsonb_build_object(
        'approvals_reset', reset_count,
        'approvals_still_expired', expired_count,
        'run_date', CURRENT_DATE,
        'run_time', NOW()
    );
    
    RETURN result;
END;
$$;


ALTER FUNCTION public.run_daily_maintenance() OWNER TO postgres;

--
-- TOC entry 4513 (class 0 OID 0)
-- Dependencies: 464
-- Name: FUNCTION run_daily_maintenance(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.run_daily_maintenance() IS 'Main maintenance function to be called daily from application or cron';


--
-- TOC entry 359 (class 1255 OID 18664)
-- Name: set_appointment_context(text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_appointment_context(p_user_role text, p_user_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  PERFORM set_config('app.current_user_role', p_user_role, true);
  PERFORM set_config('app.current_user_id', p_user_id::TEXT, true);
END;
$$;


ALTER FUNCTION public.set_appointment_context(p_user_role text, p_user_id uuid) OWNER TO postgres;

--
-- TOC entry 4515 (class 0 OID 0)
-- Dependencies: 359
-- Name: FUNCTION set_appointment_context(p_user_role text, p_user_id uuid); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.set_appointment_context(p_user_role text, p_user_id uuid) IS 'Sets security context for appointment operations';


--
-- TOC entry 327 (class 1255 OID 19118)
-- Name: trigger_approval_reset(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trigger_approval_reset() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN public.reset_expired_approvals();
END;
$$;


ALTER FUNCTION public.trigger_approval_reset() OWNER TO postgres;

--
-- TOC entry 4517 (class 0 OID 0)
-- Dependencies: 327
-- Name: FUNCTION trigger_approval_reset(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.trigger_approval_reset() IS 'Manually triggers the approval reset process for testing';


--
-- TOC entry 384 (class 1255 OID 18794)
-- Name: update_clinical_note_editor(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_clinical_note_editor() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Set last_updated_by to current user if available
  IF current_setting('app.current_user_id', true) != '' THEN
    NEW.last_updated_by = current_setting('app.current_user_id', true)::UUID;
  END IF;
  
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_clinical_note_editor() OWNER TO postgres;

--
-- TOC entry 418 (class 1255 OID 19133)
-- Name: update_next_due_from_supply_and_fax(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_next_due_from_supply_and_fax() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    preference_record RECORD;
    v_calculated_due_date DATE;
    v_updated_count INTEGER := 0;
BEGIN
    -- Loop through all preferences that have supply_days and faxed date but no next_prescription_due
    FOR preference_record IN 
        SELECT id, supply_days, faxed::date as faxed_date
        FROM patient_medication_preferences 
        WHERE supply_days IS NOT NULL 
          AND supply_days > 0 
          AND faxed IS NOT NULL
          AND (next_prescription_due IS NULL OR next_prescription_due < CURRENT_DATE)
    LOOP
        -- Calculate next due date using faxed date from preferences
        v_calculated_due_date := preference_record.faxed_date + preference_record.supply_days;
        
        UPDATE patient_medication_preferences 
        SET 
            next_prescription_due = v_calculated_due_date,
            updated_at = NOW()
        WHERE id = preference_record.id;
        
        v_updated_count := v_updated_count + 1;
    END LOOP;
    
    RETURN v_updated_count;
END;
$$;


ALTER FUNCTION public.update_next_due_from_supply_and_fax() OWNER TO postgres;

--
-- TOC entry 4520 (class 0 OID 0)
-- Dependencies: 418
-- Name: FUNCTION update_next_due_from_supply_and_fax(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.update_next_due_from_supply_and_fax() IS 'Updates next_prescription_due for preferences with supply_days based on faxed date from preferences table';


--
-- TOC entry 394 (class 1255 OID 19131)
-- Name: update_preference_on_medication_adjustment(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_preference_on_medication_adjustment() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_fax_date DATE;
    v_calculated_due_date DATE;
    v_preference_record RECORD;
BEGIN
    -- Only proceed if this is an approval (new_status = 'approved')
    IF NEW.new_status = 'approved' THEN
        -- Update the preference with the new values from the adjustment
        UPDATE patient_medication_preferences 
        SET 
            preferred_dosage = COALESCE(NEW.new_dosage, preferred_dosage),
            frequency = COALESCE(NEW.new_frequency, frequency),
            status = NEW.new_status,
            supply_days = COALESCE(NEW.new_supply_days, supply_days),
            notes = COALESCE(NEW.new_provider_notes, notes),
            updated_at = NOW()
        WHERE id = NEW.preference_id;
        
        -- If supply_days was provided, calculate and update next_prescription_due
        -- using the faxed field from the preference itself
        IF NEW.new_supply_days IS NOT NULL AND NEW.new_supply_days > 0 THEN
            -- Get the preference record to access the faxed field
            SELECT faxed::date
            INTO v_fax_date
            FROM patient_medication_preferences 
            WHERE id = NEW.preference_id;
            
            -- If we have a fax date, calculate next due date
            IF v_fax_date IS NOT NULL THEN
                v_calculated_due_date := v_fax_date + NEW.new_supply_days;
                
                -- Update the preference with the calculated due date
                UPDATE patient_medication_preferences 
                SET 
                    next_prescription_due = v_calculated_due_date,
                    updated_at = NOW()
                WHERE id = NEW.preference_id;
                
                -- Log the calculation for debugging (if logging table exists)
                BEGIN
                    INSERT INTO auth_trigger_logs (
                        step, 
                        status, 
                        message, 
                        metadata
                    ) VALUES (
                        'SUPPLY_CALCULATION', 
                        'SUCCESS', 
                        'Updated next prescription due based on preference fax date and supply',
                        jsonb_build_object(
                            'preference_id', NEW.preference_id,
                            'fax_date', v_fax_date,
                            'supply_days', NEW.new_supply_days,
                            'calculated_due_date', v_calculated_due_date
                        )
                    );
                EXCEPTION WHEN OTHERS THEN
                    -- Ignore logging errors, don't fail the main operation
                    NULL;
                END;
            ELSE
                -- Log that no fax date was found (if logging table exists)
                BEGIN
                    INSERT INTO auth_trigger_logs (
                        step, 
                        status, 
                        message, 
                        metadata
                    ) VALUES (
                        'SUPPLY_CALCULATION', 
                        'WARNING', 
                        'No fax date found in preference, cannot calculate next due date',
                        jsonb_build_object(
                            'preference_id', NEW.preference_id,
                            'supply_days', NEW.new_supply_days
                        )
                    );
                EXCEPTION WHEN OTHERS THEN
                    -- Ignore logging errors, don't fail the main operation
                    NULL;
                END;
            END IF;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_preference_on_medication_adjustment() OWNER TO postgres;

--
-- TOC entry 4522 (class 0 OID 0)
-- Dependencies: 394
-- Name: FUNCTION update_preference_on_medication_adjustment(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.update_preference_on_medication_adjustment() IS 'Updates patient_medication_preferences when medication adjustments are approved, using faxed date from preferences table for next_prescription_due calculation';


--
-- TOC entry 431 (class 1255 OID 19067)
-- Name: update_prescription_due_date(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_prescription_due_date() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    approval_record RECORD;
    preference_id UUID;
    approved_freq TEXT;
BEGIN
    -- Only proceed if delivery date was just set (order delivered)
    IF OLD.estimated_delivery IS NULL AND NEW.estimated_delivery IS NOT NULL THEN
        -- Get the approval and preference info
        SELECT ma.preference_id, ma.approved_frequency
        INTO preference_id, approved_freq
        FROM public.medication_approvals ma
        WHERE ma.id = NEW.approval_id;

        IF preference_id IS NOT NULL THEN
            -- Update the next prescription due date
            UPDATE public.patient_medication_preferences
            SET next_prescription_due = public.calculate_next_prescription_due(
                preference_id,
                NEW.estimated_delivery::DATE,
                approved_freq
            )
            WHERE id = preference_id;
        END IF;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_prescription_due_date() OWNER TO postgres;

--
-- TOC entry 4524 (class 0 OID 0)
-- Dependencies: 431
-- Name: FUNCTION update_prescription_due_date(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.update_prescription_due_date() IS 'Updates prescription due date when medication order delivery date is set (fixed variable naming to avoid ambiguity)';


--
-- TOC entry 399 (class 1255 OID 18373)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only update if the table actually has an updated_at column
    IF TG_TABLE_NAME = 'clinical_notes' THEN
        NEW.updated_at = NOW();
    END IF;
    RETURN NEW;
EXCEPTION
    WHEN OTHERS THEN
        -- Don't fail the operation if there's an issue
        RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

--
-- TOC entry 398 (class 1255 OID 18688)
-- Name: validate_appointment_business_rules(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.validate_appointment_business_rules() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Prevent booking conflicts
  IF EXISTS (
    SELECT 1 FROM appointments a
    WHERE a.provider_id = NEW.provider_id
      AND a.appointment_date = NEW.appointment_date
      AND a.start_time = NEW.start_time
      AND a.id != COALESCE(NEW.id, '00000000-0000-0000-0000-000000000000'::UUID)
      AND a.status NOT IN ('cancelled', 'no_show')
  ) THEN
    RAISE EXCEPTION 'Appointment slot already booked';
  END IF;
  
  -- Validate appointment is within provider's schedule
  IF NOT EXISTS (
    SELECT 1 FROM provider_schedules ps
    WHERE ps.provider_id = NEW.provider_id
      AND ps.day_of_week = EXTRACT(DOW FROM NEW.appointment_date)
      AND ps.start_time <= NEW.start_time
      AND ps.end_time >= NEW.end_time
      AND ps.active = true
  ) THEN
    RAISE EXCEPTION 'Appointment outside provider schedule';
  END IF;
  
  -- Check for availability overrides that block this time
  IF EXISTS (
    SELECT 1 FROM provider_availability_overrides pao
    WHERE pao.provider_id = NEW.provider_id
      AND pao.date = NEW.appointment_date
      AND pao.available = false
      AND (pao.start_time IS NULL OR NEW.start_time >= pao.start_time)
      AND (pao.end_time IS NULL OR NEW.end_time <= pao.end_time)
  ) THEN
    RAISE EXCEPTION 'Provider not available at requested time';
  END IF;
  
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.validate_appointment_business_rules() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 245 (class 1259 OID 16488)
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE auth.audit_log_entries OWNER TO supabase_auth_admin;

--
-- TOC entry 4528 (class 0 OID 0)
-- Dependencies: 245
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- TOC entry 293 (class 1259 OID 18161)
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text NOT NULL,
    code_challenge_method auth.code_challenge_method NOT NULL,
    code_challenge text NOT NULL,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone
);


ALTER TABLE auth.flow_state OWNER TO supabase_auth_admin;

--
-- TOC entry 4530 (class 0 OID 0)
-- Dependencies: 293
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.flow_state IS 'stores metadata for pkce logins';


--
-- TOC entry 284 (class 1259 OID 17959)
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE auth.identities OWNER TO supabase_auth_admin;

--
-- TOC entry 4532 (class 0 OID 0)
-- Dependencies: 284
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- TOC entry 4533 (class 0 OID 0)
-- Dependencies: 284
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- TOC entry 244 (class 1259 OID 16481)
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE auth.instances OWNER TO supabase_auth_admin;

--
-- TOC entry 4535 (class 0 OID 0)
-- Dependencies: 244
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- TOC entry 288 (class 1259 OID 18048)
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE auth.mfa_amr_claims OWNER TO supabase_auth_admin;

--
-- TOC entry 4537 (class 0 OID 0)
-- Dependencies: 288
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- TOC entry 287 (class 1259 OID 18036)
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


ALTER TABLE auth.mfa_challenges OWNER TO supabase_auth_admin;

--
-- TOC entry 4539 (class 0 OID 0)
-- Dependencies: 287
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- TOC entry 286 (class 1259 OID 18023)
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid
);


ALTER TABLE auth.mfa_factors OWNER TO supabase_auth_admin;

--
-- TOC entry 4541 (class 0 OID 0)
-- Dependencies: 286
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- TOC entry 295 (class 1259 OID 18243)
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_id text NOT NULL,
    client_secret_hash text NOT NULL,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048))
);


ALTER TABLE auth.oauth_clients OWNER TO supabase_auth_admin;

--
-- TOC entry 294 (class 1259 OID 18211)
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


ALTER TABLE auth.one_time_tokens OWNER TO supabase_auth_admin;

--
-- TOC entry 243 (class 1259 OID 16470)
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


ALTER TABLE auth.refresh_tokens OWNER TO supabase_auth_admin;

--
-- TOC entry 4545 (class 0 OID 0)
-- Dependencies: 243
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- TOC entry 242 (class 1259 OID 16469)
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE auth.refresh_tokens_id_seq OWNER TO supabase_auth_admin;

--
-- TOC entry 4547 (class 0 OID 0)
-- Dependencies: 242
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- TOC entry 291 (class 1259 OID 18090)
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


ALTER TABLE auth.saml_providers OWNER TO supabase_auth_admin;

--
-- TOC entry 4549 (class 0 OID 0)
-- Dependencies: 291
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- TOC entry 292 (class 1259 OID 18108)
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


ALTER TABLE auth.saml_relay_states OWNER TO supabase_auth_admin;

--
-- TOC entry 4551 (class 0 OID 0)
-- Dependencies: 292
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- TOC entry 246 (class 1259 OID 16496)
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE auth.schema_migrations OWNER TO supabase_auth_admin;

--
-- TOC entry 4553 (class 0 OID 0)
-- Dependencies: 246
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- TOC entry 285 (class 1259 OID 17989)
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text
);


ALTER TABLE auth.sessions OWNER TO supabase_auth_admin;

--
-- TOC entry 4555 (class 0 OID 0)
-- Dependencies: 285
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- TOC entry 4556 (class 0 OID 0)
-- Dependencies: 285
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- TOC entry 290 (class 1259 OID 18075)
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


ALTER TABLE auth.sso_domains OWNER TO supabase_auth_admin;

--
-- TOC entry 4558 (class 0 OID 0)
-- Dependencies: 290
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- TOC entry 289 (class 1259 OID 18066)
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


ALTER TABLE auth.sso_providers OWNER TO supabase_auth_admin;

--
-- TOC entry 4560 (class 0 OID 0)
-- Dependencies: 289
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- TOC entry 4561 (class 0 OID 0)
-- Dependencies: 289
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- TOC entry 241 (class 1259 OID 16458)
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


ALTER TABLE auth.users OWNER TO supabase_auth_admin;

--
-- TOC entry 4563 (class 0 OID 0)
-- Dependencies: 241
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- TOC entry 4564 (class 0 OID 0)
-- Dependencies: 241
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- TOC entry 300 (class 1259 OID 18320)
-- Name: admins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admins (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    permissions text[] DEFAULT ARRAY['dashboard'::text],
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.admins OWNER TO postgres;

--
-- TOC entry 311 (class 1259 OID 18625)
-- Name: appointment_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointment_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    appointment_id uuid NOT NULL,
    action text NOT NULL,
    performed_by text NOT NULL,
    performed_by_user_id uuid,
    old_values jsonb,
    new_values jsonb,
    reason text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT appointment_history_action_check CHECK ((action = ANY (ARRAY['created'::text, 'updated'::text, 'cancelled'::text, 'completed'::text, 'no_show'::text, 'reschedule'::text, 'rescheduled'::text]))),
    CONSTRAINT appointment_history_performed_by_check CHECK ((performed_by = ANY (ARRAY['patient'::text, 'provider'::text, 'admin'::text, 'system'::text])))
);


ALTER TABLE public.appointment_history OWNER TO postgres;

--
-- TOC entry 4567 (class 0 OID 0)
-- Dependencies: 311
-- Name: TABLE appointment_history; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.appointment_history IS 'Complete audit trail of all appointment changes';


--
-- TOC entry 310 (class 1259 OID 18587)
-- Name: appointments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    assignment_id uuid,
    appointment_date date NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    duration_minutes integer NOT NULL,
    treatment_type text NOT NULL,
    appointment_type text DEFAULT 'consultation'::text NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    patient_notes text,
    provider_notes text,
    admin_notes text,
    booked_by text NOT NULL,
    booked_by_user_id uuid,
    booking_timestamp timestamp with time zone DEFAULT now(),
    cancelled_at timestamp with time zone,
    cancelled_by text,
    cancelled_by_user_id uuid,
    cancellation_reason text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    rescheduled_from_id uuid,
    rescheduled_to_id uuid,
    is_reschedule_source boolean DEFAULT false,
    reschedule_count integer DEFAULT 0,
    CONSTRAINT appointment_in_future CHECK (((appointment_date > CURRENT_DATE) OR ((appointment_date = CURRENT_DATE) AND (start_time >= LOCALTIME)))),
    CONSTRAINT appointments_appointment_type_check CHECK ((appointment_type = ANY (ARRAY['consultation'::text, 'follow_up'::text, 'treatment'::text, 'evaluation'::text, 'review'::text]))),
    CONSTRAINT appointments_booked_by_check CHECK ((booked_by = ANY (ARRAY['patient'::text, 'provider'::text, 'admin'::text]))),
    CONSTRAINT appointments_cancelled_by_check CHECK ((cancelled_by = ANY (ARRAY['patient'::text, 'provider'::text, 'admin'::text]))),
    CONSTRAINT appointments_duration_minutes_check CHECK ((duration_minutes > 0)),
    CONSTRAINT appointments_status_check CHECK ((status = ANY (ARRAY['scheduled'::text, 'confirmed'::text, 'completed'::text, 'cancelled'::text, 'no_show'::text, 'rescheduled'::text]))),
    CONSTRAINT valid_appointment_time CHECK ((end_time > start_time)),
    CONSTRAINT valid_cancellation CHECK (((status <> 'cancelled'::text) OR ((status = 'cancelled'::text) AND (cancelled_at IS NOT NULL) AND (cancelled_by IS NOT NULL))))
);


ALTER TABLE public.appointments OWNER TO postgres;

--
-- TOC entry 4569 (class 0 OID 0)
-- Dependencies: 310
-- Name: TABLE appointments; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.appointments IS 'Core appointments between patients and providers';


--
-- TOC entry 4570 (class 0 OID 0)
-- Dependencies: 310
-- Name: COLUMN appointments.assignment_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.appointments.assignment_id IS 'Links appointment to specific patient-provider treatment assignment';


--
-- TOC entry 4571 (class 0 OID 0)
-- Dependencies: 310
-- Name: COLUMN appointments.booked_by_user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.appointments.booked_by_user_id IS 'Profile ID of the person who booked the appointment';


--
-- TOC entry 4572 (class 0 OID 0)
-- Dependencies: 310
-- Name: COLUMN appointments.rescheduled_from_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.appointments.rescheduled_from_id IS 'Points to original appointment if this is a rescheduled appointment';


--
-- TOC entry 4573 (class 0 OID 0)
-- Dependencies: 310
-- Name: COLUMN appointments.rescheduled_to_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.appointments.rescheduled_to_id IS 'Points to new appointment if this was rescheduled';


--
-- TOC entry 4574 (class 0 OID 0)
-- Dependencies: 310
-- Name: COLUMN appointments.is_reschedule_source; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.appointments.is_reschedule_source IS 'True if this appointment was rescheduled (original slot now available)';


--
-- TOC entry 4575 (class 0 OID 0)
-- Dependencies: 310
-- Name: COLUMN appointments.reschedule_count; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.appointments.reschedule_count IS 'Number of times this appointment chain has been rescheduled';


--
-- TOC entry 306 (class 1259 OID 18455)
-- Name: medication_approvals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.medication_approvals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    preference_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    status text DEFAULT 'needs_review'::text NOT NULL,
    approved_dosage text,
    approved_frequency text,
    provider_notes text,
    contraindications text,
    approval_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    provider_profile_id uuid NOT NULL,
    supply_days integer,
    CONSTRAINT check_approval_status CHECK ((status = ANY (ARRAY['approved'::text, 'denied'::text, 'needs_review'::text])))
);


ALTER TABLE public.medication_approvals OWNER TO postgres;

--
-- TOC entry 4577 (class 0 OID 0)
-- Dependencies: 306
-- Name: COLUMN medication_approvals.provider_profile_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.medication_approvals.provider_profile_id IS 'Direct reference to provider auth user ID';


--
-- TOC entry 4578 (class 0 OID 0)
-- Dependencies: 306
-- Name: COLUMN medication_approvals.supply_days; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.medication_approvals.supply_days IS 'Number of days the prescription supply should last (e.g., 30, 60, 90 days)';


--
-- TOC entry 307 (class 1259 OID 18476)
-- Name: medication_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.medication_orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    approval_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    medication_id uuid NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    payment_status text DEFAULT 'pending'::text NOT NULL,
    payment_method text,
    payment_date timestamp with time zone,
    fulfillment_status text DEFAULT 'pending'::text NOT NULL,
    tracking_number text,
    shipped_date timestamp with time zone,
    estimated_delivery timestamp with time zone,
    admin_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    sent_to_pharmacy timestamp with time zone,
    provider_profile_id uuid NOT NULL,
    patient_profile_id uuid NOT NULL,
    CONSTRAINT check_fulfillment_status CHECK ((fulfillment_status = ANY (ARRAY['pending'::text, 'processing'::text, 'shipped'::text, 'delivered'::text]))),
    CONSTRAINT check_payment_status CHECK ((payment_status = ANY (ARRAY['pending'::text, 'paid'::text, 'failed'::text, 'refunded'::text]))),
    CONSTRAINT check_positive_amounts CHECK (((unit_price >= (0)::numeric) AND (total_amount >= (0)::numeric) AND (quantity > 0)))
);


ALTER TABLE public.medication_orders OWNER TO postgres;

--
-- TOC entry 4580 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN medication_orders.shipped_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.medication_orders.shipped_date IS 'Date when medication was physically shipped to patient';


--
-- TOC entry 4581 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN medication_orders.sent_to_pharmacy; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.medication_orders.sent_to_pharmacy IS 'Date when prescription was sent to pharmacy for processing';


--
-- TOC entry 4582 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN medication_orders.provider_profile_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.medication_orders.provider_profile_id IS 'Direct reference to provider auth user ID';


--
-- TOC entry 4583 (class 0 OID 0)
-- Dependencies: 307
-- Name: COLUMN medication_orders.patient_profile_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.medication_orders.patient_profile_id IS 'Direct reference to patient auth user ID';


--
-- TOC entry 304 (class 1259 OID 18418)
-- Name: medications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.medications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    generic_name text,
    brand_name text,
    dosage_form text NOT NULL,
    strength text NOT NULL,
    description text,
    category text NOT NULL,
    unit_price numeric(10,2) DEFAULT 0 NOT NULL,
    requires_prescription boolean DEFAULT true,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.medications OWNER TO postgres;

--
-- TOC entry 305 (class 1259 OID 18431)
-- Name: patient_medication_preferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient_medication_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    medication_id uuid NOT NULL,
    preferred_dosage text,
    frequency text,
    notes text,
    status text DEFAULT 'pending'::text NOT NULL,
    requested_date timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    medication_dosage_id uuid,
    faxed timestamp with time zone,
    next_prescription_due date,
    supply_days integer,
    refill_requested boolean DEFAULT false,
    CONSTRAINT check_preference_status CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'denied'::text, 'discontinued'::text])))
);


ALTER TABLE public.patient_medication_preferences OWNER TO postgres;

--
-- TOC entry 4586 (class 0 OID 0)
-- Dependencies: 305
-- Name: COLUMN patient_medication_preferences.medication_dosage_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patient_medication_preferences.medication_dosage_id IS 'References the specific dosage selected by the patient. New preferred method over preferred_dosage text field.';


--
-- TOC entry 4587 (class 0 OID 0)
-- Dependencies: 305
-- Name: COLUMN patient_medication_preferences.faxed; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patient_medication_preferences.faxed IS 'Timestamp when prescription was last faxed to pharmacy';


--
-- TOC entry 4588 (class 0 OID 0)
-- Dependencies: 305
-- Name: COLUMN patient_medication_preferences.next_prescription_due; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patient_medication_preferences.next_prescription_due IS 'Calculated date when next prescription should be due based on frequency and delivery';


--
-- TOC entry 4589 (class 0 OID 0)
-- Dependencies: 305
-- Name: COLUMN patient_medication_preferences.supply_days; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patient_medication_preferences.supply_days IS 'Number of days of medication supply when approved via medication adjustments';


--
-- TOC entry 4590 (class 0 OID 0)
-- Dependencies: 305
-- Name: COLUMN patient_medication_preferences.refill_requested; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.patient_medication_preferences.refill_requested IS 'TRUE when patient has explicitly requested a refill, FALSE when preference was set to pending by admin/system';


--
-- TOC entry 298 (class 1259 OID 18284)
-- Name: patients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    date_of_birth date,
    phone text,
    has_completed_intake boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.patients OWNER TO postgres;

--
-- TOC entry 297 (class 1259 OID 18267)
-- Name: profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.profiles (
    id uuid NOT NULL,
    email text NOT NULL,
    first_name text,
    last_name text,
    role text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT profiles_role_check CHECK ((role = ANY (ARRAY['patient'::text, 'admin'::text, 'provider'::text])))
);


ALTER TABLE public.profiles OWNER TO postgres;

--
-- TOC entry 322 (class 1259 OID 19119)
-- Name: approval_renewal_status; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.approval_renewal_status AS
 SELECT ma.id AS approval_id,
    ma.status,
    ma.supply_days,
    ((p.first_name || ' '::text) || p.last_name) AS patient_name,
    m.name AS medication_name,
    (mo.estimated_delivery)::date AS estimated_delivery,
    mo.fulfillment_status,
        CASE
            WHEN (ma.supply_days IS NULL) THEN NULL::date
            WHEN (mo.estimated_delivery IS NULL) THEN NULL::date
            ELSE (((mo.estimated_delivery)::date + ('1 day'::interval * (ma.supply_days)::double precision)))::date
        END AS expires_on,
        CASE
            WHEN ((ma.supply_days IS NULL) OR (mo.estimated_delivery IS NULL)) THEN 'N/A'::text
            WHEN (((mo.estimated_delivery)::date + ('1 day'::interval * (ma.supply_days)::double precision)) <= CURRENT_DATE) THEN 'EXPIRED'::text
            WHEN (((mo.estimated_delivery)::date + ('1 day'::interval * (ma.supply_days)::double precision)) <= (CURRENT_DATE + '7 days'::interval)) THEN 'EXPIRING_SOON'::text
            ELSE 'ACTIVE'::text
        END AS renewal_status
   FROM (((((public.medication_approvals ma
     JOIN public.medication_orders mo ON ((ma.id = mo.approval_id)))
     JOIN public.patient_medication_preferences pmp ON ((ma.preference_id = pmp.id)))
     JOIN public.medications m ON ((pmp.medication_id = m.id)))
     JOIN public.patients pt ON ((pmp.patient_id = pt.id)))
     JOIN public.profiles p ON ((pt.profile_id = p.id)))
  WHERE (ma.status = ANY (ARRAY['approved'::text, 'pending'::text]));


ALTER VIEW public.approval_renewal_status OWNER TO postgres;

--
-- TOC entry 4594 (class 0 OID 0)
-- Dependencies: 322
-- Name: VIEW approval_renewal_status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON VIEW public.approval_renewal_status IS 'View showing renewal status of all medication approvals';


--
-- TOC entry 303 (class 1259 OID 18409)
-- Name: assignment_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assignment_log (
    id integer NOT NULL,
    message text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.assignment_log OWNER TO postgres;

--
-- TOC entry 302 (class 1259 OID 18408)
-- Name: assignment_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.assignment_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.assignment_log_id_seq OWNER TO postgres;

--
-- TOC entry 4597 (class 0 OID 0)
-- Dependencies: 302
-- Name: assignment_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.assignment_log_id_seq OWNED BY public.assignment_log.id;


--
-- TOC entry 320 (class 1259 OID 18967)
-- Name: auth_trigger_debug_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_trigger_debug_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    step text,
    status text,
    error_message text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.auth_trigger_debug_log OWNER TO postgres;

--
-- TOC entry 317 (class 1259 OID 18839)
-- Name: auth_trigger_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_trigger_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    trigger_stage text NOT NULL,
    success boolean NOT NULL,
    error_message text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.auth_trigger_logs OWNER TO postgres;

--
-- TOC entry 314 (class 1259 OID 18702)
-- Name: clinical_notes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clinical_notes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    appointment_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    allergies text[] DEFAULT '{}'::text[],
    previous_medications text[] DEFAULT '{}'::text[],
    current_medications text[] DEFAULT '{}'::text[],
    clinical_note text DEFAULT ''::text,
    internal_note text DEFAULT ''::text,
    visit_summary text DEFAULT ''::text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    created_by uuid,
    last_updated_by uuid
);


ALTER TABLE public.clinical_notes OWNER TO postgres;

--
-- TOC entry 4601 (class 0 OID 0)
-- Dependencies: 314
-- Name: TABLE clinical_notes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.clinical_notes IS 'Clinical notes and medical information recorded during patient visits';


--
-- TOC entry 4602 (class 0 OID 0)
-- Dependencies: 314
-- Name: COLUMN clinical_notes.appointment_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.clinical_notes.appointment_id IS 'Links clinical note to specific appointment';


--
-- TOC entry 4603 (class 0 OID 0)
-- Dependencies: 314
-- Name: COLUMN clinical_notes.allergies; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.clinical_notes.allergies IS 'Array of patient allergies recorded during visit';


--
-- TOC entry 4604 (class 0 OID 0)
-- Dependencies: 314
-- Name: COLUMN clinical_notes.previous_medications; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.clinical_notes.previous_medications IS 'Array of previous medications mentioned during visit';


--
-- TOC entry 4605 (class 0 OID 0)
-- Dependencies: 314
-- Name: COLUMN clinical_notes.current_medications; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.clinical_notes.current_medications IS 'Array of current medications mentioned during visit';


--
-- TOC entry 4606 (class 0 OID 0)
-- Dependencies: 314
-- Name: COLUMN clinical_notes.clinical_note; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.clinical_notes.clinical_note IS 'Main clinical observations and notes';


--
-- TOC entry 4607 (class 0 OID 0)
-- Dependencies: 314
-- Name: COLUMN clinical_notes.internal_note; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.clinical_notes.internal_note IS 'Internal provider notes, not visible to patients';


--
-- TOC entry 4608 (class 0 OID 0)
-- Dependencies: 314
-- Name: COLUMN clinical_notes.visit_summary; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.clinical_notes.visit_summary IS 'Auto-generated or custom summary of the visit';


--
-- TOC entry 321 (class 1259 OID 19024)
-- Name: faxes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faxes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    approval_id uuid NOT NULL,
    preference_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    fax_number text NOT NULL,
    fax_content text,
    fax_status text DEFAULT 'sent'::text NOT NULL,
    faxed_at timestamp with time zone DEFAULT now() NOT NULL,
    delivery_confirmation_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    provider_profile_id uuid NOT NULL,
    patient_profile_id uuid NOT NULL,
    CONSTRAINT faxes_fax_status_check CHECK ((fax_status = ANY (ARRAY['sent'::text, 'delivered'::text, 'failed'::text, 'pending'::text])))
);


ALTER TABLE public.faxes OWNER TO postgres;

--
-- TOC entry 4610 (class 0 OID 0)
-- Dependencies: 321
-- Name: TABLE faxes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.faxes IS 'Tracks all fax communications for medication prescriptions';


--
-- TOC entry 4611 (class 0 OID 0)
-- Dependencies: 321
-- Name: COLUMN faxes.approval_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.faxes.approval_id IS 'Reference to the medication approval that was faxed';


--
-- TOC entry 4612 (class 0 OID 0)
-- Dependencies: 321
-- Name: COLUMN faxes.preference_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.faxes.preference_id IS 'Reference to the patient medication preference';


--
-- TOC entry 4613 (class 0 OID 0)
-- Dependencies: 321
-- Name: COLUMN faxes.fax_number; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.faxes.fax_number IS 'Phone number or fax identifier where prescription was sent';


--
-- TOC entry 4614 (class 0 OID 0)
-- Dependencies: 321
-- Name: COLUMN faxes.fax_content; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.faxes.fax_content IS 'Content or description of what was faxed';


--
-- TOC entry 4615 (class 0 OID 0)
-- Dependencies: 321
-- Name: COLUMN faxes.fax_status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.faxes.fax_status IS 'Status of the fax transmission';


--
-- TOC entry 4616 (class 0 OID 0)
-- Dependencies: 321
-- Name: COLUMN faxes.faxed_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.faxes.faxed_at IS 'When the fax was sent';


--
-- TOC entry 4617 (class 0 OID 0)
-- Dependencies: 321
-- Name: COLUMN faxes.delivery_confirmation_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.faxes.delivery_confirmation_at IS 'When delivery was confirmed';


--
-- TOC entry 4618 (class 0 OID 0)
-- Dependencies: 321
-- Name: COLUMN faxes.provider_profile_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.faxes.provider_profile_id IS 'Direct reference to provider auth user ID';


--
-- TOC entry 4619 (class 0 OID 0)
-- Dependencies: 321
-- Name: COLUMN faxes.patient_profile_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.faxes.patient_profile_id IS 'Direct reference to patient auth user ID';


--
-- TOC entry 318 (class 1259 OID 18890)
-- Name: medication_dosages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.medication_dosages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    medication_id uuid NOT NULL,
    strength text NOT NULL,
    unit_price numeric(10,2) DEFAULT 0 NOT NULL,
    available boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.medication_dosages OWNER TO postgres;

--
-- TOC entry 4621 (class 0 OID 0)
-- Dependencies: 318
-- Name: TABLE medication_dosages; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.medication_dosages IS 'Stores multiple dosage options for each medication. Replaces the single strength field in medications table.';


--
-- TOC entry 301 (class 1259 OID 18339)
-- Name: patient_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    treatment_type text DEFAULT 'general_care'::text,
    is_primary boolean DEFAULT false,
    assigned_date timestamp with time zone DEFAULT now(),
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.patient_assignments OWNER TO postgres;

--
-- TOC entry 309 (class 1259 OID 18570)
-- Name: provider_availability_overrides; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provider_availability_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid NOT NULL,
    date date NOT NULL,
    start_time time without time zone,
    end_time time without time zone,
    available boolean NOT NULL,
    reason text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_override_time CHECK (((available = false) OR ((available = true) AND (start_time IS NOT NULL) AND (end_time IS NOT NULL) AND (end_time > start_time))))
);


ALTER TABLE public.provider_availability_overrides OWNER TO postgres;

--
-- TOC entry 4624 (class 0 OID 0)
-- Dependencies: 309
-- Name: TABLE provider_availability_overrides; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.provider_availability_overrides IS 'Date-specific availability changes (vacations, special hours, etc.)';


--
-- TOC entry 4625 (class 0 OID 0)
-- Dependencies: 309
-- Name: COLUMN provider_availability_overrides.available; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.provider_availability_overrides.available IS 'false=unavailable, true=special availability override';


--
-- TOC entry 308 (class 1259 OID 18547)
-- Name: provider_schedules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provider_schedules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid NOT NULL,
    day_of_week integer NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    slot_duration_minutes integer DEFAULT 30 NOT NULL,
    treatment_types text[] DEFAULT '{}'::text[],
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT provider_schedules_day_of_week_check CHECK (((day_of_week >= 0) AND (day_of_week <= 6))),
    CONSTRAINT provider_schedules_slot_duration_minutes_check CHECK ((slot_duration_minutes > 0)),
    CONSTRAINT valid_time_range CHECK ((end_time > start_time))
);


ALTER TABLE public.provider_schedules OWNER TO postgres;

--
-- TOC entry 4627 (class 0 OID 0)
-- Dependencies: 308
-- Name: TABLE provider_schedules; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.provider_schedules IS 'Recurring weekly availability schedules for providers';


--
-- TOC entry 4628 (class 0 OID 0)
-- Dependencies: 308
-- Name: COLUMN provider_schedules.day_of_week; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.provider_schedules.day_of_week IS '0=Sunday, 1=Monday, ..., 6=Saturday';


--
-- TOC entry 4629 (class 0 OID 0)
-- Dependencies: 308
-- Name: COLUMN provider_schedules.treatment_types; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.provider_schedules.treatment_types IS 'Empty array means available for all treatment types';


--
-- TOC entry 299 (class 1259 OID 18302)
-- Name: providers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    specialty text,
    license_number text,
    phone text,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.providers OWNER TO postgres;

--
-- TOC entry 312 (class 1259 OID 18691)
-- Name: provider_availability_summary; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.provider_availability_summary AS
 SELECT p.id AS provider_id,
    ((prof.first_name || ' '::text) || prof.last_name) AS provider_name,
    ps.day_of_week,
        CASE ps.day_of_week
            WHEN 0 THEN 'Sunday'::text
            WHEN 1 THEN 'Monday'::text
            WHEN 2 THEN 'Tuesday'::text
            WHEN 3 THEN 'Wednesday'::text
            WHEN 4 THEN 'Thursday'::text
            WHEN 5 THEN 'Friday'::text
            WHEN 6 THEN 'Saturday'::text
            ELSE NULL::text
        END AS day_name,
    ps.start_time,
    ps.end_time,
    ps.slot_duration_minutes,
    ps.treatment_types,
    ps.active
   FROM ((public.providers p
     JOIN public.profiles prof ON ((p.profile_id = prof.id)))
     JOIN public.provider_schedules ps ON ((p.id = ps.provider_id)))
  ORDER BY p.id, ps.day_of_week, ps.start_time;


ALTER VIEW public.provider_availability_summary OWNER TO postgres;

--
-- TOC entry 4632 (class 0 OID 0)
-- Dependencies: 312
-- Name: VIEW provider_availability_summary; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON VIEW public.provider_availability_summary IS 'Easy view of all provider schedules with readable day names';


--
-- TOC entry 313 (class 1259 OID 18696)
-- Name: upcoming_appointments_summary; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.upcoming_appointments_summary AS
 SELECT a.id AS appointment_id,
    ((patient_prof.first_name || ' '::text) || patient_prof.last_name) AS patient_name,
    ((provider_prof.first_name || ' '::text) || provider_prof.last_name) AS provider_name,
    a.appointment_date,
    a.start_time,
    a.end_time,
    a.treatment_type,
    a.appointment_type,
    a.status,
    a.created_at
   FROM ((((public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
     JOIN public.profiles patient_prof ON ((p.profile_id = patient_prof.id)))
     JOIN public.providers prov ON ((a.provider_id = prov.id)))
     JOIN public.profiles provider_prof ON ((prov.profile_id = provider_prof.id)))
  WHERE (a.appointment_date >= CURRENT_DATE)
  ORDER BY a.appointment_date, a.start_time;


ALTER VIEW public.upcoming_appointments_summary OWNER TO postgres;

--
-- TOC entry 4634 (class 0 OID 0)
-- Dependencies: 313
-- Name: VIEW upcoming_appointments_summary; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON VIEW public.upcoming_appointments_summary IS 'Overview of all upcoming appointments with patient and provider names';


--
-- TOC entry 319 (class 1259 OID 18920)
-- Name: visit_addendums; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.visit_addendums (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    visit_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT visit_addendums_content_not_empty CHECK ((length(TRIM(BOTH FROM content)) > 0))
);


ALTER TABLE public.visit_addendums OWNER TO postgres;

--
-- TOC entry 4636 (class 0 OID 0)
-- Dependencies: 319
-- Name: TABLE visit_addendums; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.visit_addendums IS 'Addendums to previous visits for additional notes or corrections';


--
-- TOC entry 4637 (class 0 OID 0)
-- Dependencies: 319
-- Name: COLUMN visit_addendums.visit_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.visit_addendums.visit_id IS 'Links addendum to specific appointment/visit';


--
-- TOC entry 4638 (class 0 OID 0)
-- Dependencies: 319
-- Name: COLUMN visit_addendums.provider_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.visit_addendums.provider_id IS 'Provider who created the addendum';


--
-- TOC entry 4639 (class 0 OID 0)
-- Dependencies: 319
-- Name: COLUMN visit_addendums.content; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.visit_addendums.content IS 'Content of the addendum';


--
-- TOC entry 4640 (class 0 OID 0)
-- Dependencies: 319
-- Name: COLUMN visit_addendums.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.visit_addendums.created_at IS 'When the addendum was created';


--
-- TOC entry 316 (class 1259 OID 18760)
-- Name: visit_interactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.visit_interactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinical_note_id uuid NOT NULL,
    appointment_id uuid NOT NULL,
    interaction_type text NOT NULL,
    details text,
    provider_notes text,
    created_at timestamp with time zone DEFAULT now(),
    performed_by uuid NOT NULL,
    medication_id uuid,
    medication_name text,
    previous_dosage text,
    new_dosage text,
    previous_frequency text,
    new_frequency text,
    previous_status text,
    new_status text,
    CONSTRAINT visit_interactions_interaction_type_check CHECK ((interaction_type = ANY (ARRAY['treatment_plan_update'::text, 'follow_up_scheduled'::text, 'referral_made'::text, 'lab_ordered'::text, 'allergy_noted'::text, 'vital_signs_recorded'::text]))),
    CONSTRAINT visit_interactions_new_status_check CHECK (((new_status IS NULL) OR (new_status = ANY (ARRAY['pending'::text, 'approved'::text, 'denied'::text, 'discontinued'::text]))))
);


ALTER TABLE public.visit_interactions OWNER TO postgres;

--
-- TOC entry 4642 (class 0 OID 0)
-- Dependencies: 316
-- Name: TABLE visit_interactions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.visit_interactions IS 'General interactions and activities during visits (non-medication)';


--
-- TOC entry 4643 (class 0 OID 0)
-- Dependencies: 316
-- Name: COLUMN visit_interactions.interaction_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.visit_interactions.interaction_type IS 'Type of interaction: treatment_plan_update, follow_up_scheduled, etc.';


--
-- TOC entry 4644 (class 0 OID 0)
-- Dependencies: 316
-- Name: COLUMN visit_interactions.details; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.visit_interactions.details IS 'General details about the interaction';


--
-- TOC entry 315 (class 1259 OID 18735)
-- Name: visit_medication_adjustments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.visit_medication_adjustments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinical_note_id uuid NOT NULL,
    appointment_id uuid NOT NULL,
    preference_id uuid NOT NULL,
    previous_dosage text,
    previous_frequency text,
    previous_status text,
    previous_provider_notes text,
    new_dosage text,
    new_frequency text,
    new_status text,
    new_provider_notes text,
    adjustment_reason text,
    provider_notes text,
    created_at timestamp with time zone DEFAULT now(),
    performed_by uuid NOT NULL,
    new_supply_days integer,
    CONSTRAINT visit_medication_adjustments_new_status_check CHECK ((new_status = ANY (ARRAY['pending'::text, 'approved'::text, 'denied'::text, 'discontinued'::text])))
);


ALTER TABLE public.visit_medication_adjustments OWNER TO postgres;

--
-- TOC entry 4646 (class 0 OID 0)
-- Dependencies: 315
-- Name: TABLE visit_medication_adjustments; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.visit_medication_adjustments IS 'Medication adjustments made during visits, links to patient_medication_preferences';


--
-- TOC entry 4647 (class 0 OID 0)
-- Dependencies: 315
-- Name: COLUMN visit_medication_adjustments.preference_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.visit_medication_adjustments.preference_id IS 'Links to existing patient_medication_preferences table';


--
-- TOC entry 4648 (class 0 OID 0)
-- Dependencies: 315
-- Name: COLUMN visit_medication_adjustments.adjustment_reason; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.visit_medication_adjustments.adjustment_reason IS 'Reason for the medication adjustment';


--
-- TOC entry 4649 (class 0 OID 0)
-- Dependencies: 315
-- Name: COLUMN visit_medication_adjustments.new_supply_days; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.visit_medication_adjustments.new_supply_days IS 'Number of days of medication supply when approved via medication adjustments';


--
-- TOC entry 3734 (class 2604 OID 16473)
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- TOC entry 3764 (class 2604 OID 18412)
-- Name: assignment_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignment_log ALTER COLUMN id SET DEFAULT nextval('public.assignment_log_id_seq'::regclass);


--
-- TOC entry 3924 (class 2606 OID 18061)
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- TOC entry 3897 (class 2606 OID 16494)
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 3947 (class 2606 OID 18167)
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- TOC entry 3903 (class 2606 OID 18185)
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- TOC entry 3905 (class 2606 OID 18195)
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- TOC entry 3895 (class 2606 OID 16487)
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- TOC entry 3926 (class 2606 OID 18054)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- TOC entry 3922 (class 2606 OID 18042)
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- TOC entry 3914 (class 2606 OID 18235)
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- TOC entry 3916 (class 2606 OID 18029)
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- TOC entry 3957 (class 2606 OID 18256)
-- Name: oauth_clients oauth_clients_client_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_client_id_key UNIQUE (client_id);


--
-- TOC entry 3960 (class 2606 OID 18254)
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- TOC entry 3951 (class 2606 OID 18220)
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 3889 (class 2606 OID 16477)
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 3892 (class 2606 OID 17972)
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- TOC entry 3936 (class 2606 OID 18101)
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- TOC entry 3938 (class 2606 OID 18099)
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 3943 (class 2606 OID 18115)
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- TOC entry 3900 (class 2606 OID 16500)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 3909 (class 2606 OID 17993)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3933 (class 2606 OID 18082)
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- TOC entry 3928 (class 2606 OID 18073)
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 3882 (class 2606 OID 18155)
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- TOC entry 3884 (class 2606 OID 16464)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3978 (class 2606 OID 18331)
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- TOC entry 3980 (class 2606 OID 18333)
-- Name: admins admins_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_profile_id_key UNIQUE (profile_id);


--
-- TOC entry 4047 (class 2606 OID 18635)
-- Name: appointment_history appointment_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment_history
    ADD CONSTRAINT appointment_history_pkey PRIMARY KEY (id);


--
-- TOC entry 4034 (class 2606 OID 18607)
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- TOC entry 3990 (class 2606 OID 18417)
-- Name: assignment_log assignment_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignment_log
    ADD CONSTRAINT assignment_log_pkey PRIMARY KEY (id);


--
-- TOC entry 4095 (class 2606 OID 18975)
-- Name: auth_trigger_debug_log auth_trigger_debug_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_trigger_debug_log
    ADD CONSTRAINT auth_trigger_debug_log_pkey PRIMARY KEY (id);


--
-- TOC entry 4081 (class 2606 OID 18847)
-- Name: auth_trigger_logs auth_trigger_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_trigger_logs
    ADD CONSTRAINT auth_trigger_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 4051 (class 2606 OID 18717)
-- Name: clinical_notes clinical_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_pkey PRIMARY KEY (id);


--
-- TOC entry 4097 (class 2606 OID 19036)
-- Name: faxes faxes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_pkey PRIMARY KEY (id);


--
-- TOC entry 4011 (class 2606 OID 18465)
-- Name: medication_approvals medication_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_pkey PRIMARY KEY (id);


--
-- TOC entry 4086 (class 2606 OID 18904)
-- Name: medication_dosages medication_dosages_medication_id_strength_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medication_dosages
    ADD CONSTRAINT medication_dosages_medication_id_strength_key UNIQUE (medication_id, strength);


--
-- TOC entry 4088 (class 2606 OID 18902)
-- Name: medication_dosages medication_dosages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medication_dosages
    ADD CONSTRAINT medication_dosages_pkey PRIMARY KEY (id);


--
-- TOC entry 4020 (class 2606 OID 18488)
-- Name: medication_orders medication_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_pkey PRIMARY KEY (id);


--
-- TOC entry 3994 (class 2606 OID 18430)
-- Name: medications medications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medications
    ADD CONSTRAINT medications_pkey PRIMARY KEY (id);


--
-- TOC entry 3986 (class 2606 OID 18352)
-- Name: patient_assignments patient_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT patient_assignments_pkey PRIMARY KEY (id);


--
-- TOC entry 4003 (class 2606 OID 18444)
-- Name: patient_medication_preferences patient_medication_preferences_patient_id_medication_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_patient_id_medication_id_key UNIQUE (patient_id, medication_id);


--
-- TOC entry 4005 (class 2606 OID 18442)
-- Name: patient_medication_preferences patient_medication_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_pkey PRIMARY KEY (id);


--
-- TOC entry 3969 (class 2606 OID 18294)
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- TOC entry 3971 (class 2606 OID 18296)
-- Name: patients patients_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_profile_id_key UNIQUE (profile_id);


--
-- TOC entry 3964 (class 2606 OID 18278)
-- Name: profiles profiles_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_email_key UNIQUE (email);


--
-- TOC entry 3966 (class 2606 OID 18276)
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- TOC entry 4030 (class 2606 OID 18579)
-- Name: provider_availability_overrides provider_availability_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_availability_overrides
    ADD CONSTRAINT provider_availability_overrides_pkey PRIMARY KEY (id);


--
-- TOC entry 4024 (class 2606 OID 18562)
-- Name: provider_schedules provider_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_schedules
    ADD CONSTRAINT provider_schedules_pkey PRIMARY KEY (id);


--
-- TOC entry 3974 (class 2606 OID 18312)
-- Name: providers providers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_pkey PRIMARY KEY (id);


--
-- TOC entry 3976 (class 2606 OID 18314)
-- Name: providers providers_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_profile_id_key UNIQUE (profile_id);


--
-- TOC entry 4061 (class 2606 OID 18719)
-- Name: clinical_notes unique_appointment_clinical_note; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT unique_appointment_clinical_note UNIQUE (appointment_id);


--
-- TOC entry 4063 (class 2606 OID 18816)
-- Name: clinical_notes unique_clinical_note_per_appointment; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT unique_clinical_note_per_appointment UNIQUE (appointment_id);


--
-- TOC entry 3988 (class 2606 OID 18354)
-- Name: patient_assignments unique_primary_assignment; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT unique_primary_assignment EXCLUDE USING btree (patient_id WITH =) WHERE (((is_primary = true) AND (active = true)));


--
-- TOC entry 4032 (class 2606 OID 18581)
-- Name: provider_availability_overrides unique_provider_override; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_availability_overrides
    ADD CONSTRAINT unique_provider_override UNIQUE (provider_id, date, start_time, end_time);


--
-- TOC entry 4026 (class 2606 OID 18564)
-- Name: provider_schedules unique_provider_schedule; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_schedules
    ADD CONSTRAINT unique_provider_schedule UNIQUE (provider_id, day_of_week, start_time, end_time);


--
-- TOC entry 4045 (class 2606 OID 18609)
-- Name: appointments unique_provider_slot; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT unique_provider_slot UNIQUE (provider_id, appointment_date, start_time);


--
-- TOC entry 4093 (class 2606 OID 18929)
-- Name: visit_addendums visit_addendums_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visit_addendums
    ADD CONSTRAINT visit_addendums_pkey PRIMARY KEY (id);


--
-- TOC entry 4079 (class 2606 OID 18769)
-- Name: visit_interactions visit_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visit_interactions
    ADD CONSTRAINT visit_interactions_pkey PRIMARY KEY (id);


--
-- TOC entry 4070 (class 2606 OID 18744)
-- Name: visit_medication_adjustments visit_medication_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_pkey PRIMARY KEY (id);


--
-- TOC entry 3898 (class 1259 OID 16495)
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- TOC entry 3872 (class 1259 OID 17982)
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3873 (class 1259 OID 17984)
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3874 (class 1259 OID 17985)
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3912 (class 1259 OID 18063)
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- TOC entry 3945 (class 1259 OID 18171)
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- TOC entry 3901 (class 1259 OID 18151)
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- TOC entry 4651 (class 0 OID 0)
-- Dependencies: 3901
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- TOC entry 3906 (class 1259 OID 17979)
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- TOC entry 3948 (class 1259 OID 18168)
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- TOC entry 3949 (class 1259 OID 18169)
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- TOC entry 3920 (class 1259 OID 18174)
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- TOC entry 3917 (class 1259 OID 18035)
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- TOC entry 3918 (class 1259 OID 18180)
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- TOC entry 3955 (class 1259 OID 18257)
-- Name: oauth_clients_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_clients_client_id_idx ON auth.oauth_clients USING btree (client_id);


--
-- TOC entry 3958 (class 1259 OID 18258)
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- TOC entry 3952 (class 1259 OID 18227)
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- TOC entry 3953 (class 1259 OID 18226)
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- TOC entry 3954 (class 1259 OID 18228)
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- TOC entry 3875 (class 1259 OID 17986)
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3876 (class 1259 OID 17983)
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3885 (class 1259 OID 16478)
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- TOC entry 3886 (class 1259 OID 16479)
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- TOC entry 3887 (class 1259 OID 17978)
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- TOC entry 3890 (class 1259 OID 18065)
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- TOC entry 3893 (class 1259 OID 18170)
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- TOC entry 3939 (class 1259 OID 18107)
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- TOC entry 3940 (class 1259 OID 18172)
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- TOC entry 3941 (class 1259 OID 18122)
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- TOC entry 3944 (class 1259 OID 18121)
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- TOC entry 3907 (class 1259 OID 18173)
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- TOC entry 3910 (class 1259 OID 18064)
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- TOC entry 3931 (class 1259 OID 18089)
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- TOC entry 3934 (class 1259 OID 18088)
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- TOC entry 3929 (class 1259 OID 18074)
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- TOC entry 3930 (class 1259 OID 18236)
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- TOC entry 3919 (class 1259 OID 18233)
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- TOC entry 3911 (class 1259 OID 18062)
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- TOC entry 3877 (class 1259 OID 18142)
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- TOC entry 4652 (class 0 OID 0)
-- Dependencies: 3877
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- TOC entry 3878 (class 1259 OID 17980)
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- TOC entry 3879 (class 1259 OID 16468)
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- TOC entry 3880 (class 1259 OID 18197)
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- TOC entry 3981 (class 1259 OID 18369)
-- Name: idx_admins_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_admins_profile_id ON public.admins USING btree (profile_id);


--
-- TOC entry 4048 (class 1259 OID 18651)
-- Name: idx_appointment_history_appointment; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_appointment_history_appointment ON public.appointment_history USING btree (appointment_id);


--
-- TOC entry 4049 (class 1259 OID 18652)
-- Name: idx_appointment_history_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_appointment_history_created ON public.appointment_history USING btree (created_at);


--
-- TOC entry 4035 (class 1259 OID 18650)
-- Name: idx_appointments_assignment; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_appointments_assignment ON public.appointments USING btree (assignment_id);


--
-- TOC entry 4036 (class 1259 OID 18647)
-- Name: idx_appointments_date_range; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_appointments_date_range ON public.appointments USING btree (appointment_date);


--
-- TOC entry 4037 (class 1259 OID 18645)
-- Name: idx_appointments_patient_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_appointments_patient_id ON public.appointments USING btree (patient_id);


--
-- TOC entry 4038 (class 1259 OID 18648)
-- Name: idx_appointments_provider_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_appointments_provider_date ON public.appointments USING btree (provider_id, appointment_date);


--
-- TOC entry 4039 (class 1259 OID 18646)
-- Name: idx_appointments_provider_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_appointments_provider_id ON public.appointments USING btree (provider_id);


--
-- TOC entry 4040 (class 1259 OID 18961)
-- Name: idx_appointments_reschedule_source; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_appointments_reschedule_source ON public.appointments USING btree (is_reschedule_source);


--
-- TOC entry 4041 (class 1259 OID 18959)
-- Name: idx_appointments_rescheduled_from; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_appointments_rescheduled_from ON public.appointments USING btree (rescheduled_from_id);


--
-- TOC entry 4042 (class 1259 OID 18960)
-- Name: idx_appointments_rescheduled_to; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_appointments_rescheduled_to ON public.appointments USING btree (rescheduled_to_id);


--
-- TOC entry 4043 (class 1259 OID 18649)
-- Name: idx_appointments_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_appointments_status ON public.appointments USING btree (status);


--
-- TOC entry 4052 (class 1259 OID 18780)
-- Name: idx_clinical_notes_appointment; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clinical_notes_appointment ON public.clinical_notes USING btree (appointment_id);


--
-- TOC entry 4053 (class 1259 OID 18809)
-- Name: idx_clinical_notes_appointment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clinical_notes_appointment_id ON public.clinical_notes USING btree (appointment_id);


--
-- TOC entry 4054 (class 1259 OID 18783)
-- Name: idx_clinical_notes_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clinical_notes_created_at ON public.clinical_notes USING btree (created_at);


--
-- TOC entry 4055 (class 1259 OID 18781)
-- Name: idx_clinical_notes_patient; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clinical_notes_patient ON public.clinical_notes USING btree (patient_id);


--
-- TOC entry 4056 (class 1259 OID 18810)
-- Name: idx_clinical_notes_patient_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clinical_notes_patient_id ON public.clinical_notes USING btree (patient_id);


--
-- TOC entry 4057 (class 1259 OID 18782)
-- Name: idx_clinical_notes_provider; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clinical_notes_provider ON public.clinical_notes USING btree (provider_id);


--
-- TOC entry 4058 (class 1259 OID 18811)
-- Name: idx_clinical_notes_provider_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clinical_notes_provider_id ON public.clinical_notes USING btree (provider_id);


--
-- TOC entry 4059 (class 1259 OID 18784)
-- Name: idx_clinical_notes_updated_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clinical_notes_updated_at ON public.clinical_notes USING btree (updated_at);


--
-- TOC entry 4098 (class 1259 OID 19057)
-- Name: idx_faxes_approval_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_faxes_approval_id ON public.faxes USING btree (approval_id);


--
-- TOC entry 4099 (class 1259 OID 19061)
-- Name: idx_faxes_faxed_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_faxes_faxed_at ON public.faxes USING btree (faxed_at);


--
-- TOC entry 4100 (class 1259 OID 19059)
-- Name: idx_faxes_patient_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_faxes_patient_id ON public.faxes USING btree (patient_id);


--
-- TOC entry 4101 (class 1259 OID 19112)
-- Name: idx_faxes_patient_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_faxes_patient_profile_id ON public.faxes USING btree (patient_profile_id);


--
-- TOC entry 4102 (class 1259 OID 19058)
-- Name: idx_faxes_preference_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_faxes_preference_id ON public.faxes USING btree (preference_id);


--
-- TOC entry 4103 (class 1259 OID 19060)
-- Name: idx_faxes_provider_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_faxes_provider_id ON public.faxes USING btree (provider_id);


--
-- TOC entry 4104 (class 1259 OID 19111)
-- Name: idx_faxes_provider_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_faxes_provider_profile_id ON public.faxes USING btree (provider_profile_id);


--
-- TOC entry 4105 (class 1259 OID 19062)
-- Name: idx_faxes_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_faxes_status ON public.faxes USING btree (fax_status);


--
-- TOC entry 4006 (class 1259 OID 18508)
-- Name: idx_medication_approvals_provider_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medication_approvals_provider_id ON public.medication_approvals USING btree (provider_id);


--
-- TOC entry 4007 (class 1259 OID 19110)
-- Name: idx_medication_approvals_provider_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medication_approvals_provider_profile_id ON public.medication_approvals USING btree (provider_profile_id);


--
-- TOC entry 4008 (class 1259 OID 18509)
-- Name: idx_medication_approvals_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medication_approvals_status ON public.medication_approvals USING btree (status);


--
-- TOC entry 4009 (class 1259 OID 19115)
-- Name: idx_medication_approvals_supply_days; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medication_approvals_supply_days ON public.medication_approvals USING btree (supply_days);


--
-- TOC entry 4082 (class 1259 OID 18911)
-- Name: idx_medication_dosages_available; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medication_dosages_available ON public.medication_dosages USING btree (available);


--
-- TOC entry 4083 (class 1259 OID 18910)
-- Name: idx_medication_dosages_medication_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medication_dosages_medication_id ON public.medication_dosages USING btree (medication_id);


--
-- TOC entry 4084 (class 1259 OID 18912)
-- Name: idx_medication_dosages_sort_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medication_dosages_sort_order ON public.medication_dosages USING btree (sort_order);


--
-- TOC entry 4012 (class 1259 OID 18512)
-- Name: idx_medication_orders_fulfillment_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medication_orders_fulfillment_status ON public.medication_orders USING btree (fulfillment_status);


--
-- TOC entry 4013 (class 1259 OID 18541)
-- Name: idx_medication_orders_patient_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medication_orders_patient_created ON public.medication_orders USING btree (patient_id, created_at DESC);


--
-- TOC entry 4014 (class 1259 OID 18510)
-- Name: idx_medication_orders_patient_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medication_orders_patient_id ON public.medication_orders USING btree (patient_id);


--
-- TOC entry 4015 (class 1259 OID 19114)
-- Name: idx_medication_orders_patient_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medication_orders_patient_profile_id ON public.medication_orders USING btree (patient_profile_id);


--
-- TOC entry 4016 (class 1259 OID 18511)
-- Name: idx_medication_orders_payment_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medication_orders_payment_status ON public.medication_orders USING btree (payment_status);


--
-- TOC entry 4017 (class 1259 OID 19113)
-- Name: idx_medication_orders_provider_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medication_orders_provider_profile_id ON public.medication_orders USING btree (provider_profile_id);


--
-- TOC entry 4018 (class 1259 OID 18539)
-- Name: idx_medication_orders_sent_to_pharmacy; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medication_orders_sent_to_pharmacy ON public.medication_orders USING btree (sent_to_pharmacy);


--
-- TOC entry 3991 (class 1259 OID 18505)
-- Name: idx_medications_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medications_active ON public.medications USING btree (active);


--
-- TOC entry 3992 (class 1259 OID 18504)
-- Name: idx_medications_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_medications_category ON public.medications USING btree (category);


--
-- TOC entry 3982 (class 1259 OID 18372)
-- Name: idx_patient_assignments_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patient_assignments_active ON public.patient_assignments USING btree (active);


--
-- TOC entry 3983 (class 1259 OID 18370)
-- Name: idx_patient_assignments_patient_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patient_assignments_patient_id ON public.patient_assignments USING btree (patient_id);


--
-- TOC entry 3984 (class 1259 OID 18371)
-- Name: idx_patient_assignments_provider_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patient_assignments_provider_id ON public.patient_assignments USING btree (provider_id);


--
-- TOC entry 3995 (class 1259 OID 19063)
-- Name: idx_patient_medication_preferences_faxed; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patient_medication_preferences_faxed ON public.patient_medication_preferences USING btree (faxed);


--
-- TOC entry 3996 (class 1259 OID 19064)
-- Name: idx_patient_medication_preferences_next_due; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patient_medication_preferences_next_due ON public.patient_medication_preferences USING btree (next_prescription_due);


--
-- TOC entry 3997 (class 1259 OID 18506)
-- Name: idx_patient_medication_preferences_patient_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patient_medication_preferences_patient_id ON public.patient_medication_preferences USING btree (patient_id);


--
-- TOC entry 3998 (class 1259 OID 19140)
-- Name: idx_patient_medication_preferences_refill_requested; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patient_medication_preferences_refill_requested ON public.patient_medication_preferences USING btree (refill_requested);


--
-- TOC entry 3999 (class 1259 OID 18507)
-- Name: idx_patient_medication_preferences_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patient_medication_preferences_status ON public.patient_medication_preferences USING btree (status);


--
-- TOC entry 4000 (class 1259 OID 19129)
-- Name: idx_patient_medication_preferences_supply_days; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patient_medication_preferences_supply_days ON public.patient_medication_preferences USING btree (supply_days);


--
-- TOC entry 3967 (class 1259 OID 18367)
-- Name: idx_patients_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_patients_profile_id ON public.patients USING btree (profile_id);


--
-- TOC entry 4001 (class 1259 OID 19141)
-- Name: idx_preferences_provider_approval; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_preferences_provider_approval ON public.patient_medication_preferences USING btree (status, refill_requested) WHERE ((status = 'pending'::text) AND (refill_requested = true));


--
-- TOC entry 3961 (class 1259 OID 18366)
-- Name: idx_profiles_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_profiles_email ON public.profiles USING btree (email);


--
-- TOC entry 3962 (class 1259 OID 18365)
-- Name: idx_profiles_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_profiles_role ON public.profiles USING btree (role);


--
-- TOC entry 4027 (class 1259 OID 18644)
-- Name: idx_provider_overrides_date_range; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_provider_overrides_date_range ON public.provider_availability_overrides USING btree (date);


--
-- TOC entry 4028 (class 1259 OID 18643)
-- Name: idx_provider_overrides_provider_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_provider_overrides_provider_date ON public.provider_availability_overrides USING btree (provider_id, date);


--
-- TOC entry 4021 (class 1259 OID 18642)
-- Name: idx_provider_schedules_day_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_provider_schedules_day_active ON public.provider_schedules USING btree (day_of_week, active);


--
-- TOC entry 4022 (class 1259 OID 18641)
-- Name: idx_provider_schedules_provider_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_provider_schedules_provider_id ON public.provider_schedules USING btree (provider_id);


--
-- TOC entry 3972 (class 1259 OID 18368)
-- Name: idx_providers_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_providers_profile_id ON public.providers USING btree (profile_id);


--
-- TOC entry 4089 (class 1259 OID 18942)
-- Name: idx_visit_addendums_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_visit_addendums_created_at ON public.visit_addendums USING btree (created_at);


--
-- TOC entry 4090 (class 1259 OID 18941)
-- Name: idx_visit_addendums_provider_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_visit_addendums_provider_id ON public.visit_addendums USING btree (provider_id);


--
-- TOC entry 4091 (class 1259 OID 18940)
-- Name: idx_visit_addendums_visit_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_visit_addendums_visit_id ON public.visit_addendums USING btree (visit_id);


--
-- TOC entry 4071 (class 1259 OID 18790)
-- Name: idx_visit_interactions_appointment; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_visit_interactions_appointment ON public.visit_interactions USING btree (appointment_id);


--
-- TOC entry 4072 (class 1259 OID 18813)
-- Name: idx_visit_interactions_appointment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_visit_interactions_appointment_id ON public.visit_interactions USING btree (appointment_id);


--
-- TOC entry 4073 (class 1259 OID 18789)
-- Name: idx_visit_interactions_clinical_note; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_visit_interactions_clinical_note ON public.visit_interactions USING btree (clinical_note_id);


--
-- TOC entry 4074 (class 1259 OID 18812)
-- Name: idx_visit_interactions_clinical_note_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_visit_interactions_clinical_note_id ON public.visit_interactions USING btree (clinical_note_id);


--
-- TOC entry 4075 (class 1259 OID 18792)
-- Name: idx_visit_interactions_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_visit_interactions_created_at ON public.visit_interactions USING btree (created_at);


--
-- TOC entry 4076 (class 1259 OID 18814)
-- Name: idx_visit_interactions_medication_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_visit_interactions_medication_id ON public.visit_interactions USING btree (medication_id);


--
-- TOC entry 4077 (class 1259 OID 18791)
-- Name: idx_visit_interactions_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_visit_interactions_type ON public.visit_interactions USING btree (interaction_type);


--
-- TOC entry 4064 (class 1259 OID 18786)
-- Name: idx_visit_medication_adjustments_appointment; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_visit_medication_adjustments_appointment ON public.visit_medication_adjustments USING btree (appointment_id);


--
-- TOC entry 4065 (class 1259 OID 18785)
-- Name: idx_visit_medication_adjustments_clinical_note; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_visit_medication_adjustments_clinical_note ON public.visit_medication_adjustments USING btree (clinical_note_id);


--
-- TOC entry 4066 (class 1259 OID 18788)
-- Name: idx_visit_medication_adjustments_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_visit_medication_adjustments_created_at ON public.visit_medication_adjustments USING btree (created_at);


--
-- TOC entry 4067 (class 1259 OID 18787)
-- Name: idx_visit_medication_adjustments_preference; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_visit_medication_adjustments_preference ON public.visit_medication_adjustments USING btree (preference_id);


--
-- TOC entry 4068 (class 1259 OID 19130)
-- Name: idx_visit_medication_adjustments_supply_days; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_visit_medication_adjustments_supply_days ON public.visit_medication_adjustments USING btree (new_supply_days);


--
-- TOC entry 4160 (class 2620 OID 19023)
-- Name: users on_auth_user_created; Type: TRIGGER; Schema: auth; Owner: supabase_auth_admin
--

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();


--
-- TOC entry 4174 (class 2620 OID 18656)
-- Name: appointments appointment_audit_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER appointment_audit_trigger AFTER INSERT OR DELETE OR UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.log_appointment_changes();


--
-- TOC entry 4175 (class 2620 OID 18689)
-- Name: appointments appointment_business_rules_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER appointment_business_rules_trigger BEFORE INSERT OR UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.validate_appointment_business_rules();


--
-- TOC entry 4167 (class 2620 OID 19138)
-- Name: patient_medication_preferences calculate_next_due_on_supply_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER calculate_next_due_on_supply_update BEFORE UPDATE ON public.patient_medication_preferences FOR EACH ROW EXECUTE FUNCTION public.calculate_next_prescription_due();


--
-- TOC entry 4653 (class 0 OID 0)
-- Dependencies: 4167
-- Name: TRIGGER calculate_next_due_on_supply_update ON patient_medication_preferences; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TRIGGER calculate_next_due_on_supply_update ON public.patient_medication_preferences IS 'Calculates next_prescription_due when supply_days is updated with approved status';


--
-- TOC entry 4170 (class 2620 OID 19126)
-- Name: medication_orders check_approval_expiry_on_delivery_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER check_approval_expiry_on_delivery_trigger AFTER UPDATE ON public.medication_orders FOR EACH ROW EXECUTE FUNCTION public.check_approval_expiry_on_delivery();


--
-- TOC entry 4181 (class 2620 OID 19072)
-- Name: faxes create_order_on_fax_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER create_order_on_fax_trigger AFTER INSERT ON public.faxes FOR EACH ROW EXECUTE FUNCTION public.create_order_on_fax();


--
-- TOC entry 4654 (class 0 OID 0)
-- Dependencies: 4181
-- Name: TRIGGER create_order_on_fax_trigger ON faxes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TRIGGER create_order_on_fax_trigger ON public.faxes IS 'Trigger to create medication order when fax is sent';


--
-- TOC entry 4164 (class 2620 OID 18377)
-- Name: admins update_admins_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_admins_updated_at BEFORE UPDATE ON public.admins FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4176 (class 2620 OID 18654)
-- Name: appointments update_appointments_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_appointments_updated_at BEFORE UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4177 (class 2620 OID 18795)
-- Name: clinical_notes update_clinical_note_editor_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_clinical_note_editor_trigger BEFORE UPDATE ON public.clinical_notes FOR EACH ROW EXECUTE FUNCTION public.update_clinical_note_editor();


--
-- TOC entry 4178 (class 2620 OID 18807)
-- Name: clinical_notes update_clinical_notes_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_clinical_notes_updated_at BEFORE UPDATE ON public.clinical_notes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4182 (class 2620 OID 19065)
-- Name: faxes update_faxes_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_faxes_updated_at BEFORE UPDATE ON public.faxes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4169 (class 2620 OID 18515)
-- Name: medication_approvals update_medication_approvals_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_medication_approvals_updated_at BEFORE UPDATE ON public.medication_approvals FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4180 (class 2620 OID 18913)
-- Name: medication_dosages update_medication_dosages_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_medication_dosages_updated_at BEFORE UPDATE ON public.medication_dosages FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4171 (class 2620 OID 18516)
-- Name: medication_orders update_medication_orders_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_medication_orders_updated_at BEFORE UPDATE ON public.medication_orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4166 (class 2620 OID 18513)
-- Name: medications update_medications_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_medications_updated_at BEFORE UPDATE ON public.medications FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4165 (class 2620 OID 18378)
-- Name: patient_assignments update_patient_assignments_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_patient_assignments_updated_at BEFORE UPDATE ON public.patient_assignments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4168 (class 2620 OID 18514)
-- Name: patient_medication_preferences update_patient_medication_preferences_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_patient_medication_preferences_updated_at BEFORE UPDATE ON public.patient_medication_preferences FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4162 (class 2620 OID 18375)
-- Name: patients update_patients_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_patients_updated_at BEFORE UPDATE ON public.patients FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4179 (class 2620 OID 19132)
-- Name: visit_medication_adjustments update_preference_on_adjustment_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_preference_on_adjustment_trigger AFTER INSERT ON public.visit_medication_adjustments FOR EACH ROW EXECUTE FUNCTION public.update_preference_on_medication_adjustment();


--
-- TOC entry 4655 (class 0 OID 0)
-- Dependencies: 4179
-- Name: TRIGGER update_preference_on_adjustment_trigger ON visit_medication_adjustments; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TRIGGER update_preference_on_adjustment_trigger ON public.visit_medication_adjustments IS 'Updates patient_medication_preferences when medication adjustments are approved, including supply_days and next_prescription_due calculation';


--
-- TOC entry 4172 (class 2620 OID 19068)
-- Name: medication_orders update_prescription_due_date_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_prescription_due_date_trigger AFTER UPDATE ON public.medication_orders FOR EACH ROW EXECUTE FUNCTION public.update_prescription_due_date();


--
-- TOC entry 4161 (class 2620 OID 18374)
-- Name: profiles update_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4173 (class 2620 OID 18653)
-- Name: provider_schedules update_provider_schedules_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_provider_schedules_updated_at BEFORE UPDATE ON public.provider_schedules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4163 (class 2620 OID 18376)
-- Name: providers update_providers_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_providers_updated_at BEFORE UPDATE ON public.providers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4107 (class 2606 OID 17966)
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4111 (class 2606 OID 18055)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4110 (class 2606 OID 18043)
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- TOC entry 4109 (class 2606 OID 18030)
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4116 (class 2606 OID 18221)
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4106 (class 2606 OID 17999)
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4113 (class 2606 OID 18102)
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4114 (class 2606 OID 18175)
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- TOC entry 4115 (class 2606 OID 18116)
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4108 (class 2606 OID 17994)
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4112 (class 2606 OID 18083)
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4120 (class 2606 OID 18334)
-- Name: admins admins_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4141 (class 2606 OID 18636)
-- Name: appointment_history appointment_history_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment_history
    ADD CONSTRAINT appointment_history_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4136 (class 2606 OID 18620)
-- Name: appointments appointments_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.patient_assignments(id);


--
-- TOC entry 4137 (class 2606 OID 18610)
-- Name: appointments appointments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4138 (class 2606 OID 18615)
-- Name: appointments appointments_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4139 (class 2606 OID 18949)
-- Name: appointments appointments_rescheduled_from_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_rescheduled_from_id_fkey FOREIGN KEY (rescheduled_from_id) REFERENCES public.appointments(id);


--
-- TOC entry 4140 (class 2606 OID 18954)
-- Name: appointments appointments_rescheduled_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_rescheduled_to_id_fkey FOREIGN KEY (rescheduled_to_id) REFERENCES public.appointments(id);


--
-- TOC entry 4150 (class 2606 OID 18848)
-- Name: auth_trigger_logs auth_trigger_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_trigger_logs
    ADD CONSTRAINT auth_trigger_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- TOC entry 4142 (class 2606 OID 18720)
-- Name: clinical_notes clinical_notes_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4143 (class 2606 OID 18725)
-- Name: clinical_notes clinical_notes_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4144 (class 2606 OID 18730)
-- Name: clinical_notes clinical_notes_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4154 (class 2606 OID 19037)
-- Name: faxes faxes_approval_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_approval_id_fkey FOREIGN KEY (approval_id) REFERENCES public.medication_approvals(id) ON DELETE CASCADE;


--
-- TOC entry 4155 (class 2606 OID 19047)
-- Name: faxes faxes_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4156 (class 2606 OID 19095)
-- Name: faxes faxes_patient_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_patient_profile_id_fkey FOREIGN KEY (patient_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4157 (class 2606 OID 19042)
-- Name: faxes faxes_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_preference_id_fkey FOREIGN KEY (preference_id) REFERENCES public.patient_medication_preferences(id) ON DELETE CASCADE;


--
-- TOC entry 4158 (class 2606 OID 19052)
-- Name: faxes faxes_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4159 (class 2606 OID 19090)
-- Name: faxes faxes_provider_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_provider_profile_id_fkey FOREIGN KEY (provider_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4126 (class 2606 OID 18466)
-- Name: medication_approvals medication_approvals_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_preference_id_fkey FOREIGN KEY (preference_id) REFERENCES public.patient_medication_preferences(id) ON DELETE CASCADE;


--
-- TOC entry 4127 (class 2606 OID 18471)
-- Name: medication_approvals medication_approvals_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4128 (class 2606 OID 19085)
-- Name: medication_approvals medication_approvals_provider_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_provider_profile_id_fkey FOREIGN KEY (provider_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4151 (class 2606 OID 18905)
-- Name: medication_dosages medication_dosages_medication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medication_dosages
    ADD CONSTRAINT medication_dosages_medication_id_fkey FOREIGN KEY (medication_id) REFERENCES public.medications(id) ON DELETE CASCADE;


--
-- TOC entry 4129 (class 2606 OID 18489)
-- Name: medication_orders medication_orders_approval_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_approval_id_fkey FOREIGN KEY (approval_id) REFERENCES public.medication_approvals(id) ON DELETE CASCADE;


--
-- TOC entry 4130 (class 2606 OID 18499)
-- Name: medication_orders medication_orders_medication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_medication_id_fkey FOREIGN KEY (medication_id) REFERENCES public.medications(id) ON DELETE CASCADE;


--
-- TOC entry 4131 (class 2606 OID 18494)
-- Name: medication_orders medication_orders_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4132 (class 2606 OID 19105)
-- Name: medication_orders medication_orders_patient_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_patient_profile_id_fkey FOREIGN KEY (patient_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4133 (class 2606 OID 19100)
-- Name: medication_orders medication_orders_provider_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_provider_profile_id_fkey FOREIGN KEY (provider_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4121 (class 2606 OID 18355)
-- Name: patient_assignments patient_assignments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT patient_assignments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4122 (class 2606 OID 18360)
-- Name: patient_assignments patient_assignments_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT patient_assignments_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4123 (class 2606 OID 18914)
-- Name: patient_medication_preferences patient_medication_preferences_medication_dosage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_medication_dosage_id_fkey FOREIGN KEY (medication_dosage_id) REFERENCES public.medication_dosages(id) ON DELETE SET NULL;


--
-- TOC entry 4124 (class 2606 OID 18450)
-- Name: patient_medication_preferences patient_medication_preferences_medication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_medication_id_fkey FOREIGN KEY (medication_id) REFERENCES public.medications(id) ON DELETE CASCADE;


--
-- TOC entry 4125 (class 2606 OID 18445)
-- Name: patient_medication_preferences patient_medication_preferences_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4118 (class 2606 OID 18297)
-- Name: patients patients_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4117 (class 2606 OID 18279)
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4135 (class 2606 OID 18582)
-- Name: provider_availability_overrides provider_availability_overrides_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_availability_overrides
    ADD CONSTRAINT provider_availability_overrides_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4134 (class 2606 OID 18565)
-- Name: provider_schedules provider_schedules_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_schedules
    ADD CONSTRAINT provider_schedules_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4119 (class 2606 OID 18315)
-- Name: providers providers_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4152 (class 2606 OID 18935)
-- Name: visit_addendums visit_addendums_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visit_addendums
    ADD CONSTRAINT visit_addendums_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4153 (class 2606 OID 18930)
-- Name: visit_addendums visit_addendums_visit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visit_addendums
    ADD CONSTRAINT visit_addendums_visit_id_fkey FOREIGN KEY (visit_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4148 (class 2606 OID 18775)
-- Name: visit_interactions visit_interactions_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visit_interactions
    ADD CONSTRAINT visit_interactions_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4149 (class 2606 OID 18770)
-- Name: visit_interactions visit_interactions_clinical_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visit_interactions
    ADD CONSTRAINT visit_interactions_clinical_note_id_fkey FOREIGN KEY (clinical_note_id) REFERENCES public.clinical_notes(id) ON DELETE CASCADE;


--
-- TOC entry 4145 (class 2606 OID 18750)
-- Name: visit_medication_adjustments visit_medication_adjustments_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4146 (class 2606 OID 18745)
-- Name: visit_medication_adjustments visit_medication_adjustments_clinical_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_clinical_note_id_fkey FOREIGN KEY (clinical_note_id) REFERENCES public.clinical_notes(id) ON DELETE CASCADE;


--
-- TOC entry 4147 (class 2606 OID 18755)
-- Name: visit_medication_adjustments visit_medication_adjustments_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_preference_id_fkey FOREIGN KEY (preference_id) REFERENCES public.patient_medication_preferences(id) ON DELETE CASCADE;


--
-- TOC entry 4337 (class 0 OID 16488)
-- Dependencies: 245
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4348 (class 0 OID 18161)
-- Dependencies: 293
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4339 (class 0 OID 17959)
-- Dependencies: 284
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4336 (class 0 OID 16481)
-- Dependencies: 244
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4343 (class 0 OID 18048)
-- Dependencies: 288
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4342 (class 0 OID 18036)
-- Dependencies: 287
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4341 (class 0 OID 18023)
-- Dependencies: 286
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4349 (class 0 OID 18211)
-- Dependencies: 294
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4335 (class 0 OID 16470)
-- Dependencies: 243
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4346 (class 0 OID 18090)
-- Dependencies: 291
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4347 (class 0 OID 18108)
-- Dependencies: 292
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4338 (class 0 OID 16496)
-- Dependencies: 246
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4340 (class 0 OID 17989)
-- Dependencies: 285
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4345 (class 0 OID 18075)
-- Dependencies: 290
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4344 (class 0 OID 18066)
-- Dependencies: 289
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4334 (class 0 OID 16458)
-- Dependencies: 241
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4444 (class 3256 OID 19078)
-- Name: medication_approvals Admins can manage all approvals; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can manage all approvals" ON public.medication_approvals USING ((auth.uid() IN ( SELECT a.profile_id
   FROM public.admins a
  WHERE (a.active = true))));


--
-- TOC entry 4377 (class 3256 OID 18395)
-- Name: patient_assignments Admins can manage all assignments; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can manage all assignments" ON public.patient_assignments USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4449 (class 3256 OID 19083)
-- Name: faxes Admins can manage all faxes; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can manage all faxes" ON public.faxes USING ((auth.uid() IN ( SELECT a.profile_id
   FROM public.admins a
  WHERE (a.active = true))));


--
-- TOC entry 4388 (class 3256 OID 18533)
-- Name: medication_orders Admins can manage all medication orders; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can manage all medication orders" ON public.medication_orders USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4379 (class 3256 OID 18524)
-- Name: medications Admins can manage all medications; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can manage all medications" ON public.medications USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4369 (class 3256 OID 18387)
-- Name: patients Admins can manage all patients; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can manage all patients" ON public.patients USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4372 (class 3256 OID 18390)
-- Name: providers Admins can manage all providers; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can manage all providers" ON public.providers USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4374 (class 3256 OID 18392)
-- Name: admins Admins can update own data; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can update own data" ON public.admins FOR UPDATE USING ((profile_id = auth.uid()));


--
-- TOC entry 4410 (class 3256 OID 18798)
-- Name: clinical_notes Admins can view all clinical notes; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can view all clinical notes" ON public.clinical_notes FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))));


--
-- TOC entry 4386 (class 3256 OID 18531)
-- Name: medication_approvals Admins can view all medication approvals; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can view all medication approvals" ON public.medication_approvals FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4382 (class 3256 OID 18527)
-- Name: patient_medication_preferences Admins can view all medication preferences; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can view all medication preferences" ON public.patient_medication_preferences FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4365 (class 3256 OID 18383)
-- Name: profiles Admins can view all profiles; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can view all profiles" ON public.profiles USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4428 (class 3256 OID 18946)
-- Name: visit_addendums Admins can view all visit addendums; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can view all visit addendums" ON public.visit_addendums FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))));


--
-- TOC entry 4413 (class 3256 OID 18803)
-- Name: visit_interactions Admins can view all visit interactions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can view all visit interactions" ON public.visit_interactions FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))));


--
-- TOC entry 4373 (class 3256 OID 18391)
-- Name: admins Admins can view own data; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can view own data" ON public.admins FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4425 (class 3256 OID 18854)
-- Name: auth_trigger_logs Allow admins to read logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow admins to read logs" ON public.auth_trigger_logs FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.profiles p
  WHERE ((p.id = auth.uid()) AND (p.role = 'admin'::text)))));


--
-- TOC entry 4421 (class 3256 OID 18835)
-- Name: profiles Allow auth trigger and service role; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow auth trigger and service role" ON public.profiles USING (true);


--
-- TOC entry 4423 (class 3256 OID 18837)
-- Name: provider_schedules Allow auth trigger and service role; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow auth trigger and service role" ON public.provider_schedules USING (true);


--
-- TOC entry 4422 (class 3256 OID 18836)
-- Name: providers Allow auth trigger and service role; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow auth trigger and service role" ON public.providers USING (true);


--
-- TOC entry 4424 (class 3256 OID 18853)
-- Name: auth_trigger_logs Allow trigger function to write logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow trigger function to write logs" ON public.auth_trigger_logs FOR INSERT WITH CHECK (true);


--
-- TOC entry 4378 (class 3256 OID 18523)
-- Name: medications Anyone can view active medications; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Anyone can view active medications" ON public.medications FOR SELECT USING ((active = true));


--
-- TOC entry 4380 (class 3256 OID 18525)
-- Name: patient_medication_preferences Patients can manage own medication preferences; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Patients can manage own medication preferences" ON public.patient_medication_preferences USING ((EXISTS ( SELECT 1
   FROM public.patients
  WHERE ((patients.profile_id = auth.uid()) AND (patients.id = patient_medication_preferences.patient_id)))));


--
-- TOC entry 4367 (class 3256 OID 18385)
-- Name: patients Patients can update own data; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Patients can update own data" ON public.patients FOR UPDATE USING ((profile_id = auth.uid()));


--
-- TOC entry 4375 (class 3256 OID 18393)
-- Name: patient_assignments Patients can view own assignments; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Patients can view own assignments" ON public.patient_assignments FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.patients
  WHERE ((patients.id = patient_assignments.patient_id) AND (patients.profile_id = auth.uid())))));


--
-- TOC entry 4366 (class 3256 OID 18384)
-- Name: patients Patients can view own data; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Patients can view own data" ON public.patients FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4385 (class 3256 OID 18530)
-- Name: medication_approvals Patients can view own medication approvals; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Patients can view own medication approvals" ON public.medication_approvals FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patients pt
     JOIN public.patient_medication_preferences pmp ON ((pt.id = pmp.patient_id)))
  WHERE ((pt.profile_id = auth.uid()) AND (pmp.id = medication_approvals.preference_id)))));


--
-- TOC entry 4387 (class 3256 OID 18532)
-- Name: medication_orders Patients can view own medication orders; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Patients can view own medication orders" ON public.medication_orders FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.patients
  WHERE ((patients.profile_id = auth.uid()) AND (patients.id = medication_orders.patient_id)))));


--
-- TOC entry 4409 (class 3256 OID 18797)
-- Name: clinical_notes Patients can view their clinical notes; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Patients can view their clinical notes" ON public.clinical_notes FOR SELECT TO authenticated USING ((patient_id IN ( SELECT p.id
   FROM (public.patients p
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4443 (class 3256 OID 19077)
-- Name: medication_approvals Patients can view their own approvals; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Patients can view their own approvals" ON public.medication_approvals FOR SELECT USING ((preference_id IN ( SELECT pmp.id
   FROM (public.patient_medication_preferences pmp
     JOIN public.patients pat ON ((pmp.patient_id = pat.id)))
  WHERE (pat.profile_id = auth.uid()))));


--
-- TOC entry 4656 (class 0 OID 0)
-- Dependencies: 4443
-- Name: POLICY "Patients can view their own approvals" ON medication_approvals; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON POLICY "Patients can view their own approvals" ON public.medication_approvals IS 'Allows patients to view approvals for their medication preferences';


--
-- TOC entry 4417 (class 3256 OID 18820)
-- Name: clinical_notes Patients can view their own clinical notes; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Patients can view their own clinical notes" ON public.clinical_notes FOR SELECT USING ((patient_id IN ( SELECT p.id
   FROM public.patients p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4448 (class 3256 OID 19082)
-- Name: faxes Patients can view their own faxes; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Patients can view their own faxes" ON public.faxes FOR SELECT USING ((patient_id IN ( SELECT pat.id
   FROM public.patients pat
  WHERE (pat.profile_id = auth.uid()))));


--
-- TOC entry 4657 (class 0 OID 0)
-- Dependencies: 4448
-- Name: POLICY "Patients can view their own faxes" ON faxes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON POLICY "Patients can view their own faxes" ON public.faxes IS 'Allows patients to view faxes related to their medications';


--
-- TOC entry 4420 (class 3256 OID 18825)
-- Name: visit_interactions Patients can view their own visit interactions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Patients can view their own visit interactions" ON public.visit_interactions FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4427 (class 3256 OID 18944)
-- Name: visit_addendums Patients can view their visit addendums; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Patients can view their visit addendums" ON public.visit_addendums FOR SELECT TO authenticated USING ((visit_id IN ( SELECT a.id
   FROM ((public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4412 (class 3256 OID 18801)
-- Name: visit_interactions Patients can view their visit interactions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Patients can view their visit interactions" ON public.visit_interactions FOR SELECT TO authenticated USING ((appointment_id IN ( SELECT a.id
   FROM ((public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4441 (class 3256 OID 19074)
-- Name: medication_approvals Providers can create approvals for assigned patients; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can create approvals for assigned patients" ON public.medication_approvals FOR INSERT WITH CHECK (((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))) AND (preference_id IN ( SELECT pmp.id
   FROM ((public.patient_medication_preferences pmp
     JOIN public.patients pat ON ((pmp.patient_id = pat.id)))
     JOIN public.patient_assignments pa ON ((pat.id = pa.patient_id)))
  WHERE ((pa.provider_id IN ( SELECT p.id
           FROM public.providers p
          WHERE (p.profile_id = auth.uid()))) AND (pa.active = true))))));


--
-- TOC entry 4658 (class 0 OID 0)
-- Dependencies: 4441
-- Name: POLICY "Providers can create approvals for assigned patients" ON medication_approvals; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON POLICY "Providers can create approvals for assigned patients" ON public.medication_approvals IS 'Allows providers to create approvals only for patients assigned to them';


--
-- TOC entry 4415 (class 3256 OID 18818)
-- Name: clinical_notes Providers can create clinical notes for their patients; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can create clinical notes for their patients" ON public.clinical_notes FOR INSERT WITH CHECK ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4446 (class 3256 OID 19080)
-- Name: faxes Providers can create faxes for assigned patients; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can create faxes for assigned patients" ON public.faxes FOR INSERT WITH CHECK (((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))) AND (patient_id IN ( SELECT pa.patient_id
   FROM public.patient_assignments pa
  WHERE ((pa.provider_id IN ( SELECT p.id
           FROM public.providers p
          WHERE (p.profile_id = auth.uid()))) AND (pa.active = true))))));


--
-- TOC entry 4659 (class 0 OID 0)
-- Dependencies: 4446
-- Name: POLICY "Providers can create faxes for assigned patients" ON faxes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON POLICY "Providers can create faxes for assigned patients" ON public.faxes IS 'Allows providers to create faxes only for patients assigned to them';


--
-- TOC entry 4390 (class 3256 OID 18544)
-- Name: medication_orders Providers can create orders for assigned patients; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can create orders for assigned patients" ON public.medication_orders FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = medication_orders.patient_id)))));


--
-- TOC entry 4419 (class 3256 OID 18823)
-- Name: visit_interactions Providers can create visit interactions for their appointments; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can create visit interactions for their appointments" ON public.visit_interactions FOR INSERT WITH CHECK ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.providers p ON ((a.provider_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4426 (class 3256 OID 18943)
-- Name: visit_addendums Providers can manage addendums for their patients; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can manage addendums for their patients" ON public.visit_addendums TO authenticated USING ((provider_id IN ( SELECT p.id
   FROM (public.providers p
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4383 (class 3256 OID 18528)
-- Name: medication_approvals Providers can manage approvals for assigned patients; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can manage approvals for assigned patients" ON public.medication_approvals USING ((EXISTS ( SELECT 1
   FROM ((public.providers p
     JOIN public.patient_assignments pa ON ((p.id = pa.provider_id)))
     JOIN public.patient_medication_preferences pmp ON ((pa.patient_id = pmp.patient_id)))
  WHERE ((p.profile_id = auth.uid()) AND (pmp.id = medication_approvals.preference_id)))));


--
-- TOC entry 4408 (class 3256 OID 18796)
-- Name: clinical_notes Providers can manage clinical notes for their patients; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can manage clinical notes for their patients" ON public.clinical_notes TO authenticated USING ((provider_id IN ( SELECT p.id
   FROM (public.providers p
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4411 (class 3256 OID 18799)
-- Name: visit_interactions Providers can manage visit interactions for their patients; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can manage visit interactions for their patients" ON public.visit_interactions TO authenticated USING ((appointment_id IN ( SELECT a.id
   FROM ((public.appointments a
     JOIN public.providers p ON ((a.provider_id = p.id)))
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4391 (class 3256 OID 18545)
-- Name: medication_orders Providers can update assigned patient orders; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can update assigned patient orders" ON public.medication_orders FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = medication_orders.patient_id)))));


--
-- TOC entry 4392 (class 3256 OID 18546)
-- Name: patient_medication_preferences Providers can update assigned patient preferences; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can update assigned patient preferences" ON public.patient_medication_preferences FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = patient_medication_preferences.patient_id)))));


--
-- TOC entry 4371 (class 3256 OID 18389)
-- Name: providers Providers can update own data; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can update own data" ON public.providers FOR UPDATE USING ((profile_id = auth.uid()));


--
-- TOC entry 4442 (class 3256 OID 19076)
-- Name: medication_approvals Providers can update their own approvals; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can update their own approvals" ON public.medication_approvals FOR UPDATE USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4416 (class 3256 OID 18819)
-- Name: clinical_notes Providers can update their own clinical notes; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can update their own clinical notes" ON public.clinical_notes FOR UPDATE USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4447 (class 3256 OID 19081)
-- Name: faxes Providers can update their own faxes; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can update their own faxes" ON public.faxes FOR UPDATE USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4389 (class 3256 OID 18534)
-- Name: medication_orders Providers can view assigned patient orders; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can view assigned patient orders" ON public.medication_orders FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = medication_orders.patient_id)))));


--
-- TOC entry 4381 (class 3256 OID 18526)
-- Name: patient_medication_preferences Providers can view assigned patient preferences; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can view assigned patient preferences" ON public.patient_medication_preferences FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = patient_medication_preferences.patient_id)))));


--
-- TOC entry 4368 (class 3256 OID 18386)
-- Name: patients Providers can view assigned patients; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can view assigned patients" ON public.patients FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((p.id = pa.provider_id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = patients.id) AND (pa.active = true)))));


--
-- TOC entry 4370 (class 3256 OID 18388)
-- Name: providers Providers can view own data; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can view own data" ON public.providers FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4376 (class 3256 OID 18394)
-- Name: patient_assignments Providers can view their assignments; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can view their assignments" ON public.patient_assignments FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.providers
  WHERE ((providers.id = patient_assignments.provider_id) AND (providers.profile_id = auth.uid())))));


--
-- TOC entry 4440 (class 3256 OID 19073)
-- Name: medication_approvals Providers can view their own approvals; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can view their own approvals" ON public.medication_approvals FOR SELECT USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4660 (class 0 OID 0)
-- Dependencies: 4440
-- Name: POLICY "Providers can view their own approvals" ON medication_approvals; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON POLICY "Providers can view their own approvals" ON public.medication_approvals IS 'Allows providers to view medication approvals they created';


--
-- TOC entry 4414 (class 3256 OID 18817)
-- Name: clinical_notes Providers can view their own clinical notes; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can view their own clinical notes" ON public.clinical_notes FOR SELECT USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4445 (class 3256 OID 19079)
-- Name: faxes Providers can view their own faxes; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can view their own faxes" ON public.faxes FOR SELECT USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4661 (class 0 OID 0)
-- Dependencies: 4445
-- Name: POLICY "Providers can view their own faxes" ON faxes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON POLICY "Providers can view their own faxes" ON public.faxes IS 'Allows providers to view faxes they sent';


--
-- TOC entry 4450 (class 3256 OID 19084)
-- Name: providers Providers can view their own record; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can view their own record" ON public.providers FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4662 (class 0 OID 0)
-- Dependencies: 4450
-- Name: POLICY "Providers can view their own record" ON providers; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON POLICY "Providers can view their own record" ON public.providers IS 'Allows providers to view their own provider record when authenticated';


--
-- TOC entry 4418 (class 3256 OID 18821)
-- Name: visit_interactions Providers can view their own visit interactions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Providers can view their own visit interactions" ON public.visit_interactions FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.providers p ON ((a.provider_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4434 (class 3256 OID 19008)
-- Name: admins Service role can manage admins; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Service role can manage admins" ON public.admins USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = profile_id)));


--
-- TOC entry 4439 (class 3256 OID 19021)
-- Name: admins Service role can manage all admins; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Service role can manage all admins" ON public.admins USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4437 (class 3256 OID 19019)
-- Name: patients Service role can manage all patients; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Service role can manage all patients" ON public.patients USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4436 (class 3256 OID 19018)
-- Name: profiles Service role can manage all profiles; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Service role can manage all profiles" ON public.profiles USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4438 (class 3256 OID 19020)
-- Name: providers Service role can manage all providers; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Service role can manage all providers" ON public.providers USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4432 (class 3256 OID 19006)
-- Name: patients Service role can manage patients; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Service role can manage patients" ON public.patients USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = profile_id)));


--
-- TOC entry 4430 (class 3256 OID 19004)
-- Name: profiles Service role can manage profiles; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Service role can manage profiles" ON public.profiles USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = id)));


--
-- TOC entry 4433 (class 3256 OID 19007)
-- Name: providers Service role can manage providers; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Service role can manage providers" ON public.providers USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = profile_id)));


--
-- TOC entry 4435 (class 3256 OID 19009)
-- Name: provider_schedules Service role can manage schedules; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Service role can manage schedules" ON public.provider_schedules USING ((current_setting('role'::text) = 'service_role'::text));


--
-- TOC entry 4429 (class 3256 OID 18998)
-- Name: profiles Users can update own profile; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING ((auth.uid() = id));


--
-- TOC entry 4431 (class 3256 OID 19005)
-- Name: profiles Users can view own profile; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING ((auth.uid() = id));


--
-- TOC entry 4404 (class 3256 OID 18681)
-- Name: appointments admin_full_appointments_access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY admin_full_appointments_access ON public.appointments USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4663 (class 0 OID 0)
-- Dependencies: 4404
-- Name: POLICY admin_full_appointments_access ON appointments; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON POLICY admin_full_appointments_access ON public.appointments IS 'Admins have full access to all appointment data';


--
-- TOC entry 4406 (class 3256 OID 18686)
-- Name: appointment_history admin_view_all_appointment_history; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY admin_view_all_appointment_history ON public.appointment_history USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4398 (class 3256 OID 18674)
-- Name: provider_availability_overrides admin_view_all_overrides; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY admin_view_all_overrides ON public.provider_availability_overrides USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4384 (class 3256 OID 18670)
-- Name: provider_schedules admin_view_all_schedules; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY admin_view_all_schedules ON public.provider_schedules USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4353 (class 0 OID 18320)
-- Dependencies: 300
-- Name: admins; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.admins ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4407 (class 3256 OID 18687)
-- Name: appointment_history appointment_history_readonly; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY appointment_history_readonly ON public.appointment_history FOR INSERT WITH CHECK (false);


--
-- TOC entry 4664 (class 0 OID 0)
-- Dependencies: 4407
-- Name: POLICY appointment_history_readonly ON appointment_history; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON POLICY appointment_history_readonly ON public.appointment_history IS 'History is maintained by system triggers only';


--
-- TOC entry 4362 (class 0 OID 18839)
-- Dependencies: 317
-- Name: auth_trigger_logs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_trigger_logs ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4360 (class 0 OID 18702)
-- Dependencies: 314
-- Name: clinical_notes; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.clinical_notes ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4364 (class 0 OID 19024)
-- Dependencies: 321
-- Name: faxes; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.faxes ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4356 (class 0 OID 18455)
-- Dependencies: 306
-- Name: medication_approvals; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.medication_approvals ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4357 (class 0 OID 18476)
-- Dependencies: 307
-- Name: medication_orders; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.medication_orders ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4354 (class 0 OID 18418)
-- Dependencies: 304
-- Name: medications; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.medications ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4400 (class 3256 OID 18676)
-- Name: appointments patient_booking_restrictions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY patient_booking_restrictions ON public.appointments FOR INSERT WITH CHECK (((patient_id IN ( SELECT p.id
   FROM public.patients p
  WHERE (p.profile_id = auth.uid()))) AND (provider_id IN ( SELECT pa.provider_id
   FROM (public.patient_assignments pa
     JOIN public.patients p ON ((pa.patient_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.active = true)))) AND ((appointment_date > CURRENT_DATE) OR ((appointment_date = CURRENT_DATE) AND (start_time > LOCALTIME))) AND (appointment_date <= (CURRENT_DATE + '90 days'::interval)) AND (booked_by = 'patient'::text)));


--
-- TOC entry 4665 (class 0 OID 0)
-- Dependencies: 4400
-- Name: POLICY patient_booking_restrictions ON appointments; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON POLICY patient_booking_restrictions ON public.appointments IS 'Enforces business rules for patient appointment booking';


--
-- TOC entry 4355 (class 0 OID 18431)
-- Dependencies: 305
-- Name: patient_medication_preferences; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.patient_medication_preferences ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4401 (class 3256 OID 18678)
-- Name: appointments patient_no_delete_appointments; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY patient_no_delete_appointments ON public.appointments FOR DELETE USING (false);


--
-- TOC entry 4399 (class 3256 OID 18675)
-- Name: appointments patient_own_appointments; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY patient_own_appointments ON public.appointments USING ((patient_id IN ( SELECT p.id
   FROM public.patients p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4666 (class 0 OID 0)
-- Dependencies: 4399
-- Name: POLICY patient_own_appointments ON appointments; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON POLICY patient_own_appointments ON public.appointments IS 'Patients can only access their own appointments';


--
-- TOC entry 4405 (class 3256 OID 18682)
-- Name: appointment_history patient_view_own_appointment_history; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY patient_view_own_appointment_history ON public.appointment_history FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4397 (class 3256 OID 18672)
-- Name: provider_availability_overrides patient_view_provider_overrides; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY patient_view_provider_overrides ON public.provider_availability_overrides FOR SELECT USING ((provider_id IN ( SELECT pa.provider_id
   FROM (public.patient_assignments pa
     JOIN public.patients p ON ((pa.patient_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.active = true)))));


--
-- TOC entry 4394 (class 3256 OID 18668)
-- Name: provider_schedules patient_view_provider_schedules; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY patient_view_provider_schedules ON public.provider_schedules FOR SELECT USING ((provider_id IN ( SELECT pa.provider_id
   FROM (public.patient_assignments pa
     JOIN public.patients p ON ((pa.patient_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.active = true)))));


--
-- TOC entry 4351 (class 0 OID 18284)
-- Dependencies: 298
-- Name: patients; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4350 (class 0 OID 18267)
-- Dependencies: 297
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4359 (class 0 OID 18570)
-- Dependencies: 309
-- Name: provider_availability_overrides; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.provider_availability_overrides ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4403 (class 3256 OID 18680)
-- Name: appointments provider_no_delete_appointments; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY provider_no_delete_appointments ON public.appointments FOR DELETE USING (false);


--
-- TOC entry 4402 (class 3256 OID 18679)
-- Name: appointments provider_own_appointments; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY provider_own_appointments ON public.appointments USING ((provider_id IN ( SELECT pr.id
   FROM public.providers pr
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4667 (class 0 OID 0)
-- Dependencies: 4402
-- Name: POLICY provider_own_appointments ON appointments; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON POLICY provider_own_appointments ON public.appointments IS 'Providers can manage appointments with their patients';


--
-- TOC entry 4396 (class 3256 OID 18671)
-- Name: provider_availability_overrides provider_own_overrides_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY provider_own_overrides_policy ON public.provider_availability_overrides USING ((provider_id IN ( SELECT pr.id
   FROM public.providers pr
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4393 (class 3256 OID 18667)
-- Name: provider_schedules provider_own_schedule_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY provider_own_schedule_policy ON public.provider_schedules USING ((provider_id IN ( SELECT pr.id
   FROM public.providers pr
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4358 (class 0 OID 18547)
-- Dependencies: 308
-- Name: provider_schedules; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.provider_schedules ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4395 (class 3256 OID 18684)
-- Name: appointment_history provider_view_appointment_history; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY provider_view_appointment_history ON public.appointment_history FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.providers pr ON ((a.provider_id = pr.id)))
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4352 (class 0 OID 18302)
-- Dependencies: 299
-- Name: providers; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4363 (class 0 OID 18920)
-- Dependencies: 319
-- Name: visit_addendums; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.visit_addendums ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4361 (class 0 OID 18760)
-- Dependencies: 316
-- Name: visit_interactions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.visit_interactions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4457 (class 0 OID 0)
-- Dependencies: 27
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA auth TO anon;
GRANT USAGE ON SCHEMA auth TO authenticated;
GRANT USAGE ON SCHEMA auth TO service_role;
GRANT ALL ON SCHEMA auth TO supabase_auth_admin;
GRANT ALL ON SCHEMA auth TO dashboard_user;
GRANT USAGE ON SCHEMA auth TO postgres;


--
-- TOC entry 4459 (class 0 OID 0)
-- Dependencies: 18
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;
GRANT USAGE ON SCHEMA public TO supabase_auth_admin;


--
-- TOC entry 4461 (class 0 OID 0)
-- Dependencies: 489
-- Name: FUNCTION email(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.email() TO dashboard_user;


--
-- TOC entry 4462 (class 0 OID 0)
-- Dependencies: 364
-- Name: FUNCTION jwt(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.jwt() TO postgres;
GRANT ALL ON FUNCTION auth.jwt() TO dashboard_user;


--
-- TOC entry 4464 (class 0 OID 0)
-- Dependencies: 410
-- Name: FUNCTION role(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.role() TO dashboard_user;


--
-- TOC entry 4466 (class 0 OID 0)
-- Dependencies: 408
-- Name: FUNCTION uid(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.uid() TO dashboard_user;


--
-- TOC entry 4467 (class 0 OID 0)
-- Dependencies: 375
-- Name: FUNCTION assign_patient_to_provider(patient_profile_id uuid, provider_profile_id uuid, treatment_type_param text, is_primary_param boolean); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.assign_patient_to_provider(patient_profile_id uuid, provider_profile_id uuid, treatment_type_param text, is_primary_param boolean) TO anon;
GRANT ALL ON FUNCTION public.assign_patient_to_provider(patient_profile_id uuid, provider_profile_id uuid, treatment_type_param text, is_primary_param boolean) TO authenticated;
GRANT ALL ON FUNCTION public.assign_patient_to_provider(patient_profile_id uuid, provider_profile_id uuid, treatment_type_param text, is_primary_param boolean) TO service_role;


--
-- TOC entry 4469 (class 0 OID 0)
-- Dependencies: 350
-- Name: FUNCTION book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text, p_booked_by text, p_patient_notes text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text, p_booked_by text, p_patient_notes text) TO anon;
GRANT ALL ON FUNCTION public.book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text, p_booked_by text, p_patient_notes text) TO authenticated;
GRANT ALL ON FUNCTION public.book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text, p_booked_by text, p_patient_notes text) TO service_role;


--
-- TOC entry 4471 (class 0 OID 0)
-- Dependencies: 407
-- Name: FUNCTION calculate_next_prescription_due(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.calculate_next_prescription_due() TO anon;
GRANT ALL ON FUNCTION public.calculate_next_prescription_due() TO authenticated;
GRANT ALL ON FUNCTION public.calculate_next_prescription_due() TO service_role;


--
-- TOC entry 4473 (class 0 OID 0)
-- Dependencies: 435
-- Name: FUNCTION calculate_next_prescription_due(p_preference_id uuid, p_delivery_date date, p_frequency text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.calculate_next_prescription_due(p_preference_id uuid, p_delivery_date date, p_frequency text) TO anon;
GRANT ALL ON FUNCTION public.calculate_next_prescription_due(p_preference_id uuid, p_delivery_date date, p_frequency text) TO authenticated;
GRANT ALL ON FUNCTION public.calculate_next_prescription_due(p_preference_id uuid, p_delivery_date date, p_frequency text) TO service_role;


--
-- TOC entry 4475 (class 0 OID 0)
-- Dependencies: 434
-- Name: FUNCTION cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text) TO anon;
GRANT ALL ON FUNCTION public.cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text) TO authenticated;
GRANT ALL ON FUNCTION public.cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text) TO service_role;


--
-- TOC entry 4477 (class 0 OID 0)
-- Dependencies: 480
-- Name: FUNCTION check_approval_expiry_on_delivery(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.check_approval_expiry_on_delivery() TO anon;
GRANT ALL ON FUNCTION public.check_approval_expiry_on_delivery() TO authenticated;
GRANT ALL ON FUNCTION public.check_approval_expiry_on_delivery() TO service_role;


--
-- TOC entry 4478 (class 0 OID 0)
-- Dependencies: 438
-- Name: FUNCTION check_auth_trigger_health(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.check_auth_trigger_health() TO anon;
GRANT ALL ON FUNCTION public.check_auth_trigger_health() TO authenticated;
GRANT ALL ON FUNCTION public.check_auth_trigger_health() TO service_role;


--
-- TOC entry 4480 (class 0 OID 0)
-- Dependencies: 487
-- Name: FUNCTION clear_overdue_faxed_status(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.clear_overdue_faxed_status() TO anon;
GRANT ALL ON FUNCTION public.clear_overdue_faxed_status() TO authenticated;
GRANT ALL ON FUNCTION public.clear_overdue_faxed_status() TO service_role;


--
-- TOC entry 4481 (class 0 OID 0)
-- Dependencies: 437
-- Name: FUNCTION create_default_provider_schedule(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.create_default_provider_schedule() TO anon;
GRANT ALL ON FUNCTION public.create_default_provider_schedule() TO authenticated;
GRANT ALL ON FUNCTION public.create_default_provider_schedule() TO service_role;


--
-- TOC entry 4483 (class 0 OID 0)
-- Dependencies: 458
-- Name: FUNCTION create_order_on_fax(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.create_order_on_fax() TO anon;
GRANT ALL ON FUNCTION public.create_order_on_fax() TO authenticated;
GRANT ALL ON FUNCTION public.create_order_on_fax() TO service_role;


--
-- TOC entry 4485 (class 0 OID 0)
-- Dependencies: 420
-- Name: FUNCTION daily_approval_reset_check(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.daily_approval_reset_check() TO anon;
GRANT ALL ON FUNCTION public.daily_approval_reset_check() TO authenticated;
GRANT ALL ON FUNCTION public.daily_approval_reset_check() TO service_role;


--
-- TOC entry 4487 (class 0 OID 0)
-- Dependencies: 488
-- Name: FUNCTION fix_existing_next_due_calculations(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fix_existing_next_due_calculations() TO anon;
GRANT ALL ON FUNCTION public.fix_existing_next_due_calculations() TO authenticated;
GRANT ALL ON FUNCTION public.fix_existing_next_due_calculations() TO service_role;


--
-- TOC entry 4489 (class 0 OID 0)
-- Dependencies: 326
-- Name: FUNCTION get_admin_appointment_overview(p_date_range_start date, p_date_range_end date, p_provider_id uuid, p_patient_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_admin_appointment_overview(p_date_range_start date, p_date_range_end date, p_provider_id uuid, p_patient_id uuid) TO anon;
GRANT ALL ON FUNCTION public.get_admin_appointment_overview(p_date_range_start date, p_date_range_end date, p_provider_id uuid, p_patient_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_admin_appointment_overview(p_date_range_start date, p_date_range_end date, p_provider_id uuid, p_patient_id uuid) TO service_role;


--
-- TOC entry 4490 (class 0 OID 0)
-- Dependencies: 452
-- Name: FUNCTION get_admin_fulfillment_queue(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_admin_fulfillment_queue() TO anon;
GRANT ALL ON FUNCTION public.get_admin_fulfillment_queue() TO authenticated;
GRANT ALL ON FUNCTION public.get_admin_fulfillment_queue() TO service_role;


--
-- TOC entry 4491 (class 0 OID 0)
-- Dependencies: 456
-- Name: FUNCTION get_all_patients_for_admin(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_all_patients_for_admin() TO anon;
GRANT ALL ON FUNCTION public.get_all_patients_for_admin() TO authenticated;
GRANT ALL ON FUNCTION public.get_all_patients_for_admin() TO service_role;


--
-- TOC entry 4493 (class 0 OID 0)
-- Dependencies: 324
-- Name: FUNCTION get_approvals_due_for_renewal(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_approvals_due_for_renewal() TO anon;
GRANT ALL ON FUNCTION public.get_approvals_due_for_renewal() TO authenticated;
GRANT ALL ON FUNCTION public.get_approvals_due_for_renewal() TO service_role;


--
-- TOC entry 4494 (class 0 OID 0)
-- Dependencies: 397
-- Name: FUNCTION get_assigned_patients_for_provider(provider_profile_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_assigned_patients_for_provider(provider_profile_id uuid) TO anon;
GRANT ALL ON FUNCTION public.get_assigned_patients_for_provider(provider_profile_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_assigned_patients_for_provider(provider_profile_id uuid) TO service_role;


--
-- TOC entry 4496 (class 0 OID 0)
-- Dependencies: 415
-- Name: FUNCTION get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text) TO anon;
GRANT ALL ON FUNCTION public.get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text) TO authenticated;
GRANT ALL ON FUNCTION public.get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text) TO service_role;


--
-- TOC entry 4498 (class 0 OID 0)
-- Dependencies: 329
-- Name: FUNCTION get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean) TO anon;
GRANT ALL ON FUNCTION public.get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean) TO authenticated;
GRANT ALL ON FUNCTION public.get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean) TO service_role;


--
-- TOC entry 4499 (class 0 OID 0)
-- Dependencies: 468
-- Name: FUNCTION get_patient_medication_overview(patient_uuid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_patient_medication_overview(patient_uuid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_patient_medication_overview(patient_uuid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_patient_medication_overview(patient_uuid uuid) TO service_role;


--
-- TOC entry 4500 (class 0 OID 0)
-- Dependencies: 419
-- Name: FUNCTION get_patient_medications_detailed(patient_uuid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_patient_medications_detailed(patient_uuid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_patient_medications_detailed(patient_uuid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_patient_medications_detailed(patient_uuid uuid) TO service_role;


--
-- TOC entry 4501 (class 0 OID 0)
-- Dependencies: 331
-- Name: FUNCTION get_provider_by_profile_id(provider_profile_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_provider_by_profile_id(provider_profile_id uuid) TO anon;
GRANT ALL ON FUNCTION public.get_provider_by_profile_id(provider_profile_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_provider_by_profile_id(provider_profile_id uuid) TO service_role;


--
-- TOC entry 4502 (class 0 OID 0)
-- Dependencies: 328
-- Name: FUNCTION get_provider_pending_approvals(provider_uuid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_provider_pending_approvals(provider_uuid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_provider_pending_approvals(provider_uuid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_provider_pending_approvals(provider_uuid uuid) TO service_role;


--
-- TOC entry 4503 (class 0 OID 0)
-- Dependencies: 476
-- Name: FUNCTION get_user_role(user_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_role(user_id uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_role(user_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_role(user_id uuid) TO service_role;


--
-- TOC entry 4504 (class 0 OID 0)
-- Dependencies: 425
-- Name: FUNCTION handle_new_user(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.handle_new_user() TO anon;
GRANT ALL ON FUNCTION public.handle_new_user() TO authenticated;
GRANT ALL ON FUNCTION public.handle_new_user() TO service_role;


--
-- TOC entry 4505 (class 0 OID 0)
-- Dependencies: 471
-- Name: FUNCTION log_appointment_changes(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.log_appointment_changes() TO anon;
GRANT ALL ON FUNCTION public.log_appointment_changes() TO authenticated;
GRANT ALL ON FUNCTION public.log_appointment_changes() TO service_role;


--
-- TOC entry 4506 (class 0 OID 0)
-- Dependencies: 335
-- Name: FUNCTION repair_missing_profiles(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.repair_missing_profiles() TO anon;
GRANT ALL ON FUNCTION public.repair_missing_profiles() TO authenticated;
GRANT ALL ON FUNCTION public.repair_missing_profiles() TO service_role;


--
-- TOC entry 4508 (class 0 OID 0)
-- Dependencies: 355
-- Name: FUNCTION request_prescription_refill(p_preference_id uuid, p_patient_profile_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.request_prescription_refill(p_preference_id uuid, p_patient_profile_id uuid) TO anon;
GRANT ALL ON FUNCTION public.request_prescription_refill(p_preference_id uuid, p_patient_profile_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.request_prescription_refill(p_preference_id uuid, p_patient_profile_id uuid) TO service_role;


--
-- TOC entry 4510 (class 0 OID 0)
-- Dependencies: 354
-- Name: FUNCTION reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text, p_rescheduled_by_user_id uuid, p_reason text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text, p_rescheduled_by_user_id uuid, p_reason text) TO anon;
GRANT ALL ON FUNCTION public.reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text, p_rescheduled_by_user_id uuid, p_reason text) TO authenticated;
GRANT ALL ON FUNCTION public.reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text, p_rescheduled_by_user_id uuid, p_reason text) TO service_role;


--
-- TOC entry 4512 (class 0 OID 0)
-- Dependencies: 477
-- Name: FUNCTION reset_expired_approvals(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.reset_expired_approvals() TO anon;
GRANT ALL ON FUNCTION public.reset_expired_approvals() TO authenticated;
GRANT ALL ON FUNCTION public.reset_expired_approvals() TO service_role;


--
-- TOC entry 4514 (class 0 OID 0)
-- Dependencies: 464
-- Name: FUNCTION run_daily_maintenance(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.run_daily_maintenance() TO anon;
GRANT ALL ON FUNCTION public.run_daily_maintenance() TO authenticated;
GRANT ALL ON FUNCTION public.run_daily_maintenance() TO service_role;


--
-- TOC entry 4516 (class 0 OID 0)
-- Dependencies: 359
-- Name: FUNCTION set_appointment_context(p_user_role text, p_user_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.set_appointment_context(p_user_role text, p_user_id uuid) TO anon;
GRANT ALL ON FUNCTION public.set_appointment_context(p_user_role text, p_user_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.set_appointment_context(p_user_role text, p_user_id uuid) TO service_role;


--
-- TOC entry 4518 (class 0 OID 0)
-- Dependencies: 327
-- Name: FUNCTION trigger_approval_reset(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.trigger_approval_reset() TO anon;
GRANT ALL ON FUNCTION public.trigger_approval_reset() TO authenticated;
GRANT ALL ON FUNCTION public.trigger_approval_reset() TO service_role;


--
-- TOC entry 4519 (class 0 OID 0)
-- Dependencies: 384
-- Name: FUNCTION update_clinical_note_editor(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_clinical_note_editor() TO anon;
GRANT ALL ON FUNCTION public.update_clinical_note_editor() TO authenticated;
GRANT ALL ON FUNCTION public.update_clinical_note_editor() TO service_role;


--
-- TOC entry 4521 (class 0 OID 0)
-- Dependencies: 418
-- Name: FUNCTION update_next_due_from_supply_and_fax(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_next_due_from_supply_and_fax() TO anon;
GRANT ALL ON FUNCTION public.update_next_due_from_supply_and_fax() TO authenticated;
GRANT ALL ON FUNCTION public.update_next_due_from_supply_and_fax() TO service_role;


--
-- TOC entry 4523 (class 0 OID 0)
-- Dependencies: 394
-- Name: FUNCTION update_preference_on_medication_adjustment(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_preference_on_medication_adjustment() TO anon;
GRANT ALL ON FUNCTION public.update_preference_on_medication_adjustment() TO authenticated;
GRANT ALL ON FUNCTION public.update_preference_on_medication_adjustment() TO service_role;


--
-- TOC entry 4525 (class 0 OID 0)
-- Dependencies: 431
-- Name: FUNCTION update_prescription_due_date(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_prescription_due_date() TO anon;
GRANT ALL ON FUNCTION public.update_prescription_due_date() TO authenticated;
GRANT ALL ON FUNCTION public.update_prescription_due_date() TO service_role;


--
-- TOC entry 4526 (class 0 OID 0)
-- Dependencies: 399
-- Name: FUNCTION update_updated_at_column(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.update_updated_at_column() TO anon;
GRANT ALL ON FUNCTION public.update_updated_at_column() TO authenticated;
GRANT ALL ON FUNCTION public.update_updated_at_column() TO service_role;


--
-- TOC entry 4527 (class 0 OID 0)
-- Dependencies: 398
-- Name: FUNCTION validate_appointment_business_rules(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.validate_appointment_business_rules() TO anon;
GRANT ALL ON FUNCTION public.validate_appointment_business_rules() TO authenticated;
GRANT ALL ON FUNCTION public.validate_appointment_business_rules() TO service_role;


--
-- TOC entry 4529 (class 0 OID 0)
-- Dependencies: 245
-- Name: TABLE audit_log_entries; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.audit_log_entries TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.audit_log_entries TO postgres;
GRANT SELECT ON TABLE auth.audit_log_entries TO postgres WITH GRANT OPTION;


--
-- TOC entry 4531 (class 0 OID 0)
-- Dependencies: 293
-- Name: TABLE flow_state; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.flow_state TO postgres;
GRANT SELECT ON TABLE auth.flow_state TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.flow_state TO dashboard_user;


--
-- TOC entry 4534 (class 0 OID 0)
-- Dependencies: 284
-- Name: TABLE identities; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.identities TO postgres;
GRANT SELECT ON TABLE auth.identities TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.identities TO dashboard_user;


--
-- TOC entry 4536 (class 0 OID 0)
-- Dependencies: 244
-- Name: TABLE instances; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.instances TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.instances TO postgres;
GRANT SELECT ON TABLE auth.instances TO postgres WITH GRANT OPTION;


--
-- TOC entry 4538 (class 0 OID 0)
-- Dependencies: 288
-- Name: TABLE mfa_amr_claims; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_amr_claims TO postgres;
GRANT SELECT ON TABLE auth.mfa_amr_claims TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_amr_claims TO dashboard_user;


--
-- TOC entry 4540 (class 0 OID 0)
-- Dependencies: 287
-- Name: TABLE mfa_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_challenges TO postgres;
GRANT SELECT ON TABLE auth.mfa_challenges TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_challenges TO dashboard_user;


--
-- TOC entry 4542 (class 0 OID 0)
-- Dependencies: 286
-- Name: TABLE mfa_factors; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_factors TO postgres;
GRANT SELECT ON TABLE auth.mfa_factors TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_factors TO dashboard_user;


--
-- TOC entry 4543 (class 0 OID 0)
-- Dependencies: 295
-- Name: TABLE oauth_clients; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_clients TO postgres;
GRANT ALL ON TABLE auth.oauth_clients TO dashboard_user;


--
-- TOC entry 4544 (class 0 OID 0)
-- Dependencies: 294
-- Name: TABLE one_time_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.one_time_tokens TO postgres;
GRANT SELECT ON TABLE auth.one_time_tokens TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.one_time_tokens TO dashboard_user;


--
-- TOC entry 4546 (class 0 OID 0)
-- Dependencies: 243
-- Name: TABLE refresh_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.refresh_tokens TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.refresh_tokens TO postgres;
GRANT SELECT ON TABLE auth.refresh_tokens TO postgres WITH GRANT OPTION;


--
-- TOC entry 4548 (class 0 OID 0)
-- Dependencies: 242
-- Name: SEQUENCE refresh_tokens_id_seq; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO dashboard_user;
GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO postgres;


--
-- TOC entry 4550 (class 0 OID 0)
-- Dependencies: 291
-- Name: TABLE saml_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_providers TO postgres;
GRANT SELECT ON TABLE auth.saml_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_providers TO dashboard_user;


--
-- TOC entry 4552 (class 0 OID 0)
-- Dependencies: 292
-- Name: TABLE saml_relay_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_relay_states TO postgres;
GRANT SELECT ON TABLE auth.saml_relay_states TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_relay_states TO dashboard_user;


--
-- TOC entry 4554 (class 0 OID 0)
-- Dependencies: 246
-- Name: TABLE schema_migrations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE auth.schema_migrations TO postgres WITH GRANT OPTION;


--
-- TOC entry 4557 (class 0 OID 0)
-- Dependencies: 285
-- Name: TABLE sessions; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sessions TO postgres;
GRANT SELECT ON TABLE auth.sessions TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sessions TO dashboard_user;


--
-- TOC entry 4559 (class 0 OID 0)
-- Dependencies: 290
-- Name: TABLE sso_domains; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_domains TO postgres;
GRANT SELECT ON TABLE auth.sso_domains TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_domains TO dashboard_user;


--
-- TOC entry 4562 (class 0 OID 0)
-- Dependencies: 289
-- Name: TABLE sso_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_providers TO postgres;
GRANT SELECT ON TABLE auth.sso_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_providers TO dashboard_user;


--
-- TOC entry 4565 (class 0 OID 0)
-- Dependencies: 241
-- Name: TABLE users; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.users TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.users TO postgres;
GRANT SELECT ON TABLE auth.users TO postgres WITH GRANT OPTION;


--
-- TOC entry 4566 (class 0 OID 0)
-- Dependencies: 300
-- Name: TABLE admins; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.admins TO anon;
GRANT ALL ON TABLE public.admins TO authenticated;
GRANT ALL ON TABLE public.admins TO service_role;
GRANT ALL ON TABLE public.admins TO supabase_auth_admin;


--
-- TOC entry 4568 (class 0 OID 0)
-- Dependencies: 311
-- Name: TABLE appointment_history; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.appointment_history TO anon;
GRANT ALL ON TABLE public.appointment_history TO authenticated;
GRANT ALL ON TABLE public.appointment_history TO service_role;
GRANT ALL ON TABLE public.appointment_history TO supabase_auth_admin;


--
-- TOC entry 4576 (class 0 OID 0)
-- Dependencies: 310
-- Name: TABLE appointments; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.appointments TO anon;
GRANT ALL ON TABLE public.appointments TO authenticated;
GRANT ALL ON TABLE public.appointments TO service_role;
GRANT ALL ON TABLE public.appointments TO supabase_auth_admin;


--
-- TOC entry 4579 (class 0 OID 0)
-- Dependencies: 306
-- Name: TABLE medication_approvals; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.medication_approvals TO anon;
GRANT ALL ON TABLE public.medication_approvals TO authenticated;
GRANT ALL ON TABLE public.medication_approvals TO service_role;
GRANT ALL ON TABLE public.medication_approvals TO supabase_auth_admin;


--
-- TOC entry 4584 (class 0 OID 0)
-- Dependencies: 307
-- Name: TABLE medication_orders; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.medication_orders TO anon;
GRANT ALL ON TABLE public.medication_orders TO authenticated;
GRANT ALL ON TABLE public.medication_orders TO service_role;
GRANT ALL ON TABLE public.medication_orders TO supabase_auth_admin;


--
-- TOC entry 4585 (class 0 OID 0)
-- Dependencies: 304
-- Name: TABLE medications; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.medications TO anon;
GRANT ALL ON TABLE public.medications TO authenticated;
GRANT ALL ON TABLE public.medications TO service_role;
GRANT ALL ON TABLE public.medications TO supabase_auth_admin;


--
-- TOC entry 4591 (class 0 OID 0)
-- Dependencies: 305
-- Name: TABLE patient_medication_preferences; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.patient_medication_preferences TO anon;
GRANT ALL ON TABLE public.patient_medication_preferences TO authenticated;
GRANT ALL ON TABLE public.patient_medication_preferences TO service_role;
GRANT ALL ON TABLE public.patient_medication_preferences TO supabase_auth_admin;


--
-- TOC entry 4592 (class 0 OID 0)
-- Dependencies: 298
-- Name: TABLE patients; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.patients TO anon;
GRANT ALL ON TABLE public.patients TO authenticated;
GRANT ALL ON TABLE public.patients TO service_role;
GRANT ALL ON TABLE public.patients TO supabase_auth_admin;


--
-- TOC entry 4593 (class 0 OID 0)
-- Dependencies: 297
-- Name: TABLE profiles; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.profiles TO anon;
GRANT ALL ON TABLE public.profiles TO authenticated;
GRANT ALL ON TABLE public.profiles TO service_role;
GRANT ALL ON TABLE public.profiles TO supabase_auth_admin;


--
-- TOC entry 4595 (class 0 OID 0)
-- Dependencies: 322
-- Name: TABLE approval_renewal_status; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.approval_renewal_status TO anon;
GRANT ALL ON TABLE public.approval_renewal_status TO authenticated;
GRANT ALL ON TABLE public.approval_renewal_status TO service_role;


--
-- TOC entry 4596 (class 0 OID 0)
-- Dependencies: 303
-- Name: TABLE assignment_log; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.assignment_log TO anon;
GRANT ALL ON TABLE public.assignment_log TO authenticated;
GRANT ALL ON TABLE public.assignment_log TO service_role;
GRANT ALL ON TABLE public.assignment_log TO supabase_auth_admin;


--
-- TOC entry 4598 (class 0 OID 0)
-- Dependencies: 302
-- Name: SEQUENCE assignment_log_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.assignment_log_id_seq TO anon;
GRANT ALL ON SEQUENCE public.assignment_log_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.assignment_log_id_seq TO service_role;
GRANT ALL ON SEQUENCE public.assignment_log_id_seq TO supabase_auth_admin;


--
-- TOC entry 4599 (class 0 OID 0)
-- Dependencies: 320
-- Name: TABLE auth_trigger_debug_log; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.auth_trigger_debug_log TO anon;
GRANT ALL ON TABLE public.auth_trigger_debug_log TO authenticated;
GRANT ALL ON TABLE public.auth_trigger_debug_log TO service_role;
GRANT ALL ON TABLE public.auth_trigger_debug_log TO supabase_auth_admin;


--
-- TOC entry 4600 (class 0 OID 0)
-- Dependencies: 317
-- Name: TABLE auth_trigger_logs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.auth_trigger_logs TO anon;
GRANT ALL ON TABLE public.auth_trigger_logs TO authenticated;
GRANT ALL ON TABLE public.auth_trigger_logs TO service_role;
GRANT ALL ON TABLE public.auth_trigger_logs TO supabase_auth_admin;


--
-- TOC entry 4609 (class 0 OID 0)
-- Dependencies: 314
-- Name: TABLE clinical_notes; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.clinical_notes TO anon;
GRANT ALL ON TABLE public.clinical_notes TO authenticated;
GRANT ALL ON TABLE public.clinical_notes TO service_role;
GRANT ALL ON TABLE public.clinical_notes TO supabase_auth_admin;


--
-- TOC entry 4620 (class 0 OID 0)
-- Dependencies: 321
-- Name: TABLE faxes; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.faxes TO anon;
GRANT ALL ON TABLE public.faxes TO authenticated;
GRANT ALL ON TABLE public.faxes TO service_role;


--
-- TOC entry 4622 (class 0 OID 0)
-- Dependencies: 318
-- Name: TABLE medication_dosages; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.medication_dosages TO anon;
GRANT ALL ON TABLE public.medication_dosages TO authenticated;
GRANT ALL ON TABLE public.medication_dosages TO service_role;
GRANT ALL ON TABLE public.medication_dosages TO supabase_auth_admin;


--
-- TOC entry 4623 (class 0 OID 0)
-- Dependencies: 301
-- Name: TABLE patient_assignments; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.patient_assignments TO anon;
GRANT ALL ON TABLE public.patient_assignments TO authenticated;
GRANT ALL ON TABLE public.patient_assignments TO service_role;
GRANT ALL ON TABLE public.patient_assignments TO supabase_auth_admin;


--
-- TOC entry 4626 (class 0 OID 0)
-- Dependencies: 309
-- Name: TABLE provider_availability_overrides; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.provider_availability_overrides TO anon;
GRANT ALL ON TABLE public.provider_availability_overrides TO authenticated;
GRANT ALL ON TABLE public.provider_availability_overrides TO service_role;
GRANT ALL ON TABLE public.provider_availability_overrides TO supabase_auth_admin;


--
-- TOC entry 4630 (class 0 OID 0)
-- Dependencies: 308
-- Name: TABLE provider_schedules; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.provider_schedules TO anon;
GRANT ALL ON TABLE public.provider_schedules TO authenticated;
GRANT ALL ON TABLE public.provider_schedules TO service_role;
GRANT ALL ON TABLE public.provider_schedules TO supabase_auth_admin;


--
-- TOC entry 4631 (class 0 OID 0)
-- Dependencies: 299
-- Name: TABLE providers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.providers TO anon;
GRANT ALL ON TABLE public.providers TO authenticated;
GRANT ALL ON TABLE public.providers TO service_role;
GRANT ALL ON TABLE public.providers TO supabase_auth_admin;


--
-- TOC entry 4633 (class 0 OID 0)
-- Dependencies: 312
-- Name: TABLE provider_availability_summary; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.provider_availability_summary TO anon;
GRANT ALL ON TABLE public.provider_availability_summary TO authenticated;
GRANT ALL ON TABLE public.provider_availability_summary TO service_role;
GRANT ALL ON TABLE public.provider_availability_summary TO supabase_auth_admin;


--
-- TOC entry 4635 (class 0 OID 0)
-- Dependencies: 313
-- Name: TABLE upcoming_appointments_summary; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.upcoming_appointments_summary TO anon;
GRANT ALL ON TABLE public.upcoming_appointments_summary TO authenticated;
GRANT ALL ON TABLE public.upcoming_appointments_summary TO service_role;
GRANT ALL ON TABLE public.upcoming_appointments_summary TO supabase_auth_admin;


--
-- TOC entry 4641 (class 0 OID 0)
-- Dependencies: 319
-- Name: TABLE visit_addendums; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.visit_addendums TO anon;
GRANT ALL ON TABLE public.visit_addendums TO authenticated;
GRANT ALL ON TABLE public.visit_addendums TO service_role;
GRANT ALL ON TABLE public.visit_addendums TO supabase_auth_admin;


--
-- TOC entry 4645 (class 0 OID 0)
-- Dependencies: 316
-- Name: TABLE visit_interactions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.visit_interactions TO anon;
GRANT ALL ON TABLE public.visit_interactions TO authenticated;
GRANT ALL ON TABLE public.visit_interactions TO service_role;
GRANT ALL ON TABLE public.visit_interactions TO supabase_auth_admin;


--
-- TOC entry 4650 (class 0 OID 0)
-- Dependencies: 315
-- Name: TABLE visit_medication_adjustments; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.visit_medication_adjustments TO anon;
GRANT ALL ON TABLE public.visit_medication_adjustments TO authenticated;
GRANT ALL ON TABLE public.visit_medication_adjustments TO service_role;
GRANT ALL ON TABLE public.visit_medication_adjustments TO supabase_auth_admin;


--
-- TOC entry 2534 (class 826 OID 16603)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- TOC entry 2535 (class 826 OID 16604)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- TOC entry 2533 (class 826 OID 16602)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO dashboard_user;


--
-- TOC entry 2526 (class 826 OID 16453)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- TOC entry 2527 (class 826 OID 16454)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- TOC entry 2525 (class 826 OID 16452)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- TOC entry 2529 (class 826 OID 16456)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- TOC entry 2524 (class 826 OID 16451)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- TOC entry 2528 (class 826 OID 16455)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO service_role;


-- Completed on 2025-10-02 02:29:38 UTC

--
-- PostgreSQL database dump complete
--

