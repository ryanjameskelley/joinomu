--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-10-03 08:14:08 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS postgres;
--
-- TOC entry 4746 (class 1262 OID 5)
-- Name: postgres; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = icu LOCALE = 'en_US.UTF-8' ICU_LOCALE = 'en-US';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4747 (class 0 OID 0)
-- Dependencies: 4746
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- TOC entry 4748 (class 0 OID 0)
-- Name: postgres; Type: DATABASE PROPERTIES; Schema: -; Owner: -
--

ALTER DATABASE postgres SET "app.settings.jwt_secret" TO 'super-secret-jwt-token-with-at-least-32-characters-long';
ALTER DATABASE postgres SET "app.settings.jwt_exp" TO '3600';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 38 (class 2615 OID 16457)
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- TOC entry 29 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- TOC entry 4749 (class 0 OID 0)
-- Dependencies: 29
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- TOC entry 23 (class 2615 OID 16605)
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA realtime;


--
-- TOC entry 39 (class 2615 OID 16505)
-- Name: storage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA storage;


--
-- TOC entry 17 (class 2615 OID 16750)
-- Name: supabase_functions; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA supabase_functions;


--
-- TOC entry 1278 (class 1247 OID 18022)
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


--
-- TOC entry 1302 (class 1247 OID 18163)
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


--
-- TOC entry 1275 (class 1247 OID 18016)
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


--
-- TOC entry 1272 (class 1247 OID 18011)
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


--
-- TOC entry 1314 (class 1247 OID 18244)
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


--
-- TOC entry 1308 (class 1247 OID 18205)
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


--
-- TOC entry 1218 (class 1247 OID 16890)
-- Name: action; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


--
-- TOC entry 1209 (class 1247 OID 16850)
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


--
-- TOC entry 1212 (class 1247 OID 16865)
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


--
-- TOC entry 1224 (class 1247 OID 16932)
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


--
-- TOC entry 1221 (class 1247 OID 16903)
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


--
-- TOC entry 1257 (class 1247 OID 17887)
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: -
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS'
);


--
-- TOC entry 532 (class 1255 OID 16503)
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


--
-- TOC entry 4750 (class 0 OID 0)
-- Dependencies: 532
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- TOC entry 370 (class 1255 OID 17993)
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


--
-- TOC entry 451 (class 1255 OID 16502)
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


--
-- TOC entry 4751 (class 0 OID 0)
-- Dependencies: 451
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- TOC entry 448 (class 1255 OID 16501)
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


--
-- TOC entry 4752 (class 0 OID 0)
-- Dependencies: 448
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- TOC entry 525 (class 1255 OID 18413)
-- Name: assign_patient_to_provider(uuid, uuid, text, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.assign_patient_to_provider(patient_profile_id uuid, provider_profile_id uuid, treatment_type_param text DEFAULT 'general_care'::text, is_primary_param boolean DEFAULT false) RETURNS TABLE(success boolean, message text, assignment_id uuid)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  patient_id_var UUID;
  provider_id_var UUID;
  assignment_id_var UUID;
BEGIN
  -- Get the patient ID from profile ID
  SELECT id INTO patient_id_var
  FROM patients
  WHERE profile_id = patient_profile_id;
  
  IF patient_id_var IS NULL THEN
    RETURN QUERY SELECT false, 'Patient not found', NULL::UUID;
    RETURN;
  END IF;
  
  -- Get the provider ID from profile ID
  SELECT id INTO provider_id_var
  FROM providers
  WHERE profile_id = provider_profile_id AND active = true;
  
  IF provider_id_var IS NULL THEN
    RETURN QUERY SELECT false, 'Provider not found or inactive', NULL::UUID;
    RETURN;
  END IF;
  
  -- Check if assignment already exists
  IF EXISTS (
    SELECT 1 FROM patient_assignments 
    WHERE patient_id = patient_id_var 
    AND provider_id = provider_id_var
    AND treatment_type = treatment_type_param
  ) THEN
    RETURN QUERY SELECT false, 'Patient is already assigned to this provider for this treatment type', NULL::UUID;
    RETURN;
  END IF;
  
  -- Create the assignment
  INSERT INTO patient_assignments (
    patient_id,
    provider_id,
    treatment_type,
    is_primary,
    assigned_date
  ) VALUES (
    patient_id_var,
    provider_id_var,
    treatment_type_param,
    is_primary_param,
    CURRENT_DATE
  ) RETURNING id INTO assignment_id_var;
  
  RETURN QUERY SELECT true, 'Patient successfully assigned to provider', assignment_id_var;
END;
$$;


--
-- TOC entry 489 (class 1255 OID 18666)
-- Name: book_appointment(uuid, uuid, date, time without time zone, text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text DEFAULT 'consultation'::text, p_booked_by text DEFAULT 'patient'::text, p_patient_notes text DEFAULT NULL::text) RETURNS TABLE(success boolean, appointment_id uuid, message text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  v_patient_id UUID;
  v_assignment_id UUID;
  v_duration_minutes INTEGER;
  v_end_time TIME;
  v_new_appointment_id UUID;
BEGIN
  -- Get patient ID from profile ID
  SELECT p.id INTO v_patient_id
  FROM patients p
  WHERE p.profile_id = p_patient_profile_id;
  
  IF v_patient_id IS NULL THEN
    success := false;
    appointment_id := NULL;
    message := 'Patient not found';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Verify patient-provider relationship exists
  SELECT pa.id INTO v_assignment_id
  FROM patient_assignments pa
  WHERE pa.patient_id = v_patient_id
    AND pa.provider_id = p_provider_id
    AND pa.active = true
  LIMIT 1;
  
  IF v_assignment_id IS NULL THEN
    success := false;
    appointment_id := NULL;
    message := 'No active assignment between patient and provider';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Check if the requested slot is available
  SELECT ps.slot_duration_minutes INTO v_duration_minutes
  FROM provider_schedules ps
  WHERE ps.provider_id = p_provider_id
    AND ps.day_of_week = EXTRACT(DOW FROM p_appointment_date)
    AND ps.start_time <= p_start_time
    AND ps.end_time >= p_start_time + INTERVAL '30 minutes' -- minimum slot
    AND ps.active = true
    AND (p_treatment_type = ANY(ps.treatment_types) OR array_length(ps.treatment_types, 1) IS NULL)
  LIMIT 1;
  
  IF v_duration_minutes IS NULL THEN
    success := false;
    appointment_id := NULL;
    message := 'Provider not available at requested time';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Calculate end time
  v_end_time := p_start_time + INTERVAL '1 minute' * v_duration_minutes;
  
  -- Check for scheduling conflicts
  IF EXISTS (
    SELECT 1 FROM appointments a
    WHERE a.provider_id = p_provider_id
      AND a.appointment_date = p_appointment_date
      AND a.start_time = p_start_time
      AND a.status NOT IN ('cancelled', 'no_show')
  ) THEN
    success := false;
    appointment_id := NULL;
    message := 'Time slot already booked';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Check for availability overrides
  IF EXISTS (
    SELECT 1 FROM provider_availability_overrides pao
    WHERE pao.provider_id = p_provider_id
      AND pao.date = p_appointment_date
      AND pao.available = false
      AND (pao.start_time IS NULL OR p_start_time >= pao.start_time)
      AND (pao.end_time IS NULL OR v_end_time <= pao.end_time)
  ) THEN
    success := false;
    appointment_id := NULL;
    message := 'Provider not available on requested date';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Create the appointment
  INSERT INTO appointments (
    patient_id,
    provider_id,
    assignment_id,
    appointment_date,
    start_time,
    end_time,
    duration_minutes,
    treatment_type,
    appointment_type,
    status,
    patient_notes,
    booked_by,
    booked_by_user_id
  ) VALUES (
    v_patient_id,
    p_provider_id,
    v_assignment_id,
    p_appointment_date,
    p_start_time,
    v_end_time,
    v_duration_minutes,
    p_treatment_type,
    p_appointment_type,
    'scheduled',
    p_patient_notes,
    p_booked_by,
    p_patient_profile_id
  ) RETURNING id INTO v_new_appointment_id;
  
  -- Return success
  success := true;
  appointment_id := v_new_appointment_id;
  message := 'Appointment booked successfully';
  RETURN NEXT;
  RETURN;
  
EXCEPTION
  WHEN OTHERS THEN
    success := false;
    appointment_id := NULL;
    message := 'Error booking appointment: ' || SQLERRM;
    RETURN NEXT;
    RETURN;
END;
$$;


--
-- TOC entry 4753 (class 0 OID 0)
-- Dependencies: 489
-- Name: FUNCTION book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text, p_booked_by text, p_patient_notes text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text, p_booked_by text, p_patient_notes text) IS 'Books a new appointment with full validation';


--
-- TOC entry 406 (class 1255 OID 19121)
-- Name: calculate_next_prescription_due(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.calculate_next_prescription_due() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_fax_date DATE;
    v_calculated_due_date DATE;
BEGIN
    -- Only proceed if supply_days was added/changed and we have an approved status
    IF NEW.supply_days IS NOT NULL 
       AND NEW.supply_days > 0 
       AND NEW.status = 'approved'
       AND (OLD.supply_days IS NULL OR OLD.supply_days != NEW.supply_days OR OLD.status != 'approved') THEN
        
        -- Use the faxed date from the preference itself
        IF NEW.faxed IS NOT NULL THEN
            v_fax_date := NEW.faxed::date;
            v_calculated_due_date := v_fax_date + NEW.supply_days;
            
            -- Update the next_prescription_due field
            NEW.next_prescription_due := v_calculated_due_date;
            
            -- Log the calculation for debugging (if logging table exists)
            BEGIN
                INSERT INTO auth_trigger_logs (
                    step, 
                    status, 
                    message, 
                    metadata
                ) VALUES (
                    'SUPPLY_CALCULATION', 
                    'SUCCESS', 
                    'Calculated next prescription due from preference update',
                    jsonb_build_object(
                        'preference_id', NEW.id,
                        'fax_date', v_fax_date,
                        'supply_days', NEW.supply_days,
                        'calculated_due_date', v_calculated_due_date
                    )
                );
            EXCEPTION WHEN OTHERS THEN
                -- Ignore logging errors, don't fail the main operation
                NULL;
            END;
        ELSE
            -- If no fax date, set the faxed date to now when approving with supply
            NEW.faxed := NOW();
            v_fax_date := NEW.faxed::date;
            v_calculated_due_date := v_fax_date + NEW.supply_days;
            NEW.next_prescription_due := v_calculated_due_date;
            
            -- Log that we set the fax date
            BEGIN
                INSERT INTO auth_trigger_logs (
                    step, 
                    status, 
                    message, 
                    metadata
                ) VALUES (
                    'SUPPLY_CALCULATION', 
                    'SUCCESS', 
                    'Set fax date to now and calculated next prescription due',
                    jsonb_build_object(
                        'preference_id', NEW.id,
                        'fax_date', v_fax_date,
                        'supply_days', NEW.supply_days,
                        'calculated_due_date', v_calculated_due_date
                    )
                );
            EXCEPTION WHEN OTHERS THEN
                -- Ignore logging errors, don't fail the main operation
                NULL;
            END;
        END IF;
    END IF;
    
    -- Reset refill_requested flag when status changes to approved
    IF NEW.status = 'approved' AND OLD.status != 'approved' THEN
        NEW.refill_requested := FALSE;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- TOC entry 4754 (class 0 OID 0)
-- Dependencies: 406
-- Name: FUNCTION calculate_next_prescription_due(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.calculate_next_prescription_due() IS 'Calculates next_prescription_due when supply_days is updated with approved status, and resets refill_requested flag on approval';


--
-- TOC entry 501 (class 1255 OID 19049)
-- Name: calculate_next_prescription_due(uuid, date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.calculate_next_prescription_due(p_preference_id uuid, p_delivery_date date, p_frequency text DEFAULT NULL::text) RETURNS date
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_supply_days INTEGER;
    v_frequency TEXT;
    v_next_due_date DATE;
BEGIN
    -- Get supply_days and frequency from the preference
    SELECT supply_days, frequency 
    INTO v_supply_days, v_frequency
    FROM patient_medication_preferences 
    WHERE id = p_preference_id;
    
    -- Use provided frequency if given, otherwise use the preference frequency
    IF p_frequency IS NOT NULL THEN
        v_frequency := p_frequency;
    END IF;
    
    -- If supply_days is set, use it directly
    IF v_supply_days IS NOT NULL AND v_supply_days > 0 THEN
        v_next_due_date := p_delivery_date + v_supply_days;
    ELSE
        -- Fall back to frequency-based calculation
        CASE 
            WHEN v_frequency = 'daily' THEN
                v_next_due_date := p_delivery_date + INTERVAL '30 days';
            WHEN v_frequency = 'weekly' THEN
                v_next_due_date := p_delivery_date + INTERVAL '12 weeks';
            WHEN v_frequency = 'monthly' THEN
                v_next_due_date := p_delivery_date + INTERVAL '3 months';
            WHEN v_frequency = 'quarterly' THEN
                v_next_due_date := p_delivery_date + INTERVAL '3 months';
            ELSE
                -- Default to 30 days if frequency not recognized
                v_next_due_date := p_delivery_date + INTERVAL '30 days';
        END CASE;
    END IF;
    
    RETURN v_next_due_date;
END;
$$;


--
-- TOC entry 4755 (class 0 OID 0)
-- Dependencies: 501
-- Name: FUNCTION calculate_next_prescription_due(p_preference_id uuid, p_delivery_date date, p_frequency text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.calculate_next_prescription_due(p_preference_id uuid, p_delivery_date date, p_frequency text) IS 'Calculate next prescription due date using supply_days from preferences if available, otherwise fall back to frequency-based calculation';


--
-- TOC entry 447 (class 1255 OID 18668)
-- Name: cancel_appointment(uuid, text, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text) RETURNS TABLE(success boolean, message text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  v_appointment RECORD;
BEGIN
  -- Get appointment details
  SELECT * INTO v_appointment
  FROM appointments
  WHERE id = p_appointment_id;
  
  IF NOT FOUND THEN
    success := false;
    message := 'Appointment not found';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Check if appointment can be cancelled
  IF v_appointment.status NOT IN ('scheduled', 'confirmed') THEN
    success := false;
    message := 'Appointment cannot be cancelled in current status: ' || v_appointment.status;
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Update appointment status
  UPDATE appointments
  SET 
    status = 'cancelled',
    cancelled_at = NOW(),
    cancelled_by = p_cancelled_by,
    cancelled_by_user_id = p_cancelled_by_user_id,
    cancellation_reason = p_cancellation_reason
  WHERE id = p_appointment_id;
  
  success := true;
  message := 'Appointment cancelled successfully';
  RETURN NEXT;
  RETURN;
  
EXCEPTION
  WHEN OTHERS THEN
    success := false;
    message := 'Error cancelling appointment: ' || SQLERRM;
    RETURN NEXT;
    RETURN;
END;
$$;


--
-- TOC entry 4756 (class 0 OID 0)
-- Dependencies: 447
-- Name: FUNCTION cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text) IS 'Cancels an existing appointment with audit trail';


--
-- TOC entry 515 (class 1255 OID 19109)
-- Name: check_approval_expiry_on_delivery(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_approval_expiry_on_delivery() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only proceed if fulfillment status changed to 'delivered' and estimated_delivery is set
    IF OLD.fulfillment_status != 'delivered' AND NEW.fulfillment_status = 'delivered' AND NEW.estimated_delivery IS NOT NULL THEN
        -- Check if this specific preference should be reset due to expiry
        UPDATE public.patient_medication_preferences 
        SET 
            status = 'pending',
            updated_at = NOW()
        FROM public.medication_approvals ma
        WHERE patient_medication_preferences.id = ma.preference_id
        AND ma.id = NEW.approval_id
        AND ma.status = 'approved'
        AND ma.supply_days IS NOT NULL
        AND (NEW.estimated_delivery::DATE + INTERVAL '1 day' * ma.supply_days) <= CURRENT_DATE;
        
        -- Also run the general daily check (but it will skip if already run today)
        PERFORM public.daily_approval_reset_check();
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- TOC entry 4757 (class 0 OID 0)
-- Dependencies: 515
-- Name: FUNCTION check_approval_expiry_on_delivery(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.check_approval_expiry_on_delivery() IS 'Check preference expiry when orders are delivered and reset to pending status';


--
-- TOC entry 474 (class 1255 OID 18865)
-- Name: check_auth_trigger_health(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_auth_trigger_health() RETURNS TABLE(metric text, value integer, status text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    auth_users_count INTEGER;
    profiles_count INTEGER;
    providers_count INTEGER;
    schedules_count INTEGER;
    recent_failures INTEGER;
    missing_profiles INTEGER;
BEGIN
    -- Get counts
    SELECT COUNT(*) INTO auth_users_count FROM auth.users;
    SELECT COUNT(*) INTO profiles_count FROM public.profiles;
    SELECT COUNT(*) INTO providers_count FROM public.providers;
    SELECT COUNT(*) INTO schedules_count FROM public.provider_schedules;
    
    -- Check for missing profiles
    SELECT COUNT(*) INTO missing_profiles 
    FROM auth.users u 
    LEFT JOIN public.profiles p ON u.id = p.id 
    WHERE p.id IS NULL;
    
    -- Check recent failures
    SELECT COUNT(*) INTO recent_failures 
    FROM public.auth_trigger_logs 
    WHERE success = false 
    AND created_at > NOW() - INTERVAL '1 hour';
    
    -- Return metrics
    RETURN QUERY VALUES 
        ('auth_users', auth_users_count, CASE WHEN auth_users_count > 0 THEN 'OK' ELSE 'EMPTY' END),
        ('profiles', profiles_count, CASE WHEN profiles_count >= auth_users_count THEN 'OK' ELSE 'MISSING' END),
        ('providers', providers_count, 'INFO'),
        ('schedules', schedules_count, 'INFO'),
        ('missing_profiles', missing_profiles, CASE WHEN missing_profiles = 0 THEN 'OK' ELSE 'NEEDS_REPAIR' END),
        ('recent_failures', recent_failures, CASE WHEN recent_failures = 0 THEN 'OK' ELSE 'ATTENTION' END);
END;
$$;


--
-- TOC entry 369 (class 1255 OID 19052)
-- Name: clear_overdue_faxed_status(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.clear_overdue_faxed_status() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    rows_updated INTEGER;
BEGIN
    UPDATE public.patient_medication_preferences 
    SET faxed = NULL
    WHERE faxed IS NOT NULL 
    AND next_prescription_due IS NOT NULL 
    AND next_prescription_due <= CURRENT_DATE;
    
    GET DIAGNOSTICS rows_updated = ROW_COUNT;
    RETURN rows_updated;
END;
$$;


--
-- TOC entry 4758 (class 0 OID 0)
-- Dependencies: 369
-- Name: FUNCTION clear_overdue_faxed_status(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.clear_overdue_faxed_status() IS 'Clears faxed status for preferences where prescription is now due';


--
-- TOC entry 442 (class 1255 OID 18836)
-- Name: create_default_provider_schedule(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_default_provider_schedule() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RAISE LOG 'Provider schedule trigger fired for provider ID: %', NEW.id;
    RAISE NOTICE 'Provider schedule trigger fired for provider ID: %', NEW.id;
    
    -- Add Monday-Friday 9 AM to 5 PM schedule for new provider
    INSERT INTO provider_schedules (provider_id, day_of_week, start_time, end_time, active, created_at) VALUES
    (NEW.id, 1, '09:00:00', '17:00:00', true, now()), -- Monday
    (NEW.id, 2, '09:00:00', '17:00:00', true, now()), -- Tuesday
    (NEW.id, 3, '09:00:00', '17:00:00', true, now()), -- Wednesday
    (NEW.id, 4, '09:00:00', '17:00:00', true, now()), -- Thursday
    (NEW.id, 5, '09:00:00', '17:00:00', true, now()); -- Friday
    
    RAISE LOG 'Created default schedule for provider %', NEW.id;
    RAISE NOTICE 'Created default schedule for provider %', NEW.id;
    
    RETURN NEW;
EXCEPTION
    WHEN OTHERS THEN
        -- Log error but don't fail the provider creation
        RAISE LOG 'Error creating default schedule for provider %: %', NEW.id, SQLERRM;
        RAISE NOTICE 'Error creating default schedule for provider %: %', NEW.id, SQLERRM;
        RETURN NEW;
END;
$$;


--
-- TOC entry 416 (class 1255 OID 19054)
-- Name: create_order_on_fax(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_order_on_fax() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only create order when a fax is inserted
    IF TG_OP = 'INSERT' THEN
        -- Insert medication order using profile IDs directly
        INSERT INTO public.medication_orders (
            approval_id,
            medication_id,
            patient_id,
            provider_profile_id,
            patient_profile_id,
            quantity,
            unit_price,
            total_amount
        )
        SELECT 
            NEW.approval_id,
            pmp.medication_id,
            (SELECT pt.id FROM public.patients pt WHERE pt.profile_id = NEW.patient_profile_id LIMIT 1),
            NEW.provider_profile_id,
            NEW.patient_profile_id,
            1, -- Default quantity
            COALESCE(m.unit_price, 0.00), -- Get price from medications table
            COALESCE(m.unit_price, 0.00) * 1 -- Total = unit_price * quantity
        FROM public.medication_approvals ma
        JOIN public.patient_medication_preferences pmp ON ma.preference_id = pmp.id
        JOIN public.medications m ON pmp.medication_id = m.id
        WHERE ma.id = NEW.approval_id;
        
        RETURN NEW;
    END IF;
    
    RETURN NULL;
END;
$$;


--
-- TOC entry 4759 (class 0 OID 0)
-- Dependencies: 416
-- Name: FUNCTION create_order_on_fax(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.create_order_on_fax() IS 'Creates medication order when prescription is faxed - uses profile IDs directly for simplicity';


--
-- TOC entry 397 (class 1255 OID 19108)
-- Name: daily_approval_reset_check(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.daily_approval_reset_check() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    last_run_date DATE;
    rows_reset INTEGER;
BEGIN
    -- Check when this was last run using correct column names
    SELECT (metadata->>'reset_date')::DATE 
    INTO last_run_date
    FROM public.auth_trigger_logs 
    WHERE trigger_stage = 'APPROVAL_RESET' 
    AND success = true
    ORDER BY created_at DESC 
    LIMIT 1;
    
    -- Only run if we haven't run today
    IF last_run_date IS NULL OR last_run_date < CURRENT_DATE THEN
        rows_reset := public.reset_expired_approvals();
        RETURN rows_reset;
    ELSE
        -- Log that we skipped because already ran today
        INSERT INTO public.auth_trigger_logs (trigger_stage, success, error_message, metadata, created_at)
        VALUES (
            'APPROVAL_RESET_SKIPPED', 
            true, 
            'Skipped approval reset - already ran today',
            jsonb_build_object('last_run_date', last_run_date, 'current_date', CURRENT_DATE),
            NOW()
        );
        RETURN 0;
    END IF;
END;
$$;


--
-- TOC entry 4760 (class 0 OID 0)
-- Dependencies: 397
-- Name: FUNCTION daily_approval_reset_check(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.daily_approval_reset_check() IS 'Daily check for expired approvals with duplicate run prevention (fixed to use trigger_stage and success columns)';


--
-- TOC entry 510 (class 1255 OID 19120)
-- Name: fix_existing_next_due_calculations(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fix_existing_next_due_calculations() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    preference_record RECORD;
    v_fax_date DATE;
    v_calculated_due_date DATE;
    v_updated_count INTEGER := 0;
BEGIN
    -- Loop through all preferences that have supply_days but no next_prescription_due
    FOR preference_record IN 
        SELECT id, supply_days, faxed
        FROM patient_medication_preferences 
        WHERE supply_days IS NOT NULL 
          AND supply_days > 0 
          AND (next_prescription_due IS NULL OR next_prescription_due < CURRENT_DATE)
          AND faxed IS NOT NULL
    LOOP
        -- Use the faxed date from the preference
        v_fax_date := preference_record.faxed::date;
        
        -- Calculate and update
        IF v_fax_date IS NOT NULL THEN
            v_calculated_due_date := v_fax_date + preference_record.supply_days;
            
            UPDATE patient_medication_preferences 
            SET 
                next_prescription_due = v_calculated_due_date,
                updated_at = NOW()
            WHERE id = preference_record.id;
            
            v_updated_count := v_updated_count + 1;
        END IF;
    END LOOP;
    
    RETURN v_updated_count;
END;
$$;


--
-- TOC entry 4761 (class 0 OID 0)
-- Dependencies: 510
-- Name: FUNCTION fix_existing_next_due_calculations(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.fix_existing_next_due_calculations() IS 'Fixes next_prescription_due for preferences with supply_days based on preference.faxed field';


--
-- TOC entry 390 (class 1255 OID 18669)
-- Name: get_admin_appointment_overview(date, date, uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_admin_appointment_overview(p_date_range_start date DEFAULT CURRENT_DATE, p_date_range_end date DEFAULT (CURRENT_DATE + '7 days'::interval), p_provider_id uuid DEFAULT NULL::uuid, p_patient_id uuid DEFAULT NULL::uuid) RETURNS TABLE(appointment_id uuid, patient_name text, provider_name text, appointment_date date, start_time time without time zone, end_time time without time zone, treatment_type text, appointment_type text, status text, last_updated timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    a.id as appointment_id,
    (patient_prof.first_name || ' ' || patient_prof.last_name) as patient_name,
    (provider_prof.first_name || ' ' || provider_prof.last_name) as provider_name,
    a.appointment_date,
    a.start_time,
    a.end_time,
    a.treatment_type,
    a.appointment_type,
    a.status,
    a.updated_at as last_updated
  FROM appointments a
  INNER JOIN patients p ON a.patient_id = p.id
  INNER JOIN profiles patient_prof ON p.profile_id = patient_prof.id
  INNER JOIN providers prov ON a.provider_id = prov.id
  INNER JOIN profiles provider_prof ON prov.profile_id = provider_prof.id
  WHERE a.appointment_date >= p_date_range_start
    AND a.appointment_date <= p_date_range_end
    AND (p_provider_id IS NULL OR a.provider_id = p_provider_id)
    AND (p_patient_id IS NULL OR a.patient_id = p_patient_id)
  ORDER BY a.appointment_date ASC, a.start_time ASC;
END;
$$;


--
-- TOC entry 4762 (class 0 OID 0)
-- Dependencies: 390
-- Name: FUNCTION get_admin_appointment_overview(p_date_range_start date, p_date_range_end date, p_provider_id uuid, p_patient_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_admin_appointment_overview(p_date_range_start date, p_date_range_end date, p_provider_id uuid, p_patient_id uuid) IS 'Admin dashboard view of appointments with filtering';


--
-- TOC entry 438 (class 1255 OID 18543)
-- Name: get_admin_fulfillment_queue(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_admin_fulfillment_queue() RETURNS TABLE(order_id uuid, patient_name text, medication_name text, quantity integer, total_amount numeric, payment_status text, fulfillment_status text, order_date timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    mo.id,
    CONCAT(pr.first_name, ' ', pr.last_name),
    m.name,
    mo.quantity,
    mo.total_amount,
    mo.payment_status,
    mo.fulfillment_status,
    mo.created_at
  FROM medication_orders mo
  JOIN medications m ON mo.medication_id = m.id
  JOIN patients pt ON mo.patient_id = pt.id
  JOIN profiles pr ON pt.profile_id = pr.id
  WHERE mo.fulfillment_status IN ('pending', 'processing')
  ORDER BY 
    CASE mo.payment_status 
      WHEN 'paid' THEN 1 
      ELSE 2 
    END,
    mo.created_at ASC;
END;
$$;


--
-- TOC entry 530 (class 1255 OID 18548)
-- Name: get_all_patients_for_admin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_all_patients_for_admin() RETURNS TABLE(patient_id uuid, profile_id uuid, first_name text, last_name text, email text, phone text, date_of_birth date, has_completed_intake boolean, assigned_providers text[], treatment_types text[], medications text[], created_at timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id as patient_id,
    p.profile_id,
    prof.first_name,
    prof.last_name,
    prof.email,
    p.phone,
    p.date_of_birth,
    p.has_completed_intake,
    COALESCE(
      ARRAY_AGG(
        DISTINCT CONCAT(prov_prof.first_name, ' ', prov_prof.last_name)
      ) FILTER (WHERE pa.id IS NOT NULL),
      '{}'::TEXT[]
    ) as assigned_providers,
    COALESCE(
      ARRAY_AGG(DISTINCT pa.treatment_type) FILTER (WHERE pa.treatment_type IS NOT NULL),
      '{}'::TEXT[]
    ) as treatment_types,
    COALESCE(
      ARRAY_AGG(DISTINCT m.name) FILTER (WHERE m.name IS NOT NULL),
      '{}'::TEXT[]
    ) as medications,
    p.created_at
  FROM patients p
  INNER JOIN profiles prof ON p.profile_id = prof.id
  LEFT JOIN patient_assignments pa ON p.profile_id = pa.patient_id
  LEFT JOIN providers prov ON pa.provider_id = prov.id
  LEFT JOIN profiles prov_prof ON prov.profile_id = prov_prof.id
  LEFT JOIN patient_medication_preferences pmp ON p.id = pmp.patient_id
  LEFT JOIN medications m ON pmp.medication_id = m.id
  WHERE prof.role = 'patient'  -- Only include users with patient role
  GROUP BY p.id, p.profile_id, prof.first_name, prof.last_name, prof.email, p.phone, p.date_of_birth, p.has_completed_intake, p.created_at
  ORDER BY prof.first_name, prof.last_name;
END;
$$;


--
-- TOC entry 372 (class 1255 OID 19101)
-- Name: get_approvals_due_for_renewal(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_approvals_due_for_renewal() RETURNS TABLE(approval_id uuid, patient_name text, medication_name text, supply_days integer, estimated_delivery date, days_since_delivery integer, expires_on date)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        ma.id as approval_id,
        (p.first_name || ' ' || p.last_name) as patient_name,
        m.name as medication_name,
        ma.supply_days,
        mo.estimated_delivery::DATE as estimated_delivery,
        (CURRENT_DATE - mo.estimated_delivery::DATE) as days_since_delivery,
        (mo.estimated_delivery::DATE + INTERVAL '1 day' * ma.supply_days)::DATE as expires_on
    FROM public.medication_approvals ma
    JOIN public.medication_orders mo ON ma.id = mo.approval_id
    JOIN public.patient_medication_preferences pmp ON ma.preference_id = pmp.id
    JOIN public.medications m ON pmp.medication_id = m.id
    JOIN public.patients pt ON pmp.patient_id = pt.id
    JOIN public.profiles p ON pt.profile_id = p.id
    WHERE ma.status = 'approved'
    AND ma.supply_days IS NOT NULL
    AND mo.estimated_delivery IS NOT NULL
    AND mo.fulfillment_status = 'delivered'
    AND (mo.estimated_delivery::DATE + INTERVAL '1 day' * ma.supply_days) <= CURRENT_DATE;
END;
$$;


--
-- TOC entry 4763 (class 0 OID 0)
-- Dependencies: 372
-- Name: FUNCTION get_approvals_due_for_renewal(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_approvals_due_for_renewal() IS 'Returns list of approvals that are due for renewal based on supply expiry';


--
-- TOC entry 492 (class 1255 OID 18549)
-- Name: get_assigned_patients_for_provider(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_assigned_patients_for_provider(provider_profile_id uuid) RETURNS TABLE(patient_id uuid, profile_id uuid, first_name text, last_name text, email text, phone text, date_of_birth date, treatment_type text, assigned_date date, is_primary boolean, has_completed_intake boolean, created_at timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id as patient_id,
    p.profile_id,
    prof.first_name,
    prof.last_name,
    prof.email,
    p.phone,
    p.date_of_birth,
    pa.treatment_type,
    pa.assigned_date::DATE,
    pa.is_primary,
    p.has_completed_intake,
    p.created_at
  FROM patients p
  INNER JOIN profiles prof ON p.profile_id = prof.id
  INNER JOIN patient_assignments pa ON p.id = pa.patient_id  -- Fixed: was p.profile_id = pa.patient_id
  INNER JOIN providers prov ON pa.provider_id = prov.id
  WHERE prov.profile_id = provider_profile_id
  ORDER BY pa.assigned_date DESC, prof.first_name, prof.last_name;
END;
$$;


--
-- TOC entry 450 (class 1255 OID 18971)
-- Name: get_available_slots_for_provider(uuid, date, date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text DEFAULT NULL::text) RETURNS TABLE(slot_date date, slot_start_time time without time zone, slot_end_time time without time zone, duration_minutes integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY
  WITH RECURSIVE date_series AS (
    SELECT p_start_date AS date
    UNION ALL
    SELECT date + 1
    FROM date_series
    WHERE date < p_end_date
  ),
  provider_daily_schedule AS (
    SELECT 
      ds.date,
      ps.start_time,
      ps.end_time,
      ps.slot_duration_minutes,
      ps.treatment_types
    FROM date_series ds
    CROSS JOIN provider_schedules ps
    WHERE ps.provider_id = p_provider_id
      AND ps.active = true
      AND ps.day_of_week = EXTRACT(DOW FROM ds.date)
      AND (
        p_treatment_type IS NULL 
        OR array_length(ps.treatment_types, 1) IS NULL 
        OR p_treatment_type = ANY(ps.treatment_types)
      )
  ),
  time_slots AS (
    SELECT 
      pds.date,
      slot_time::TIME AS start_time,
      (slot_time + (pds.slot_duration_minutes || ' minutes')::INTERVAL)::TIME AS end_time,
      pds.slot_duration_minutes
    FROM provider_daily_schedule pds
    CROSS JOIN LATERAL generate_series(
      pds.date + pds.start_time,
      pds.date + pds.end_time - (pds.slot_duration_minutes || ' minutes')::INTERVAL,
      (pds.slot_duration_minutes || ' minutes')::INTERVAL
    ) AS slot_time
  )
  SELECT 
    ts.date AS slot_date,
    ts.start_time AS slot_start_time,
    ts.end_time AS slot_end_time,
    ts.slot_duration_minutes AS duration_minutes
  FROM time_slots ts
  LEFT JOIN appointments a ON (
    a.provider_id = p_provider_id
    AND a.appointment_date = ts.date
    AND a.start_time = ts.start_time
    AND a.status IN ('scheduled', 'confirmed')
    AND (a.is_reschedule_source IS NULL OR a.is_reschedule_source = false)
  )
  WHERE a.id IS NULL  -- Only return slots that don't have existing appointments
  ORDER BY ts.date, ts.start_time;
END;
$$;


--
-- TOC entry 4764 (class 0 OID 0)
-- Dependencies: 450
-- Name: FUNCTION get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text) IS 'Returns available appointment slots for a provider excluding rescheduled appointments';


--
-- TOC entry 378 (class 1255 OID 18665)
-- Name: get_patient_appointments(uuid, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean DEFAULT false) RETURNS TABLE(appointment_id uuid, provider_name text, provider_specialty text, appointment_date date, start_time time without time zone, end_time time without time zone, treatment_type text, appointment_type text, status text, patient_notes text, provider_notes text, can_cancel boolean, can_reschedule boolean, created_at timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    a.id as appointment_id,
    (prof.first_name || ' ' || prof.last_name) as provider_name,
    prov.specialty as provider_specialty,
    a.appointment_date,
    a.start_time,
    a.end_time,
    a.treatment_type,
    a.appointment_type,
    a.status,
    a.patient_notes,
    a.provider_notes,
    -- Can cancel if appointment is scheduled/confirmed and at least 24 hours away
    CASE 
      WHEN a.status IN ('scheduled', 'confirmed') 
        AND (a.appointment_date > CURRENT_DATE + INTERVAL '1 day' 
             OR (a.appointment_date = CURRENT_DATE + INTERVAL '1 day' AND a.start_time > LOCALTIME))
      THEN true
      ELSE false
    END as can_cancel,
    -- Can reschedule if appointment is scheduled/confirmed and at least 48 hours away
    CASE 
      WHEN a.status IN ('scheduled', 'confirmed') 
        AND (a.appointment_date > CURRENT_DATE + INTERVAL '2 days'
             OR (a.appointment_date = CURRENT_DATE + INTERVAL '2 days' AND a.start_time > LOCALTIME))
      THEN true
      ELSE false
    END as can_reschedule,
    a.created_at
  FROM appointments a
  INNER JOIN patients p ON a.patient_id = p.id
  INNER JOIN providers prov ON a.provider_id = prov.id
  INNER JOIN profiles prof ON prov.profile_id = prof.id
  WHERE p.profile_id = p_patient_profile_id
    AND (p_include_past = true OR a.appointment_date >= CURRENT_DATE)
  ORDER BY a.appointment_date ASC, a.start_time ASC;
END;
$$;


--
-- TOC entry 4765 (class 0 OID 0)
-- Dependencies: 378
-- Name: FUNCTION get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean) IS 'Gets all appointments for a patient with cancellation/reschedule permissions';


--
-- TOC entry 526 (class 1255 OID 18541)
-- Name: get_patient_medication_overview(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_patient_medication_overview(patient_uuid uuid) RETURNS TABLE(medication_name text, category text, preference_status text, approval_status text, order_status text, payment_status text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    m.name,
    m.category,
    pmp.status as preference_status,
    COALESCE(ma.status, 'no_review') as approval_status,
    COALESCE(mo.fulfillment_status, 'no_order') as order_status,
    COALESCE(mo.payment_status, 'no_payment') as payment_status
  FROM patient_medication_preferences pmp
  JOIN medications m ON pmp.medication_id = m.id
  LEFT JOIN medication_approvals ma ON pmp.id = ma.preference_id
  LEFT JOIN medication_orders mo ON ma.id = mo.approval_id
  WHERE pmp.patient_id = patient_uuid
  ORDER BY pmp.created_at DESC;
END;
$$;


--
-- TOC entry 502 (class 1255 OID 18546)
-- Name: get_patient_medications_detailed(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_patient_medications_detailed(patient_uuid uuid) RETURNS TABLE(medication_id uuid, medication_name text, dosage text, supply text, status text, last_payment_date timestamp with time zone, sent_to_pharmacy_date timestamp with time zone, shipped_date timestamp with time zone, tracking_number text, order_id uuid)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        m.id as medication_id,
        m.name as medication_name,
        CONCAT(m.strength, ' ', m.dosage_form) as dosage,
        CASE 
            WHEN mo.quantity > 1 THEN CONCAT(mo.quantity::TEXT, ' units')
            ELSE '30 day supply'
        END as supply,
        mo.fulfillment_status as status,
        mo.payment_date as last_payment_date,
        mo.sent_to_pharmacy as sent_to_pharmacy_date,
        mo.shipped_date as shipped_date,
        mo.tracking_number as tracking_number,
        mo.id as order_id
    FROM medication_orders mo
    JOIN medications m ON mo.medication_id = m.id
    JOIN medication_approvals ma ON mo.approval_id = ma.id
    JOIN patient_medication_preferences pmp ON ma.preference_id = pmp.id
    WHERE mo.patient_id = patient_uuid
    AND pmp.status = 'approved'
    AND ma.status = 'approved'
    ORDER BY mo.created_at DESC;
END;
$$;


--
-- TOC entry 518 (class 1255 OID 18409)
-- Name: get_provider_by_profile_id(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_provider_by_profile_id(provider_profile_id uuid) RETURNS TABLE(provider_id uuid, profile_id uuid, first_name text, last_name text, email text, specialty text, license_number text, phone text, active boolean)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    prov.id as provider_id,
    prov.profile_id,
    prof.first_name,
    prof.last_name,
    prof.email,
    prov.specialty,
    prov.license_number,
    prov.phone,
    prov.active
  FROM providers prov
  INNER JOIN profiles prof ON prov.profile_id = prof.id
  WHERE prov.profile_id = provider_profile_id
  AND prov.active = true;
END;
$$;


--
-- TOC entry 495 (class 1255 OID 18542)
-- Name: get_provider_pending_approvals(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_provider_pending_approvals(provider_uuid uuid) RETURNS TABLE(preference_id uuid, patient_name text, medication_name text, preferred_dosage text, frequency text, patient_notes text, requested_date timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    pmp.id,
    CONCAT(pr.first_name, ' ', pr.last_name),
    m.name,
    pmp.preferred_dosage,
    pmp.frequency,
    pmp.notes,
    pmp.requested_date
  FROM patient_medication_preferences pmp
  JOIN medications m ON pmp.medication_id = m.id
  JOIN patients pt ON pmp.patient_id = pt.id
  JOIN profiles pr ON pt.profile_id = pr.id
  JOIN patient_assignments pa ON pt.id = pa.patient_id
  JOIN providers prov ON pa.provider_id = prov.id
  LEFT JOIN medication_approvals ma ON pmp.id = ma.preference_id
  WHERE prov.profile_id = provider_uuid
  AND pmp.status = 'pending'
  AND ma.id IS NULL -- No approval exists yet
  ORDER BY pmp.requested_date ASC;
END;
$$;


--
-- TOC entry 398 (class 1255 OID 18402)
-- Name: get_user_role(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_user_role(user_id uuid DEFAULT auth.uid()) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN (
    SELECT role 
    FROM profiles 
    WHERE id = user_id
  );
END;
$$;


--
-- TOC entry 455 (class 1255 OID 19005)
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    user_role TEXT;
    first_name TEXT;
    last_name TEXT;
    phone_val TEXT;
    specialty_val TEXT;
    license_number_val TEXT;
    new_provider_id UUID;
BEGIN
    -- Extract data from raw_user_meta_data only
    user_role := COALESCE(NEW.raw_user_meta_data->>'role', 'patient');
    first_name := COALESCE(
        NEW.raw_user_meta_data->>'first_name',
        NEW.raw_user_meta_data->>'firstName', 
        'User'
    );
    last_name := COALESCE(
        NEW.raw_user_meta_data->>'last_name',
        NEW.raw_user_meta_data->>'lastName', 
        'Unknown'
    );
    phone_val := NEW.raw_user_meta_data->>'phone';
    specialty_val := NEW.raw_user_meta_data->>'specialty';
    license_number_val := COALESCE(
        NEW.raw_user_meta_data->>'license_number',
        NEW.raw_user_meta_data->>'licenseNumber'
    );

    -- Create profile first with explicit schema reference
    INSERT INTO public.profiles (id, email, first_name, last_name, role, created_at, updated_at)
    VALUES (NEW.id, NEW.email, first_name, last_name, user_role, NOW(), NOW());

    -- Create role-specific records with explicit schema references
    IF user_role = 'patient' THEN
        INSERT INTO public.patients (profile_id, phone, has_completed_intake, created_at, updated_at)
        VALUES (NEW.id, phone_val, false, NOW(), NOW());

    ELSIF user_role = 'provider' THEN
        -- Create provider record and capture the ID for schedule creation
        INSERT INTO public.providers (profile_id, specialty, license_number, phone, active, created_at, updated_at)
        VALUES (NEW.id, specialty_val, license_number_val, phone_val, true, NOW(), NOW())
        RETURNING id INTO new_provider_id;

        -- Create default provider schedule (Monday-Friday, 9 AM - 5 PM)
        INSERT INTO public.provider_schedules (provider_id, day_of_week, start_time, end_time, treatment_types, active, created_at, updated_at)
        VALUES
            (new_provider_id, 1, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 2, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 3, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 4, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 5, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW());

    ELSIF user_role = 'admin' THEN
        INSERT INTO public.admins (profile_id, permissions, active, created_at, updated_at)
        VALUES (NEW.id, ARRAY['dashboard', 'patients', 'providers', 'assignments'], true, NOW(), NOW());
    END IF;

    RETURN NEW;
EXCEPTION
    WHEN OTHERS THEN
        RAISE LOG 'Error in handle_new_user trigger for user %: % - %', NEW.id, SQLSTATE, SQLERRM;
        RAISE;
END;
$$;


--
-- TOC entry 392 (class 1255 OID 18661)
-- Name: log_appointment_changes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.log_appointment_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Insert into appointment_history
  INSERT INTO appointment_history (
    appointment_id,
    action,
    performed_by,
    performed_by_user_id,
    old_values,
    new_values,
    reason
  ) VALUES (
    COALESCE(NEW.id, OLD.id),
    CASE 
      WHEN TG_OP = 'INSERT' THEN 'created'
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'cancelled' AND OLD.status != 'cancelled' THEN 'cancelled'
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'completed' AND OLD.status != 'completed' THEN 'completed'  
      WHEN TG_OP = 'UPDATE' AND (NEW.appointment_date != OLD.appointment_date OR NEW.start_time != OLD.start_time) THEN 'rescheduled'
      WHEN TG_OP = 'UPDATE' THEN 'updated'
      WHEN TG_OP = 'DELETE' THEN 'deleted'
    END,
    COALESCE(
      current_setting('app.current_user_role', true),
      'system'
    ),
    CASE 
      WHEN current_setting('app.current_user_id', true) != '' 
      THEN current_setting('app.current_user_id', true)::UUID
      ELSE NULL
    END,
    CASE WHEN TG_OP != 'INSERT' THEN to_jsonb(OLD) ELSE NULL END,
    CASE WHEN TG_OP != 'DELETE' THEN to_jsonb(NEW) ELSE NULL END,
    CASE 
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'cancelled' THEN NEW.cancellation_reason
      ELSE NULL
    END
  );
  
  RETURN COALESCE(NEW, OLD);
END;
$$;


--
-- TOC entry 528 (class 1255 OID 18864)
-- Name: repair_missing_profiles(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.repair_missing_profiles() RETURNS TABLE(user_id uuid, action_taken text, success boolean, error_message text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    user_rec RECORD;
    new_provider_id UUID;
    schedule_count INTEGER;
BEGIN
    -- Find users without profiles
    FOR user_rec IN (
        SELECT u.id, u.email, u.created_at, u.raw_user_meta_data
        FROM auth.users u
        LEFT JOIN public.profiles p ON u.id = p.id
        WHERE p.id IS NULL
        ORDER BY u.created_at DESC
    ) LOOP
        BEGIN
            -- Extract role and create profile
            DECLARE
                user_role TEXT := COALESCE(user_rec.raw_user_meta_data->>'role', 'patient');
                first_name_val TEXT := COALESCE(
                    user_rec.raw_user_meta_data->>'firstName',
                    user_rec.raw_user_meta_data->>'first_name',
                    split_part(user_rec.email, '@', 1)
                );
                last_name_val TEXT := COALESCE(
                    user_rec.raw_user_meta_data->>'lastName',
                    user_rec.raw_user_meta_data->>'last_name',
                    'User'
                );
            BEGIN
                -- Create profile
                INSERT INTO public.profiles (id, email, role, first_name, last_name, created_at)
                VALUES (user_rec.id, user_rec.email, user_role, first_name_val, last_name_val, user_rec.created_at);
                
                -- Create role-specific records
                IF user_role = 'provider' THEN
                    INSERT INTO public.providers (profile_id, specialty, license_number, active, created_at)
                    VALUES (user_rec.id, 'General Practice', 'REPAIRED', true, user_rec.created_at)
                    RETURNING id INTO new_provider_id;
                    
                    -- Create schedules
                    INSERT INTO public.provider_schedules (provider_id, day_of_week, start_time, end_time, active, created_at)
                    SELECT new_provider_id, day_num, '09:00:00'::TIME, '17:00:00'::TIME, true, user_rec.created_at
                    FROM generate_series(1, 5) AS day_num;
                    
                    GET DIAGNOSTICS schedule_count = ROW_COUNT;
                    
                    RETURN QUERY SELECT 
                        user_rec.id,
                        format('Created profile, provider, and %s schedules', schedule_count),
                        true,
                        NULL::TEXT;
                        
                ELSIF user_role = 'patient' THEN
                    INSERT INTO public.patients (profile_id, has_completed_intake, created_at)
                    VALUES (user_rec.id, false, user_rec.created_at);
                    
                    RETURN QUERY SELECT 
                        user_rec.id,
                        'Created profile and patient record',
                        true,
                        NULL::TEXT;
                        
                ELSIF user_role = 'admin' THEN
                    INSERT INTO public.admins (profile_id, permissions, active, created_at)
                    VALUES (user_rec.id, ARRAY['dashboard', 'patients', 'providers'], true, user_rec.created_at);
                    
                    RETURN QUERY SELECT 
                        user_rec.id,
                        'Created profile and admin record',
                        true,
                        NULL::TEXT;
                ELSE
                    RETURN QUERY SELECT 
                        user_rec.id,
                        'Created profile only',
                        true,
                        NULL::TEXT;
                END IF;
                
            EXCEPTION WHEN OTHERS THEN
                RETURN QUERY SELECT 
                    user_rec.id,
                    'Failed to repair',
                    false,
                    SQLERRM;
            END;
        END;
    END LOOP;
END;
$$;


--
-- TOC entry 434 (class 1255 OID 19119)
-- Name: request_prescription_refill(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.request_prescription_refill(p_preference_id uuid, p_patient_profile_id uuid) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_preference_record RECORD;
    v_patient_id UUID;
    v_days_until_due INTEGER;
BEGIN
    -- Get patient ID from profile
    SELECT id INTO v_patient_id 
    FROM patients 
    WHERE profile_id = p_patient_profile_id;
    
    IF v_patient_id IS NULL THEN
        RETURN json_build_object(
            'success', false,
            'error', 'Patient not found'
        );
    END IF;
    
    -- Get the preference record
    SELECT 
        id, 
        patient_id, 
        status, 
        next_prescription_due,
        medication_id,
        preferred_dosage,
        frequency
    INTO v_preference_record
    FROM patient_medication_preferences 
    WHERE id = p_preference_id 
      AND patient_id = v_patient_id;
    
    IF v_preference_record.id IS NULL THEN
        RETURN json_build_object(
            'success', false,
            'error', 'Medication preference not found or access denied'
        );
    END IF;
    
    -- Check if preference is currently approved
    IF v_preference_record.status != 'approved' THEN
        RETURN json_build_object(
            'success', false,
            'error', 'Can only request refills for approved medications'
        );
    END IF;
    
    -- Check if next_prescription_due exists
    IF v_preference_record.next_prescription_due IS NULL THEN
        RETURN json_build_object(
            'success', false,
            'error', 'No prescription due date found'
        );
    END IF;
    
    -- Calculate days until due
    v_days_until_due := v_preference_record.next_prescription_due::date - CURRENT_DATE;
    
    -- Only allow refill requests within 3 days of due date (or past due)
    IF v_days_until_due > 3 THEN
        RETURN json_build_object(
            'success', false,
            'error', 'Refill can only be requested within 3 days of due date'
        );
    END IF;
    
    -- Update preference status to pending AND set refill_requested = TRUE
    UPDATE patient_medication_preferences 
    SET 
        status = 'pending',
        refill_requested = TRUE,  -- Mark as patient-requested refill
        notes = COALESCE(notes, '') || 
                CASE 
                    WHEN notes IS NULL OR notes = '' THEN 
                        'Refill requested on ' || CURRENT_DATE::text
                    ELSE 
                        '; Refill requested on ' || CURRENT_DATE::text
                END,
        updated_at = NOW()
    WHERE id = p_preference_id;
    
    RETURN json_build_object(
        'success', true,
        'message', 'Refill request submitted successfully',
        'preference_id', p_preference_id,
        'new_status', 'pending',
        'refill_requested', true,
        'days_until_due', v_days_until_due
    );
    
EXCEPTION WHEN OTHERS THEN
    RETURN json_build_object(
        'success', false,
        'error', 'An error occurred while processing the refill request: ' || SQLERRM
    );
END;
$$;


--
-- TOC entry 4766 (class 0 OID 0)
-- Dependencies: 434
-- Name: FUNCTION request_prescription_refill(p_preference_id uuid, p_patient_profile_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.request_prescription_refill(p_preference_id uuid, p_patient_profile_id uuid) IS 'Allows patients to request prescription refills within 3 days of due date, sets refill_requested=TRUE for provider approval filtering';


--
-- TOC entry 491 (class 1255 OID 18945)
-- Name: reschedule_appointment(uuid, date, time without time zone, text, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text DEFAULT 'patient'::text, p_rescheduled_by_user_id uuid DEFAULT NULL::uuid, p_reason text DEFAULT NULL::text) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_old_appointment appointments%ROWTYPE;
  v_new_appointment_id UUID;
  v_new_end_time TIME;
  v_duration_minutes INTEGER;
BEGIN
  -- Get the original appointment
  SELECT * INTO v_old_appointment 
  FROM appointments 
  WHERE id = p_appointment_id AND status NOT IN ('cancelled', 'completed');
  
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Appointment not found or cannot be rescheduled'
    );
  END IF;
  
  -- Check if the new slot is available
  IF EXISTS (
    SELECT 1 FROM appointments a
    WHERE a.provider_id = v_old_appointment.provider_id
      AND a.appointment_date = p_new_date
      AND a.start_time = p_new_time
      AND a.status NOT IN ('cancelled', 'no_show')
      AND a.id != p_appointment_id
  ) THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Selected time slot is already booked'
    );
  END IF;
  
  -- Calculate new end time (preserve original duration)
  v_duration_minutes := COALESCE(v_old_appointment.duration_minutes, 30);
  v_new_end_time := p_new_time + (v_duration_minutes || ' minutes')::INTERVAL;
  
  -- Start transaction
  BEGIN
    -- Mark the original appointment as rescheduled
    UPDATE appointments 
    SET 
      status = 'rescheduled',
      updated_at = NOW()
    WHERE id = p_appointment_id;
    
    -- Create new appointment
    INSERT INTO appointments (
      patient_id,
      provider_id,
      assignment_id,
      appointment_date,
      start_time,
      end_time,
      duration_minutes,
      treatment_type,
      appointment_type,
      status,
      patient_notes,
      provider_notes,
      admin_notes,
      booked_by,
      booked_by_user_id
    ) VALUES (
      v_old_appointment.patient_id,
      v_old_appointment.provider_id,
      v_old_appointment.assignment_id,
      p_new_date,
      p_new_time,
      v_new_end_time,
      v_duration_minutes,
      v_old_appointment.treatment_type,
      v_old_appointment.appointment_type,
      'scheduled',
      v_old_appointment.patient_notes,
      v_old_appointment.provider_notes,
      'Rescheduled from ' || v_old_appointment.appointment_date || ' ' || v_old_appointment.start_time,
      p_rescheduled_by,
      p_rescheduled_by_user_id
    ) RETURNING id INTO v_new_appointment_id;
    
    -- Return success
    RETURN json_build_object(
      'success', true,
      'old_appointment_id', p_appointment_id,
      'new_appointment_id', v_new_appointment_id,
      'message', 'Appointment successfully rescheduled'
    );
    
  EXCEPTION WHEN OTHERS THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Failed to reschedule appointment: ' || SQLERRM
    );
  END;
END;
$$;


--
-- TOC entry 4767 (class 0 OID 0)
-- Dependencies: 491
-- Name: FUNCTION reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text, p_rescheduled_by_user_id uuid, p_reason text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text, p_rescheduled_by_user_id uuid, p_reason text) IS 'Reschedule an appointment to a new date and time';


--
-- TOC entry 471 (class 1255 OID 19100)
-- Name: reset_expired_approvals(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reset_expired_approvals() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    rows_updated INTEGER;
BEGIN
    -- Reset patient preferences to pending when supply period has elapsed
    -- This way they show up in the provider dashboard as new approval requests
    UPDATE public.patient_medication_preferences
    SET
        status = 'pending',
        updated_at = NOW()
    FROM public.medication_approvals ma
    JOIN public.medication_orders mo ON ma.id = mo.approval_id
    WHERE patient_medication_preferences.id = ma.preference_id
    AND ma.status = 'approved'
    AND ma.supply_days IS NOT NULL
    AND mo.estimated_delivery IS NOT NULL
    AND mo.fulfillment_status = 'delivered'
    AND (mo.estimated_delivery::DATE + INTERVAL '1 day' * ma.supply_days) <= CURRENT_DATE;

    GET DIAGNOSTICS rows_updated = ROW_COUNT;

    -- Log the action for debugging
    INSERT INTO public.auth_trigger_logs (trigger_stage, success, error_message, metadata, created_at)
    VALUES (
        'APPROVAL_RESET',
        true,
        format('Reset %s expired preferences to pending status', rows_updated),
        jsonb_build_object('reset_count', rows_updated, 'reset_date', CURRENT_DATE),
        NOW()
    );

    RETURN rows_updated;
END;
$$;


--
-- TOC entry 4768 (class 0 OID 0)
-- Dependencies: 471
-- Name: FUNCTION reset_expired_approvals(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.reset_expired_approvals() IS 'Reset expired patient preferences to pending status so they appear in provider dashboard';


--
-- TOC entry 454 (class 1255 OID 19111)
-- Name: run_daily_maintenance(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.run_daily_maintenance() RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    reset_count INTEGER;
    expired_count INTEGER;
    result JSONB;
BEGIN
    -- Run the daily approval reset check
    reset_count := public.daily_approval_reset_check();
    
    -- Get count of approvals that are currently expired but not yet reset
    SELECT COUNT(*)::INTEGER INTO expired_count
    FROM public.approval_renewal_status
    WHERE renewal_status = 'EXPIRED' AND status = 'approved';
    
    -- Return summary
    result := jsonb_build_object(
        'approvals_reset', reset_count,
        'approvals_still_expired', expired_count,
        'run_date', CURRENT_DATE,
        'run_time', NOW()
    );
    
    RETURN result;
END;
$$;


--
-- TOC entry 4769 (class 0 OID 0)
-- Dependencies: 454
-- Name: FUNCTION run_daily_maintenance(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.run_daily_maintenance() IS 'Main maintenance function to be called daily from application or cron';


--
-- TOC entry 418 (class 1255 OID 18670)
-- Name: set_appointment_context(text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_appointment_context(p_user_role text, p_user_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  PERFORM set_config('app.current_user_role', p_user_role, true);
  PERFORM set_config('app.current_user_id', p_user_id::TEXT, true);
END;
$$;


--
-- TOC entry 4770 (class 0 OID 0)
-- Dependencies: 418
-- Name: FUNCTION set_appointment_context(p_user_role text, p_user_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.set_appointment_context(p_user_role text, p_user_id uuid) IS 'Sets security context for appointment operations';


--
-- TOC entry 412 (class 1255 OID 19102)
-- Name: trigger_approval_reset(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trigger_approval_reset() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN public.reset_expired_approvals();
END;
$$;


--
-- TOC entry 4771 (class 0 OID 0)
-- Dependencies: 412
-- Name: FUNCTION trigger_approval_reset(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.trigger_approval_reset() IS 'Manually triggers the approval reset process for testing';


--
-- TOC entry 468 (class 1255 OID 18800)
-- Name: update_clinical_note_editor(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_clinical_note_editor() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Set last_updated_by to current user if available
  IF current_setting('app.current_user_id', true) != '' THEN
    NEW.last_updated_by = current_setting('app.current_user_id', true)::UUID;
  END IF;
  
  RETURN NEW;
END;
$$;


--
-- TOC entry 366 (class 1255 OID 19117)
-- Name: update_next_due_from_supply_and_fax(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_next_due_from_supply_and_fax() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    preference_record RECORD;
    v_calculated_due_date DATE;
    v_updated_count INTEGER := 0;
BEGIN
    -- Loop through all preferences that have supply_days and faxed date but no next_prescription_due
    FOR preference_record IN 
        SELECT id, supply_days, faxed::date as faxed_date
        FROM patient_medication_preferences 
        WHERE supply_days IS NOT NULL 
          AND supply_days > 0 
          AND faxed IS NOT NULL
          AND (next_prescription_due IS NULL OR next_prescription_due < CURRENT_DATE)
    LOOP
        -- Calculate next due date using faxed date from preferences
        v_calculated_due_date := preference_record.faxed_date + preference_record.supply_days;
        
        UPDATE patient_medication_preferences 
        SET 
            next_prescription_due = v_calculated_due_date,
            updated_at = NOW()
        WHERE id = preference_record.id;
        
        v_updated_count := v_updated_count + 1;
    END LOOP;
    
    RETURN v_updated_count;
END;
$$;


--
-- TOC entry 4772 (class 0 OID 0)
-- Dependencies: 366
-- Name: FUNCTION update_next_due_from_supply_and_fax(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.update_next_due_from_supply_and_fax() IS 'Updates next_prescription_due for preferences with supply_days based on faxed date from preferences table';


--
-- TOC entry 376 (class 1255 OID 19115)
-- Name: update_preference_on_medication_adjustment(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_preference_on_medication_adjustment() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_fax_date DATE;
    v_calculated_due_date DATE;
    v_preference_record RECORD;
BEGIN
    -- Only proceed if this is an approval (new_status = 'approved')
    IF NEW.new_status = 'approved' THEN
        -- Update the preference with the new values from the adjustment
        UPDATE patient_medication_preferences 
        SET 
            preferred_dosage = COALESCE(NEW.new_dosage, preferred_dosage),
            frequency = COALESCE(NEW.new_frequency, frequency),
            status = NEW.new_status,
            supply_days = COALESCE(NEW.new_supply_days, supply_days),
            notes = COALESCE(NEW.new_provider_notes, notes),
            updated_at = NOW()
        WHERE id = NEW.preference_id;
        
        -- If supply_days was provided, calculate and update next_prescription_due
        -- using the faxed field from the preference itself
        IF NEW.new_supply_days IS NOT NULL AND NEW.new_supply_days > 0 THEN
            -- Get the preference record to access the faxed field
            SELECT faxed::date
            INTO v_fax_date
            FROM patient_medication_preferences 
            WHERE id = NEW.preference_id;
            
            -- If we have a fax date, calculate next due date
            IF v_fax_date IS NOT NULL THEN
                v_calculated_due_date := v_fax_date + NEW.new_supply_days;
                
                -- Update the preference with the calculated due date
                UPDATE patient_medication_preferences 
                SET 
                    next_prescription_due = v_calculated_due_date,
                    updated_at = NOW()
                WHERE id = NEW.preference_id;
                
                -- Log the calculation for debugging (if logging table exists)
                BEGIN
                    INSERT INTO auth_trigger_logs (
                        step, 
                        status, 
                        message, 
                        metadata
                    ) VALUES (
                        'SUPPLY_CALCULATION', 
                        'SUCCESS', 
                        'Updated next prescription due based on preference fax date and supply',
                        jsonb_build_object(
                            'preference_id', NEW.preference_id,
                            'fax_date', v_fax_date,
                            'supply_days', NEW.new_supply_days,
                            'calculated_due_date', v_calculated_due_date
                        )
                    );
                EXCEPTION WHEN OTHERS THEN
                    -- Ignore logging errors, don't fail the main operation
                    NULL;
                END;
            ELSE
                -- Log that no fax date was found (if logging table exists)
                BEGIN
                    INSERT INTO auth_trigger_logs (
                        step, 
                        status, 
                        message, 
                        metadata
                    ) VALUES (
                        'SUPPLY_CALCULATION', 
                        'WARNING', 
                        'No fax date found in preference, cannot calculate next due date',
                        jsonb_build_object(
                            'preference_id', NEW.preference_id,
                            'supply_days', NEW.new_supply_days
                        )
                    );
                EXCEPTION WHEN OTHERS THEN
                    -- Ignore logging errors, don't fail the main operation
                    NULL;
                END;
            END IF;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- TOC entry 4773 (class 0 OID 0)
-- Dependencies: 376
-- Name: FUNCTION update_preference_on_medication_adjustment(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.update_preference_on_medication_adjustment() IS 'Updates patient_medication_preferences when medication adjustments are approved, using faxed date from preferences table for next_prescription_due calculation';


--
-- TOC entry 425 (class 1255 OID 19050)
-- Name: update_prescription_due_date(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_prescription_due_date() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    approval_record RECORD;
    preference_id UUID;
    approved_freq TEXT;
BEGIN
    -- Only proceed if delivery date was just set (order delivered)
    IF OLD.estimated_delivery IS NULL AND NEW.estimated_delivery IS NOT NULL THEN
        -- Get the approval and preference info
        SELECT ma.preference_id, ma.approved_frequency
        INTO preference_id, approved_freq
        FROM public.medication_approvals ma
        WHERE ma.id = NEW.approval_id;

        IF preference_id IS NOT NULL THEN
            -- Update the next prescription due date
            UPDATE public.patient_medication_preferences
            SET next_prescription_due = public.calculate_next_prescription_due(
                preference_id,
                NEW.estimated_delivery::DATE,
                approved_freq
            )
            WHERE id = preference_id;
        END IF;
    END IF;

    RETURN NEW;
END;
$$;


--
-- TOC entry 4774 (class 0 OID 0)
-- Dependencies: 425
-- Name: FUNCTION update_prescription_due_date(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.update_prescription_due_date() IS 'Updates prescription due date when medication order delivery date is set (fixed variable naming to avoid ambiguity)';


--
-- TOC entry 485 (class 1255 OID 18379)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only update if the table actually has an updated_at column
    IF TG_TABLE_NAME = 'clinical_notes' THEN
        NEW.updated_at = NOW();
    END IF;
    RETURN NEW;
EXCEPTION
    WHEN OTHERS THEN
        -- Don't fail the operation if there's an issue
        RETURN NEW;
END;
$$;


--
-- TOC entry 381 (class 1255 OID 18694)
-- Name: validate_appointment_business_rules(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_appointment_business_rules() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Prevent booking conflicts
  IF EXISTS (
    SELECT 1 FROM appointments a
    WHERE a.provider_id = NEW.provider_id
      AND a.appointment_date = NEW.appointment_date
      AND a.start_time = NEW.start_time
      AND a.id != COALESCE(NEW.id, '00000000-0000-0000-0000-000000000000'::UUID)
      AND a.status NOT IN ('cancelled', 'no_show')
  ) THEN
    RAISE EXCEPTION 'Appointment slot already booked';
  END IF;
  
  -- Validate appointment is within provider's schedule
  IF NOT EXISTS (
    SELECT 1 FROM provider_schedules ps
    WHERE ps.provider_id = NEW.provider_id
      AND ps.day_of_week = EXTRACT(DOW FROM NEW.appointment_date)
      AND ps.start_time <= NEW.start_time
      AND ps.end_time >= NEW.end_time
      AND ps.active = true
  ) THEN
    RAISE EXCEPTION 'Appointment outside provider schedule';
  END IF;
  
  -- Check for availability overrides that block this time
  IF EXISTS (
    SELECT 1 FROM provider_availability_overrides pao
    WHERE pao.provider_id = NEW.provider_id
      AND pao.date = NEW.appointment_date
      AND pao.available = false
      AND (pao.start_time IS NULL OR NEW.start_time >= pao.start_time)
      AND (pao.end_time IS NULL OR NEW.end_time <= pao.end_time)
  ) THEN
    RAISE EXCEPTION 'Provider not available at requested time';
  END IF;
  
  RETURN NEW;
END;
$$;


--
-- TOC entry 520 (class 1255 OID 16925)
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_;

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


--
-- TOC entry 488 (class 1255 OID 17004)
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


--
-- TOC entry 409 (class 1255 OID 16937)
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


--
-- TOC entry 531 (class 1255 OID 16887)
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
    declare
      res jsonb;
    begin
      execute format('select to_jsonb(%L::'|| type_::text || ')', val)  into res;
      return res;
    end
    $$;


--
-- TOC entry 507 (class 1255 OID 16882)
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


--
-- TOC entry 469 (class 1255 OID 16933)
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


--
-- TOC entry 393 (class 1255 OID 16944)
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS SETOF realtime.wal_rls
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
      with pub as (
        select
          concat_ws(
            ',',
            case when bool_or(pubinsert) then 'insert' else null end,
            case when bool_or(pubupdate) then 'update' else null end,
            case when bool_or(pubdelete) then 'delete' else null end
          ) as w2j_actions,
          coalesce(
            string_agg(
              realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
              ','
            ) filter (where ppt.tablename is not null and ppt.tablename not like '% %'),
            ''
          ) w2j_add_tables
        from
          pg_publication pp
          left join pg_publication_tables ppt
            on pp.pubname = ppt.pubname
        where
          pp.pubname = publication
        group by
          pp.pubname
        limit 1
      ),
      w2j as (
        select
          x.*, pub.w2j_add_tables
        from
          pub,
          pg_logical_slot_get_changes(
            slot_name, null, max_changes,
            'include-pk', 'true',
            'include-transaction', 'false',
            'include-timestamp', 'true',
            'include-type-oids', 'true',
            'format-version', '2',
            'actions', pub.w2j_actions,
            'add-tables', pub.w2j_add_tables
          ) x
      )
      select
        xyz.wal,
        xyz.is_rls_enabled,
        xyz.subscription_ids,
        xyz.errors
      from
        w2j,
        realtime.apply_rls(
          wal := w2j.data::jsonb,
          max_record_bytes := max_record_bytes
        ) xyz(wal, is_rls_enabled, subscription_ids, errors)
      where
        w2j.w2j_add_tables <> ''
        and xyz.subscription_ids[1] is not null
    $$;


--
-- TOC entry 423 (class 1255 OID 16881)
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


--
-- TOC entry 522 (class 1255 OID 17003)
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  BEGIN
    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (payload, event, topic, private, extension)
    VALUES (payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      RAISE WARNING 'ErrorSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- TOC entry 519 (class 1255 OID 16879)
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


--
-- TOC entry 490 (class 1255 OID 16914)
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


--
-- TOC entry 371 (class 1255 OID 16997)
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


--
-- TOC entry 387 (class 1255 OID 17865)
-- Name: add_prefixes(text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.add_prefixes(_bucket_id text, _name text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    prefixes text[];
BEGIN
    prefixes := "storage"."get_prefixes"("_name");

    IF array_length(prefixes, 1) > 0 THEN
        INSERT INTO storage.prefixes (name, bucket_id)
        SELECT UNNEST(prefixes) as name, "_bucket_id" ON CONFLICT DO NOTHING;
    END IF;
END;
$$;


--
-- TOC entry 402 (class 1255 OID 17791)
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


--
-- TOC entry 482 (class 1255 OID 17866)
-- Name: delete_prefix(text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.delete_prefix(_bucket_id text, _name text) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    -- Check if we can delete the prefix
    IF EXISTS(
        SELECT FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name") + 1
          AND "prefixes"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    )
    OR EXISTS(
        SELECT FROM "storage"."objects"
        WHERE "objects"."bucket_id" = "_bucket_id"
          AND "storage"."get_level"("objects"."name") = "storage"."get_level"("_name") + 1
          AND "objects"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    ) THEN
    -- There are sub-objects, skip deletion
    RETURN false;
    ELSE
        DELETE FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name")
          AND "prefixes"."name" = "_name";
        RETURN true;
    END IF;
END;
$$;


--
-- TOC entry 473 (class 1255 OID 17869)
-- Name: delete_prefix_hierarchy_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.delete_prefix_hierarchy_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    prefix text;
BEGIN
    prefix := "storage"."get_prefix"(OLD."name");

    IF coalesce(prefix, '') != '' THEN
        PERFORM "storage"."delete_prefix"(OLD."bucket_id", prefix);
    END IF;

    RETURN OLD;
END;
$$;


--
-- TOC entry 432 (class 1255 OID 17884)
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


--
-- TOC entry 405 (class 1255 OID 17765)
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    SELECT _parts[array_length(_parts,1)] INTO _filename;
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


--
-- TOC entry 521 (class 1255 OID 17764)
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


--
-- TOC entry 404 (class 1255 OID 17763)
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


--
-- TOC entry 414 (class 1255 OID 17847)
-- Name: get_level(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_level(name text) RETURNS integer
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
SELECT array_length(string_to_array("name", '/'), 1);
$$;


--
-- TOC entry 413 (class 1255 OID 17863)
-- Name: get_prefix(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_prefix(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
SELECT
    CASE WHEN strpos("name", '/') > 0 THEN
             regexp_replace("name", '[\/]{1}[^\/]+\/?$', '')
         ELSE
             ''
        END;
$_$;


--
-- TOC entry 461 (class 1255 OID 17864)
-- Name: get_prefixes(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_prefixes(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $$
DECLARE
    parts text[];
    prefixes text[];
    prefix text;
BEGIN
    -- Split the name into parts by '/'
    parts := string_to_array("name", '/');
    prefixes := '{}';

    -- Construct the prefixes, stopping one level below the last part
    FOR i IN 1..array_length(parts, 1) - 1 LOOP
            prefix := array_to_string(parts[1:i], '/');
            prefixes := array_append(prefixes, prefix);
    END LOOP;

    RETURN prefixes;
END;
$$;


--
-- TOC entry 419 (class 1255 OID 17882)
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


--
-- TOC entry 470 (class 1255 OID 17830)
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


--
-- TOC entry 475 (class 1255 OID 17793)
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(name COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                        substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1)))
                    ELSE
                        name
                END AS name, id, metadata, updated_at
            FROM
                storage.objects
            WHERE
                bucket_id = $5 AND
                name ILIKE $1 || ''%'' AND
                CASE
                    WHEN $6 != '''' THEN
                    name COLLATE "C" > $6
                ELSE true END
                AND CASE
                    WHEN $4 != '''' THEN
                        CASE
                            WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                                substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                name COLLATE "C" > $4
                            END
                    ELSE
                        true
                END
            ORDER BY
                name COLLATE "C" ASC) as e order by name COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_token, bucket_id, start_after;
END;
$_$;


--
-- TOC entry 512 (class 1255 OID 17868)
-- Name: objects_insert_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.objects_insert_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    NEW.level := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


--
-- TOC entry 400 (class 1255 OID 17883)
-- Name: objects_update_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.objects_update_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    old_prefixes TEXT[];
BEGIN
    -- Ensure this is an update operation and the name has changed
    IF TG_OP = 'UPDATE' AND (NEW."name" <> OLD."name" OR NEW."bucket_id" <> OLD."bucket_id") THEN
        -- Retrieve old prefixes
        old_prefixes := "storage"."get_prefixes"(OLD."name");

        -- Remove old prefixes that are only used by this object
        WITH all_prefixes as (
            SELECT unnest(old_prefixes) as prefix
        ),
        can_delete_prefixes as (
             SELECT prefix
             FROM all_prefixes
             WHERE NOT EXISTS (
                 SELECT 1 FROM "storage"."objects"
                 WHERE "bucket_id" = OLD."bucket_id"
                   AND "name" <> OLD."name"
                   AND "name" LIKE (prefix || '%')
             )
         )
        DELETE FROM "storage"."prefixes" WHERE name IN (SELECT prefix FROM can_delete_prefixes);

        -- Add new prefixes
        PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    END IF;
    -- Set the new level
    NEW."level" := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


--
-- TOC entry 506 (class 1255 OID 17846)
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


--
-- TOC entry 467 (class 1255 OID 17867)
-- Name: prefixes_insert_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.prefixes_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    RETURN NEW;
END;
$$;


--
-- TOC entry 463 (class 1255 OID 17780)
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql
    AS $$
declare
    can_bypass_rls BOOLEAN;
begin
    SELECT rolbypassrls
    INTO can_bypass_rls
    FROM pg_roles
    WHERE rolname = coalesce(nullif(current_setting('role', true), 'none'), current_user);

    IF can_bypass_rls THEN
        RETURN QUERY SELECT * FROM storage.search_v1_optimised(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    ELSE
        RETURN QUERY SELECT * FROM storage.search_legacy_v1(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    END IF;
end;
$$;


--
-- TOC entry 508 (class 1255 OID 17880)
-- Name: search_legacy_v1(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_legacy_v1(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select path_tokens[$1] as folder
           from storage.objects
             where objects.name ilike $2 || $3 || ''%''
               and bucket_id = $4
               and array_length(objects.path_tokens, 1) <> $1
           group by folder
           order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(objects.path_tokens, 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


--
-- TOC entry 428 (class 1255 OID 17879)
-- Name: search_v1_optimised(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v1_optimised(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select (string_to_array(name, ''/''))[level] as name
           from storage.prefixes
             where lower(prefixes.name) like lower($2 || $3) || ''%''
               and bucket_id = $4
               and level = $1
           order by name ' || v_sort_order || '
     )
     (select name,
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[level] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where lower(objects.name) like lower($2 || $3) || ''%''
       and bucket_id = $4
       and level = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


--
-- TOC entry 500 (class 1255 OID 17874)
-- Name: search_v2(text, text, integer, integer, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
BEGIN
    RETURN query EXECUTE
        $sql$
        SELECT * FROM (
            (
                SELECT
                    split_part(name, '/', $4) AS key,
                    name || '/' AS name,
                    NULL::uuid AS id,
                    NULL::timestamptz AS updated_at,
                    NULL::timestamptz AS created_at,
                    NULL::jsonb AS metadata
                FROM storage.prefixes
                WHERE name COLLATE "C" LIKE $1 || '%'
                AND bucket_id = $2
                AND level = $4
                AND name COLLATE "C" > $5
                ORDER BY prefixes.name COLLATE "C" LIMIT $3
            )
            UNION ALL
            (SELECT split_part(name, '/', $4) AS key,
                name,
                id,
                updated_at,
                created_at,
                metadata
            FROM storage.objects
            WHERE name COLLATE "C" LIKE $1 || '%'
                AND bucket_id = $2
                AND level = $4
                AND name COLLATE "C" > $5
            ORDER BY name COLLATE "C" LIMIT $3)
        ) obj
        ORDER BY name COLLATE "C" LIMIT $3;
        $sql$
        USING prefix, bucket_name, limits, levels, start_after;
END;
$_$;


--
-- TOC entry 503 (class 1255 OID 17781)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


--
-- TOC entry 478 (class 1255 OID 16774)
-- Name: http_request(); Type: FUNCTION; Schema: supabase_functions; Owner: -
--

CREATE FUNCTION supabase_functions.http_request() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'supabase_functions'
    AS $$
  DECLARE
    request_id bigint;
    payload jsonb;
    url text := TG_ARGV[0]::text;
    method text := TG_ARGV[1]::text;
    headers jsonb DEFAULT '{}'::jsonb;
    params jsonb DEFAULT '{}'::jsonb;
    timeout_ms integer DEFAULT 1000;
  BEGIN
    IF url IS NULL OR url = 'null' THEN
      RAISE EXCEPTION 'url argument is missing';
    END IF;

    IF method IS NULL OR method = 'null' THEN
      RAISE EXCEPTION 'method argument is missing';
    END IF;

    IF TG_ARGV[2] IS NULL OR TG_ARGV[2] = 'null' THEN
      headers = '{"Content-Type": "application/json"}'::jsonb;
    ELSE
      headers = TG_ARGV[2]::jsonb;
    END IF;

    IF TG_ARGV[3] IS NULL OR TG_ARGV[3] = 'null' THEN
      params = '{}'::jsonb;
    ELSE
      params = TG_ARGV[3]::jsonb;
    END IF;

    IF TG_ARGV[4] IS NULL OR TG_ARGV[4] = 'null' THEN
      timeout_ms = 1000;
    ELSE
      timeout_ms = TG_ARGV[4]::integer;
    END IF;

    CASE
      WHEN method = 'GET' THEN
        SELECT http_get INTO request_id FROM net.http_get(
          url,
          params,
          headers,
          timeout_ms
        );
      WHEN method = 'POST' THEN
        payload = jsonb_build_object(
          'old_record', OLD,
          'record', NEW,
          'type', TG_OP,
          'table', TG_TABLE_NAME,
          'schema', TG_TABLE_SCHEMA
        );

        SELECT http_post INTO request_id FROM net.http_post(
          url,
          payload,
          params,
          headers,
          timeout_ms
        );
      ELSE
        RAISE EXCEPTION 'method argument % is invalid', method;
    END CASE;

    INSERT INTO supabase_functions.hooks
      (hook_table_id, hook_name, request_id)
    VALUES
      (TG_RELID, TG_NAME, request_id);

    RETURN NEW;
  END
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 287 (class 1259 OID 16488)
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


--
-- TOC entry 4775 (class 0 OID 0)
-- Dependencies: 287
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- TOC entry 335 (class 1259 OID 18167)
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text NOT NULL,
    code_challenge_method auth.code_challenge_method NOT NULL,
    code_challenge text NOT NULL,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone
);


--
-- TOC entry 4776 (class 0 OID 0)
-- Dependencies: 335
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.flow_state IS 'stores metadata for pkce logins';


--
-- TOC entry 326 (class 1259 OID 17965)
-- Name: identities; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 4777 (class 0 OID 0)
-- Dependencies: 326
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- TOC entry 4778 (class 0 OID 0)
-- Dependencies: 326
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- TOC entry 286 (class 1259 OID 16481)
-- Name: instances; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- TOC entry 4779 (class 0 OID 0)
-- Dependencies: 286
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- TOC entry 330 (class 1259 OID 18054)
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


--
-- TOC entry 4780 (class 0 OID 0)
-- Dependencies: 330
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- TOC entry 329 (class 1259 OID 18042)
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


--
-- TOC entry 4781 (class 0 OID 0)
-- Dependencies: 329
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- TOC entry 328 (class 1259 OID 18029)
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid
);


--
-- TOC entry 4782 (class 0 OID 0)
-- Dependencies: 328
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- TOC entry 337 (class 1259 OID 18249)
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_id text NOT NULL,
    client_secret_hash text NOT NULL,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048))
);


--
-- TOC entry 336 (class 1259 OID 18217)
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


--
-- TOC entry 285 (class 1259 OID 16470)
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


--
-- TOC entry 4783 (class 0 OID 0)
-- Dependencies: 285
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- TOC entry 284 (class 1259 OID 16469)
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: -
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4784 (class 0 OID 0)
-- Dependencies: 284
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: -
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- TOC entry 333 (class 1259 OID 18096)
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


--
-- TOC entry 4785 (class 0 OID 0)
-- Dependencies: 333
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- TOC entry 334 (class 1259 OID 18114)
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


--
-- TOC entry 4786 (class 0 OID 0)
-- Dependencies: 334
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- TOC entry 288 (class 1259 OID 16496)
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


--
-- TOC entry 4787 (class 0 OID 0)
-- Dependencies: 288
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- TOC entry 327 (class 1259 OID 17995)
-- Name: sessions; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text
);


--
-- TOC entry 4788 (class 0 OID 0)
-- Dependencies: 327
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- TOC entry 4789 (class 0 OID 0)
-- Dependencies: 327
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- TOC entry 332 (class 1259 OID 18081)
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


--
-- TOC entry 4790 (class 0 OID 0)
-- Dependencies: 332
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- TOC entry 331 (class 1259 OID 18072)
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


--
-- TOC entry 4791 (class 0 OID 0)
-- Dependencies: 331
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- TOC entry 4792 (class 0 OID 0)
-- Dependencies: 331
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- TOC entry 283 (class 1259 OID 16458)
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


--
-- TOC entry 4793 (class 0 OID 0)
-- Dependencies: 283
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- TOC entry 4794 (class 0 OID 0)
-- Dependencies: 283
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- TOC entry 342 (class 1259 OID 18326)
-- Name: admins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admins (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    permissions text[] DEFAULT ARRAY['dashboard'::text],
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 353 (class 1259 OID 18631)
-- Name: appointment_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointment_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    appointment_id uuid NOT NULL,
    action text NOT NULL,
    performed_by text NOT NULL,
    performed_by_user_id uuid,
    old_values jsonb,
    new_values jsonb,
    reason text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT appointment_history_action_check CHECK ((action = ANY (ARRAY['created'::text, 'updated'::text, 'cancelled'::text, 'completed'::text, 'no_show'::text, 'reschedule'::text, 'rescheduled'::text]))),
    CONSTRAINT appointment_history_performed_by_check CHECK ((performed_by = ANY (ARRAY['patient'::text, 'provider'::text, 'admin'::text, 'system'::text])))
);


--
-- TOC entry 4795 (class 0 OID 0)
-- Dependencies: 353
-- Name: TABLE appointment_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.appointment_history IS 'Complete audit trail of all appointment changes';


--
-- TOC entry 352 (class 1259 OID 18593)
-- Name: appointments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    assignment_id uuid,
    appointment_date date NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    duration_minutes integer NOT NULL,
    treatment_type text NOT NULL,
    appointment_type text DEFAULT 'consultation'::text NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    patient_notes text,
    provider_notes text,
    admin_notes text,
    booked_by text NOT NULL,
    booked_by_user_id uuid,
    booking_timestamp timestamp with time zone DEFAULT now(),
    cancelled_at timestamp with time zone,
    cancelled_by text,
    cancelled_by_user_id uuid,
    cancellation_reason text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    rescheduled_from_id uuid,
    rescheduled_to_id uuid,
    is_reschedule_source boolean DEFAULT false,
    reschedule_count integer DEFAULT 0,
    CONSTRAINT appointment_in_future CHECK (((appointment_date > CURRENT_DATE) OR ((appointment_date = CURRENT_DATE) AND (start_time >= LOCALTIME)))),
    CONSTRAINT appointments_appointment_type_check CHECK ((appointment_type = ANY (ARRAY['consultation'::text, 'follow_up'::text, 'treatment'::text, 'evaluation'::text, 'review'::text]))),
    CONSTRAINT appointments_booked_by_check CHECK ((booked_by = ANY (ARRAY['patient'::text, 'provider'::text, 'admin'::text]))),
    CONSTRAINT appointments_cancelled_by_check CHECK ((cancelled_by = ANY (ARRAY['patient'::text, 'provider'::text, 'admin'::text]))),
    CONSTRAINT appointments_duration_minutes_check CHECK ((duration_minutes > 0)),
    CONSTRAINT appointments_status_check CHECK ((status = ANY (ARRAY['scheduled'::text, 'confirmed'::text, 'completed'::text, 'cancelled'::text, 'no_show'::text, 'rescheduled'::text]))),
    CONSTRAINT valid_appointment_time CHECK ((end_time > start_time)),
    CONSTRAINT valid_cancellation CHECK (((status <> 'cancelled'::text) OR ((status = 'cancelled'::text) AND (cancelled_at IS NOT NULL) AND (cancelled_by IS NOT NULL))))
);


--
-- TOC entry 4796 (class 0 OID 0)
-- Dependencies: 352
-- Name: TABLE appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.appointments IS 'Core appointments between patients and providers';


--
-- TOC entry 4797 (class 0 OID 0)
-- Dependencies: 352
-- Name: COLUMN appointments.assignment_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.assignment_id IS 'Links appointment to specific patient-provider treatment assignment';


--
-- TOC entry 4798 (class 0 OID 0)
-- Dependencies: 352
-- Name: COLUMN appointments.booked_by_user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.booked_by_user_id IS 'Profile ID of the person who booked the appointment';


--
-- TOC entry 4799 (class 0 OID 0)
-- Dependencies: 352
-- Name: COLUMN appointments.rescheduled_from_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.rescheduled_from_id IS 'Points to original appointment if this is a rescheduled appointment';


--
-- TOC entry 4800 (class 0 OID 0)
-- Dependencies: 352
-- Name: COLUMN appointments.rescheduled_to_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.rescheduled_to_id IS 'Points to new appointment if this was rescheduled';


--
-- TOC entry 4801 (class 0 OID 0)
-- Dependencies: 352
-- Name: COLUMN appointments.is_reschedule_source; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.is_reschedule_source IS 'True if this appointment was rescheduled (original slot now available)';


--
-- TOC entry 4802 (class 0 OID 0)
-- Dependencies: 352
-- Name: COLUMN appointments.reschedule_count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.reschedule_count IS 'Number of times this appointment chain has been rescheduled';


--
-- TOC entry 348 (class 1259 OID 18461)
-- Name: medication_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medication_approvals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    preference_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    status text DEFAULT 'needs_review'::text NOT NULL,
    approved_dosage text,
    approved_frequency text,
    provider_notes text,
    contraindications text,
    approval_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    provider_profile_id uuid NOT NULL,
    supply_days integer,
    CONSTRAINT check_approval_status CHECK ((status = ANY (ARRAY['approved'::text, 'denied'::text, 'needs_review'::text])))
);


--
-- TOC entry 4803 (class 0 OID 0)
-- Dependencies: 348
-- Name: COLUMN medication_approvals.provider_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_approvals.provider_profile_id IS 'Direct reference to provider auth user ID';


--
-- TOC entry 4804 (class 0 OID 0)
-- Dependencies: 348
-- Name: COLUMN medication_approvals.supply_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_approvals.supply_days IS 'Number of days the prescription supply should last (e.g., 30, 60, 90 days)';


--
-- TOC entry 349 (class 1259 OID 18482)
-- Name: medication_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medication_orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    approval_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    medication_id uuid NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    payment_status text DEFAULT 'pending'::text NOT NULL,
    payment_method text,
    payment_date timestamp with time zone,
    fulfillment_status text DEFAULT 'pending'::text NOT NULL,
    tracking_number text,
    shipped_date timestamp with time zone,
    estimated_delivery timestamp with time zone,
    admin_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    sent_to_pharmacy timestamp with time zone,
    provider_profile_id uuid NOT NULL,
    patient_profile_id uuid NOT NULL,
    CONSTRAINT check_fulfillment_status CHECK ((fulfillment_status = ANY (ARRAY['pending'::text, 'processing'::text, 'shipped'::text, 'delivered'::text]))),
    CONSTRAINT check_payment_status CHECK ((payment_status = ANY (ARRAY['pending'::text, 'paid'::text, 'failed'::text, 'refunded'::text]))),
    CONSTRAINT check_positive_amounts CHECK (((unit_price >= (0)::numeric) AND (total_amount >= (0)::numeric) AND (quantity > 0)))
);


--
-- TOC entry 4805 (class 0 OID 0)
-- Dependencies: 349
-- Name: COLUMN medication_orders.shipped_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_orders.shipped_date IS 'Date when medication was physically shipped to patient';


--
-- TOC entry 4806 (class 0 OID 0)
-- Dependencies: 349
-- Name: COLUMN medication_orders.sent_to_pharmacy; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_orders.sent_to_pharmacy IS 'Date when prescription was sent to pharmacy for processing';


--
-- TOC entry 4807 (class 0 OID 0)
-- Dependencies: 349
-- Name: COLUMN medication_orders.provider_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_orders.provider_profile_id IS 'Direct reference to provider auth user ID';


--
-- TOC entry 4808 (class 0 OID 0)
-- Dependencies: 349
-- Name: COLUMN medication_orders.patient_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_orders.patient_profile_id IS 'Direct reference to patient auth user ID';


--
-- TOC entry 346 (class 1259 OID 18424)
-- Name: medications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    generic_name text,
    brand_name text,
    dosage_form text NOT NULL,
    strength text NOT NULL,
    description text,
    category text NOT NULL,
    unit_price numeric(10,2) DEFAULT 0 NOT NULL,
    requires_prescription boolean DEFAULT true,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 347 (class 1259 OID 18437)
-- Name: patient_medication_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patient_medication_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    medication_id uuid NOT NULL,
    preferred_dosage text,
    frequency text,
    notes text,
    status text DEFAULT 'pending'::text NOT NULL,
    requested_date timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    medication_dosage_id uuid,
    faxed timestamp with time zone,
    next_prescription_due date,
    supply_days integer,
    refill_requested boolean DEFAULT false,
    CONSTRAINT check_preference_status CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'denied'::text, 'discontinued'::text])))
);


--
-- TOC entry 4809 (class 0 OID 0)
-- Dependencies: 347
-- Name: COLUMN patient_medication_preferences.medication_dosage_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.medication_dosage_id IS 'References the specific dosage selected by the patient. New preferred method over preferred_dosage text field.';


--
-- TOC entry 4810 (class 0 OID 0)
-- Dependencies: 347
-- Name: COLUMN patient_medication_preferences.faxed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.faxed IS 'Timestamp when prescription was last faxed to pharmacy';


--
-- TOC entry 4811 (class 0 OID 0)
-- Dependencies: 347
-- Name: COLUMN patient_medication_preferences.next_prescription_due; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.next_prescription_due IS 'Calculated date when next prescription should be due based on frequency and delivery';


--
-- TOC entry 4812 (class 0 OID 0)
-- Dependencies: 347
-- Name: COLUMN patient_medication_preferences.supply_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.supply_days IS 'Number of days of medication supply when approved via medication adjustments';


--
-- TOC entry 4813 (class 0 OID 0)
-- Dependencies: 347
-- Name: COLUMN patient_medication_preferences.refill_requested; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.refill_requested IS 'TRUE when patient has explicitly requested a refill, FALSE when preference was set to pending by admin/system';


--
-- TOC entry 340 (class 1259 OID 18290)
-- Name: patients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    date_of_birth date,
    phone text,
    has_completed_intake boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 339 (class 1259 OID 18273)
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL,
    email text NOT NULL,
    first_name text,
    last_name text,
    role text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT profiles_role_check CHECK ((role = ANY (ARRAY['patient'::text, 'admin'::text, 'provider'::text])))
);


--
-- TOC entry 364 (class 1259 OID 19103)
-- Name: approval_renewal_status; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.approval_renewal_status AS
 SELECT ma.id AS approval_id,
    ma.status,
    ma.supply_days,
    ((p.first_name || ' '::text) || p.last_name) AS patient_name,
    m.name AS medication_name,
    (mo.estimated_delivery)::date AS estimated_delivery,
    mo.fulfillment_status,
        CASE
            WHEN (ma.supply_days IS NULL) THEN NULL::date
            WHEN (mo.estimated_delivery IS NULL) THEN NULL::date
            ELSE (((mo.estimated_delivery)::date + ('1 day'::interval * (ma.supply_days)::double precision)))::date
        END AS expires_on,
        CASE
            WHEN ((ma.supply_days IS NULL) OR (mo.estimated_delivery IS NULL)) THEN 'N/A'::text
            WHEN (((mo.estimated_delivery)::date + ('1 day'::interval * (ma.supply_days)::double precision)) <= CURRENT_DATE) THEN 'EXPIRED'::text
            WHEN (((mo.estimated_delivery)::date + ('1 day'::interval * (ma.supply_days)::double precision)) <= (CURRENT_DATE + '7 days'::interval)) THEN 'EXPIRING_SOON'::text
            ELSE 'ACTIVE'::text
        END AS renewal_status
   FROM (((((public.medication_approvals ma
     JOIN public.medication_orders mo ON ((ma.id = mo.approval_id)))
     JOIN public.patient_medication_preferences pmp ON ((ma.preference_id = pmp.id)))
     JOIN public.medications m ON ((pmp.medication_id = m.id)))
     JOIN public.patients pt ON ((pmp.patient_id = pt.id)))
     JOIN public.profiles p ON ((pt.profile_id = p.id)))
  WHERE (ma.status = ANY (ARRAY['approved'::text, 'pending'::text]));


--
-- TOC entry 4814 (class 0 OID 0)
-- Dependencies: 364
-- Name: VIEW approval_renewal_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.approval_renewal_status IS 'View showing renewal status of all medication approvals';


--
-- TOC entry 345 (class 1259 OID 18415)
-- Name: assignment_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assignment_log (
    id integer NOT NULL,
    message text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- TOC entry 344 (class 1259 OID 18414)
-- Name: assignment_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assignment_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4815 (class 0 OID 0)
-- Dependencies: 344
-- Name: assignment_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assignment_log_id_seq OWNED BY public.assignment_log.id;


--
-- TOC entry 362 (class 1259 OID 18950)
-- Name: auth_trigger_debug_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_trigger_debug_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    step text,
    status text,
    error_message text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 359 (class 1259 OID 18845)
-- Name: auth_trigger_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_trigger_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    trigger_stage text NOT NULL,
    success boolean NOT NULL,
    error_message text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 356 (class 1259 OID 18708)
-- Name: clinical_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clinical_notes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    appointment_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    allergies text[] DEFAULT '{}'::text[],
    previous_medications text[] DEFAULT '{}'::text[],
    current_medications text[] DEFAULT '{}'::text[],
    clinical_note text DEFAULT ''::text,
    internal_note text DEFAULT ''::text,
    visit_summary text DEFAULT ''::text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    created_by uuid,
    last_updated_by uuid
);


--
-- TOC entry 4816 (class 0 OID 0)
-- Dependencies: 356
-- Name: TABLE clinical_notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.clinical_notes IS 'Clinical notes and medical information recorded during patient visits';


--
-- TOC entry 4817 (class 0 OID 0)
-- Dependencies: 356
-- Name: COLUMN clinical_notes.appointment_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.appointment_id IS 'Links clinical note to specific appointment';


--
-- TOC entry 4818 (class 0 OID 0)
-- Dependencies: 356
-- Name: COLUMN clinical_notes.allergies; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.allergies IS 'Array of patient allergies recorded during visit';


--
-- TOC entry 4819 (class 0 OID 0)
-- Dependencies: 356
-- Name: COLUMN clinical_notes.previous_medications; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.previous_medications IS 'Array of previous medications mentioned during visit';


--
-- TOC entry 4820 (class 0 OID 0)
-- Dependencies: 356
-- Name: COLUMN clinical_notes.current_medications; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.current_medications IS 'Array of current medications mentioned during visit';


--
-- TOC entry 4821 (class 0 OID 0)
-- Dependencies: 356
-- Name: COLUMN clinical_notes.clinical_note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.clinical_note IS 'Main clinical observations and notes';


--
-- TOC entry 4822 (class 0 OID 0)
-- Dependencies: 356
-- Name: COLUMN clinical_notes.internal_note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.internal_note IS 'Internal provider notes, not visible to patients';


--
-- TOC entry 4823 (class 0 OID 0)
-- Dependencies: 356
-- Name: COLUMN clinical_notes.visit_summary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.visit_summary IS 'Auto-generated or custom summary of the visit';


--
-- TOC entry 363 (class 1259 OID 19007)
-- Name: faxes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.faxes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    approval_id uuid NOT NULL,
    preference_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    fax_number text NOT NULL,
    fax_content text,
    fax_status text DEFAULT 'sent'::text NOT NULL,
    faxed_at timestamp with time zone DEFAULT now() NOT NULL,
    delivery_confirmation_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    provider_profile_id uuid NOT NULL,
    patient_profile_id uuid NOT NULL,
    CONSTRAINT faxes_fax_status_check CHECK ((fax_status = ANY (ARRAY['sent'::text, 'delivered'::text, 'failed'::text, 'pending'::text])))
);


--
-- TOC entry 4824 (class 0 OID 0)
-- Dependencies: 363
-- Name: TABLE faxes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.faxes IS 'Tracks all fax communications for medication prescriptions';


--
-- TOC entry 4825 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN faxes.approval_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.approval_id IS 'Reference to the medication approval that was faxed';


--
-- TOC entry 4826 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN faxes.preference_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.preference_id IS 'Reference to the patient medication preference';


--
-- TOC entry 4827 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN faxes.fax_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.fax_number IS 'Phone number or fax identifier where prescription was sent';


--
-- TOC entry 4828 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN faxes.fax_content; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.fax_content IS 'Content or description of what was faxed';


--
-- TOC entry 4829 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN faxes.fax_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.fax_status IS 'Status of the fax transmission';


--
-- TOC entry 4830 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN faxes.faxed_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.faxed_at IS 'When the fax was sent';


--
-- TOC entry 4831 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN faxes.delivery_confirmation_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.delivery_confirmation_at IS 'When delivery was confirmed';


--
-- TOC entry 4832 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN faxes.provider_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.provider_profile_id IS 'Direct reference to provider auth user ID';


--
-- TOC entry 4833 (class 0 OID 0)
-- Dependencies: 363
-- Name: COLUMN faxes.patient_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.patient_profile_id IS 'Direct reference to patient auth user ID';


--
-- TOC entry 360 (class 1259 OID 18873)
-- Name: medication_dosages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medication_dosages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    medication_id uuid NOT NULL,
    strength text NOT NULL,
    unit_price numeric(10,2) DEFAULT 0 NOT NULL,
    available boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 4834 (class 0 OID 0)
-- Dependencies: 360
-- Name: TABLE medication_dosages; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.medication_dosages IS 'Stores multiple dosage options for each medication. Replaces the single strength field in medications table.';


--
-- TOC entry 343 (class 1259 OID 18345)
-- Name: patient_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patient_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    treatment_type text DEFAULT 'general_care'::text,
    is_primary boolean DEFAULT false,
    assigned_date timestamp with time zone DEFAULT now(),
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 351 (class 1259 OID 18576)
-- Name: provider_availability_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provider_availability_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid NOT NULL,
    date date NOT NULL,
    start_time time without time zone,
    end_time time without time zone,
    available boolean NOT NULL,
    reason text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_override_time CHECK (((available = false) OR ((available = true) AND (start_time IS NOT NULL) AND (end_time IS NOT NULL) AND (end_time > start_time))))
);


--
-- TOC entry 4835 (class 0 OID 0)
-- Dependencies: 351
-- Name: TABLE provider_availability_overrides; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.provider_availability_overrides IS 'Date-specific availability changes (vacations, special hours, etc.)';


--
-- TOC entry 4836 (class 0 OID 0)
-- Dependencies: 351
-- Name: COLUMN provider_availability_overrides.available; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provider_availability_overrides.available IS 'false=unavailable, true=special availability override';


--
-- TOC entry 350 (class 1259 OID 18553)
-- Name: provider_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provider_schedules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid NOT NULL,
    day_of_week integer NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    slot_duration_minutes integer DEFAULT 30 NOT NULL,
    treatment_types text[] DEFAULT '{}'::text[],
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT provider_schedules_day_of_week_check CHECK (((day_of_week >= 0) AND (day_of_week <= 6))),
    CONSTRAINT provider_schedules_slot_duration_minutes_check CHECK ((slot_duration_minutes > 0)),
    CONSTRAINT valid_time_range CHECK ((end_time > start_time))
);


--
-- TOC entry 4837 (class 0 OID 0)
-- Dependencies: 350
-- Name: TABLE provider_schedules; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.provider_schedules IS 'Recurring weekly availability schedules for providers';


--
-- TOC entry 4838 (class 0 OID 0)
-- Dependencies: 350
-- Name: COLUMN provider_schedules.day_of_week; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provider_schedules.day_of_week IS '0=Sunday, 1=Monday, ..., 6=Saturday';


--
-- TOC entry 4839 (class 0 OID 0)
-- Dependencies: 350
-- Name: COLUMN provider_schedules.treatment_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provider_schedules.treatment_types IS 'Empty array means available for all treatment types';


--
-- TOC entry 341 (class 1259 OID 18308)
-- Name: providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    specialty text,
    license_number text,
    phone text,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 354 (class 1259 OID 18697)
-- Name: provider_availability_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.provider_availability_summary AS
 SELECT p.id AS provider_id,
    ((prof.first_name || ' '::text) || prof.last_name) AS provider_name,
    ps.day_of_week,
        CASE ps.day_of_week
            WHEN 0 THEN 'Sunday'::text
            WHEN 1 THEN 'Monday'::text
            WHEN 2 THEN 'Tuesday'::text
            WHEN 3 THEN 'Wednesday'::text
            WHEN 4 THEN 'Thursday'::text
            WHEN 5 THEN 'Friday'::text
            WHEN 6 THEN 'Saturday'::text
            ELSE NULL::text
        END AS day_name,
    ps.start_time,
    ps.end_time,
    ps.slot_duration_minutes,
    ps.treatment_types,
    ps.active
   FROM ((public.providers p
     JOIN public.profiles prof ON ((p.profile_id = prof.id)))
     JOIN public.provider_schedules ps ON ((p.id = ps.provider_id)))
  ORDER BY p.id, ps.day_of_week, ps.start_time;


--
-- TOC entry 4840 (class 0 OID 0)
-- Dependencies: 354
-- Name: VIEW provider_availability_summary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.provider_availability_summary IS 'Easy view of all provider schedules with readable day names';


--
-- TOC entry 355 (class 1259 OID 18702)
-- Name: upcoming_appointments_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.upcoming_appointments_summary AS
 SELECT a.id AS appointment_id,
    ((patient_prof.first_name || ' '::text) || patient_prof.last_name) AS patient_name,
    ((provider_prof.first_name || ' '::text) || provider_prof.last_name) AS provider_name,
    a.appointment_date,
    a.start_time,
    a.end_time,
    a.treatment_type,
    a.appointment_type,
    a.status,
    a.created_at
   FROM ((((public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
     JOIN public.profiles patient_prof ON ((p.profile_id = patient_prof.id)))
     JOIN public.providers prov ON ((a.provider_id = prov.id)))
     JOIN public.profiles provider_prof ON ((prov.profile_id = provider_prof.id)))
  WHERE (a.appointment_date >= CURRENT_DATE)
  ORDER BY a.appointment_date, a.start_time;


--
-- TOC entry 4841 (class 0 OID 0)
-- Dependencies: 355
-- Name: VIEW upcoming_appointments_summary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.upcoming_appointments_summary IS 'Overview of all upcoming appointments with patient and provider names';


--
-- TOC entry 361 (class 1259 OID 18903)
-- Name: visit_addendums; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visit_addendums (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    visit_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT visit_addendums_content_not_empty CHECK ((length(TRIM(BOTH FROM content)) > 0))
);


--
-- TOC entry 4842 (class 0 OID 0)
-- Dependencies: 361
-- Name: TABLE visit_addendums; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.visit_addendums IS 'Addendums to previous visits for additional notes or corrections';


--
-- TOC entry 4843 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN visit_addendums.visit_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_addendums.visit_id IS 'Links addendum to specific appointment/visit';


--
-- TOC entry 4844 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN visit_addendums.provider_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_addendums.provider_id IS 'Provider who created the addendum';


--
-- TOC entry 4845 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN visit_addendums.content; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_addendums.content IS 'Content of the addendum';


--
-- TOC entry 4846 (class 0 OID 0)
-- Dependencies: 361
-- Name: COLUMN visit_addendums.created_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_addendums.created_at IS 'When the addendum was created';


--
-- TOC entry 358 (class 1259 OID 18766)
-- Name: visit_interactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visit_interactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinical_note_id uuid NOT NULL,
    appointment_id uuid NOT NULL,
    interaction_type text NOT NULL,
    details text,
    provider_notes text,
    created_at timestamp with time zone DEFAULT now(),
    performed_by uuid NOT NULL,
    medication_id uuid,
    medication_name text,
    previous_dosage text,
    new_dosage text,
    previous_frequency text,
    new_frequency text,
    previous_status text,
    new_status text,
    CONSTRAINT visit_interactions_interaction_type_check CHECK ((interaction_type = ANY (ARRAY['treatment_plan_update'::text, 'follow_up_scheduled'::text, 'referral_made'::text, 'lab_ordered'::text, 'allergy_noted'::text, 'vital_signs_recorded'::text]))),
    CONSTRAINT visit_interactions_new_status_check CHECK (((new_status IS NULL) OR (new_status = ANY (ARRAY['pending'::text, 'approved'::text, 'denied'::text, 'discontinued'::text]))))
);


--
-- TOC entry 4847 (class 0 OID 0)
-- Dependencies: 358
-- Name: TABLE visit_interactions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.visit_interactions IS 'General interactions and activities during visits (non-medication)';


--
-- TOC entry 4848 (class 0 OID 0)
-- Dependencies: 358
-- Name: COLUMN visit_interactions.interaction_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_interactions.interaction_type IS 'Type of interaction: treatment_plan_update, follow_up_scheduled, etc.';


--
-- TOC entry 4849 (class 0 OID 0)
-- Dependencies: 358
-- Name: COLUMN visit_interactions.details; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_interactions.details IS 'General details about the interaction';


--
-- TOC entry 357 (class 1259 OID 18741)
-- Name: visit_medication_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visit_medication_adjustments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinical_note_id uuid NOT NULL,
    appointment_id uuid NOT NULL,
    preference_id uuid NOT NULL,
    previous_dosage text,
    previous_frequency text,
    previous_status text,
    previous_provider_notes text,
    new_dosage text,
    new_frequency text,
    new_status text,
    new_provider_notes text,
    adjustment_reason text,
    provider_notes text,
    created_at timestamp with time zone DEFAULT now(),
    performed_by uuid NOT NULL,
    new_supply_days integer,
    CONSTRAINT visit_medication_adjustments_new_status_check CHECK ((new_status = ANY (ARRAY['pending'::text, 'approved'::text, 'denied'::text, 'discontinued'::text])))
);


--
-- TOC entry 4850 (class 0 OID 0)
-- Dependencies: 357
-- Name: TABLE visit_medication_adjustments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.visit_medication_adjustments IS 'Medication adjustments made during visits, links to patient_medication_preferences';


--
-- TOC entry 4851 (class 0 OID 0)
-- Dependencies: 357
-- Name: COLUMN visit_medication_adjustments.preference_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_medication_adjustments.preference_id IS 'Links to existing patient_medication_preferences table';


--
-- TOC entry 4852 (class 0 OID 0)
-- Dependencies: 357
-- Name: COLUMN visit_medication_adjustments.adjustment_reason; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_medication_adjustments.adjustment_reason IS 'Reason for the medication adjustment';


--
-- TOC entry 4853 (class 0 OID 0)
-- Dependencies: 357
-- Name: COLUMN visit_medication_adjustments.new_supply_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_medication_adjustments.new_supply_days IS 'Number of days of medication supply when approved via medication adjustments';


--
-- TOC entry 314 (class 1259 OID 17007)
-- Name: messages; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
)
PARTITION BY RANGE (inserted_at);


--
-- TOC entry 315 (class 1259 OID 17024)
-- Name: messages_2025_10_01; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_10_01 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 316 (class 1259 OID 17036)
-- Name: messages_2025_10_02; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_10_02 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 317 (class 1259 OID 17048)
-- Name: messages_2025_10_03; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_10_03 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 318 (class 1259 OID 17060)
-- Name: messages_2025_10_04; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_10_04 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 319 (class 1259 OID 17072)
-- Name: messages_2025_10_05; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_10_05 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 308 (class 1259 OID 16844)
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


--
-- TOC entry 311 (class 1259 OID 16867)
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);


--
-- TOC entry 310 (class 1259 OID 16866)
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: -
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 289 (class 1259 OID 16509)
-- Name: buckets; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


--
-- TOC entry 4854 (class 0 OID 0)
-- Dependencies: 289
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 323 (class 1259 OID 17892)
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_analytics (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 324 (class 1259 OID 17903)
-- Name: iceberg_namespaces; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.iceberg_namespaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 325 (class 1259 OID 17919)
-- Name: iceberg_tables; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.iceberg_tables (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    namespace_id uuid NOT NULL,
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    location text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 291 (class 1259 OID 16551)
-- Name: migrations; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 290 (class 1259 OID 16524)
-- Name: objects; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb,
    level integer
);


--
-- TOC entry 4855 (class 0 OID 0)
-- Dependencies: 290
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 322 (class 1259 OID 17848)
-- Name: prefixes; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.prefixes (
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    level integer GENERATED ALWAYS AS (storage.get_level(name)) STORED NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 320 (class 1259 OID 17795)
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb
);


--
-- TOC entry 321 (class 1259 OID 17809)
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 304 (class 1259 OID 16763)
-- Name: hooks; Type: TABLE; Schema: supabase_functions; Owner: -
--

CREATE TABLE supabase_functions.hooks (
    id bigint NOT NULL,
    hook_table_id integer NOT NULL,
    hook_name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    request_id bigint
);


--
-- TOC entry 4856 (class 0 OID 0)
-- Dependencies: 304
-- Name: TABLE hooks; Type: COMMENT; Schema: supabase_functions; Owner: -
--

COMMENT ON TABLE supabase_functions.hooks IS 'Supabase Functions Hooks: Audit trail for triggered hooks.';


--
-- TOC entry 303 (class 1259 OID 16762)
-- Name: hooks_id_seq; Type: SEQUENCE; Schema: supabase_functions; Owner: -
--

CREATE SEQUENCE supabase_functions.hooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4857 (class 0 OID 0)
-- Dependencies: 303
-- Name: hooks_id_seq; Type: SEQUENCE OWNED BY; Schema: supabase_functions; Owner: -
--

ALTER SEQUENCE supabase_functions.hooks_id_seq OWNED BY supabase_functions.hooks.id;


--
-- TOC entry 302 (class 1259 OID 16754)
-- Name: migrations; Type: TABLE; Schema: supabase_functions; Owner: -
--

CREATE TABLE supabase_functions.migrations (
    version text NOT NULL,
    inserted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 3792 (class 0 OID 0)
-- Name: messages_2025_10_01; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_01 FOR VALUES FROM ('2025-10-01 00:00:00') TO ('2025-10-02 00:00:00');


--
-- TOC entry 3793 (class 0 OID 0)
-- Name: messages_2025_10_02; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_02 FOR VALUES FROM ('2025-10-02 00:00:00') TO ('2025-10-03 00:00:00');


--
-- TOC entry 3794 (class 0 OID 0)
-- Name: messages_2025_10_03; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_03 FOR VALUES FROM ('2025-10-03 00:00:00') TO ('2025-10-04 00:00:00');


--
-- TOC entry 3795 (class 0 OID 0)
-- Name: messages_2025_10_04; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_04 FOR VALUES FROM ('2025-10-04 00:00:00') TO ('2025-10-05 00:00:00');


--
-- TOC entry 3796 (class 0 OID 0)
-- Name: messages_2025_10_05; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_05 FOR VALUES FROM ('2025-10-05 00:00:00') TO ('2025-10-06 00:00:00');


--
-- TOC entry 3806 (class 2604 OID 16473)
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- TOC entry 3895 (class 2604 OID 18418)
-- Name: assignment_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assignment_log ALTER COLUMN id SET DEFAULT nextval('public.assignment_log_id_seq'::regclass);


--
-- TOC entry 3820 (class 2604 OID 16766)
-- Name: hooks id; Type: DEFAULT; Schema: supabase_functions; Owner: -
--

ALTER TABLE ONLY supabase_functions.hooks ALTER COLUMN id SET DEFAULT nextval('supabase_functions.hooks_id_seq'::regclass);


--
-- TOC entry 4684 (class 0 OID 16488)
-- Dependencies: 287
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
00000000-0000-0000-0000-000000000000	d07b5862-03c7-406b-b6ef-44637b0d5b20	{"action":"user_signedup","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"team","traits":{"provider":"email"}}	2025-10-02 03:48:31.051417+00	
00000000-0000-0000-0000-000000000000	244359f1-63ae-4358-b503-64b94de82738	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 03:48:31.05316+00	
00000000-0000-0000-0000-000000000000	be4c9266-6728-4340-b3b1-b2bac6adc01d	{"action":"user_signedup","actor_id":"83a1dde8-655a-4283-b7c6-62ddf063cd83","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"team","traits":{"provider":"email"}}	2025-10-02 03:48:55.251282+00	
00000000-0000-0000-0000-000000000000	9d8422f1-35c8-4eea-a282-39817af3ba5f	{"action":"login","actor_id":"83a1dde8-655a-4283-b7c6-62ddf063cd83","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 03:48:55.254554+00	
00000000-0000-0000-0000-000000000000	bdd785f8-5cd1-4791-bacb-dbd4ac763a31	{"action":"user_signedup","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"team","traits":{"provider":"email"}}	2025-10-02 03:49:37.226647+00	
00000000-0000-0000-0000-000000000000	56870157-b33b-4cff-8dc7-6e478efd0b19	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 03:49:37.2279+00	
00000000-0000-0000-0000-000000000000	6915fe0b-1502-45e6-9d3f-76934d71bafa	{"action":"logout","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 03:49:46.216072+00	
00000000-0000-0000-0000-000000000000	b585c053-2f49-4e74-a403-e43b0c0d8f4e	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 03:50:02.05751+00	
00000000-0000-0000-0000-000000000000	b99f4f5e-8c41-4ce2-bdde-d19fd881fc04	{"action":"logout","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 03:50:10.819288+00	
00000000-0000-0000-0000-000000000000	fb99528b-3e72-49c2-9614-4eb11a7b1ba4	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 03:54:23.532895+00	
00000000-0000-0000-0000-000000000000	be87916e-4be1-493c-9dc5-c22938ae29b3	{"action":"logout","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 03:54:36.588506+00	
00000000-0000-0000-0000-000000000000	759425fe-ee0d-4ae2-981a-bb5dee950c0d	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 03:54:43.751398+00	
00000000-0000-0000-0000-000000000000	2aa549a5-15ee-4129-a3ad-22c1b998bc6d	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 03:56:21.79872+00	
00000000-0000-0000-0000-000000000000	6ff11d2e-c313-458f-a9ca-5a9abb951f21	{"action":"logout","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 03:57:01.045139+00	
00000000-0000-0000-0000-000000000000	85e1791c-5674-43ca-88b1-b80cff34a77f	{"action":"login","actor_id":"83a1dde8-655a-4283-b7c6-62ddf063cd83","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 03:57:10.302649+00	
00000000-0000-0000-0000-000000000000	29b63265-4d33-4e1c-a3fb-d1ebfac7cefa	{"action":"login","actor_id":"83a1dde8-655a-4283-b7c6-62ddf063cd83","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 03:59:30.826125+00	
00000000-0000-0000-0000-000000000000	bddc0a55-83b0-47ee-91d0-886574b60674	{"action":"logout","actor_id":"83a1dde8-655a-4283-b7c6-62ddf063cd83","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 04:00:20.728161+00	
00000000-0000-0000-0000-000000000000	bdfea61a-4e61-423e-843c-322341404d48	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 04:00:38.396372+00	
00000000-0000-0000-0000-000000000000	9ea3fb58-d4aa-4c98-8da3-a6d115140bec	{"action":"logout","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 04:01:46.244639+00	
00000000-0000-0000-0000-000000000000	05452029-0749-4c38-b256-553155cbaffb	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 04:03:02.476707+00	
00000000-0000-0000-0000-000000000000	00c47d9a-21cf-4097-ab4d-7dca0a57a866	{"action":"logout","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 04:03:19.080966+00	
00000000-0000-0000-0000-000000000000	570c797c-a7d0-435e-8fa4-d516e1bb0e15	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 04:03:35.86088+00	
00000000-0000-0000-0000-000000000000	6593a828-b67c-46c6-b7b9-5b40b8c60d2b	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 04:05:16.453273+00	
00000000-0000-0000-0000-000000000000	d901110c-cd8b-48cb-bd8c-8d1e56621067	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 04:09:44.328539+00	
00000000-0000-0000-0000-000000000000	ae315904-8d0c-4b82-a72b-eb21f19e8399	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 04:19:15.300127+00	
00000000-0000-0000-0000-000000000000	4acb75e0-9382-46fd-9f10-cc97cbbb0e3d	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 04:35:04.906687+00	
00000000-0000-0000-0000-000000000000	4f248a15-bd4e-4b5d-b2e2-d5bb2a58beae	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 04:40:39.197018+00	
00000000-0000-0000-0000-000000000000	12c19085-6ab7-48a7-8185-bbebed114a23	{"action":"logout","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 04:41:06.610359+00	
00000000-0000-0000-0000-000000000000	60495fa2-dcb5-4725-abbd-c80408699c95	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 04:41:26.628077+00	
00000000-0000-0000-0000-000000000000	20ead8aa-c41f-4eef-bfdd-9e59d0f2c2f4	{"action":"logout","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 04:41:50.413061+00	
00000000-0000-0000-0000-000000000000	fc36c735-fc5d-47d3-bc61-3bf74db073e0	{"action":"login","actor_id":"83a1dde8-655a-4283-b7c6-62ddf063cd83","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 04:43:05.764479+00	
00000000-0000-0000-0000-000000000000	7f89718a-43c5-4bb9-9117-f93dd8121ecc	{"action":"logout","actor_id":"83a1dde8-655a-4283-b7c6-62ddf063cd83","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 04:44:29.663964+00	
00000000-0000-0000-0000-000000000000	d791c5bb-ca12-43b1-92f5-925a5ddab758	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 04:45:34.433617+00	
00000000-0000-0000-0000-000000000000	39c097e6-fc2b-4937-8783-ca87600cc8f6	{"action":"logout","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 04:47:06.35085+00	
00000000-0000-0000-0000-000000000000	421fd0ea-06e7-4146-980d-35fe6194e500	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 04:47:49.554726+00	
00000000-0000-0000-0000-000000000000	8815ebfd-b005-456e-b33f-d9649fd11eba	{"action":"logout","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 04:48:33.937378+00	
00000000-0000-0000-0000-000000000000	3cc089d6-aa26-4ae6-87d4-4c64076b01b0	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 04:48:45.464975+00	
00000000-0000-0000-0000-000000000000	1dffbbbb-4726-42dc-8037-97908e2793dc	{"action":"logout","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 04:48:52.553368+00	
00000000-0000-0000-0000-000000000000	89b327cb-8a96-40a9-87f1-fafc7baae822	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 04:49:03.812328+00	
00000000-0000-0000-0000-000000000000	3b93a6ed-ce39-4821-a2cc-616e6591aeaa	{"action":"logout","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 04:49:42.982108+00	
00000000-0000-0000-0000-000000000000	102841e1-a2c6-46f4-990c-6fef944f0719	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 04:49:52.728347+00	
00000000-0000-0000-0000-000000000000	ee21fda8-1c10-4ca8-9e12-d4ceb927b541	{"action":"logout","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 04:50:27.873667+00	
00000000-0000-0000-0000-000000000000	834ad3e0-86d4-49ea-89f7-fc1a7409405c	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 04:50:51.28678+00	
00000000-0000-0000-0000-000000000000	7fa0f921-4a50-4e37-ba98-d61ab5f72263	{"action":"logout","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 04:51:29.950202+00	
00000000-0000-0000-0000-000000000000	67f1b056-23b3-41af-afcd-f58c510b5094	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 04:51:44.80932+00	
00000000-0000-0000-0000-000000000000	b53a8e25-6b37-4c74-b9f9-ebeae281c41a	{"action":"logout","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 04:59:14.581029+00	
00000000-0000-0000-0000-000000000000	198716eb-9c33-4d59-8242-a841c6b63395	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 18:44:35.075799+00	
00000000-0000-0000-0000-000000000000	df842c68-bc74-4257-b8e3-378d6b2f6b19	{"action":"logout","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 18:45:11.328287+00	
00000000-0000-0000-0000-000000000000	2fcd40d9-5506-4667-b927-6ac0eb25353c	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 19:39:43.367575+00	
00000000-0000-0000-0000-000000000000	74d9b4b9-68fc-4c5e-b6ec-bc9b217e3ffb	{"action":"logout","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 19:40:15.178623+00	
00000000-0000-0000-0000-000000000000	1607602a-3c22-44d5-bf4a-6d2a966f0c87	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 19:40:26.333718+00	
00000000-0000-0000-0000-000000000000	afcb8182-60a5-4339-b83f-ec1a045baf21	{"action":"logout","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 19:45:23.676296+00	
00000000-0000-0000-0000-000000000000	ff5a63e6-617e-47e5-b2f2-9a17d533e902	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 19:45:39.294075+00	
00000000-0000-0000-0000-000000000000	3221f6b0-c848-4f9e-a091-7dd556aff0f8	{"action":"logout","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 19:45:54.636222+00	
00000000-0000-0000-0000-000000000000	9edfd06c-c55c-4778-9a7b-cf22322ced3e	{"action":"login","actor_id":"83a1dde8-655a-4283-b7c6-62ddf063cd83","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 19:46:08.270427+00	
00000000-0000-0000-0000-000000000000	c4d82c0c-36c8-4959-bb1f-005aff80ea7e	{"action":"logout","actor_id":"83a1dde8-655a-4283-b7c6-62ddf063cd83","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 19:46:52.811889+00	
00000000-0000-0000-0000-000000000000	f6a5dac0-6064-44da-bbe4-f82f1a59a67d	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 19:47:10.050492+00	
00000000-0000-0000-0000-000000000000	16d4d6b5-5f2e-4056-881b-397f7544452b	{"action":"logout","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 19:47:26.383159+00	
00000000-0000-0000-0000-000000000000	7f3cc58e-689f-4537-bb02-fb2ea39f4f78	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 19:47:37.965468+00	
00000000-0000-0000-0000-000000000000	71dc9d49-239a-4079-8ad0-cc144bed3e89	{"action":"logout","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 19:47:58.000154+00	
00000000-0000-0000-0000-000000000000	7a953a23-a16e-4c29-9cd6-601b80ccf34f	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 19:52:42.997112+00	
00000000-0000-0000-0000-000000000000	0622f4a0-034c-46e9-8e50-4295c66f2684	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 19:55:04.843989+00	
00000000-0000-0000-0000-000000000000	652ddfa3-c317-42d7-b3d6-540a13a439ee	{"action":"logout","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 19:56:37.639817+00	
00000000-0000-0000-0000-000000000000	2a5843c5-425a-4f00-b70e-1253f79a6b6e	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 19:56:49.596391+00	
00000000-0000-0000-0000-000000000000	75b375a6-0853-4030-81b6-3252d1bf99f2	{"action":"logout","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 19:58:33.953129+00	
00000000-0000-0000-0000-000000000000	7e7247e1-cbc4-41b3-a6f6-8e90f730468c	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 19:58:48.013769+00	
00000000-0000-0000-0000-000000000000	9c1fc5a8-49f6-4b28-987c-e5d64dbd5073	{"action":"logout","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 20:00:41.349871+00	
00000000-0000-0000-0000-000000000000	a4f3d913-93d1-432a-8a9a-da323cb8aefb	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 20:00:50.464377+00	
00000000-0000-0000-0000-000000000000	3c92b884-f7b6-4758-9019-a2f3c5a512c4	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 20:23:09.093595+00	
00000000-0000-0000-0000-000000000000	ba0be89e-7099-41f3-b1c8-38e04b20c603	{"action":"logout","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 20:23:21.0794+00	
00000000-0000-0000-0000-000000000000	7b547ecb-b346-47e9-b5b7-c98eb144ac81	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 20:23:34.628739+00	
00000000-0000-0000-0000-000000000000	7ca12068-8a12-40b0-a404-b63137589357	{"action":"logout","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 20:23:50.413048+00	
00000000-0000-0000-0000-000000000000	ef78c14c-e7bc-41b0-a195-86962431fdd2	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 20:24:51.31596+00	
00000000-0000-0000-0000-000000000000	8ad13b0f-f35d-4cb1-b3a0-922974c2aeee	{"action":"logout","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 20:25:07.081002+00	
00000000-0000-0000-0000-000000000000	12a3d7d7-939c-404d-bbbe-db2343c30e71	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 20:25:20.182164+00	
00000000-0000-0000-0000-000000000000	c9f1d3d7-74c4-4802-a9d7-fc240e893c9f	{"action":"logout","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 20:25:41.599993+00	
00000000-0000-0000-0000-000000000000	81f2063a-d1f6-42fa-9446-cbc6cf029060	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 20:25:52.298568+00	
00000000-0000-0000-0000-000000000000	c60a3eae-84dd-4f1c-9913-01169ca2d282	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 21:11:54.658597+00	
00000000-0000-0000-0000-000000000000	197739f7-b47d-4078-980b-5bb5df7dfe51	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 21:22:33.507149+00	
00000000-0000-0000-0000-000000000000	ba8388e2-fab0-487c-9c27-da2cf418b892	{"action":"login","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 21:23:31.794212+00	
00000000-0000-0000-0000-000000000000	bc1fb7b4-836c-4008-8dc7-15aba96e5c1d	{"action":"logout","actor_id":"e2b62e92-840b-4db4-8e37-7f2208b1ac23","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-02 21:23:41.621016+00	
00000000-0000-0000-0000-000000000000	4afc9eae-af7a-4213-8455-a6bc28589cc0	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 21:23:51.739953+00	
00000000-0000-0000-0000-000000000000	80feff21-7da3-40fb-a724-24a8b7e79d7a	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 22:08:47.49717+00	
00000000-0000-0000-0000-000000000000	d779a909-83c4-41ad-9242-81f06251264f	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 22:24:49.263363+00	
00000000-0000-0000-0000-000000000000	b755d625-e036-49c3-9b46-829c10c8f713	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 22:37:29.870382+00	
00000000-0000-0000-0000-000000000000	086210b9-9895-44ae-97aa-a6aab16c2e8e	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-02 23:44:37.588397+00	
00000000-0000-0000-0000-000000000000	e4f96d9d-7bd6-4253-9d23-550a73fb52bd	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-03 00:36:18.126518+00	
00000000-0000-0000-0000-000000000000	240b493b-cd04-4322-9ce5-8e692dec2b88	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-03 00:56:21.158321+00	
00000000-0000-0000-0000-000000000000	df264527-ab9e-4e06-91d5-dc22eced0e29	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-03 01:11:51.546466+00	
00000000-0000-0000-0000-000000000000	0ec763f3-c24d-4194-bae8-463293c62b67	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-03 01:35:37.752533+00	
00000000-0000-0000-0000-000000000000	ccbdcc00-2463-4289-b410-f4f63630e3eb	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-03 02:10:59.682283+00	
00000000-0000-0000-0000-000000000000	3bf51d29-c3e5-4b4e-9f98-3d23c0294028	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-03 03:30:46.10555+00	
00000000-0000-0000-0000-000000000000	dbc14d1c-2961-4839-970d-c5a639606896	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-03 03:38:19.008686+00	
00000000-0000-0000-0000-000000000000	5e9ccd48-1910-4635-9301-a44c1816b801	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-03 03:42:06.71835+00	
00000000-0000-0000-0000-000000000000	60b58afe-5a69-43f7-93b2-f910409ff9b2	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-03 03:48:37.955547+00	
00000000-0000-0000-0000-000000000000	b6a28c28-06f5-48a6-a1eb-9d693a185b1b	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-03 03:53:15.939759+00	
00000000-0000-0000-0000-000000000000	bbd1a785-a876-402f-b52a-f8b354ce034f	{"action":"login","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-03 03:56:06.462218+00	
00000000-0000-0000-0000-000000000000	272f7a86-7d1b-4a6c-a659-9fe4a355effc	{"action":"logout","actor_id":"02438205-29ee-44c1-94f2-10342a9fe7cf","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-03 03:57:19.532638+00	
00000000-0000-0000-0000-000000000000	3d8dc988-8251-4f4e-9a26-c96285900795	{"action":"login","actor_id":"83a1dde8-655a-4283-b7c6-62ddf063cd83","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-03 03:57:27.716055+00	
\.


--
-- TOC entry 4715 (class 0 OID 18167)
-- Dependencies: 335
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at) FROM stdin;
\.


--
-- TOC entry 4706 (class 0 OID 17965)
-- Dependencies: 326
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
e2b62e92-840b-4db4-8e37-7f2208b1ac23	e2b62e92-840b-4db4-8e37-7f2208b1ac23	{"sub": "e2b62e92-840b-4db4-8e37-7f2208b1ac23", "role": "patient", "email": "patientexample@test.com", "last_name": "example", "first_name": "patient", "email_verified": false, "phone_verified": false}	email	2025-10-02 03:48:31.050406+00	2025-10-02 03:48:31.050421+00	2025-10-02 03:48:31.050421+00	68c9aa1d-0dd0-42b3-87e5-b6daba5542ba
83a1dde8-655a-4283-b7c6-62ddf063cd83	83a1dde8-655a-4283-b7c6-62ddf063cd83	{"sub": "83a1dde8-655a-4283-b7c6-62ddf063cd83", "role": "admin", "email": "adminexample@test.com", "last_name": "example", "first_name": "admin", "email_verified": false, "phone_verified": false}	email	2025-10-02 03:48:55.250595+00	2025-10-02 03:48:55.250607+00	2025-10-02 03:48:55.250607+00	31dc7525-de53-4c78-8c91-aee27e92c32c
02438205-29ee-44c1-94f2-10342a9fe7cf	02438205-29ee-44c1-94f2-10342a9fe7cf	{"sub": "02438205-29ee-44c1-94f2-10342a9fe7cf", "role": "provider", "email": "providerexample@test.com", "phone": "", "last_name": "example", "specialty": "weight loss", "first_name": "provider", "email_verified": false, "license_number": "1234567890", "phone_verified": false}	email	2025-10-02 03:49:37.225943+00	2025-10-02 03:49:37.225955+00	2025-10-02 03:49:37.225955+00	cd0ae8fd-bd4e-4df9-9138-e91cfa87804f
\.


--
-- TOC entry 4683 (class 0 OID 16481)
-- Dependencies: 286
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4710 (class 0 OID 18054)
-- Dependencies: 330
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
6f1519d3-8b52-4dfc-ad8e-0b28d0d92c77	2025-10-03 03:57:27.717707+00	2025-10-03 03:57:27.717707+00	password	e45cacb1-c8dd-449f-b028-82abbc1e6f3f
\.


--
-- TOC entry 4709 (class 0 OID 18042)
-- Dependencies: 329
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- TOC entry 4708 (class 0 OID 18029)
-- Dependencies: 328
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid) FROM stdin;
\.


--
-- TOC entry 4717 (class 0 OID 18249)
-- Dependencies: 337
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_clients (id, client_id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- TOC entry 4716 (class 0 OID 18217)
-- Dependencies: 336
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4682 (class 0 OID 16470)
-- Dependencies: 285
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
00000000-0000-0000-0000-000000000000	63	e2bazmtuibqj	83a1dde8-655a-4283-b7c6-62ddf063cd83	f	2025-10-03 03:57:27.717096+00	2025-10-03 03:57:27.717096+00	\N	6f1519d3-8b52-4dfc-ad8e-0b28d0d92c77
\.


--
-- TOC entry 4713 (class 0 OID 18096)
-- Dependencies: 333
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- TOC entry 4714 (class 0 OID 18114)
-- Dependencies: 334
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- TOC entry 4685 (class 0 OID 16496)
-- Dependencies: 288
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
\.


--
-- TOC entry 4707 (class 0 OID 17995)
-- Dependencies: 327
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag) FROM stdin;
6f1519d3-8b52-4dfc-ad8e-0b28d0d92c77	83a1dde8-655a-4283-b7c6-62ddf063cd83	2025-10-03 03:57:27.716622+00	2025-10-03 03:57:27.716622+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
\.


--
-- TOC entry 4712 (class 0 OID 18081)
-- Dependencies: 332
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4711 (class 0 OID 18072)
-- Dependencies: 331
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- TOC entry 4680 (class 0 OID 16458)
-- Dependencies: 283
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\N	22222222-2222-2222-2222-222222222222	\N	\N	michael.r@test.com	$2a$10$dummyhashformichaelroberts	2025-10-02 03:43:24.568988+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	33333333-3333-3333-3333-333333333333	\N	\N	jennifer.m@test.com	$2a$10$dummyhashforjennifermartinez	2025-10-02 03:43:24.568988+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	44444444-4444-4444-4444-444444444444	\N	\N	david.a@test.com	$2a$10$dummyhashfordavidanderson	2025-10-02 03:43:24.568988+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb	\N	\N	dr.watson@test.com	$2a$10$dummyhashfordrwatson	2025-10-02 03:43:24.568988+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	cccccccc-cccc-cccc-cccc-cccccccccccc	\N	\N	dr.wilson@test.com	$2a$10$dummyhashfordrwilson	2025-10-02 03:43:24.568988+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa	\N	\N	admin@test.com	admin123	2025-10-02 03:43:24.575787+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"role": "admin", "last_name": "User", "first_name": "Admin"}	\N	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.575787+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	11111111-1111-1111-1111-111111111111	\N	\N	sarah.j@test.com	patient123	2025-10-02 03:43:24.575787+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"role": "patient", "last_name": "Johnson", "first_name": "Sarah"}	\N	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.575787+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	e2b62e92-840b-4db4-8e37-7f2208b1ac23	authenticated	authenticated	patientexample@test.com	$2a$10$t/sEiyINdLxzr0LROXdvxumflzBdzVZWlwiOIKDJM0dMPzcU7M9k2	2025-10-02 03:48:31.051741+00	\N		\N		\N			\N	2025-10-02 21:23:31.794503+00	{"provider": "email", "providers": ["email"]}	{"sub": "e2b62e92-840b-4db4-8e37-7f2208b1ac23", "role": "patient", "email": "patientexample@test.com", "last_name": "example", "first_name": "patient", "email_verified": true, "phone_verified": false}	\N	2025-10-02 03:48:31.048218+00	2025-10-02 21:23:31.795206+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	02438205-29ee-44c1-94f2-10342a9fe7cf	authenticated	authenticated	providerexample@test.com	$2a$10$8.sutpWXHxFfyLWkkki/neTGtoQVr6R0l2GcZzUHy1tR/pLAdLarm	2025-10-02 03:49:37.226902+00	\N		\N		\N			\N	2025-10-03 03:56:06.462548+00	{"provider": "email", "providers": ["email"]}	{"sub": "02438205-29ee-44c1-94f2-10342a9fe7cf", "role": "provider", "email": "providerexample@test.com", "phone": "", "last_name": "example", "specialty": "weight loss", "first_name": "provider", "email_verified": true, "license_number": "1234567890", "phone_verified": false}	\N	2025-10-02 03:49:37.224439+00	2025-10-03 03:56:06.463315+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	83a1dde8-655a-4283-b7c6-62ddf063cd83	authenticated	authenticated	adminexample@test.com	$2a$10$z5Yc5bKelcIg6BtpHtRKnO8J4C0OtQky4ah7crANVx0w2Bux/6qgO	2025-10-02 03:48:55.251526+00	\N		\N		\N			\N	2025-10-03 03:57:27.716587+00	{"provider": "email", "providers": ["email"]}	{"sub": "83a1dde8-655a-4283-b7c6-62ddf063cd83", "role": "admin", "email": "adminexample@test.com", "last_name": "example", "first_name": "admin", "email_verified": true, "phone_verified": false}	\N	2025-10-02 03:48:55.24916+00	2025-10-03 03:57:27.717569+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- TOC entry 4721 (class 0 OID 18326)
-- Dependencies: 342
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admins (id, profile_id, permissions, active, created_at, updated_at) FROM stdin;
5f3748eb-25f6-4f54-9768-b24127686f60	83a1dde8-655a-4283-b7c6-62ddf063cd83	{dashboard,patients,providers,assignments}	t	2025-10-02 03:48:55.249004+00	2025-10-02 03:48:55.249004+00
\.


--
-- TOC entry 4732 (class 0 OID 18631)
-- Dependencies: 353
-- Data for Name: appointment_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appointment_history (id, appointment_id, action, performed_by, performed_by_user_id, old_values, new_values, reason, created_at) FROM stdin;
6250fc68-7d7a-49d7-941c-305f3236ffad	a78d8128-fe15-4d05-945d-5b719feb8794	created	system	\N	\N	{"id": "a78d8128-fe15-4d05-945d-5b719feb8794", "status": "scheduled", "end_time": "10:30:00", "booked_by": "patient", "created_at": "2025-10-02T21:23:39.480151+00:00", "patient_id": "82aebe01-9634-4b4e-8ca1-ac821ec69b24", "start_time": "10:00:00", "updated_at": "2025-10-02T21:23:39.480151+00:00", "admin_notes": null, "provider_id": "20f1623f-c067-486f-87b2-a9e3153f59ad", "cancelled_at": null, "cancelled_by": null, "assignment_id": "37608889-f91b-4df5-a756-30b773e08f2f", "patient_notes": "Initial consultation for Semaglutide Visit", "provider_notes": null, "treatment_type": "weight_loss", "appointment_date": "2025-10-06", "appointment_type": "consultation", "duration_minutes": 30, "reschedule_count": 0, "booked_by_user_id": "e2b62e92-840b-4db4-8e37-7f2208b1ac23", "booking_timestamp": "2025-10-02T21:23:39.480151+00:00", "rescheduled_to_id": null, "cancellation_reason": null, "rescheduled_from_id": null, "cancelled_by_user_id": null, "is_reschedule_source": false}	\N	2025-10-02 21:23:39.480151+00
\.


--
-- TOC entry 4731 (class 0 OID 18593)
-- Dependencies: 352
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appointments (id, patient_id, provider_id, assignment_id, appointment_date, start_time, end_time, duration_minutes, treatment_type, appointment_type, status, patient_notes, provider_notes, admin_notes, booked_by, booked_by_user_id, booking_timestamp, cancelled_at, cancelled_by, cancelled_by_user_id, cancellation_reason, created_at, updated_at, rescheduled_from_id, rescheduled_to_id, is_reschedule_source, reschedule_count) FROM stdin;
78c31e62-52d6-499c-aeb1-9da97371cc3e	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-10	09:00:00	09:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Semaglutide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 03:54:31.885599+00	\N	\N	\N	\N	2025-10-02 03:54:31.885599+00	2025-10-02 03:54:31.885599+00	\N	\N	f	0
4be64277-6420-42ff-8d8c-2b970b80af7b	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-09	09:00:00	09:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 04:00:49.22066+00	\N	\N	\N	\N	2025-10-02 04:00:49.22066+00	2025-10-02 04:00:49.22066+00	\N	\N	f	0
a804ae02-ce51-4adc-a62c-74ccfa7b2fd4	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-10	09:30:00	10:00:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 04:03:44.881567+00	\N	\N	\N	\N	2025-10-02 04:03:44.881567+00	2025-10-02 04:03:44.881567+00	\N	\N	f	0
68fe73f5-f97b-469c-8210-6c3caae6b2fb	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-10	10:00:00	10:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 04:05:24.365243+00	\N	\N	\N	\N	2025-10-02 04:05:24.365243+00	2025-10-02 04:05:24.365243+00	\N	\N	f	0
1babfda8-4761-4c4e-a3bf-1e6993b4bbc1	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-10	10:30:00	11:00:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 04:09:53.474067+00	\N	\N	\N	\N	2025-10-02 04:09:53.474067+00	2025-10-02 04:09:53.474067+00	\N	\N	f	0
e194f206-4a79-4c69-808c-4433bda93281	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-10	11:00:00	11:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Semaglutide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 04:41:03.919776+00	\N	\N	\N	\N	2025-10-02 04:41:03.919776+00	2025-10-02 04:41:03.919776+00	\N	\N	f	0
321a6cfd-dd8a-4c25-84e9-23e897488cbf	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-10	11:30:00	12:00:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 04:45:46.070697+00	\N	\N	\N	\N	2025-10-02 04:45:46.070697+00	2025-10-02 04:45:46.070697+00	\N	\N	f	0
60b27e03-ed6a-4f7d-8bcf-d9b41eb09998	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-09	09:30:00	10:00:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 04:48:00.629005+00	\N	\N	\N	\N	2025-10-02 04:48:00.629005+00	2025-10-02 04:48:00.629005+00	\N	\N	f	0
2274338f-f48c-4a9f-b19b-2a4fd8e0fe95	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-09	10:00:00	10:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 04:49:09.301749+00	\N	\N	\N	\N	2025-10-02 04:49:09.301749+00	2025-10-02 04:49:09.301749+00	\N	\N	f	0
ea88d15b-13fe-4ba1-850e-e19b603934b6	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-09	10:30:00	11:00:00	30	weight_loss	consultation	scheduled	Initial consultation for Semaglutide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 04:50:56.329944+00	\N	\N	\N	\N	2025-10-02 04:50:56.329944+00	2025-10-02 04:50:56.329944+00	\N	\N	f	0
6c576aca-794f-4fd2-bd5b-f0cacb7c9d86	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-10	12:00:00	12:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Semaglutide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 18:44:54.572169+00	\N	\N	\N	\N	2025-10-02 18:44:54.572169+00	2025-10-02 18:44:54.572169+00	\N	\N	f	0
c9378529-45e1-4ff2-abb3-c44905bdd180	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-06	09:00:00	09:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 19:40:35.49904+00	\N	\N	\N	\N	2025-10-02 19:40:35.49904+00	2025-10-02 19:40:35.49904+00	\N	\N	f	0
b2a47a84-ed4a-40c8-8a59-fd0ea431f850	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-08	09:00:00	09:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 19:47:16.422546+00	\N	\N	\N	\N	2025-10-02 19:47:16.422546+00	2025-10-02 19:47:16.422546+00	\N	\N	f	0
f479617c-0874-4726-8e29-b68ad9fb60a2	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-08	09:30:00	10:00:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 19:52:48.778191+00	\N	\N	\N	\N	2025-10-02 19:52:48.778191+00	2025-10-02 19:52:48.778191+00	\N	\N	f	0
953ddeb7-2c79-40fb-9e67-ae2bf9c7a978	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-08	10:00:00	10:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 19:55:12.058689+00	\N	\N	\N	\N	2025-10-02 19:55:12.058689+00	2025-10-02 19:55:12.058689+00	\N	\N	f	0
b80c7f1e-7ab1-452b-9e4f-8d47fb6ef6d3	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-09	11:00:00	11:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 19:58:54.43344+00	\N	\N	\N	\N	2025-10-02 19:58:54.43344+00	2025-10-02 19:58:54.43344+00	\N	\N	f	0
a85d5421-abf7-42c2-a441-daed36fbba61	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-06	09:30:00	10:00:00	30	weight_loss	consultation	scheduled	Initial consultation for Semaglutide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 20:25:39.339809+00	\N	\N	\N	\N	2025-10-02 20:25:39.339809+00	2025-10-02 20:25:39.339809+00	\N	\N	f	0
a78d8128-fe15-4d05-945d-5b719feb8794	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	37608889-f91b-4df5-a756-30b773e08f2f	2025-10-06	10:00:00	10:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Semaglutide Visit	\N	\N	patient	e2b62e92-840b-4db4-8e37-7f2208b1ac23	2025-10-02 21:23:39.480151+00	\N	\N	\N	\N	2025-10-02 21:23:39.480151+00	2025-10-02 21:23:39.480151+00	\N	\N	f	0
\.


--
-- TOC entry 4724 (class 0 OID 18415)
-- Dependencies: 345
-- Data for Name: assignment_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assignment_log (id, message, created_at) FROM stdin;
1	Starting provider assignment process	2025-10-02 03:43:24.556249
2	Provider assignment process completed	2025-10-02 03:43:24.556249
\.


--
-- TOC entry 4739 (class 0 OID 18950)
-- Dependencies: 362
-- Data for Name: auth_trigger_debug_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_trigger_debug_log (id, user_id, step, status, error_message, metadata, created_at) FROM stdin;
\.


--
-- TOC entry 4736 (class 0 OID 18845)
-- Dependencies: 359
-- Data for Name: auth_trigger_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_trigger_logs (id, user_id, trigger_stage, success, error_message, metadata, created_at) FROM stdin;
fdee3db3-7de4-43a0-bb81-a95c41031153	\N	APPROVAL_RESET	t	Reset 0 expired preferences to pending status	{"reset_date": "2025-10-02", "reset_count": 0}	2025-10-02 04:00:16.38784+00
985b8902-cfda-458f-a517-78e82f7d5147	\N	APPROVAL_RESET	t	Reset 0 expired preferences to pending status	{"reset_date": "2025-10-02", "reset_count": 0}	2025-10-02 04:03:10.685948+00
f8681454-8592-413a-b225-718ccd02912f	\N	APPROVAL_RESET_SKIPPED	t	Skipped approval reset - already ran today	{"current_date": "2025-10-02", "last_run_date": "2025-10-02"}	2025-10-02 04:44:25.17574+00
875e42e1-8f77-4154-b8b7-4e4d9369fccf	\N	APPROVAL_RESET_SKIPPED	t	Skipped approval reset - already ran today	{"current_date": "2025-10-02", "last_run_date": "2025-10-02"}	2025-10-02 19:46:47.216449+00
d552fc99-1f0b-4fe7-ab6d-0c0e9b502dca	\N	APPROVAL_RESET	t	Reset 0 expired preferences to pending status	{"reset_date": "2025-10-02", "reset_count": 0}	2025-10-02 20:23:48.154274+00
\.


--
-- TOC entry 4733 (class 0 OID 18708)
-- Dependencies: 356
-- Data for Name: clinical_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clinical_notes (id, appointment_id, patient_id, provider_id, allergies, previous_medications, current_medications, clinical_note, internal_note, visit_summary, created_at, updated_at, created_by, last_updated_by) FROM stdin;
75b307f4-bc33-411d-bb5e-198866a1009a	6c576aca-794f-4fd2-bd5b-f0cacb7c9d86	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	{}	{}	{}			Patient and I discussed their weight loss goals and Tirzepatide 2.8mg was prescribed for as needed. The patient should plan on a follow up visit in 30 days to continue their treatment.	2025-10-02 19:40:06.255+00	2025-10-02 19:40:06.255+00	\N	\N
973f1545-aa0f-4095-bdce-8394b4e94b40	a78d8128-fe15-4d05-945d-5b719feb8794	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	{}	{}	{}				2025-10-03 03:56:56.143+00	2025-10-03 03:56:56.143+00	\N	\N
\.


--
-- TOC entry 4740 (class 0 OID 19007)
-- Dependencies: 363
-- Data for Name: faxes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.faxes (id, approval_id, preference_id, patient_id, provider_id, fax_number, fax_content, fax_status, faxed_at, delivery_confirmation_at, notes, created_at, updated_at, provider_profile_id, patient_profile_id) FROM stdin;
2d2fc0d3-396e-4597-8f61-5adedffd70d2	02dda2f2-32bd-4dba-bf3c-cd046f50f7ce	0aa0ec28-298a-4651-9dd4-65327aade765	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	1-800-PHARMACY	Prescription for Tirzepatide 2.8mg	sent	2025-10-02 19:40:06.332+00	\N	\N	2025-10-02 19:40:06.334092+00	2025-10-02 19:40:06.334092+00	02438205-29ee-44c1-94f2-10342a9fe7cf	e2b62e92-840b-4db4-8e37-7f2208b1ac23
be9a9eee-18fb-498e-8a57-4a7da340b0b2	87042327-6fde-44fd-a67c-357e9d9b92a2	1a52fc52-5390-453b-ba60-0c51ff11fca9	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	1-800-PHARMACY	Prescription for Tirzepatide 2.8mg	sent	2025-10-03 03:56:56.223+00	\N	\N	2025-10-03 03:56:56.223536+00	2025-10-03 03:56:56.223536+00	02438205-29ee-44c1-94f2-10342a9fe7cf	e2b62e92-840b-4db4-8e37-7f2208b1ac23
bd031d5b-e4e8-446c-ab3a-76e94cb1c82a	0e24f24f-b117-403b-b423-a0c6f278eda1	fd299047-ccd1-4a3c-b7fb-7485bd8b40f0	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	1-800-PHARMACY	Prescription for Tirzepatide 2.8mg	sent	2025-10-03 03:56:56.285+00	\N	\N	2025-10-03 03:56:56.285253+00	2025-10-03 03:56:56.285253+00	02438205-29ee-44c1-94f2-10342a9fe7cf	e2b62e92-840b-4db4-8e37-7f2208b1ac23
55c47ae5-8a01-4857-bd5c-77c00cf286d0	02dda2f2-32bd-4dba-bf3c-cd046f50f7ce	0aa0ec28-298a-4651-9dd4-65327aade765	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	1-800-PHARMACY	Prescription for Tirzepatide 2.8mg	sent	2025-10-03 03:56:56.337+00	\N	\N	2025-10-03 03:56:56.337072+00	2025-10-03 03:56:56.337072+00	02438205-29ee-44c1-94f2-10342a9fe7cf	e2b62e92-840b-4db4-8e37-7f2208b1ac23
\.


--
-- TOC entry 4727 (class 0 OID 18461)
-- Dependencies: 348
-- Data for Name: medication_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medication_approvals (id, preference_id, provider_id, status, approved_dosage, approved_frequency, provider_notes, contraindications, approval_date, created_at, updated_at, provider_profile_id, supply_days) FROM stdin;
02dda2f2-32bd-4dba-bf3c-cd046f50f7ce	0aa0ec28-298a-4651-9dd4-65327aade765	20f1623f-c067-486f-87b2-a9e3153f59ad	approved	\N	\N	Approved and faxed during clinical visit	\N	2025-10-02 19:40:06.318+00	2025-10-02 19:40:06.319933+00	2025-10-02 19:40:06.319933+00	02438205-29ee-44c1-94f2-10342a9fe7cf	10
87042327-6fde-44fd-a67c-357e9d9b92a2	1a52fc52-5390-453b-ba60-0c51ff11fca9	20f1623f-c067-486f-87b2-a9e3153f59ad	approved	\N	\N	Refill requested on 2025-10-02	\N	2025-10-03 03:56:56.209+00	2025-10-03 03:56:56.209583+00	2025-10-03 03:56:56.209583+00	02438205-29ee-44c1-94f2-10342a9fe7cf	10
0e24f24f-b117-403b-b423-a0c6f278eda1	fd299047-ccd1-4a3c-b7fb-7485bd8b40f0	20f1623f-c067-486f-87b2-a9e3153f59ad	approved	\N	\N	Refill requested on 2025-10-02	\N	2025-10-03 03:56:56.274+00	2025-10-03 03:56:56.27433+00	2025-10-03 03:56:56.27433+00	02438205-29ee-44c1-94f2-10342a9fe7cf	10
\.


--
-- TOC entry 4737 (class 0 OID 18873)
-- Dependencies: 360
-- Data for Name: medication_dosages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medication_dosages (id, medication_id, strength, unit_price, available, sort_order, created_at, updated_at) FROM stdin;
7564d035-7ceb-4504-aa14-a1315240ab23	213a3ca1-4b4a-4ef5-9332-1a39d3817dae	3.0mg	1099.99	t	1	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
72f9a5cd-a3ff-4609-875c-a0f485137728	37820256-ac89-48f9-9f63-258c28c1f89d	1.62%	299.99	t	1	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
5d642615-0399-461d-b449-7fc5d803b338	427c2f0b-f65a-4534-a807-f0c25d24fe11	37.5mg	89.99	t	1	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
7b81bb69-557b-41a1-99dc-467c7805a736	49f60cf1-37cb-46a9-8fa9-efebba8a00a2	50mg	89.99	t	1	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
324b0f06-c72b-4f2e-87b0-058755e99640	4df3ad68-30f3-4af3-ac90-6b7aacee6d30	250mg/ml	219.99	t	1	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
cbd74c62-7ad0-4d44-9f34-81607837edf4	5713e010-6a56-4d16-9454-fc396a630c0b	0.5mg	899.99	t	1	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
670ad4bd-fe06-401f-9c92-daac775cca82	5c1b38e4-405f-4ce1-99fa-6e71c45f95bc	2.5mg	1199.99	t	1	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
ebf02e1f-1a8d-40e9-99b8-54aa1e0aed0f	991e47aa-9dd3-4d3a-8291-47f6ce39ba18	5000 IU	149.99	t	1	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
8098260a-408e-4167-b184-bbf31f169500	9e2ad559-8f87-48d1-91c4-535d908a0bfb	1.0mg	1299.99	t	1	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
08e49198-c617-4123-adbd-1b62f58d869b	a7ba7cb8-d5b5-4890-abb8-4620d0d23356	120mg	199.99	t	1	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
350dc3f8-3f0b-4a1c-a78f-c08b58d6d895	acd6fefd-3d48-43d7-b1e8-e6bcd653aca6	1mg	79.99	t	1	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
434e8255-9840-44a1-95c9-9e2e823e08c7	b62cf870-7009-4be7-b896-bf7efab0744f	200mg/ml	199.99	t	1	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
188c5d06-60b9-482c-8062-0a8c7b5c45ea	c5ad6fef-becb-45fb-a466-3df6b24c845a	20mg	99.99	t	1	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
44f2d18b-c882-40bc-ab7d-a1e7afbadee1	5c1b38e4-405f-4ce1-99fa-6e71c45f95bc	5.0mg	1399.99	t	10	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
9939a2db-7bce-4842-bf2c-d44326e91416	5c1b38e4-405f-4ce1-99fa-6e71c45f95bc	7.5mg	1599.99	t	20	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
541aa129-92eb-496c-abe6-1e02d73a2d4b	5c1b38e4-405f-4ce1-99fa-6e71c45f95bc	10mg	1799.99	t	30	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
bac86964-2143-4ca8-9772-73c2ab11060e	5c1b38e4-405f-4ce1-99fa-6e71c45f95bc	12.5mg	1999.99	t	40	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
c0af327b-9f53-4f55-a6d9-8b814a5318b0	5c1b38e4-405f-4ce1-99fa-6e71c45f95bc	15mg	2199.99	t	50	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
77f2c6f1-3123-4813-bb22-bef880af17a0	5713e010-6a56-4d16-9454-fc396a630c0b	0.25mg	799.99	t	1	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
aa1a4f5e-03d1-4607-af40-55dace8d3366	5713e010-6a56-4d16-9454-fc396a630c0b	1.0mg	999.99	t	11	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
2746fc79-53b2-4b18-9c79-42b84c3756dc	5713e010-6a56-4d16-9454-fc396a630c0b	2.0mg	1199.99	t	21	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
d503dddb-19f2-4e04-8f97-0998314c9036	b62cf870-7009-4be7-b896-bf7efab0744f	100mg/ml	159.99	t	5	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
85872f21-cdb6-49e9-a7f3-241165ceaaf7	b62cf870-7009-4be7-b896-bf7efab0744f	250mg/ml	239.99	t	15	2025-10-02 04:39:27.890212+00	2025-10-02 04:39:27.890212+00
\.


--
-- TOC entry 4728 (class 0 OID 18482)
-- Dependencies: 349
-- Data for Name: medication_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medication_orders (id, approval_id, patient_id, medication_id, quantity, unit_price, total_amount, payment_status, payment_method, payment_date, fulfillment_status, tracking_number, shipped_date, estimated_delivery, admin_notes, created_at, updated_at, sent_to_pharmacy, provider_profile_id, patient_profile_id) FROM stdin;
8707d668-2ede-4a83-a633-478f3df0cdb6	02dda2f2-32bd-4dba-bf3c-cd046f50f7ce	82aebe01-9634-4b4e-8ca1-ac821ec69b24	5c1b38e4-405f-4ce1-99fa-6e71c45f95bc	1	1199.99	1199.99	paid	payment	2025-09-30 00:00:00+00	delivered	j4325jn4325j	2025-09-30 00:00:00+00	2025-10-10 00:00:00+00		2025-10-02 19:40:06.334092+00	2025-10-02 19:40:06.334092+00	\N	02438205-29ee-44c1-94f2-10342a9fe7cf	e2b62e92-840b-4db4-8e37-7f2208b1ac23
36c0242d-5015-46dc-a083-56cf5db742d8	87042327-6fde-44fd-a67c-357e9d9b92a2	82aebe01-9634-4b4e-8ca1-ac821ec69b24	9e2ad559-8f87-48d1-91c4-535d908a0bfb	1	1299.99	1299.99	pending	\N	\N	pending	\N	\N	\N	\N	2025-10-03 03:56:56.223536+00	2025-10-03 03:56:56.223536+00	\N	02438205-29ee-44c1-94f2-10342a9fe7cf	e2b62e92-840b-4db4-8e37-7f2208b1ac23
06a0ee66-280c-483c-8b85-48aca0b3f16c	0e24f24f-b117-403b-b423-a0c6f278eda1	82aebe01-9634-4b4e-8ca1-ac821ec69b24	5713e010-6a56-4d16-9454-fc396a630c0b	1	899.99	899.99	pending	\N	\N	pending	\N	\N	\N	\N	2025-10-03 03:56:56.285253+00	2025-10-03 03:56:56.285253+00	\N	02438205-29ee-44c1-94f2-10342a9fe7cf	e2b62e92-840b-4db4-8e37-7f2208b1ac23
150339a1-814b-402c-9288-dc84a7e8146b	02dda2f2-32bd-4dba-bf3c-cd046f50f7ce	82aebe01-9634-4b4e-8ca1-ac821ec69b24	5c1b38e4-405f-4ce1-99fa-6e71c45f95bc	1	1199.99	1199.99	pending	\N	\N	pending	\N	\N	\N	\N	2025-10-03 03:56:56.337072+00	2025-10-03 03:56:56.337072+00	\N	02438205-29ee-44c1-94f2-10342a9fe7cf	e2b62e92-840b-4db4-8e37-7f2208b1ac23
\.


--
-- TOC entry 4725 (class 0 OID 18424)
-- Dependencies: 346
-- Data for Name: medications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medications (id, name, generic_name, brand_name, dosage_form, strength, description, category, unit_price, requires_prescription, active, created_at, updated_at) FROM stdin;
5713e010-6a56-4d16-9454-fc396a630c0b	Semaglutide	Semaglutide	Ozempic	injection	0.5mg	GLP-1 receptor agonist for weight management and diabetes	weight_loss	899.99	t	t	2025-10-02 04:33:34.473315+00	2025-10-02 04:33:34.473315+00
9e2ad559-8f87-48d1-91c4-535d908a0bfb	Semaglutide	Semaglutide	Wegovy	injection	1.0mg	GLP-1 receptor agonist specifically for chronic weight management	weight_loss	1299.99	t	t	2025-10-02 04:33:34.473315+00	2025-10-02 04:33:34.473315+00
5c1b38e4-405f-4ce1-99fa-6e71c45f95bc	Tirzepatide	Tirzepatide	Mounjaro	injection	2.5mg	Dual GIP/GLP-1 receptor agonist for weight loss	weight_loss	1199.99	t	t	2025-10-02 04:33:34.473315+00	2025-10-02 04:33:34.473315+00
213a3ca1-4b4a-4ef5-9332-1a39d3817dae	Liraglutide	Liraglutide	Saxenda	injection	3.0mg	GLP-1 receptor agonist for weight management	weight_loss	1099.99	t	t	2025-10-02 04:33:34.473315+00	2025-10-02 04:33:34.473315+00
a7ba7cb8-d5b5-4890-abb8-4620d0d23356	Orlistat	Orlistat	Xenical	capsule	120mg	Lipase inhibitor for weight loss	weight_loss	199.99	t	t	2025-10-02 04:33:34.473315+00	2025-10-02 04:33:34.473315+00
427c2f0b-f65a-4534-a807-f0c25d24fe11	Phentermine	Phentermine	Adipex-P	tablet	37.5mg	Appetite suppressant for short-term weight loss	weight_loss	89.99	t	t	2025-10-02 04:33:34.473315+00	2025-10-02 04:33:34.473315+00
b62cf870-7009-4be7-b896-bf7efab0744f	Testosterone Cypionate	Testosterone Cypionate	Depo-Testosterone	injection	200mg/ml	Testosterone replacement therapy for hypogonadism	mens_health	199.99	t	t	2025-10-02 04:33:34.473315+00	2025-10-02 04:33:34.473315+00
4df3ad68-30f3-4af3-ac90-6b7aacee6d30	Testosterone Enanthate	Testosterone Enanthate	Delatestryl	injection	250mg/ml	Long-acting testosterone for hormone replacement	mens_health	219.99	t	t	2025-10-02 04:33:34.473315+00	2025-10-02 04:33:34.473315+00
37820256-ac89-48f9-9f63-258c28c1f89d	Testosterone Gel	Testosterone	AndroGel	gel	1.62%	Topical testosterone replacement therapy	mens_health	299.99	t	t	2025-10-02 04:33:34.473315+00	2025-10-02 04:33:34.473315+00
49f60cf1-37cb-46a9-8fa9-efebba8a00a2	Sildenafil	Sildenafil	Viagra	tablet	50mg	PDE5 inhibitor for erectile dysfunction	mens_health	89.99	t	t	2025-10-02 04:33:34.473315+00	2025-10-02 04:33:34.473315+00
c5ad6fef-becb-45fb-a466-3df6b24c845a	Tadalafil	Tadalafil	Cialis	tablet	20mg	Long-acting PDE5 inhibitor for erectile dysfunction	mens_health	99.99	t	t	2025-10-02 04:33:34.473315+00	2025-10-02 04:33:34.473315+00
acd6fefd-3d48-43d7-b1e8-e6bcd653aca6	Finasteride	Finasteride	Propecia	tablet	1mg	5-alpha reductase inhibitor for male pattern baldness	mens_health	79.99	t	t	2025-10-02 04:33:34.473315+00	2025-10-02 04:33:34.473315+00
991e47aa-9dd3-4d3a-8291-47f6ce39ba18	HCG	Human Chorionic Gonadotropin	Pregnyl	injection	5000 IU	Hormone therapy to support testosterone production	mens_health	149.99	t	t	2025-10-02 04:33:34.473315+00	2025-10-02 04:33:34.473315+00
\.


--
-- TOC entry 4722 (class 0 OID 18345)
-- Dependencies: 343
-- Data for Name: patient_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patient_assignments (id, patient_id, provider_id, treatment_type, is_primary, assigned_date, active, created_at, updated_at) FROM stdin;
37608889-f91b-4df5-a756-30b773e08f2f	82aebe01-9634-4b4e-8ca1-ac821ec69b24	20f1623f-c067-486f-87b2-a9e3153f59ad	weight_loss	t	2025-10-02 03:53:48.379+00	t	2025-10-02 03:53:48.385118+00	2025-10-02 03:53:48.385118+00
\.


--
-- TOC entry 4726 (class 0 OID 18437)
-- Dependencies: 347
-- Data for Name: patient_medication_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patient_medication_preferences (id, patient_id, medication_id, preferred_dosage, frequency, notes, status, requested_date, created_at, updated_at, medication_dosage_id, faxed, next_prescription_due, supply_days, refill_requested) FROM stdin;
0aa0ec28-298a-4651-9dd4-65327aade765	82aebe01-9634-4b4e-8ca1-ac821ec69b24	5c1b38e4-405f-4ce1-99fa-6e71c45f95bc	2.8mg	\N	Refill requested on 2025-10-02	approved	2025-10-02 18:44:41.844357+00	2025-10-02 18:44:41.844357+00	2025-10-03 03:56:56.345+00	\N	2025-10-03 03:56:56.345+00	2025-10-13	10	f
ff0e724e-70c7-4fe7-bcd2-9b5c7b7e1476	5dc7941e-5a22-467f-96ea-c3d24ece61e4	5713e010-6a56-4d16-9454-fc396a630c0b	1mg	Weekly	Test preference for Semaglutide	pending	2025-10-02 21:05:25.488083+00	2025-10-02 21:05:25.488+00	2025-10-02 21:05:25.488+00	\N	\N	\N	\N	t
1833ac3d-f339-49f6-bdfe-9d2f53bff905	5dc7941e-5a22-467f-96ea-c3d24ece61e4	9e2ad559-8f87-48d1-91c4-535d908a0bfb	2.5mg	Weekly	Test preference for Semaglutide	pending	2025-10-02 21:05:25.488083+00	2025-10-02 21:05:25.488+00	2025-10-02 21:05:25.488+00	\N	\N	\N	\N	t
ed8aebb1-3bb9-4876-8958-6d4f158977fb	5dc7941e-5a22-467f-96ea-c3d24ece61e4	5c1b38e4-405f-4ce1-99fa-6e71c45f95bc	5mg	Weekly	Test preference for Tirzepatide	pending	2025-10-02 21:05:25.488083+00	2025-10-02 21:05:25.488+00	2025-10-02 21:05:25.488+00	\N	\N	\N	\N	f
1a52fc52-5390-453b-ba60-0c51ff11fca9	82aebe01-9634-4b4e-8ca1-ac821ec69b24	9e2ad559-8f87-48d1-91c4-535d908a0bfb	1.0mg	\N	\N	approved	2025-10-02 20:25:32.888128+00	2025-10-02 20:25:32.888128+00	2025-10-03 03:56:56.236+00	\N	2025-10-03 03:56:56.236+00	\N	\N	f
fd299047-ccd1-4a3c-b7fb-7485bd8b40f0	82aebe01-9634-4b4e-8ca1-ac821ec69b24	5713e010-6a56-4d16-9454-fc396a630c0b	0.5mg	\N	\N	approved	2025-10-02 20:23:17.455038+00	2025-10-02 20:23:17.455038+00	2025-10-03 03:56:56.295+00	\N	2025-10-03 03:56:56.295+00	\N	\N	f
\.


--
-- TOC entry 4719 (class 0 OID 18290)
-- Dependencies: 340
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patients (id, profile_id, date_of_birth, phone, has_completed_intake, created_at, updated_at) FROM stdin;
f99b1571-4f0e-4e63-9b14-3a150588d7eb	aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa	\N	\N	f	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00
9a6ab216-b302-4a38-a324-51521b5e4db0	bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb	\N	\N	f	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00
7ebfc75d-8b88-4d41-b20d-eceb18cdfd5f	cccccccc-cccc-cccc-cccc-cccccccccccc	\N	\N	f	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00
5dc7941e-5a22-467f-96ea-c3d24ece61e4	11111111-1111-1111-1111-111111111111	\N	555-0101	t	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00
2ec8beef-4ae3-4aeb-83b4-b08fb8b94039	22222222-2222-2222-2222-222222222222	\N	555-0102	t	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00
908c2d51-9315-4729-97f6-f7250df504ce	33333333-3333-3333-3333-333333333333	\N	555-0103	t	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00
6b182d8b-0d65-412f-9809-2253d5a0c6dc	44444444-4444-4444-4444-444444444444	\N	555-0104	t	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00
82aebe01-9634-4b4e-8ca1-ac821ec69b24	e2b62e92-840b-4db4-8e37-7f2208b1ac23	\N	\N	f	2025-10-02 03:48:31.048075+00	2025-10-02 03:48:31.048075+00
\.


--
-- TOC entry 4718 (class 0 OID 18273)
-- Dependencies: 339
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (id, email, first_name, last_name, role, created_at, updated_at) FROM stdin;
11111111-1111-1111-1111-111111111111	sarah.j@test.com	Sarah	Johnson	patient	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00
22222222-2222-2222-2222-222222222222	michael.r@test.com	Michael	Roberts	patient	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00
33333333-3333-3333-3333-333333333333	jennifer.m@test.com	Jennifer	Martinez	patient	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00
44444444-4444-4444-4444-444444444444	david.a@test.com	David	Anderson	patient	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00
aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa	admin@test.com	Admin	User	admin	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00
bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb	dr.watson@test.com	Dr. Emily	Watson	provider	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00
cccccccc-cccc-cccc-cccc-cccccccccccc	dr.wilson@test.com	Dr. James	Wilson	provider	2025-10-02 03:43:24.568988+00	2025-10-02 03:43:24.568988+00
e2b62e92-840b-4db4-8e37-7f2208b1ac23	patientexample@test.com	patient	example	patient	2025-10-02 03:48:31.048075+00	2025-10-02 03:48:31.048075+00
83a1dde8-655a-4283-b7c6-62ddf063cd83	adminexample@test.com	admin	example	admin	2025-10-02 03:48:55.249004+00	2025-10-02 03:48:55.249004+00
02438205-29ee-44c1-94f2-10342a9fe7cf	providerexample@test.com	provider	example	provider	2025-10-02 03:49:37.22427+00	2025-10-02 03:49:37.22427+00
\.


--
-- TOC entry 4730 (class 0 OID 18576)
-- Dependencies: 351
-- Data for Name: provider_availability_overrides; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.provider_availability_overrides (id, provider_id, date, start_time, end_time, available, reason, created_at) FROM stdin;
\.


--
-- TOC entry 4729 (class 0 OID 18553)
-- Dependencies: 350
-- Data for Name: provider_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.provider_schedules (id, provider_id, day_of_week, start_time, end_time, slot_duration_minutes, treatment_types, active, created_at, updated_at) FROM stdin;
e8412cd5-0cda-478f-b76c-d9b7ce0d4294	20f1623f-c067-486f-87b2-a9e3153f59ad	1	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-10-02 03:49:37.22427+00	2025-10-02 03:49:37.22427+00
2e4763df-2b76-4c60-86b6-f08329b9d4ea	20f1623f-c067-486f-87b2-a9e3153f59ad	2	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-10-02 03:49:37.22427+00	2025-10-02 03:49:37.22427+00
a39e6ce4-7836-4a25-b236-77b77a1d4871	20f1623f-c067-486f-87b2-a9e3153f59ad	3	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-10-02 03:49:37.22427+00	2025-10-02 03:49:37.22427+00
3e7f8766-4e25-433f-9fac-0367249bdd3c	20f1623f-c067-486f-87b2-a9e3153f59ad	4	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-10-02 03:49:37.22427+00	2025-10-02 03:49:37.22427+00
ef0c903c-5d1d-49e3-94f3-f80da6cd8808	20f1623f-c067-486f-87b2-a9e3153f59ad	5	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-10-02 03:49:37.22427+00	2025-10-02 03:49:37.22427+00
\.


--
-- TOC entry 4720 (class 0 OID 18308)
-- Dependencies: 341
-- Data for Name: providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.providers (id, profile_id, specialty, license_number, phone, active, created_at, updated_at) FROM stdin;
20f1623f-c067-486f-87b2-a9e3153f59ad	02438205-29ee-44c1-94f2-10342a9fe7cf	weight loss	1234567890		t	2025-10-02 03:49:37.22427+00	2025-10-02 03:49:37.22427+00
\.


--
-- TOC entry 4738 (class 0 OID 18903)
-- Dependencies: 361
-- Data for Name: visit_addendums; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visit_addendums (id, visit_id, provider_id, content, created_at) FROM stdin;
\.


--
-- TOC entry 4735 (class 0 OID 18766)
-- Dependencies: 358
-- Data for Name: visit_interactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visit_interactions (id, clinical_note_id, appointment_id, interaction_type, details, provider_notes, created_at, performed_by, medication_id, medication_name, previous_dosage, new_dosage, previous_frequency, new_frequency, previous_status, new_status) FROM stdin;
\.


--
-- TOC entry 4734 (class 0 OID 18741)
-- Dependencies: 357
-- Data for Name: visit_medication_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visit_medication_adjustments (id, clinical_note_id, appointment_id, preference_id, previous_dosage, previous_frequency, previous_status, previous_provider_notes, new_dosage, new_frequency, new_status, new_provider_notes, adjustment_reason, provider_notes, created_at, performed_by, new_supply_days) FROM stdin;
\.


--
-- TOC entry 4695 (class 0 OID 17024)
-- Dependencies: 315
-- Data for Name: messages_2025_10_01; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_10_01 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4696 (class 0 OID 17036)
-- Dependencies: 316
-- Data for Name: messages_2025_10_02; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_10_02 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4697 (class 0 OID 17048)
-- Dependencies: 317
-- Data for Name: messages_2025_10_03; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_10_03 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4698 (class 0 OID 17060)
-- Dependencies: 318
-- Data for Name: messages_2025_10_04; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_10_04 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4699 (class 0 OID 17072)
-- Dependencies: 319
-- Data for Name: messages_2025_10_05; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_10_05 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4692 (class 0 OID 16844)
-- Dependencies: 308
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2025-10-02 03:43:17
20211116045059	2025-10-02 03:43:17
20211116050929	2025-10-02 03:43:17
20211116051442	2025-10-02 03:43:17
20211116212300	2025-10-02 03:43:17
20211116213355	2025-10-02 03:43:17
20211116213934	2025-10-02 03:43:17
20211116214523	2025-10-02 03:43:17
20211122062447	2025-10-02 03:43:17
20211124070109	2025-10-02 03:43:17
20211202204204	2025-10-02 03:43:17
20211202204605	2025-10-02 03:43:17
20211210212804	2025-10-02 03:43:17
20211228014915	2025-10-02 03:43:17
20220107221237	2025-10-02 03:43:17
20220228202821	2025-10-02 03:43:17
20220312004840	2025-10-02 03:43:17
20220603231003	2025-10-02 03:43:17
20220603232444	2025-10-02 03:43:17
20220615214548	2025-10-02 03:43:17
20220712093339	2025-10-02 03:43:17
20220908172859	2025-10-02 03:43:17
20220916233421	2025-10-02 03:43:17
20230119133233	2025-10-02 03:43:17
20230128025114	2025-10-02 03:43:17
20230128025212	2025-10-02 03:43:17
20230227211149	2025-10-02 03:43:17
20230228184745	2025-10-02 03:43:17
20230308225145	2025-10-02 03:43:17
20230328144023	2025-10-02 03:43:17
20231018144023	2025-10-02 03:43:17
20231204144023	2025-10-02 03:43:17
20231204144024	2025-10-02 03:43:17
20231204144025	2025-10-02 03:43:17
20240108234812	2025-10-02 03:43:17
20240109165339	2025-10-02 03:43:17
20240227174441	2025-10-02 03:43:17
20240311171622	2025-10-02 03:43:17
20240321100241	2025-10-02 03:43:17
20240401105812	2025-10-02 03:43:17
20240418121054	2025-10-02 03:43:17
20240523004032	2025-10-02 03:43:17
20240618124746	2025-10-02 03:43:17
20240801235015	2025-10-02 03:43:17
20240805133720	2025-10-02 03:43:17
20240827160934	2025-10-02 03:43:17
20240919163303	2025-10-02 03:43:17
20240919163305	2025-10-02 03:43:17
20241019105805	2025-10-02 03:43:17
20241030150047	2025-10-02 03:43:17
20241108114728	2025-10-02 03:43:17
20241121104152	2025-10-02 03:43:17
20241130184212	2025-10-02 03:43:17
20241220035512	2025-10-02 03:43:17
20241220123912	2025-10-02 03:43:17
20241224161212	2025-10-02 03:43:17
20250107150512	2025-10-02 03:43:17
20250110162412	2025-10-02 03:43:17
20250123174212	2025-10-02 03:43:17
20250128220012	2025-10-02 03:43:17
20250506224012	2025-10-02 03:43:17
20250523164012	2025-10-02 03:43:17
20250714121412	2025-10-02 03:43:17
20250905041441	2025-10-02 03:43:17
\.


--
-- TOC entry 4694 (class 0 OID 16867)
-- Dependencies: 311
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at) FROM stdin;
\.


--
-- TOC entry 4686 (class 0 OID 16509)
-- Dependencies: 289
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
\.


--
-- TOC entry 4703 (class 0 OID 17892)
-- Dependencies: 323
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_analytics (id, type, format, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4704 (class 0 OID 17903)
-- Dependencies: 324
-- Data for Name: iceberg_namespaces; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.iceberg_namespaces (id, bucket_id, name, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4705 (class 0 OID 17919)
-- Dependencies: 325
-- Data for Name: iceberg_tables; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.iceberg_tables (id, namespace_id, bucket_id, name, location, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4688 (class 0 OID 16551)
-- Dependencies: 291
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2025-10-02 03:43:24.054781
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2025-10-02 03:43:24.056202
2	storage-schema	5c7968fd083fcea04050c1b7f6253c9771b99011	2025-10-02 03:43:24.056877
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2025-10-02 03:43:24.059548
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2025-10-02 03:43:24.061746
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2025-10-02 03:43:24.062365
6	change-column-name-in-get-size	f93f62afdf6613ee5e7e815b30d02dc990201044	2025-10-02 03:43:24.063386
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2025-10-02 03:43:24.064458
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2025-10-02 03:43:24.065052
9	fix-search-function	3a0af29f42e35a4d101c259ed955b67e1bee6825	2025-10-02 03:43:24.065604
10	search-files-search-function	68dc14822daad0ffac3746a502234f486182ef6e	2025-10-02 03:43:24.066534
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2025-10-02 03:43:24.067378
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2025-10-02 03:43:24.068438
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2025-10-02 03:43:24.068933
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2025-10-02 03:43:24.069491
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2025-10-02 03:43:24.073604
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2025-10-02 03:43:24.07427
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2025-10-02 03:43:24.074876
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2025-10-02 03:43:24.075643
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2025-10-02 03:43:24.076399
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2025-10-02 03:43:24.07716
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2025-10-02 03:43:24.078115
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2025-10-02 03:43:24.080581
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2025-10-02 03:43:24.082331
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2025-10-02 03:43:24.083055
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2025-10-02 03:43:24.083782
26	objects-prefixes	ef3f7871121cdc47a65308e6702519e853422ae2	2025-10-02 03:43:24.084316
27	search-v2	33b8f2a7ae53105f028e13e9fcda9dc4f356b4a2	2025-10-02 03:43:24.087091
28	object-bucket-name-sorting	ba85ec41b62c6a30a3f136788227ee47f311c436	2025-10-02 03:43:24.101862
29	create-prefixes	a7b1a22c0dc3ab630e3055bfec7ce7d2045c5b7b	2025-10-02 03:43:24.102758
30	update-object-levels	6c6f6cc9430d570f26284a24cf7b210599032db7	2025-10-02 03:43:24.10336
31	objects-level-index	33f1fef7ec7fea08bb892222f4f0f5d79bab5eb8	2025-10-02 03:43:24.104215
32	backward-compatible-index-on-objects	2d51eeb437a96868b36fcdfb1ddefdf13bef1647	2025-10-02 03:43:24.105004
33	backward-compatible-index-on-prefixes	fe473390e1b8c407434c0e470655945b110507bf	2025-10-02 03:43:24.105661
34	optimize-search-function-v1	82b0e469a00e8ebce495e29bfa70a0797f7ebd2c	2025-10-02 03:43:24.105835
35	add-insert-trigger-prefixes	63bb9fd05deb3dc5e9fa66c83e82b152f0caf589	2025-10-02 03:43:24.10688
36	optimise-existing-functions	81cf92eb0c36612865a18016a38496c530443899	2025-10-02 03:43:24.107386
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2025-10-02 03:43:24.108972
38	iceberg-catalog-flag-on-buckets	19a8bd89d5dfa69af7f222a46c726b7c41e462c5	2025-10-02 03:43:24.109628
\.


--
-- TOC entry 4687 (class 0 OID 16524)
-- Dependencies: 290
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata, level) FROM stdin;
\.


--
-- TOC entry 4702 (class 0 OID 17848)
-- Dependencies: 322
-- Data for Name: prefixes; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.prefixes (bucket_id, name, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4700 (class 0 OID 17795)
-- Dependencies: 320
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata) FROM stdin;
\.


--
-- TOC entry 4701 (class 0 OID 17809)
-- Dependencies: 321
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- TOC entry 4691 (class 0 OID 16763)
-- Dependencies: 304
-- Data for Name: hooks; Type: TABLE DATA; Schema: supabase_functions; Owner: -
--

COPY supabase_functions.hooks (id, hook_table_id, hook_name, created_at, request_id) FROM stdin;
\.


--
-- TOC entry 4689 (class 0 OID 16754)
-- Dependencies: 302
-- Data for Name: migrations; Type: TABLE DATA; Schema: supabase_functions; Owner: -
--

COPY supabase_functions.migrations (version, inserted_at) FROM stdin;
initial	2025-10-02 03:43:12.439898+00
20210809183423_update_grants	2025-10-02 03:43:12.439898+00
\.


--
-- TOC entry 4858 (class 0 OID 0)
-- Dependencies: 284
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 63, true);


--
-- TOC entry 4859 (class 0 OID 0)
-- Dependencies: 344
-- Name: assignment_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assignment_log_id_seq', 2, true);


--
-- TOC entry 4860 (class 0 OID 0)
-- Dependencies: 310
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: -
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- TOC entry 4861 (class 0 OID 0)
-- Dependencies: 303
-- Name: hooks_id_seq; Type: SEQUENCE SET; Schema: supabase_functions; Owner: -
--

SELECT pg_catalog.setval('supabase_functions.hooks_id_seq', 1, false);


--
-- TOC entry 4116 (class 2606 OID 18067)
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- TOC entry 4028 (class 2606 OID 16494)
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 4139 (class 2606 OID 18173)
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- TOC entry 4095 (class 2606 OID 18191)
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- TOC entry 4097 (class 2606 OID 18201)
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- TOC entry 4026 (class 2606 OID 16487)
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- TOC entry 4118 (class 2606 OID 18060)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- TOC entry 4114 (class 2606 OID 18048)
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- TOC entry 4106 (class 2606 OID 18241)
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- TOC entry 4108 (class 2606 OID 18035)
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- TOC entry 4149 (class 2606 OID 18262)
-- Name: oauth_clients oauth_clients_client_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_client_id_key UNIQUE (client_id);


--
-- TOC entry 4152 (class 2606 OID 18260)
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- TOC entry 4143 (class 2606 OID 18226)
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 4020 (class 2606 OID 16477)
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 4023 (class 2606 OID 17978)
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- TOC entry 4128 (class 2606 OID 18107)
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- TOC entry 4130 (class 2606 OID 18105)
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4135 (class 2606 OID 18121)
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- TOC entry 4031 (class 2606 OID 16500)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4101 (class 2606 OID 17999)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 4125 (class 2606 OID 18088)
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- TOC entry 4120 (class 2606 OID 18079)
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4013 (class 2606 OID 18161)
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- TOC entry 4015 (class 2606 OID 16464)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4170 (class 2606 OID 18337)
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- TOC entry 4172 (class 2606 OID 18339)
-- Name: admins admins_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_profile_id_key UNIQUE (profile_id);


--
-- TOC entry 4239 (class 2606 OID 18641)
-- Name: appointment_history appointment_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment_history
    ADD CONSTRAINT appointment_history_pkey PRIMARY KEY (id);


--
-- TOC entry 4226 (class 2606 OID 18613)
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- TOC entry 4182 (class 2606 OID 18423)
-- Name: assignment_log assignment_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assignment_log
    ADD CONSTRAINT assignment_log_pkey PRIMARY KEY (id);


--
-- TOC entry 4287 (class 2606 OID 18958)
-- Name: auth_trigger_debug_log auth_trigger_debug_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_trigger_debug_log
    ADD CONSTRAINT auth_trigger_debug_log_pkey PRIMARY KEY (id);


--
-- TOC entry 4273 (class 2606 OID 18853)
-- Name: auth_trigger_logs auth_trigger_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_trigger_logs
    ADD CONSTRAINT auth_trigger_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 4243 (class 2606 OID 18723)
-- Name: clinical_notes clinical_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_pkey PRIMARY KEY (id);


--
-- TOC entry 4289 (class 2606 OID 19019)
-- Name: faxes faxes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_pkey PRIMARY KEY (id);


--
-- TOC entry 4203 (class 2606 OID 18471)
-- Name: medication_approvals medication_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_pkey PRIMARY KEY (id);


--
-- TOC entry 4278 (class 2606 OID 18887)
-- Name: medication_dosages medication_dosages_medication_id_strength_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_dosages
    ADD CONSTRAINT medication_dosages_medication_id_strength_key UNIQUE (medication_id, strength);


--
-- TOC entry 4280 (class 2606 OID 18885)
-- Name: medication_dosages medication_dosages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_dosages
    ADD CONSTRAINT medication_dosages_pkey PRIMARY KEY (id);


--
-- TOC entry 4212 (class 2606 OID 18494)
-- Name: medication_orders medication_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_pkey PRIMARY KEY (id);


--
-- TOC entry 4186 (class 2606 OID 18436)
-- Name: medications medications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medications
    ADD CONSTRAINT medications_pkey PRIMARY KEY (id);


--
-- TOC entry 4178 (class 2606 OID 18358)
-- Name: patient_assignments patient_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT patient_assignments_pkey PRIMARY KEY (id);


--
-- TOC entry 4195 (class 2606 OID 18450)
-- Name: patient_medication_preferences patient_medication_preferences_patient_id_medication_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_patient_id_medication_id_key UNIQUE (patient_id, medication_id);


--
-- TOC entry 4197 (class 2606 OID 18448)
-- Name: patient_medication_preferences patient_medication_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_pkey PRIMARY KEY (id);


--
-- TOC entry 4161 (class 2606 OID 18300)
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- TOC entry 4163 (class 2606 OID 18302)
-- Name: patients patients_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_profile_id_key UNIQUE (profile_id);


--
-- TOC entry 4156 (class 2606 OID 18284)
-- Name: profiles profiles_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_email_key UNIQUE (email);


--
-- TOC entry 4158 (class 2606 OID 18282)
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- TOC entry 4222 (class 2606 OID 18585)
-- Name: provider_availability_overrides provider_availability_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_availability_overrides
    ADD CONSTRAINT provider_availability_overrides_pkey PRIMARY KEY (id);


--
-- TOC entry 4216 (class 2606 OID 18568)
-- Name: provider_schedules provider_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_schedules
    ADD CONSTRAINT provider_schedules_pkey PRIMARY KEY (id);


--
-- TOC entry 4166 (class 2606 OID 18318)
-- Name: providers providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4168 (class 2606 OID 18320)
-- Name: providers providers_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_profile_id_key UNIQUE (profile_id);


--
-- TOC entry 4253 (class 2606 OID 18725)
-- Name: clinical_notes unique_appointment_clinical_note; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT unique_appointment_clinical_note UNIQUE (appointment_id);


--
-- TOC entry 4255 (class 2606 OID 18822)
-- Name: clinical_notes unique_clinical_note_per_appointment; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT unique_clinical_note_per_appointment UNIQUE (appointment_id);


--
-- TOC entry 4180 (class 2606 OID 18360)
-- Name: patient_assignments unique_primary_assignment; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT unique_primary_assignment EXCLUDE USING btree (patient_id WITH =) WHERE (((is_primary = true) AND (active = true)));


--
-- TOC entry 4224 (class 2606 OID 18587)
-- Name: provider_availability_overrides unique_provider_override; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_availability_overrides
    ADD CONSTRAINT unique_provider_override UNIQUE (provider_id, date, start_time, end_time);


--
-- TOC entry 4218 (class 2606 OID 18570)
-- Name: provider_schedules unique_provider_schedule; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_schedules
    ADD CONSTRAINT unique_provider_schedule UNIQUE (provider_id, day_of_week, start_time, end_time);


--
-- TOC entry 4237 (class 2606 OID 18615)
-- Name: appointments unique_provider_slot; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT unique_provider_slot UNIQUE (provider_id, appointment_date, start_time);


--
-- TOC entry 4285 (class 2606 OID 18912)
-- Name: visit_addendums visit_addendums_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_addendums
    ADD CONSTRAINT visit_addendums_pkey PRIMARY KEY (id);


--
-- TOC entry 4271 (class 2606 OID 18775)
-- Name: visit_interactions visit_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_interactions
    ADD CONSTRAINT visit_interactions_pkey PRIMARY KEY (id);


--
-- TOC entry 4262 (class 2606 OID 18750)
-- Name: visit_medication_adjustments visit_medication_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_pkey PRIMARY KEY (id);


--
-- TOC entry 4061 (class 2606 OID 17021)
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4064 (class 2606 OID 17032)
-- Name: messages_2025_10_01 messages_2025_10_01_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_10_01
    ADD CONSTRAINT messages_2025_10_01_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4067 (class 2606 OID 17044)
-- Name: messages_2025_10_02 messages_2025_10_02_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_10_02
    ADD CONSTRAINT messages_2025_10_02_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4070 (class 2606 OID 17056)
-- Name: messages_2025_10_03 messages_2025_10_03_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_10_03
    ADD CONSTRAINT messages_2025_10_03_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4073 (class 2606 OID 17068)
-- Name: messages_2025_10_04 messages_2025_10_04_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_10_04
    ADD CONSTRAINT messages_2025_10_04_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4076 (class 2606 OID 17080)
-- Name: messages_2025_10_05 messages_2025_10_05_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_10_05
    ADD CONSTRAINT messages_2025_10_05_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4057 (class 2606 OID 16875)
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- TOC entry 4054 (class 2606 OID 16848)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4086 (class 2606 OID 17902)
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- TOC entry 4034 (class 2606 OID 16517)
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- TOC entry 4088 (class 2606 OID 17912)
-- Name: iceberg_namespaces iceberg_namespaces_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_namespaces
    ADD CONSTRAINT iceberg_namespaces_pkey PRIMARY KEY (id);


--
-- TOC entry 4091 (class 2606 OID 17928)
-- Name: iceberg_tables iceberg_tables_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_pkey PRIMARY KEY (id);


--
-- TOC entry 4044 (class 2606 OID 16558)
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- TOC entry 4046 (class 2606 OID 16556)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 4042 (class 2606 OID 16534)
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- TOC entry 4084 (class 2606 OID 17857)
-- Name: prefixes prefixes_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT prefixes_pkey PRIMARY KEY (bucket_id, level, name);


--
-- TOC entry 4081 (class 2606 OID 17818)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- TOC entry 4079 (class 2606 OID 17803)
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- TOC entry 4050 (class 2606 OID 16771)
-- Name: hooks hooks_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: -
--

ALTER TABLE ONLY supabase_functions.hooks
    ADD CONSTRAINT hooks_pkey PRIMARY KEY (id);


--
-- TOC entry 4048 (class 2606 OID 16761)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: -
--

ALTER TABLE ONLY supabase_functions.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4029 (class 1259 OID 16495)
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- TOC entry 4003 (class 1259 OID 17988)
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4004 (class 1259 OID 17990)
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4005 (class 1259 OID 17991)
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4104 (class 1259 OID 18069)
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- TOC entry 4137 (class 1259 OID 18177)
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- TOC entry 4093 (class 1259 OID 18157)
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- TOC entry 4862 (class 0 OID 0)
-- Dependencies: 4093
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- TOC entry 4098 (class 1259 OID 17985)
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- TOC entry 4140 (class 1259 OID 18174)
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- TOC entry 4141 (class 1259 OID 18175)
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- TOC entry 4112 (class 1259 OID 18180)
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- TOC entry 4109 (class 1259 OID 18041)
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- TOC entry 4110 (class 1259 OID 18186)
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- TOC entry 4147 (class 1259 OID 18263)
-- Name: oauth_clients_client_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_client_id_idx ON auth.oauth_clients USING btree (client_id);


--
-- TOC entry 4150 (class 1259 OID 18264)
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- TOC entry 4144 (class 1259 OID 18233)
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- TOC entry 4145 (class 1259 OID 18232)
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- TOC entry 4146 (class 1259 OID 18234)
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- TOC entry 4006 (class 1259 OID 17992)
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4007 (class 1259 OID 17989)
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4016 (class 1259 OID 16478)
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- TOC entry 4017 (class 1259 OID 16479)
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- TOC entry 4018 (class 1259 OID 17984)
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- TOC entry 4021 (class 1259 OID 18071)
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- TOC entry 4024 (class 1259 OID 18176)
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- TOC entry 4131 (class 1259 OID 18113)
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- TOC entry 4132 (class 1259 OID 18178)
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- TOC entry 4133 (class 1259 OID 18128)
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- TOC entry 4136 (class 1259 OID 18127)
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- TOC entry 4099 (class 1259 OID 18179)
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- TOC entry 4102 (class 1259 OID 18070)
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- TOC entry 4123 (class 1259 OID 18095)
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- TOC entry 4126 (class 1259 OID 18094)
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- TOC entry 4121 (class 1259 OID 18080)
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- TOC entry 4122 (class 1259 OID 18242)
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- TOC entry 4111 (class 1259 OID 18239)
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- TOC entry 4103 (class 1259 OID 18068)
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- TOC entry 4008 (class 1259 OID 18148)
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- TOC entry 4863 (class 0 OID 0)
-- Dependencies: 4008
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- TOC entry 4009 (class 1259 OID 17986)
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- TOC entry 4010 (class 1259 OID 16468)
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- TOC entry 4011 (class 1259 OID 18203)
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- TOC entry 4173 (class 1259 OID 18375)
-- Name: idx_admins_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admins_profile_id ON public.admins USING btree (profile_id);


--
-- TOC entry 4240 (class 1259 OID 18657)
-- Name: idx_appointment_history_appointment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointment_history_appointment ON public.appointment_history USING btree (appointment_id);


--
-- TOC entry 4241 (class 1259 OID 18658)
-- Name: idx_appointment_history_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointment_history_created ON public.appointment_history USING btree (created_at);


--
-- TOC entry 4227 (class 1259 OID 18656)
-- Name: idx_appointments_assignment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_assignment ON public.appointments USING btree (assignment_id);


--
-- TOC entry 4228 (class 1259 OID 18653)
-- Name: idx_appointments_date_range; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_date_range ON public.appointments USING btree (appointment_date);


--
-- TOC entry 4229 (class 1259 OID 18651)
-- Name: idx_appointments_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_patient_id ON public.appointments USING btree (patient_id);


--
-- TOC entry 4230 (class 1259 OID 18654)
-- Name: idx_appointments_provider_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_provider_date ON public.appointments USING btree (provider_id, appointment_date);


--
-- TOC entry 4231 (class 1259 OID 18652)
-- Name: idx_appointments_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_provider_id ON public.appointments USING btree (provider_id);


--
-- TOC entry 4232 (class 1259 OID 18944)
-- Name: idx_appointments_reschedule_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_reschedule_source ON public.appointments USING btree (is_reschedule_source);


--
-- TOC entry 4233 (class 1259 OID 18942)
-- Name: idx_appointments_rescheduled_from; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_rescheduled_from ON public.appointments USING btree (rescheduled_from_id);


--
-- TOC entry 4234 (class 1259 OID 18943)
-- Name: idx_appointments_rescheduled_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_rescheduled_to ON public.appointments USING btree (rescheduled_to_id);


--
-- TOC entry 4235 (class 1259 OID 18655)
-- Name: idx_appointments_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_status ON public.appointments USING btree (status);


--
-- TOC entry 4244 (class 1259 OID 18786)
-- Name: idx_clinical_notes_appointment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_appointment ON public.clinical_notes USING btree (appointment_id);


--
-- TOC entry 4245 (class 1259 OID 18815)
-- Name: idx_clinical_notes_appointment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_appointment_id ON public.clinical_notes USING btree (appointment_id);


--
-- TOC entry 4246 (class 1259 OID 18789)
-- Name: idx_clinical_notes_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_created_at ON public.clinical_notes USING btree (created_at);


--
-- TOC entry 4247 (class 1259 OID 18787)
-- Name: idx_clinical_notes_patient; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_patient ON public.clinical_notes USING btree (patient_id);


--
-- TOC entry 4248 (class 1259 OID 18816)
-- Name: idx_clinical_notes_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_patient_id ON public.clinical_notes USING btree (patient_id);


--
-- TOC entry 4249 (class 1259 OID 18788)
-- Name: idx_clinical_notes_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_provider ON public.clinical_notes USING btree (provider_id);


--
-- TOC entry 4250 (class 1259 OID 18817)
-- Name: idx_clinical_notes_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_provider_id ON public.clinical_notes USING btree (provider_id);


--
-- TOC entry 4251 (class 1259 OID 18790)
-- Name: idx_clinical_notes_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_updated_at ON public.clinical_notes USING btree (updated_at);


--
-- TOC entry 4290 (class 1259 OID 19040)
-- Name: idx_faxes_approval_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_approval_id ON public.faxes USING btree (approval_id);


--
-- TOC entry 4291 (class 1259 OID 19044)
-- Name: idx_faxes_faxed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_faxed_at ON public.faxes USING btree (faxed_at);


--
-- TOC entry 4292 (class 1259 OID 19042)
-- Name: idx_faxes_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_patient_id ON public.faxes USING btree (patient_id);


--
-- TOC entry 4293 (class 1259 OID 19096)
-- Name: idx_faxes_patient_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_patient_profile_id ON public.faxes USING btree (patient_profile_id);


--
-- TOC entry 4294 (class 1259 OID 19041)
-- Name: idx_faxes_preference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_preference_id ON public.faxes USING btree (preference_id);


--
-- TOC entry 4295 (class 1259 OID 19043)
-- Name: idx_faxes_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_provider_id ON public.faxes USING btree (provider_id);


--
-- TOC entry 4296 (class 1259 OID 19095)
-- Name: idx_faxes_provider_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_provider_profile_id ON public.faxes USING btree (provider_profile_id);


--
-- TOC entry 4297 (class 1259 OID 19045)
-- Name: idx_faxes_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_status ON public.faxes USING btree (fax_status);


--
-- TOC entry 4198 (class 1259 OID 18514)
-- Name: idx_medication_approvals_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_approvals_provider_id ON public.medication_approvals USING btree (provider_id);


--
-- TOC entry 4199 (class 1259 OID 19094)
-- Name: idx_medication_approvals_provider_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_approvals_provider_profile_id ON public.medication_approvals USING btree (provider_profile_id);


--
-- TOC entry 4200 (class 1259 OID 18515)
-- Name: idx_medication_approvals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_approvals_status ON public.medication_approvals USING btree (status);


--
-- TOC entry 4201 (class 1259 OID 19099)
-- Name: idx_medication_approvals_supply_days; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_approvals_supply_days ON public.medication_approvals USING btree (supply_days);


--
-- TOC entry 4274 (class 1259 OID 18894)
-- Name: idx_medication_dosages_available; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_dosages_available ON public.medication_dosages USING btree (available);


--
-- TOC entry 4275 (class 1259 OID 18893)
-- Name: idx_medication_dosages_medication_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_dosages_medication_id ON public.medication_dosages USING btree (medication_id);


--
-- TOC entry 4276 (class 1259 OID 18895)
-- Name: idx_medication_dosages_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_dosages_sort_order ON public.medication_dosages USING btree (sort_order);


--
-- TOC entry 4204 (class 1259 OID 18518)
-- Name: idx_medication_orders_fulfillment_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_fulfillment_status ON public.medication_orders USING btree (fulfillment_status);


--
-- TOC entry 4205 (class 1259 OID 18547)
-- Name: idx_medication_orders_patient_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_patient_created ON public.medication_orders USING btree (patient_id, created_at DESC);


--
-- TOC entry 4206 (class 1259 OID 18516)
-- Name: idx_medication_orders_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_patient_id ON public.medication_orders USING btree (patient_id);


--
-- TOC entry 4207 (class 1259 OID 19098)
-- Name: idx_medication_orders_patient_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_patient_profile_id ON public.medication_orders USING btree (patient_profile_id);


--
-- TOC entry 4208 (class 1259 OID 18517)
-- Name: idx_medication_orders_payment_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_payment_status ON public.medication_orders USING btree (payment_status);


--
-- TOC entry 4209 (class 1259 OID 19097)
-- Name: idx_medication_orders_provider_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_provider_profile_id ON public.medication_orders USING btree (provider_profile_id);


--
-- TOC entry 4210 (class 1259 OID 18545)
-- Name: idx_medication_orders_sent_to_pharmacy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_sent_to_pharmacy ON public.medication_orders USING btree (sent_to_pharmacy);


--
-- TOC entry 4183 (class 1259 OID 18511)
-- Name: idx_medications_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medications_active ON public.medications USING btree (active);


--
-- TOC entry 4184 (class 1259 OID 18510)
-- Name: idx_medications_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medications_category ON public.medications USING btree (category);


--
-- TOC entry 4174 (class 1259 OID 18378)
-- Name: idx_patient_assignments_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_assignments_active ON public.patient_assignments USING btree (active);


--
-- TOC entry 4175 (class 1259 OID 18376)
-- Name: idx_patient_assignments_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_assignments_patient_id ON public.patient_assignments USING btree (patient_id);


--
-- TOC entry 4176 (class 1259 OID 18377)
-- Name: idx_patient_assignments_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_assignments_provider_id ON public.patient_assignments USING btree (provider_id);


--
-- TOC entry 4187 (class 1259 OID 19046)
-- Name: idx_patient_medication_preferences_faxed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_faxed ON public.patient_medication_preferences USING btree (faxed);


--
-- TOC entry 4188 (class 1259 OID 19047)
-- Name: idx_patient_medication_preferences_next_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_next_due ON public.patient_medication_preferences USING btree (next_prescription_due);


--
-- TOC entry 4189 (class 1259 OID 18512)
-- Name: idx_patient_medication_preferences_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_patient_id ON public.patient_medication_preferences USING btree (patient_id);


--
-- TOC entry 4190 (class 1259 OID 19124)
-- Name: idx_patient_medication_preferences_refill_requested; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_refill_requested ON public.patient_medication_preferences USING btree (refill_requested);


--
-- TOC entry 4191 (class 1259 OID 18513)
-- Name: idx_patient_medication_preferences_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_status ON public.patient_medication_preferences USING btree (status);


--
-- TOC entry 4192 (class 1259 OID 19113)
-- Name: idx_patient_medication_preferences_supply_days; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_supply_days ON public.patient_medication_preferences USING btree (supply_days);


--
-- TOC entry 4159 (class 1259 OID 18373)
-- Name: idx_patients_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patients_profile_id ON public.patients USING btree (profile_id);


--
-- TOC entry 4193 (class 1259 OID 19125)
-- Name: idx_preferences_provider_approval; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_preferences_provider_approval ON public.patient_medication_preferences USING btree (status, refill_requested) WHERE ((status = 'pending'::text) AND (refill_requested = true));


--
-- TOC entry 4153 (class 1259 OID 18372)
-- Name: idx_profiles_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_email ON public.profiles USING btree (email);


--
-- TOC entry 4154 (class 1259 OID 18371)
-- Name: idx_profiles_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_role ON public.profiles USING btree (role);


--
-- TOC entry 4219 (class 1259 OID 18650)
-- Name: idx_provider_overrides_date_range; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provider_overrides_date_range ON public.provider_availability_overrides USING btree (date);


--
-- TOC entry 4220 (class 1259 OID 18649)
-- Name: idx_provider_overrides_provider_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provider_overrides_provider_date ON public.provider_availability_overrides USING btree (provider_id, date);


--
-- TOC entry 4213 (class 1259 OID 18648)
-- Name: idx_provider_schedules_day_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provider_schedules_day_active ON public.provider_schedules USING btree (day_of_week, active);


--
-- TOC entry 4214 (class 1259 OID 18647)
-- Name: idx_provider_schedules_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provider_schedules_provider_id ON public.provider_schedules USING btree (provider_id);


--
-- TOC entry 4164 (class 1259 OID 18374)
-- Name: idx_providers_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_providers_profile_id ON public.providers USING btree (profile_id);


--
-- TOC entry 4281 (class 1259 OID 18925)
-- Name: idx_visit_addendums_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_addendums_created_at ON public.visit_addendums USING btree (created_at);


--
-- TOC entry 4282 (class 1259 OID 18924)
-- Name: idx_visit_addendums_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_addendums_provider_id ON public.visit_addendums USING btree (provider_id);


--
-- TOC entry 4283 (class 1259 OID 18923)
-- Name: idx_visit_addendums_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_addendums_visit_id ON public.visit_addendums USING btree (visit_id);


--
-- TOC entry 4263 (class 1259 OID 18796)
-- Name: idx_visit_interactions_appointment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_appointment ON public.visit_interactions USING btree (appointment_id);


--
-- TOC entry 4264 (class 1259 OID 18819)
-- Name: idx_visit_interactions_appointment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_appointment_id ON public.visit_interactions USING btree (appointment_id);


--
-- TOC entry 4265 (class 1259 OID 18795)
-- Name: idx_visit_interactions_clinical_note; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_clinical_note ON public.visit_interactions USING btree (clinical_note_id);


--
-- TOC entry 4266 (class 1259 OID 18818)
-- Name: idx_visit_interactions_clinical_note_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_clinical_note_id ON public.visit_interactions USING btree (clinical_note_id);


--
-- TOC entry 4267 (class 1259 OID 18798)
-- Name: idx_visit_interactions_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_created_at ON public.visit_interactions USING btree (created_at);


--
-- TOC entry 4268 (class 1259 OID 18820)
-- Name: idx_visit_interactions_medication_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_medication_id ON public.visit_interactions USING btree (medication_id);


--
-- TOC entry 4269 (class 1259 OID 18797)
-- Name: idx_visit_interactions_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_type ON public.visit_interactions USING btree (interaction_type);


--
-- TOC entry 4256 (class 1259 OID 18792)
-- Name: idx_visit_medication_adjustments_appointment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_appointment ON public.visit_medication_adjustments USING btree (appointment_id);


--
-- TOC entry 4257 (class 1259 OID 18791)
-- Name: idx_visit_medication_adjustments_clinical_note; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_clinical_note ON public.visit_medication_adjustments USING btree (clinical_note_id);


--
-- TOC entry 4258 (class 1259 OID 18794)
-- Name: idx_visit_medication_adjustments_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_created_at ON public.visit_medication_adjustments USING btree (created_at);


--
-- TOC entry 4259 (class 1259 OID 18793)
-- Name: idx_visit_medication_adjustments_preference; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_preference ON public.visit_medication_adjustments USING btree (preference_id);


--
-- TOC entry 4260 (class 1259 OID 19114)
-- Name: idx_visit_medication_adjustments_supply_days; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_supply_days ON public.visit_medication_adjustments USING btree (new_supply_days);


--
-- TOC entry 4055 (class 1259 OID 17022)
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- TOC entry 4059 (class 1259 OID 17023)
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4062 (class 1259 OID 17033)
-- Name: messages_2025_10_01_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_10_01_inserted_at_topic_idx ON realtime.messages_2025_10_01 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4065 (class 1259 OID 17045)
-- Name: messages_2025_10_02_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_10_02_inserted_at_topic_idx ON realtime.messages_2025_10_02 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4068 (class 1259 OID 17057)
-- Name: messages_2025_10_03_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_10_03_inserted_at_topic_idx ON realtime.messages_2025_10_03 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4071 (class 1259 OID 17069)
-- Name: messages_2025_10_04_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_10_04_inserted_at_topic_idx ON realtime.messages_2025_10_04 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4074 (class 1259 OID 17081)
-- Name: messages_2025_10_05_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_10_05_inserted_at_topic_idx ON realtime.messages_2025_10_05 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4058 (class 1259 OID 16924)
-- Name: subscription_subscription_id_entity_filters_key; Type: INDEX; Schema: realtime; Owner: -
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_key ON realtime.subscription USING btree (subscription_id, entity, filters);


--
-- TOC entry 4032 (class 1259 OID 16523)
-- Name: bname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- TOC entry 4035 (class 1259 OID 16545)
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- TOC entry 4089 (class 1259 OID 17918)
-- Name: idx_iceberg_namespaces_bucket_id; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX idx_iceberg_namespaces_bucket_id ON storage.iceberg_namespaces USING btree (bucket_id, name);


--
-- TOC entry 4092 (class 1259 OID 17939)
-- Name: idx_iceberg_tables_namespace_id; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX idx_iceberg_tables_namespace_id ON storage.iceberg_tables USING btree (namespace_id, name);


--
-- TOC entry 4077 (class 1259 OID 17829)
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- TOC entry 4036 (class 1259 OID 17875)
-- Name: idx_name_bucket_level_unique; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX idx_name_bucket_level_unique ON storage.objects USING btree (name COLLATE "C", bucket_id, level);


--
-- TOC entry 4037 (class 1259 OID 17794)
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- TOC entry 4038 (class 1259 OID 17877)
-- Name: idx_objects_lower_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_lower_name ON storage.objects USING btree ((path_tokens[level]), lower(name) text_pattern_ops, bucket_id, level);


--
-- TOC entry 4082 (class 1259 OID 17878)
-- Name: idx_prefixes_lower_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_prefixes_lower_name ON storage.prefixes USING btree (bucket_id, level, ((string_to_array(name, '/'::text))[level]), lower(name) text_pattern_ops);


--
-- TOC entry 4039 (class 1259 OID 16546)
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- TOC entry 4040 (class 1259 OID 17876)
-- Name: objects_bucket_id_level_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX objects_bucket_id_level_idx ON storage.objects USING btree (bucket_id, level, name COLLATE "C");


--
-- TOC entry 4051 (class 1259 OID 16773)
-- Name: supabase_functions_hooks_h_table_id_h_name_idx; Type: INDEX; Schema: supabase_functions; Owner: -
--

CREATE INDEX supabase_functions_hooks_h_table_id_h_name_idx ON supabase_functions.hooks USING btree (hook_table_id, hook_name);


--
-- TOC entry 4052 (class 1259 OID 16772)
-- Name: supabase_functions_hooks_request_id_idx; Type: INDEX; Schema: supabase_functions; Owner: -
--

CREATE INDEX supabase_functions_hooks_request_id_idx ON supabase_functions.hooks USING btree (request_id);


--
-- TOC entry 4298 (class 0 OID 0)
-- Name: messages_2025_10_01_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_01_inserted_at_topic_idx;


--
-- TOC entry 4299 (class 0 OID 0)
-- Name: messages_2025_10_01_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_01_pkey;


--
-- TOC entry 4300 (class 0 OID 0)
-- Name: messages_2025_10_02_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_02_inserted_at_topic_idx;


--
-- TOC entry 4301 (class 0 OID 0)
-- Name: messages_2025_10_02_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_02_pkey;


--
-- TOC entry 4302 (class 0 OID 0)
-- Name: messages_2025_10_03_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_03_inserted_at_topic_idx;


--
-- TOC entry 4303 (class 0 OID 0)
-- Name: messages_2025_10_03_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_03_pkey;


--
-- TOC entry 4304 (class 0 OID 0)
-- Name: messages_2025_10_04_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_04_inserted_at_topic_idx;


--
-- TOC entry 4305 (class 0 OID 0)
-- Name: messages_2025_10_04_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_04_pkey;


--
-- TOC entry 4306 (class 0 OID 0)
-- Name: messages_2025_10_05_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_05_inserted_at_topic_idx;


--
-- TOC entry 4307 (class 0 OID 0)
-- Name: messages_2025_10_05_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_05_pkey;


--
-- TOC entry 4370 (class 2620 OID 19006)
-- Name: users on_auth_user_created; Type: TRIGGER; Schema: auth; Owner: -
--

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();


--
-- TOC entry 4392 (class 2620 OID 18662)
-- Name: appointments appointment_audit_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER appointment_audit_trigger AFTER INSERT OR DELETE OR UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.log_appointment_changes();


--
-- TOC entry 4393 (class 2620 OID 18695)
-- Name: appointments appointment_business_rules_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER appointment_business_rules_trigger BEFORE INSERT OR UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.validate_appointment_business_rules();


--
-- TOC entry 4385 (class 2620 OID 19122)
-- Name: patient_medication_preferences calculate_next_due_on_supply_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER calculate_next_due_on_supply_update BEFORE UPDATE ON public.patient_medication_preferences FOR EACH ROW EXECUTE FUNCTION public.calculate_next_prescription_due();


--
-- TOC entry 4864 (class 0 OID 0)
-- Dependencies: 4385
-- Name: TRIGGER calculate_next_due_on_supply_update ON patient_medication_preferences; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TRIGGER calculate_next_due_on_supply_update ON public.patient_medication_preferences IS 'Calculates next_prescription_due when supply_days is updated with approved status';


--
-- TOC entry 4388 (class 2620 OID 19110)
-- Name: medication_orders check_approval_expiry_on_delivery_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER check_approval_expiry_on_delivery_trigger AFTER UPDATE ON public.medication_orders FOR EACH ROW EXECUTE FUNCTION public.check_approval_expiry_on_delivery();


--
-- TOC entry 4399 (class 2620 OID 19055)
-- Name: faxes create_order_on_fax_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER create_order_on_fax_trigger AFTER INSERT ON public.faxes FOR EACH ROW EXECUTE FUNCTION public.create_order_on_fax();


--
-- TOC entry 4865 (class 0 OID 0)
-- Dependencies: 4399
-- Name: TRIGGER create_order_on_fax_trigger ON faxes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TRIGGER create_order_on_fax_trigger ON public.faxes IS 'Trigger to create medication order when fax is sent';


--
-- TOC entry 4382 (class 2620 OID 18383)
-- Name: admins update_admins_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_admins_updated_at BEFORE UPDATE ON public.admins FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4394 (class 2620 OID 18660)
-- Name: appointments update_appointments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_appointments_updated_at BEFORE UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4395 (class 2620 OID 18801)
-- Name: clinical_notes update_clinical_note_editor_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_clinical_note_editor_trigger BEFORE UPDATE ON public.clinical_notes FOR EACH ROW EXECUTE FUNCTION public.update_clinical_note_editor();


--
-- TOC entry 4396 (class 2620 OID 18813)
-- Name: clinical_notes update_clinical_notes_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_clinical_notes_updated_at BEFORE UPDATE ON public.clinical_notes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4400 (class 2620 OID 19048)
-- Name: faxes update_faxes_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_faxes_updated_at BEFORE UPDATE ON public.faxes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4387 (class 2620 OID 18521)
-- Name: medication_approvals update_medication_approvals_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medication_approvals_updated_at BEFORE UPDATE ON public.medication_approvals FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4398 (class 2620 OID 18896)
-- Name: medication_dosages update_medication_dosages_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medication_dosages_updated_at BEFORE UPDATE ON public.medication_dosages FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4389 (class 2620 OID 18522)
-- Name: medication_orders update_medication_orders_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medication_orders_updated_at BEFORE UPDATE ON public.medication_orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4384 (class 2620 OID 18519)
-- Name: medications update_medications_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medications_updated_at BEFORE UPDATE ON public.medications FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4383 (class 2620 OID 18384)
-- Name: patient_assignments update_patient_assignments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patient_assignments_updated_at BEFORE UPDATE ON public.patient_assignments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4386 (class 2620 OID 18520)
-- Name: patient_medication_preferences update_patient_medication_preferences_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patient_medication_preferences_updated_at BEFORE UPDATE ON public.patient_medication_preferences FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4380 (class 2620 OID 18381)
-- Name: patients update_patients_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patients_updated_at BEFORE UPDATE ON public.patients FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4397 (class 2620 OID 19116)
-- Name: visit_medication_adjustments update_preference_on_adjustment_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_preference_on_adjustment_trigger AFTER INSERT ON public.visit_medication_adjustments FOR EACH ROW EXECUTE FUNCTION public.update_preference_on_medication_adjustment();


--
-- TOC entry 4866 (class 0 OID 0)
-- Dependencies: 4397
-- Name: TRIGGER update_preference_on_adjustment_trigger ON visit_medication_adjustments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TRIGGER update_preference_on_adjustment_trigger ON public.visit_medication_adjustments IS 'Updates patient_medication_preferences when medication adjustments are approved, including supply_days and next_prescription_due calculation';


--
-- TOC entry 4390 (class 2620 OID 19051)
-- Name: medication_orders update_prescription_due_date_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_prescription_due_date_trigger AFTER UPDATE ON public.medication_orders FOR EACH ROW EXECUTE FUNCTION public.update_prescription_due_date();


--
-- TOC entry 4379 (class 2620 OID 18380)
-- Name: profiles update_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4391 (class 2620 OID 18659)
-- Name: provider_schedules update_provider_schedules_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_provider_schedules_updated_at BEFORE UPDATE ON public.provider_schedules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4381 (class 2620 OID 18382)
-- Name: providers update_providers_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_providers_updated_at BEFORE UPDATE ON public.providers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4376 (class 2620 OID 16880)
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: -
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- TOC entry 4371 (class 2620 OID 17885)
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- TOC entry 4372 (class 2620 OID 17873)
-- Name: objects objects_delete_delete_prefix; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER objects_delete_delete_prefix AFTER DELETE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- TOC entry 4373 (class 2620 OID 17871)
-- Name: objects objects_insert_create_prefix; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER objects_insert_create_prefix BEFORE INSERT ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.objects_insert_prefix_trigger();


--
-- TOC entry 4374 (class 2620 OID 17872)
-- Name: objects objects_update_create_prefix; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER objects_update_create_prefix BEFORE UPDATE ON storage.objects FOR EACH ROW WHEN (((new.name <> old.name) OR (new.bucket_id <> old.bucket_id))) EXECUTE FUNCTION storage.objects_update_prefix_trigger();


--
-- TOC entry 4377 (class 2620 OID 17881)
-- Name: prefixes prefixes_create_hierarchy; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER prefixes_create_hierarchy BEFORE INSERT ON storage.prefixes FOR EACH ROW WHEN ((pg_trigger_depth() < 1)) EXECUTE FUNCTION storage.prefixes_insert_trigger();


--
-- TOC entry 4378 (class 2620 OID 17870)
-- Name: prefixes prefixes_delete_hierarchy; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER prefixes_delete_hierarchy AFTER DELETE ON storage.prefixes FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- TOC entry 4375 (class 2620 OID 17782)
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- TOC entry 4317 (class 2606 OID 17972)
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4321 (class 2606 OID 18061)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4320 (class 2606 OID 18049)
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- TOC entry 4319 (class 2606 OID 18036)
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4326 (class 2606 OID 18227)
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4308 (class 2606 OID 18005)
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4323 (class 2606 OID 18108)
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4324 (class 2606 OID 18181)
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- TOC entry 4325 (class 2606 OID 18122)
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4318 (class 2606 OID 18000)
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4322 (class 2606 OID 18089)
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4330 (class 2606 OID 18340)
-- Name: admins admins_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4351 (class 2606 OID 18642)
-- Name: appointment_history appointment_history_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment_history
    ADD CONSTRAINT appointment_history_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4346 (class 2606 OID 18626)
-- Name: appointments appointments_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.patient_assignments(id);


--
-- TOC entry 4347 (class 2606 OID 18616)
-- Name: appointments appointments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4348 (class 2606 OID 18621)
-- Name: appointments appointments_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4349 (class 2606 OID 18932)
-- Name: appointments appointments_rescheduled_from_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_rescheduled_from_id_fkey FOREIGN KEY (rescheduled_from_id) REFERENCES public.appointments(id);


--
-- TOC entry 4350 (class 2606 OID 18937)
-- Name: appointments appointments_rescheduled_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_rescheduled_to_id_fkey FOREIGN KEY (rescheduled_to_id) REFERENCES public.appointments(id);


--
-- TOC entry 4360 (class 2606 OID 18854)
-- Name: auth_trigger_logs auth_trigger_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_trigger_logs
    ADD CONSTRAINT auth_trigger_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- TOC entry 4352 (class 2606 OID 18726)
-- Name: clinical_notes clinical_notes_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4353 (class 2606 OID 18731)
-- Name: clinical_notes clinical_notes_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4354 (class 2606 OID 18736)
-- Name: clinical_notes clinical_notes_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4364 (class 2606 OID 19020)
-- Name: faxes faxes_approval_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_approval_id_fkey FOREIGN KEY (approval_id) REFERENCES public.medication_approvals(id) ON DELETE CASCADE;


--
-- TOC entry 4365 (class 2606 OID 19030)
-- Name: faxes faxes_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4366 (class 2606 OID 19079)
-- Name: faxes faxes_patient_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_patient_profile_id_fkey FOREIGN KEY (patient_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4367 (class 2606 OID 19025)
-- Name: faxes faxes_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_preference_id_fkey FOREIGN KEY (preference_id) REFERENCES public.patient_medication_preferences(id) ON DELETE CASCADE;


--
-- TOC entry 4368 (class 2606 OID 19035)
-- Name: faxes faxes_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4369 (class 2606 OID 19074)
-- Name: faxes faxes_provider_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_provider_profile_id_fkey FOREIGN KEY (provider_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4336 (class 2606 OID 18472)
-- Name: medication_approvals medication_approvals_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_preference_id_fkey FOREIGN KEY (preference_id) REFERENCES public.patient_medication_preferences(id) ON DELETE CASCADE;


--
-- TOC entry 4337 (class 2606 OID 18477)
-- Name: medication_approvals medication_approvals_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4338 (class 2606 OID 19069)
-- Name: medication_approvals medication_approvals_provider_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_provider_profile_id_fkey FOREIGN KEY (provider_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4361 (class 2606 OID 18888)
-- Name: medication_dosages medication_dosages_medication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_dosages
    ADD CONSTRAINT medication_dosages_medication_id_fkey FOREIGN KEY (medication_id) REFERENCES public.medications(id) ON DELETE CASCADE;


--
-- TOC entry 4339 (class 2606 OID 18495)
-- Name: medication_orders medication_orders_approval_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_approval_id_fkey FOREIGN KEY (approval_id) REFERENCES public.medication_approvals(id) ON DELETE CASCADE;


--
-- TOC entry 4340 (class 2606 OID 18505)
-- Name: medication_orders medication_orders_medication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_medication_id_fkey FOREIGN KEY (medication_id) REFERENCES public.medications(id) ON DELETE CASCADE;


--
-- TOC entry 4341 (class 2606 OID 18500)
-- Name: medication_orders medication_orders_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4342 (class 2606 OID 19089)
-- Name: medication_orders medication_orders_patient_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_patient_profile_id_fkey FOREIGN KEY (patient_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4343 (class 2606 OID 19084)
-- Name: medication_orders medication_orders_provider_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_provider_profile_id_fkey FOREIGN KEY (provider_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4331 (class 2606 OID 18361)
-- Name: patient_assignments patient_assignments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT patient_assignments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4332 (class 2606 OID 18366)
-- Name: patient_assignments patient_assignments_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT patient_assignments_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4333 (class 2606 OID 18897)
-- Name: patient_medication_preferences patient_medication_preferences_medication_dosage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_medication_dosage_id_fkey FOREIGN KEY (medication_dosage_id) REFERENCES public.medication_dosages(id) ON DELETE SET NULL;


--
-- TOC entry 4334 (class 2606 OID 18456)
-- Name: patient_medication_preferences patient_medication_preferences_medication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_medication_id_fkey FOREIGN KEY (medication_id) REFERENCES public.medications(id) ON DELETE CASCADE;


--
-- TOC entry 4335 (class 2606 OID 18451)
-- Name: patient_medication_preferences patient_medication_preferences_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4328 (class 2606 OID 18303)
-- Name: patients patients_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4327 (class 2606 OID 18285)
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4345 (class 2606 OID 18588)
-- Name: provider_availability_overrides provider_availability_overrides_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_availability_overrides
    ADD CONSTRAINT provider_availability_overrides_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4344 (class 2606 OID 18571)
-- Name: provider_schedules provider_schedules_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_schedules
    ADD CONSTRAINT provider_schedules_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4329 (class 2606 OID 18321)
-- Name: providers providers_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4362 (class 2606 OID 18918)
-- Name: visit_addendums visit_addendums_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_addendums
    ADD CONSTRAINT visit_addendums_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4363 (class 2606 OID 18913)
-- Name: visit_addendums visit_addendums_visit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_addendums
    ADD CONSTRAINT visit_addendums_visit_id_fkey FOREIGN KEY (visit_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4358 (class 2606 OID 18781)
-- Name: visit_interactions visit_interactions_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_interactions
    ADD CONSTRAINT visit_interactions_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4359 (class 2606 OID 18776)
-- Name: visit_interactions visit_interactions_clinical_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_interactions
    ADD CONSTRAINT visit_interactions_clinical_note_id_fkey FOREIGN KEY (clinical_note_id) REFERENCES public.clinical_notes(id) ON DELETE CASCADE;


--
-- TOC entry 4355 (class 2606 OID 18756)
-- Name: visit_medication_adjustments visit_medication_adjustments_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4356 (class 2606 OID 18751)
-- Name: visit_medication_adjustments visit_medication_adjustments_clinical_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_clinical_note_id_fkey FOREIGN KEY (clinical_note_id) REFERENCES public.clinical_notes(id) ON DELETE CASCADE;


--
-- TOC entry 4357 (class 2606 OID 18761)
-- Name: visit_medication_adjustments visit_medication_adjustments_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_preference_id_fkey FOREIGN KEY (preference_id) REFERENCES public.patient_medication_preferences(id) ON DELETE CASCADE;


--
-- TOC entry 4314 (class 2606 OID 17913)
-- Name: iceberg_namespaces iceberg_namespaces_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_namespaces
    ADD CONSTRAINT iceberg_namespaces_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_analytics(id) ON DELETE CASCADE;


--
-- TOC entry 4315 (class 2606 OID 17934)
-- Name: iceberg_tables iceberg_tables_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_analytics(id) ON DELETE CASCADE;


--
-- TOC entry 4316 (class 2606 OID 17929)
-- Name: iceberg_tables iceberg_tables_namespace_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES storage.iceberg_namespaces(id) ON DELETE CASCADE;


--
-- TOC entry 4309 (class 2606 OID 16535)
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4313 (class 2606 OID 17858)
-- Name: prefixes prefixes_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT "prefixes_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4310 (class 2606 OID 17804)
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4311 (class 2606 OID 17824)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4312 (class 2606 OID 17819)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- TOC entry 4555 (class 0 OID 16488)
-- Dependencies: 287
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4576 (class 0 OID 18167)
-- Dependencies: 335
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4567 (class 0 OID 17965)
-- Dependencies: 326
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4554 (class 0 OID 16481)
-- Dependencies: 286
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4571 (class 0 OID 18054)
-- Dependencies: 330
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4570 (class 0 OID 18042)
-- Dependencies: 329
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4569 (class 0 OID 18029)
-- Dependencies: 328
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4577 (class 0 OID 18217)
-- Dependencies: 336
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4553 (class 0 OID 16470)
-- Dependencies: 285
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4574 (class 0 OID 18096)
-- Dependencies: 333
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4575 (class 0 OID 18114)
-- Dependencies: 334
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4556 (class 0 OID 16496)
-- Dependencies: 288
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4568 (class 0 OID 17995)
-- Dependencies: 327
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4573 (class 0 OID 18081)
-- Dependencies: 332
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4572 (class 0 OID 18072)
-- Dependencies: 331
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4552 (class 0 OID 16458)
-- Dependencies: 283
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4672 (class 3256 OID 19062)
-- Name: medication_approvals Admins can manage all approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all approvals" ON public.medication_approvals USING ((auth.uid() IN ( SELECT a.profile_id
   FROM public.admins a
  WHERE (a.active = true))));


--
-- TOC entry 4605 (class 3256 OID 18401)
-- Name: patient_assignments Admins can manage all assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all assignments" ON public.patient_assignments USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4677 (class 3256 OID 19067)
-- Name: faxes Admins can manage all faxes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all faxes" ON public.faxes USING ((auth.uid() IN ( SELECT a.profile_id
   FROM public.admins a
  WHERE (a.active = true))));


--
-- TOC entry 4616 (class 3256 OID 18539)
-- Name: medication_orders Admins can manage all medication orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all medication orders" ON public.medication_orders USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4607 (class 3256 OID 18530)
-- Name: medications Admins can manage all medications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all medications" ON public.medications USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4597 (class 3256 OID 18393)
-- Name: patients Admins can manage all patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all patients" ON public.patients USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4600 (class 3256 OID 18396)
-- Name: providers Admins can manage all providers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all providers" ON public.providers USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4602 (class 3256 OID 18398)
-- Name: admins Admins can update own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can update own data" ON public.admins FOR UPDATE USING ((profile_id = auth.uid()));


--
-- TOC entry 4638 (class 3256 OID 18804)
-- Name: clinical_notes Admins can view all clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all clinical notes" ON public.clinical_notes FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))));


--
-- TOC entry 4614 (class 3256 OID 18537)
-- Name: medication_approvals Admins can view all medication approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all medication approvals" ON public.medication_approvals FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4610 (class 3256 OID 18533)
-- Name: patient_medication_preferences Admins can view all medication preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all medication preferences" ON public.patient_medication_preferences FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4593 (class 3256 OID 18389)
-- Name: profiles Admins can view all profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all profiles" ON public.profiles USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4656 (class 3256 OID 18929)
-- Name: visit_addendums Admins can view all visit addendums; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all visit addendums" ON public.visit_addendums FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))));


--
-- TOC entry 4641 (class 3256 OID 18809)
-- Name: visit_interactions Admins can view all visit interactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all visit interactions" ON public.visit_interactions FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))));


--
-- TOC entry 4601 (class 3256 OID 18397)
-- Name: admins Admins can view own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view own data" ON public.admins FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4653 (class 3256 OID 18860)
-- Name: auth_trigger_logs Allow admins to read logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow admins to read logs" ON public.auth_trigger_logs FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.profiles p
  WHERE ((p.id = auth.uid()) AND (p.role = 'admin'::text)))));


--
-- TOC entry 4649 (class 3256 OID 18841)
-- Name: profiles Allow auth trigger and service role; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow auth trigger and service role" ON public.profiles USING (true);


--
-- TOC entry 4651 (class 3256 OID 18843)
-- Name: provider_schedules Allow auth trigger and service role; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow auth trigger and service role" ON public.provider_schedules USING (true);


--
-- TOC entry 4650 (class 3256 OID 18842)
-- Name: providers Allow auth trigger and service role; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow auth trigger and service role" ON public.providers USING (true);


--
-- TOC entry 4652 (class 3256 OID 18859)
-- Name: auth_trigger_logs Allow trigger function to write logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow trigger function to write logs" ON public.auth_trigger_logs FOR INSERT WITH CHECK (true);


--
-- TOC entry 4606 (class 3256 OID 18529)
-- Name: medications Anyone can view active medications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can view active medications" ON public.medications FOR SELECT USING ((active = true));


--
-- TOC entry 4608 (class 3256 OID 18531)
-- Name: patient_medication_preferences Patients can manage own medication preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can manage own medication preferences" ON public.patient_medication_preferences USING ((EXISTS ( SELECT 1
   FROM public.patients
  WHERE ((patients.profile_id = auth.uid()) AND (patients.id = patient_medication_preferences.patient_id)))));


--
-- TOC entry 4595 (class 3256 OID 18391)
-- Name: patients Patients can update own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can update own data" ON public.patients FOR UPDATE USING ((profile_id = auth.uid()));


--
-- TOC entry 4603 (class 3256 OID 18399)
-- Name: patient_assignments Patients can view own assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view own assignments" ON public.patient_assignments FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.patients
  WHERE ((patients.id = patient_assignments.patient_id) AND (patients.profile_id = auth.uid())))));


--
-- TOC entry 4594 (class 3256 OID 18390)
-- Name: patients Patients can view own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view own data" ON public.patients FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4613 (class 3256 OID 18536)
-- Name: medication_approvals Patients can view own medication approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view own medication approvals" ON public.medication_approvals FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patients pt
     JOIN public.patient_medication_preferences pmp ON ((pt.id = pmp.patient_id)))
  WHERE ((pt.profile_id = auth.uid()) AND (pmp.id = medication_approvals.preference_id)))));


--
-- TOC entry 4615 (class 3256 OID 18538)
-- Name: medication_orders Patients can view own medication orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view own medication orders" ON public.medication_orders FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.patients
  WHERE ((patients.profile_id = auth.uid()) AND (patients.id = medication_orders.patient_id)))));


--
-- TOC entry 4637 (class 3256 OID 18803)
-- Name: clinical_notes Patients can view their clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their clinical notes" ON public.clinical_notes FOR SELECT TO authenticated USING ((patient_id IN ( SELECT p.id
   FROM (public.patients p
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4671 (class 3256 OID 19060)
-- Name: medication_approvals Patients can view their own approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their own approvals" ON public.medication_approvals FOR SELECT USING ((preference_id IN ( SELECT pmp.id
   FROM (public.patient_medication_preferences pmp
     JOIN public.patients pat ON ((pmp.patient_id = pat.id)))
  WHERE (pat.profile_id = auth.uid()))));


--
-- TOC entry 4867 (class 0 OID 0)
-- Dependencies: 4671
-- Name: POLICY "Patients can view their own approvals" ON medication_approvals; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Patients can view their own approvals" ON public.medication_approvals IS 'Allows patients to view approvals for their medication preferences';


--
-- TOC entry 4645 (class 3256 OID 18826)
-- Name: clinical_notes Patients can view their own clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their own clinical notes" ON public.clinical_notes FOR SELECT USING ((patient_id IN ( SELECT p.id
   FROM public.patients p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4676 (class 3256 OID 19066)
-- Name: faxes Patients can view their own faxes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their own faxes" ON public.faxes FOR SELECT USING ((patient_id IN ( SELECT pat.id
   FROM public.patients pat
  WHERE (pat.profile_id = auth.uid()))));


--
-- TOC entry 4868 (class 0 OID 0)
-- Dependencies: 4676
-- Name: POLICY "Patients can view their own faxes" ON faxes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Patients can view their own faxes" ON public.faxes IS 'Allows patients to view faxes related to their medications';


--
-- TOC entry 4648 (class 3256 OID 18831)
-- Name: visit_interactions Patients can view their own visit interactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their own visit interactions" ON public.visit_interactions FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4655 (class 3256 OID 18927)
-- Name: visit_addendums Patients can view their visit addendums; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their visit addendums" ON public.visit_addendums FOR SELECT TO authenticated USING ((visit_id IN ( SELECT a.id
   FROM ((public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4640 (class 3256 OID 18807)
-- Name: visit_interactions Patients can view their visit interactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their visit interactions" ON public.visit_interactions FOR SELECT TO authenticated USING ((appointment_id IN ( SELECT a.id
   FROM ((public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4669 (class 3256 OID 19057)
-- Name: medication_approvals Providers can create approvals for assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create approvals for assigned patients" ON public.medication_approvals FOR INSERT WITH CHECK (((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))) AND (preference_id IN ( SELECT pmp.id
   FROM ((public.patient_medication_preferences pmp
     JOIN public.patients pat ON ((pmp.patient_id = pat.id)))
     JOIN public.patient_assignments pa ON ((pat.id = pa.patient_id)))
  WHERE ((pa.provider_id IN ( SELECT p.id
           FROM public.providers p
          WHERE (p.profile_id = auth.uid()))) AND (pa.active = true))))));


--
-- TOC entry 4869 (class 0 OID 0)
-- Dependencies: 4669
-- Name: POLICY "Providers can create approvals for assigned patients" ON medication_approvals; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Providers can create approvals for assigned patients" ON public.medication_approvals IS 'Allows providers to create approvals only for patients assigned to them';


--
-- TOC entry 4643 (class 3256 OID 18824)
-- Name: clinical_notes Providers can create clinical notes for their patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create clinical notes for their patients" ON public.clinical_notes FOR INSERT WITH CHECK ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4674 (class 3256 OID 19064)
-- Name: faxes Providers can create faxes for assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create faxes for assigned patients" ON public.faxes FOR INSERT WITH CHECK (((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))) AND (patient_id IN ( SELECT pa.patient_id
   FROM public.patient_assignments pa
  WHERE ((pa.provider_id IN ( SELECT p.id
           FROM public.providers p
          WHERE (p.profile_id = auth.uid()))) AND (pa.active = true))))));


--
-- TOC entry 4870 (class 0 OID 0)
-- Dependencies: 4674
-- Name: POLICY "Providers can create faxes for assigned patients" ON faxes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Providers can create faxes for assigned patients" ON public.faxes IS 'Allows providers to create faxes only for patients assigned to them';


--
-- TOC entry 4618 (class 3256 OID 18550)
-- Name: medication_orders Providers can create orders for assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create orders for assigned patients" ON public.medication_orders FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = medication_orders.patient_id)))));


--
-- TOC entry 4647 (class 3256 OID 18829)
-- Name: visit_interactions Providers can create visit interactions for their appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create visit interactions for their appointments" ON public.visit_interactions FOR INSERT WITH CHECK ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.providers p ON ((a.provider_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4654 (class 3256 OID 18926)
-- Name: visit_addendums Providers can manage addendums for their patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can manage addendums for their patients" ON public.visit_addendums TO authenticated USING ((provider_id IN ( SELECT p.id
   FROM (public.providers p
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4611 (class 3256 OID 18534)
-- Name: medication_approvals Providers can manage approvals for assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can manage approvals for assigned patients" ON public.medication_approvals USING ((EXISTS ( SELECT 1
   FROM ((public.providers p
     JOIN public.patient_assignments pa ON ((p.id = pa.provider_id)))
     JOIN public.patient_medication_preferences pmp ON ((pa.patient_id = pmp.patient_id)))
  WHERE ((p.profile_id = auth.uid()) AND (pmp.id = medication_approvals.preference_id)))));


--
-- TOC entry 4636 (class 3256 OID 18802)
-- Name: clinical_notes Providers can manage clinical notes for their patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can manage clinical notes for their patients" ON public.clinical_notes TO authenticated USING ((provider_id IN ( SELECT p.id
   FROM (public.providers p
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4639 (class 3256 OID 18805)
-- Name: visit_interactions Providers can manage visit interactions for their patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can manage visit interactions for their patients" ON public.visit_interactions TO authenticated USING ((appointment_id IN ( SELECT a.id
   FROM ((public.appointments a
     JOIN public.providers p ON ((a.provider_id = p.id)))
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4619 (class 3256 OID 18551)
-- Name: medication_orders Providers can update assigned patient orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update assigned patient orders" ON public.medication_orders FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = medication_orders.patient_id)))));


--
-- TOC entry 4620 (class 3256 OID 18552)
-- Name: patient_medication_preferences Providers can update assigned patient preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update assigned patient preferences" ON public.patient_medication_preferences FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = patient_medication_preferences.patient_id)))));


--
-- TOC entry 4599 (class 3256 OID 18395)
-- Name: providers Providers can update own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update own data" ON public.providers FOR UPDATE USING ((profile_id = auth.uid()));


--
-- TOC entry 4670 (class 3256 OID 19059)
-- Name: medication_approvals Providers can update their own approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update their own approvals" ON public.medication_approvals FOR UPDATE USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4644 (class 3256 OID 18825)
-- Name: clinical_notes Providers can update their own clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update their own clinical notes" ON public.clinical_notes FOR UPDATE USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4675 (class 3256 OID 19065)
-- Name: faxes Providers can update their own faxes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update their own faxes" ON public.faxes FOR UPDATE USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4617 (class 3256 OID 18540)
-- Name: medication_orders Providers can view assigned patient orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view assigned patient orders" ON public.medication_orders FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = medication_orders.patient_id)))));


--
-- TOC entry 4609 (class 3256 OID 18532)
-- Name: patient_medication_preferences Providers can view assigned patient preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view assigned patient preferences" ON public.patient_medication_preferences FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = patient_medication_preferences.patient_id)))));


--
-- TOC entry 4596 (class 3256 OID 18392)
-- Name: patients Providers can view assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view assigned patients" ON public.patients FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((p.id = pa.provider_id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = patients.id) AND (pa.active = true)))));


--
-- TOC entry 4598 (class 3256 OID 18394)
-- Name: providers Providers can view own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view own data" ON public.providers FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4604 (class 3256 OID 18400)
-- Name: patient_assignments Providers can view their assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their assignments" ON public.patient_assignments FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.providers
  WHERE ((providers.id = patient_assignments.provider_id) AND (providers.profile_id = auth.uid())))));


--
-- TOC entry 4668 (class 3256 OID 19056)
-- Name: medication_approvals Providers can view their own approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their own approvals" ON public.medication_approvals FOR SELECT USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4871 (class 0 OID 0)
-- Dependencies: 4668
-- Name: POLICY "Providers can view their own approvals" ON medication_approvals; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Providers can view their own approvals" ON public.medication_approvals IS 'Allows providers to view medication approvals they created';


--
-- TOC entry 4642 (class 3256 OID 18823)
-- Name: clinical_notes Providers can view their own clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their own clinical notes" ON public.clinical_notes FOR SELECT USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4673 (class 3256 OID 19063)
-- Name: faxes Providers can view their own faxes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their own faxes" ON public.faxes FOR SELECT USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4872 (class 0 OID 0)
-- Dependencies: 4673
-- Name: POLICY "Providers can view their own faxes" ON faxes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Providers can view their own faxes" ON public.faxes IS 'Allows providers to view faxes they sent';


--
-- TOC entry 4678 (class 3256 OID 19068)
-- Name: providers Providers can view their own record; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their own record" ON public.providers FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4873 (class 0 OID 0)
-- Dependencies: 4678
-- Name: POLICY "Providers can view their own record" ON providers; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Providers can view their own record" ON public.providers IS 'Allows providers to view their own provider record when authenticated';


--
-- TOC entry 4646 (class 3256 OID 18827)
-- Name: visit_interactions Providers can view their own visit interactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their own visit interactions" ON public.visit_interactions FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.providers p ON ((a.provider_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4662 (class 3256 OID 18991)
-- Name: admins Service role can manage admins; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage admins" ON public.admins USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = profile_id)));


--
-- TOC entry 4667 (class 3256 OID 19004)
-- Name: admins Service role can manage all admins; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage all admins" ON public.admins USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4665 (class 3256 OID 19002)
-- Name: patients Service role can manage all patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage all patients" ON public.patients USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4664 (class 3256 OID 19001)
-- Name: profiles Service role can manage all profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage all profiles" ON public.profiles USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4666 (class 3256 OID 19003)
-- Name: providers Service role can manage all providers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage all providers" ON public.providers USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4660 (class 3256 OID 18989)
-- Name: patients Service role can manage patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage patients" ON public.patients USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = profile_id)));


--
-- TOC entry 4658 (class 3256 OID 18987)
-- Name: profiles Service role can manage profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage profiles" ON public.profiles USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = id)));


--
-- TOC entry 4661 (class 3256 OID 18990)
-- Name: providers Service role can manage providers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage providers" ON public.providers USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = profile_id)));


--
-- TOC entry 4663 (class 3256 OID 18992)
-- Name: provider_schedules Service role can manage schedules; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage schedules" ON public.provider_schedules USING ((current_setting('role'::text) = 'service_role'::text));


--
-- TOC entry 4657 (class 3256 OID 18981)
-- Name: profiles Users can update own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING ((auth.uid() = id));


--
-- TOC entry 4659 (class 3256 OID 18988)
-- Name: profiles Users can view own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING ((auth.uid() = id));


--
-- TOC entry 4632 (class 3256 OID 18687)
-- Name: appointments admin_full_appointments_access; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_full_appointments_access ON public.appointments USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4874 (class 0 OID 0)
-- Dependencies: 4632
-- Name: POLICY admin_full_appointments_access ON appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY admin_full_appointments_access ON public.appointments IS 'Admins have full access to all appointment data';


--
-- TOC entry 4634 (class 3256 OID 18692)
-- Name: appointment_history admin_view_all_appointment_history; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_view_all_appointment_history ON public.appointment_history USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4626 (class 3256 OID 18680)
-- Name: provider_availability_overrides admin_view_all_overrides; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_view_all_overrides ON public.provider_availability_overrides USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4612 (class 3256 OID 18676)
-- Name: provider_schedules admin_view_all_schedules; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_view_all_schedules ON public.provider_schedules USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4581 (class 0 OID 18326)
-- Dependencies: 342
-- Name: admins; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.admins ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4635 (class 3256 OID 18693)
-- Name: appointment_history appointment_history_readonly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY appointment_history_readonly ON public.appointment_history FOR INSERT WITH CHECK (false);


--
-- TOC entry 4875 (class 0 OID 0)
-- Dependencies: 4635
-- Name: POLICY appointment_history_readonly ON appointment_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY appointment_history_readonly ON public.appointment_history IS 'History is maintained by system triggers only';


--
-- TOC entry 4590 (class 0 OID 18845)
-- Dependencies: 359
-- Name: auth_trigger_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.auth_trigger_logs ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4588 (class 0 OID 18708)
-- Dependencies: 356
-- Name: clinical_notes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.clinical_notes ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4592 (class 0 OID 19007)
-- Dependencies: 363
-- Name: faxes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.faxes ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4584 (class 0 OID 18461)
-- Dependencies: 348
-- Name: medication_approvals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medication_approvals ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4585 (class 0 OID 18482)
-- Dependencies: 349
-- Name: medication_orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medication_orders ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4582 (class 0 OID 18424)
-- Dependencies: 346
-- Name: medications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medications ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4628 (class 3256 OID 18682)
-- Name: appointments patient_booking_restrictions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_booking_restrictions ON public.appointments FOR INSERT WITH CHECK (((patient_id IN ( SELECT p.id
   FROM public.patients p
  WHERE (p.profile_id = auth.uid()))) AND (provider_id IN ( SELECT pa.provider_id
   FROM (public.patient_assignments pa
     JOIN public.patients p ON ((pa.patient_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.active = true)))) AND ((appointment_date > CURRENT_DATE) OR ((appointment_date = CURRENT_DATE) AND (start_time > LOCALTIME))) AND (appointment_date <= (CURRENT_DATE + '90 days'::interval)) AND (booked_by = 'patient'::text)));


--
-- TOC entry 4876 (class 0 OID 0)
-- Dependencies: 4628
-- Name: POLICY patient_booking_restrictions ON appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY patient_booking_restrictions ON public.appointments IS 'Enforces business rules for patient appointment booking';


--
-- TOC entry 4583 (class 0 OID 18437)
-- Dependencies: 347
-- Name: patient_medication_preferences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.patient_medication_preferences ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4629 (class 3256 OID 18684)
-- Name: appointments patient_no_delete_appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_no_delete_appointments ON public.appointments FOR DELETE USING (false);


--
-- TOC entry 4627 (class 3256 OID 18681)
-- Name: appointments patient_own_appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_own_appointments ON public.appointments USING ((patient_id IN ( SELECT p.id
   FROM public.patients p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4877 (class 0 OID 0)
-- Dependencies: 4627
-- Name: POLICY patient_own_appointments ON appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY patient_own_appointments ON public.appointments IS 'Patients can only access their own appointments';


--
-- TOC entry 4633 (class 3256 OID 18688)
-- Name: appointment_history patient_view_own_appointment_history; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_view_own_appointment_history ON public.appointment_history FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4625 (class 3256 OID 18678)
-- Name: provider_availability_overrides patient_view_provider_overrides; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_view_provider_overrides ON public.provider_availability_overrides FOR SELECT USING ((provider_id IN ( SELECT pa.provider_id
   FROM (public.patient_assignments pa
     JOIN public.patients p ON ((pa.patient_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.active = true)))));


--
-- TOC entry 4622 (class 3256 OID 18674)
-- Name: provider_schedules patient_view_provider_schedules; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_view_provider_schedules ON public.provider_schedules FOR SELECT USING ((provider_id IN ( SELECT pa.provider_id
   FROM (public.patient_assignments pa
     JOIN public.patients p ON ((pa.patient_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.active = true)))));


--
-- TOC entry 4579 (class 0 OID 18290)
-- Dependencies: 340
-- Name: patients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4578 (class 0 OID 18273)
-- Dependencies: 339
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4587 (class 0 OID 18576)
-- Dependencies: 351
-- Name: provider_availability_overrides; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.provider_availability_overrides ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4631 (class 3256 OID 18686)
-- Name: appointments provider_no_delete_appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_no_delete_appointments ON public.appointments FOR DELETE USING (false);


--
-- TOC entry 4630 (class 3256 OID 18685)
-- Name: appointments provider_own_appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_own_appointments ON public.appointments USING ((provider_id IN ( SELECT pr.id
   FROM public.providers pr
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4878 (class 0 OID 0)
-- Dependencies: 4630
-- Name: POLICY provider_own_appointments ON appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY provider_own_appointments ON public.appointments IS 'Providers can manage appointments with their patients';


--
-- TOC entry 4624 (class 3256 OID 18677)
-- Name: provider_availability_overrides provider_own_overrides_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_own_overrides_policy ON public.provider_availability_overrides USING ((provider_id IN ( SELECT pr.id
   FROM public.providers pr
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4621 (class 3256 OID 18673)
-- Name: provider_schedules provider_own_schedule_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_own_schedule_policy ON public.provider_schedules USING ((provider_id IN ( SELECT pr.id
   FROM public.providers pr
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4586 (class 0 OID 18553)
-- Dependencies: 350
-- Name: provider_schedules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.provider_schedules ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4623 (class 3256 OID 18690)
-- Name: appointment_history provider_view_appointment_history; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_view_appointment_history ON public.appointment_history FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.providers pr ON ((a.provider_id = pr.id)))
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4580 (class 0 OID 18308)
-- Dependencies: 341
-- Name: providers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4591 (class 0 OID 18903)
-- Dependencies: 361
-- Name: visit_addendums; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.visit_addendums ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4589 (class 0 OID 18766)
-- Dependencies: 358
-- Name: visit_interactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.visit_interactions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4560 (class 0 OID 17007)
-- Dependencies: 314
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4557 (class 0 OID 16509)
-- Dependencies: 289
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4564 (class 0 OID 17892)
-- Dependencies: 323
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4565 (class 0 OID 17903)
-- Dependencies: 324
-- Name: iceberg_namespaces; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.iceberg_namespaces ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4566 (class 0 OID 17919)
-- Dependencies: 325
-- Name: iceberg_tables; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.iceberg_tables ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4559 (class 0 OID 16551)
-- Dependencies: 291
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4558 (class 0 OID 16524)
-- Dependencies: 290
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4563 (class 0 OID 17848)
-- Dependencies: 322
-- Name: prefixes; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.prefixes ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4561 (class 0 OID 17795)
-- Dependencies: 320
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4562 (class 0 OID 17809)
-- Dependencies: 321
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

-- Completed on 2025-10-03 08:14:08 UTC

--
-- PostgreSQL database dump complete
--

