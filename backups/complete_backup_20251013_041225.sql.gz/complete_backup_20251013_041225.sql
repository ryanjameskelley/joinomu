--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-10-13 08:41:55 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS postgres;
--
-- TOC entry 4774 (class 1262 OID 5)
-- Name: postgres; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = icu LOCALE = 'en_US.UTF-8' ICU_LOCALE = 'en-US';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4775 (class 0 OID 0)
-- Dependencies: 4774
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- TOC entry 4776 (class 0 OID 0)
-- Name: postgres; Type: DATABASE PROPERTIES; Schema: -; Owner: -
--

ALTER DATABASE postgres SET "app.settings.jwt_secret" TO 'super-secret-jwt-token-with-at-least-32-characters-long';
ALTER DATABASE postgres SET "app.settings.jwt_exp" TO '3600';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 34 (class 2615 OID 16457)
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- TOC entry 26 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- TOC entry 4777 (class 0 OID 0)
-- Dependencies: 26
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- TOC entry 23 (class 2615 OID 16605)
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA realtime;


--
-- TOC entry 35 (class 2615 OID 16505)
-- Name: storage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA storage;


--
-- TOC entry 17 (class 2615 OID 16750)
-- Name: supabase_functions; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA supabase_functions;


--
-- TOC entry 1258 (class 1247 OID 18034)
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


--
-- TOC entry 1282 (class 1247 OID 18175)
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


--
-- TOC entry 1255 (class 1247 OID 18028)
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


--
-- TOC entry 1252 (class 1247 OID 18023)
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


--
-- TOC entry 1294 (class 1247 OID 18256)
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


--
-- TOC entry 1288 (class 1247 OID 18217)
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


--
-- TOC entry 1198 (class 1247 OID 16890)
-- Name: action; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


--
-- TOC entry 1189 (class 1247 OID 16850)
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


--
-- TOC entry 1192 (class 1247 OID 16865)
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


--
-- TOC entry 1204 (class 1247 OID 16932)
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


--
-- TOC entry 1201 (class 1247 OID 16903)
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


--
-- TOC entry 1237 (class 1247 OID 17887)
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: -
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS'
);


--
-- TOC entry 512 (class 1255 OID 16503)
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


--
-- TOC entry 4778 (class 0 OID 0)
-- Dependencies: 512
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- TOC entry 469 (class 1255 OID 18005)
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


--
-- TOC entry 427 (class 1255 OID 16502)
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


--
-- TOC entry 4779 (class 0 OID 0)
-- Dependencies: 427
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- TOC entry 425 (class 1255 OID 16501)
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


--
-- TOC entry 4780 (class 0 OID 0)
-- Dependencies: 425
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- TOC entry 377 (class 1255 OID 18425)
-- Name: assign_patient_to_provider(uuid, uuid, text, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.assign_patient_to_provider(patient_profile_id uuid, provider_profile_id uuid, treatment_type_param text DEFAULT 'general_care'::text, is_primary_param boolean DEFAULT false) RETURNS TABLE(success boolean, message text, assignment_id uuid)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  patient_id_var UUID;
  provider_id_var UUID;
  assignment_id_var UUID;
BEGIN
  -- Get the patient ID from profile ID
  SELECT id INTO patient_id_var
  FROM patients
  WHERE profile_id = patient_profile_id;
  
  IF patient_id_var IS NULL THEN
    RETURN QUERY SELECT false, 'Patient not found', NULL::UUID;
    RETURN;
  END IF;
  
  -- Get the provider ID from profile ID
  SELECT id INTO provider_id_var
  FROM providers
  WHERE profile_id = provider_profile_id AND active = true;
  
  IF provider_id_var IS NULL THEN
    RETURN QUERY SELECT false, 'Provider not found or inactive', NULL::UUID;
    RETURN;
  END IF;
  
  -- Check if assignment already exists
  IF EXISTS (
    SELECT 1 FROM patient_assignments 
    WHERE patient_id = patient_id_var 
    AND provider_id = provider_id_var
    AND treatment_type = treatment_type_param
  ) THEN
    RETURN QUERY SELECT false, 'Patient is already assigned to this provider for this treatment type', NULL::UUID;
    RETURN;
  END IF;
  
  -- Create the assignment
  INSERT INTO patient_assignments (
    patient_id,
    provider_id,
    treatment_type,
    is_primary,
    assigned_date
  ) VALUES (
    patient_id_var,
    provider_id_var,
    treatment_type_param,
    is_primary_param,
    CURRENT_DATE
  ) RETURNING id INTO assignment_id_var;
  
  RETURN QUERY SELECT true, 'Patient successfully assigned to provider', assignment_id_var;
END;
$$;


--
-- TOC entry 468 (class 1255 OID 18678)
-- Name: book_appointment(uuid, uuid, date, time without time zone, text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text DEFAULT 'consultation'::text, p_booked_by text DEFAULT 'patient'::text, p_patient_notes text DEFAULT NULL::text) RETURNS TABLE(success boolean, appointment_id uuid, message text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  v_patient_id UUID;
  v_assignment_id UUID;
  v_duration_minutes INTEGER;
  v_end_time TIME;
  v_new_appointment_id UUID;
BEGIN
  -- Get patient ID from profile ID
  SELECT p.id INTO v_patient_id
  FROM patients p
  WHERE p.profile_id = p_patient_profile_id;
  
  IF v_patient_id IS NULL THEN
    success := false;
    appointment_id := NULL;
    message := 'Patient not found';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Verify patient-provider relationship exists
  SELECT pa.id INTO v_assignment_id
  FROM patient_assignments pa
  WHERE pa.patient_id = v_patient_id
    AND pa.provider_id = p_provider_id
    AND pa.active = true
  LIMIT 1;
  
  IF v_assignment_id IS NULL THEN
    success := false;
    appointment_id := NULL;
    message := 'No active assignment between patient and provider';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Check if the requested slot is available
  SELECT ps.slot_duration_minutes INTO v_duration_minutes
  FROM provider_schedules ps
  WHERE ps.provider_id = p_provider_id
    AND ps.day_of_week = EXTRACT(DOW FROM p_appointment_date)
    AND ps.start_time <= p_start_time
    AND ps.end_time >= p_start_time + INTERVAL '30 minutes' -- minimum slot
    AND ps.active = true
    AND (p_treatment_type = ANY(ps.treatment_types) OR array_length(ps.treatment_types, 1) IS NULL)
  LIMIT 1;
  
  IF v_duration_minutes IS NULL THEN
    success := false;
    appointment_id := NULL;
    message := 'Provider not available at requested time';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Calculate end time
  v_end_time := p_start_time + INTERVAL '1 minute' * v_duration_minutes;
  
  -- Check for scheduling conflicts
  IF EXISTS (
    SELECT 1 FROM appointments a
    WHERE a.provider_id = p_provider_id
      AND a.appointment_date = p_appointment_date
      AND a.start_time = p_start_time
      AND a.status NOT IN ('cancelled', 'no_show')
  ) THEN
    success := false;
    appointment_id := NULL;
    message := 'Time slot already booked';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Check for availability overrides
  IF EXISTS (
    SELECT 1 FROM provider_availability_overrides pao
    WHERE pao.provider_id = p_provider_id
      AND pao.date = p_appointment_date
      AND pao.available = false
      AND (pao.start_time IS NULL OR p_start_time >= pao.start_time)
      AND (pao.end_time IS NULL OR v_end_time <= pao.end_time)
  ) THEN
    success := false;
    appointment_id := NULL;
    message := 'Provider not available on requested date';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Create the appointment
  INSERT INTO appointments (
    patient_id,
    provider_id,
    assignment_id,
    appointment_date,
    start_time,
    end_time,
    duration_minutes,
    treatment_type,
    appointment_type,
    status,
    patient_notes,
    booked_by,
    booked_by_user_id
  ) VALUES (
    v_patient_id,
    p_provider_id,
    v_assignment_id,
    p_appointment_date,
    p_start_time,
    v_end_time,
    v_duration_minutes,
    p_treatment_type,
    p_appointment_type,
    'scheduled',
    p_patient_notes,
    p_booked_by,
    p_patient_profile_id
  ) RETURNING id INTO v_new_appointment_id;
  
  -- Return success
  success := true;
  appointment_id := v_new_appointment_id;
  message := 'Appointment booked successfully';
  RETURN NEXT;
  RETURN;
  
EXCEPTION
  WHEN OTHERS THEN
    success := false;
    appointment_id := NULL;
    message := 'Error booking appointment: ' || SQLERRM;
    RETURN NEXT;
    RETURN;
END;
$$;


--
-- TOC entry 4781 (class 0 OID 0)
-- Dependencies: 468
-- Name: FUNCTION book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text, p_booked_by text, p_patient_notes text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text, p_booked_by text, p_patient_notes text) IS 'Books a new appointment with full validation';


--
-- TOC entry 490 (class 1255 OID 19138)
-- Name: calculate_next_prescription_due(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.calculate_next_prescription_due() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_fax_date DATE;
    v_calculated_due_date DATE;
BEGIN
    -- Only proceed if supply_days was added/changed and we have an approved status
    IF NEW.supply_days IS NOT NULL 
       AND NEW.supply_days > 0 
       AND NEW.status = 'approved'
       AND (OLD.supply_days IS NULL OR OLD.supply_days != NEW.supply_days OR OLD.status != 'approved') THEN
        
        -- Use the faxed date from the preference itself
        IF NEW.faxed IS NOT NULL THEN
            v_fax_date := NEW.faxed::date;
            v_calculated_due_date := v_fax_date + NEW.supply_days;
            
            -- Update the next_prescription_due field
            NEW.next_prescription_due := v_calculated_due_date;
            
            -- Log the calculation for debugging (if logging table exists)
            BEGIN
                INSERT INTO auth_trigger_logs (
                    step, 
                    status, 
                    message, 
                    metadata
                ) VALUES (
                    'SUPPLY_CALCULATION', 
                    'SUCCESS', 
                    'Calculated next prescription due from preference update',
                    jsonb_build_object(
                        'preference_id', NEW.id,
                        'fax_date', v_fax_date,
                        'supply_days', NEW.supply_days,
                        'calculated_due_date', v_calculated_due_date
                    )
                );
            EXCEPTION WHEN OTHERS THEN
                -- Ignore logging errors, don't fail the main operation
                NULL;
            END;
        ELSE
            -- If no fax date, set the faxed date to now when approving with supply
            NEW.faxed := NOW();
            v_fax_date := NEW.faxed::date;
            v_calculated_due_date := v_fax_date + NEW.supply_days;
            NEW.next_prescription_due := v_calculated_due_date;
            
            -- Log that we set the fax date
            BEGIN
                INSERT INTO auth_trigger_logs (
                    step, 
                    status, 
                    message, 
                    metadata
                ) VALUES (
                    'SUPPLY_CALCULATION', 
                    'SUCCESS', 
                    'Set fax date to now and calculated next prescription due',
                    jsonb_build_object(
                        'preference_id', NEW.id,
                        'fax_date', v_fax_date,
                        'supply_days', NEW.supply_days,
                        'calculated_due_date', v_calculated_due_date
                    )
                );
            EXCEPTION WHEN OTHERS THEN
                -- Ignore logging errors, don't fail the main operation
                NULL;
            END;
        END IF;
    END IF;
    
    -- Reset refill_requested flag when status changes to approved
    IF NEW.status = 'approved' AND OLD.status != 'approved' THEN
        NEW.refill_requested := FALSE;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- TOC entry 4782 (class 0 OID 0)
-- Dependencies: 490
-- Name: FUNCTION calculate_next_prescription_due(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.calculate_next_prescription_due() IS 'Calculates next_prescription_due when supply_days is updated with approved status, and resets refill_requested flag on approval';


--
-- TOC entry 452 (class 1255 OID 19066)
-- Name: calculate_next_prescription_due(uuid, date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.calculate_next_prescription_due(p_preference_id uuid, p_delivery_date date, p_frequency text DEFAULT NULL::text) RETURNS date
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_supply_days INTEGER;
    v_frequency TEXT;
    v_next_due_date DATE;
BEGIN
    -- Get supply_days and frequency from the preference
    SELECT supply_days, frequency 
    INTO v_supply_days, v_frequency
    FROM patient_medication_preferences 
    WHERE id = p_preference_id;
    
    -- Use provided frequency if given, otherwise use the preference frequency
    IF p_frequency IS NOT NULL THEN
        v_frequency := p_frequency;
    END IF;
    
    -- If supply_days is set, use it directly
    IF v_supply_days IS NOT NULL AND v_supply_days > 0 THEN
        v_next_due_date := p_delivery_date + v_supply_days;
    ELSE
        -- Fall back to frequency-based calculation
        CASE 
            WHEN v_frequency = 'daily' THEN
                v_next_due_date := p_delivery_date + INTERVAL '30 days';
            WHEN v_frequency = 'weekly' THEN
                v_next_due_date := p_delivery_date + INTERVAL '12 weeks';
            WHEN v_frequency = 'monthly' THEN
                v_next_due_date := p_delivery_date + INTERVAL '3 months';
            WHEN v_frequency = 'quarterly' THEN
                v_next_due_date := p_delivery_date + INTERVAL '3 months';
            ELSE
                -- Default to 30 days if frequency not recognized
                v_next_due_date := p_delivery_date + INTERVAL '30 days';
        END CASE;
    END IF;
    
    RETURN v_next_due_date;
END;
$$;


--
-- TOC entry 4783 (class 0 OID 0)
-- Dependencies: 452
-- Name: FUNCTION calculate_next_prescription_due(p_preference_id uuid, p_delivery_date date, p_frequency text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.calculate_next_prescription_due(p_preference_id uuid, p_delivery_date date, p_frequency text) IS 'Calculate next prescription due date using supply_days from preferences if available, otherwise fall back to frequency-based calculation';


--
-- TOC entry 450 (class 1255 OID 18680)
-- Name: cancel_appointment(uuid, text, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text) RETURNS TABLE(success boolean, message text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  v_appointment RECORD;
BEGIN
  -- Get appointment details
  SELECT * INTO v_appointment
  FROM appointments
  WHERE id = p_appointment_id;
  
  IF NOT FOUND THEN
    success := false;
    message := 'Appointment not found';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Check if appointment can be cancelled
  IF v_appointment.status NOT IN ('scheduled', 'confirmed') THEN
    success := false;
    message := 'Appointment cannot be cancelled in current status: ' || v_appointment.status;
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Update appointment status
  UPDATE appointments
  SET 
    status = 'cancelled',
    cancelled_at = NOW(),
    cancelled_by = p_cancelled_by,
    cancelled_by_user_id = p_cancelled_by_user_id,
    cancellation_reason = p_cancellation_reason
  WHERE id = p_appointment_id;
  
  success := true;
  message := 'Appointment cancelled successfully';
  RETURN NEXT;
  RETURN;
  
EXCEPTION
  WHEN OTHERS THEN
    success := false;
    message := 'Error cancelling appointment: ' || SQLERRM;
    RETURN NEXT;
    RETURN;
END;
$$;


--
-- TOC entry 4784 (class 0 OID 0)
-- Dependencies: 450
-- Name: FUNCTION cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text) IS 'Cancels an existing appointment with audit trail';


--
-- TOC entry 453 (class 1255 OID 19126)
-- Name: check_approval_expiry_on_delivery(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_approval_expiry_on_delivery() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only proceed if fulfillment status changed to 'delivered' and estimated_delivery is set
    IF OLD.fulfillment_status != 'delivered' AND NEW.fulfillment_status = 'delivered' AND NEW.estimated_delivery IS NOT NULL THEN
        -- Check if this specific preference should be reset due to expiry
        UPDATE public.patient_medication_preferences 
        SET 
            status = 'pending',
            updated_at = NOW()
        FROM public.medication_approvals ma
        WHERE patient_medication_preferences.id = ma.preference_id
        AND ma.id = NEW.approval_id
        AND ma.status = 'approved'
        AND ma.supply_days IS NOT NULL
        AND (NEW.estimated_delivery::DATE + INTERVAL '1 day' * ma.supply_days) <= CURRENT_DATE;
        
        -- Also run the general daily check (but it will skip if already run today)
        PERFORM public.daily_approval_reset_check();
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- TOC entry 4785 (class 0 OID 0)
-- Dependencies: 453
-- Name: FUNCTION check_approval_expiry_on_delivery(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.check_approval_expiry_on_delivery() IS 'Check preference expiry when orders are delivered and reset to pending status';


--
-- TOC entry 503 (class 1255 OID 18877)
-- Name: check_auth_trigger_health(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_auth_trigger_health() RETURNS TABLE(metric text, value integer, status text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    auth_users_count INTEGER;
    profiles_count INTEGER;
    providers_count INTEGER;
    schedules_count INTEGER;
    recent_failures INTEGER;
    missing_profiles INTEGER;
BEGIN
    -- Get counts
    SELECT COUNT(*) INTO auth_users_count FROM auth.users;
    SELECT COUNT(*) INTO profiles_count FROM public.profiles;
    SELECT COUNT(*) INTO providers_count FROM public.providers;
    SELECT COUNT(*) INTO schedules_count FROM public.provider_schedules;
    
    -- Check for missing profiles
    SELECT COUNT(*) INTO missing_profiles 
    FROM auth.users u 
    LEFT JOIN public.profiles p ON u.id = p.id 
    WHERE p.id IS NULL;
    
    -- Check recent failures
    SELECT COUNT(*) INTO recent_failures 
    FROM public.auth_trigger_logs 
    WHERE success = false 
    AND created_at > NOW() - INTERVAL '1 hour';
    
    -- Return metrics
    RETURN QUERY VALUES 
        ('auth_users', auth_users_count, CASE WHEN auth_users_count > 0 THEN 'OK' ELSE 'EMPTY' END),
        ('profiles', profiles_count, CASE WHEN profiles_count >= auth_users_count THEN 'OK' ELSE 'MISSING' END),
        ('providers', providers_count, 'INFO'),
        ('schedules', schedules_count, 'INFO'),
        ('missing_profiles', missing_profiles, CASE WHEN missing_profiles = 0 THEN 'OK' ELSE 'NEEDS_REPAIR' END),
        ('recent_failures', recent_failures, CASE WHEN recent_failures = 0 THEN 'OK' ELSE 'ATTENTION' END);
END;
$$;


--
-- TOC entry 509 (class 1255 OID 19069)
-- Name: clear_overdue_faxed_status(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.clear_overdue_faxed_status() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    rows_updated INTEGER;
BEGIN
    UPDATE public.patient_medication_preferences 
    SET faxed = NULL
    WHERE faxed IS NOT NULL 
    AND next_prescription_due IS NOT NULL 
    AND next_prescription_due <= CURRENT_DATE;
    
    GET DIAGNOSTICS rows_updated = ROW_COUNT;
    RETURN rows_updated;
END;
$$;


--
-- TOC entry 4786 (class 0 OID 0)
-- Dependencies: 509
-- Name: FUNCTION clear_overdue_faxed_status(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.clear_overdue_faxed_status() IS 'Clears faxed status for preferences where prescription is now due';


--
-- TOC entry 389 (class 1255 OID 18848)
-- Name: create_default_provider_schedule(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_default_provider_schedule() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RAISE LOG 'Provider schedule trigger fired for provider ID: %', NEW.id;
    RAISE NOTICE 'Provider schedule trigger fired for provider ID: %', NEW.id;
    
    -- Add Monday-Friday 9 AM to 5 PM schedule for new provider
    INSERT INTO provider_schedules (provider_id, day_of_week, start_time, end_time, active, created_at) VALUES
    (NEW.id, 1, '09:00:00', '17:00:00', true, now()), -- Monday
    (NEW.id, 2, '09:00:00', '17:00:00', true, now()), -- Tuesday
    (NEW.id, 3, '09:00:00', '17:00:00', true, now()), -- Wednesday
    (NEW.id, 4, '09:00:00', '17:00:00', true, now()), -- Thursday
    (NEW.id, 5, '09:00:00', '17:00:00', true, now()); -- Friday
    
    RAISE LOG 'Created default schedule for provider %', NEW.id;
    RAISE NOTICE 'Created default schedule for provider %', NEW.id;
    
    RETURN NEW;
EXCEPTION
    WHEN OTHERS THEN
        -- Log error but don't fail the provider creation
        RAISE LOG 'Error creating default schedule for provider %: %', NEW.id, SQLERRM;
        RAISE NOTICE 'Error creating default schedule for provider %: %', NEW.id, SQLERRM;
        RETURN NEW;
END;
$$;


--
-- TOC entry 477 (class 1255 OID 19071)
-- Name: create_order_on_fax(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_order_on_fax() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only create order when a fax is inserted
    IF TG_OP = 'INSERT' THEN
        -- Insert medication order using profile IDs directly
        INSERT INTO public.medication_orders (
            approval_id,
            medication_id,
            patient_id,
            provider_profile_id,
            patient_profile_id,
            quantity,
            unit_price,
            total_amount
        )
        SELECT 
            NEW.approval_id,
            pmp.medication_id,
            (SELECT pt.id FROM public.patients pt WHERE pt.profile_id = NEW.patient_profile_id LIMIT 1),
            NEW.provider_profile_id,
            NEW.patient_profile_id,
            1, -- Default quantity
            COALESCE(m.unit_price, 0.00), -- Get price from medications table
            COALESCE(m.unit_price, 0.00) * 1 -- Total = unit_price * quantity
        FROM public.medication_approvals ma
        JOIN public.patient_medication_preferences pmp ON ma.preference_id = pmp.id
        JOIN public.medications m ON pmp.medication_id = m.id
        WHERE ma.id = NEW.approval_id;
        
        RETURN NEW;
    END IF;
    
    RETURN NULL;
END;
$$;


--
-- TOC entry 4787 (class 0 OID 0)
-- Dependencies: 477
-- Name: FUNCTION create_order_on_fax(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.create_order_on_fax() IS 'Creates medication order when prescription is faxed - uses profile IDs directly for simplicity';


--
-- TOC entry 500 (class 1255 OID 19125)
-- Name: daily_approval_reset_check(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.daily_approval_reset_check() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    last_run_date DATE;
    rows_reset INTEGER;
BEGIN
    -- Check when this was last run using correct column names
    SELECT (metadata->>'reset_date')::DATE 
    INTO last_run_date
    FROM public.auth_trigger_logs 
    WHERE trigger_stage = 'APPROVAL_RESET' 
    AND success = true
    ORDER BY created_at DESC 
    LIMIT 1;
    
    -- Only run if we haven't run today
    IF last_run_date IS NULL OR last_run_date < CURRENT_DATE THEN
        rows_reset := public.reset_expired_approvals();
        RETURN rows_reset;
    ELSE
        -- Log that we skipped because already ran today
        INSERT INTO public.auth_trigger_logs (trigger_stage, success, error_message, metadata, created_at)
        VALUES (
            'APPROVAL_RESET_SKIPPED', 
            true, 
            'Skipped approval reset - already ran today',
            jsonb_build_object('last_run_date', last_run_date, 'current_date', CURRENT_DATE),
            NOW()
        );
        RETURN 0;
    END IF;
END;
$$;


--
-- TOC entry 4788 (class 0 OID 0)
-- Dependencies: 500
-- Name: FUNCTION daily_approval_reset_check(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.daily_approval_reset_check() IS 'Daily check for expired approvals with duplicate run prevention (fixed to use trigger_stage and success columns)';


--
-- TOC entry 424 (class 1255 OID 19137)
-- Name: fix_existing_next_due_calculations(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fix_existing_next_due_calculations() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    preference_record RECORD;
    v_fax_date DATE;
    v_calculated_due_date DATE;
    v_updated_count INTEGER := 0;
BEGIN
    -- Loop through all preferences that have supply_days but no next_prescription_due
    FOR preference_record IN 
        SELECT id, supply_days, faxed
        FROM patient_medication_preferences 
        WHERE supply_days IS NOT NULL 
          AND supply_days > 0 
          AND (next_prescription_due IS NULL OR next_prescription_due < CURRENT_DATE)
          AND faxed IS NOT NULL
    LOOP
        -- Use the faxed date from the preference
        v_fax_date := preference_record.faxed::date;
        
        -- Calculate and update
        IF v_fax_date IS NOT NULL THEN
            v_calculated_due_date := v_fax_date + preference_record.supply_days;
            
            UPDATE patient_medication_preferences 
            SET 
                next_prescription_due = v_calculated_due_date,
                updated_at = NOW()
            WHERE id = preference_record.id;
            
            v_updated_count := v_updated_count + 1;
        END IF;
    END LOOP;
    
    RETURN v_updated_count;
END;
$$;


--
-- TOC entry 4789 (class 0 OID 0)
-- Dependencies: 424
-- Name: FUNCTION fix_existing_next_due_calculations(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.fix_existing_next_due_calculations() IS 'Fixes next_prescription_due for preferences with supply_days based on preference.faxed field';


--
-- TOC entry 436 (class 1255 OID 18681)
-- Name: get_admin_appointment_overview(date, date, uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_admin_appointment_overview(p_date_range_start date DEFAULT CURRENT_DATE, p_date_range_end date DEFAULT (CURRENT_DATE + '7 days'::interval), p_provider_id uuid DEFAULT NULL::uuid, p_patient_id uuid DEFAULT NULL::uuid) RETURNS TABLE(appointment_id uuid, patient_name text, provider_name text, appointment_date date, start_time time without time zone, end_time time without time zone, treatment_type text, appointment_type text, status text, last_updated timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    a.id as appointment_id,
    (patient_prof.first_name || ' ' || patient_prof.last_name) as patient_name,
    (provider_prof.first_name || ' ' || provider_prof.last_name) as provider_name,
    a.appointment_date,
    a.start_time,
    a.end_time,
    a.treatment_type,
    a.appointment_type,
    a.status,
    a.updated_at as last_updated
  FROM appointments a
  INNER JOIN patients p ON a.patient_id = p.id
  INNER JOIN profiles patient_prof ON p.profile_id = patient_prof.id
  INNER JOIN providers prov ON a.provider_id = prov.id
  INNER JOIN profiles provider_prof ON prov.profile_id = provider_prof.id
  WHERE a.appointment_date >= p_date_range_start
    AND a.appointment_date <= p_date_range_end
    AND (p_provider_id IS NULL OR a.provider_id = p_provider_id)
    AND (p_patient_id IS NULL OR a.patient_id = p_patient_id)
  ORDER BY a.appointment_date ASC, a.start_time ASC;
END;
$$;


--
-- TOC entry 4790 (class 0 OID 0)
-- Dependencies: 436
-- Name: FUNCTION get_admin_appointment_overview(p_date_range_start date, p_date_range_end date, p_provider_id uuid, p_patient_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_admin_appointment_overview(p_date_range_start date, p_date_range_end date, p_provider_id uuid, p_patient_id uuid) IS 'Admin dashboard view of appointments with filtering';


--
-- TOC entry 396 (class 1255 OID 18555)
-- Name: get_admin_fulfillment_queue(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_admin_fulfillment_queue() RETURNS TABLE(order_id uuid, patient_name text, medication_name text, quantity integer, total_amount numeric, payment_status text, fulfillment_status text, order_date timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    mo.id,
    CONCAT(pr.first_name, ' ', pr.last_name),
    m.name,
    mo.quantity,
    mo.total_amount,
    mo.payment_status,
    mo.fulfillment_status,
    mo.created_at
  FROM medication_orders mo
  JOIN medications m ON mo.medication_id = m.id
  JOIN patients pt ON mo.patient_id = pt.id
  JOIN profiles pr ON pt.profile_id = pr.id
  WHERE mo.fulfillment_status IN ('pending', 'processing')
  ORDER BY 
    CASE mo.payment_status 
      WHEN 'paid' THEN 1 
      ELSE 2 
    END,
    mo.created_at ASC;
END;
$$;


--
-- TOC entry 472 (class 1255 OID 18560)
-- Name: get_all_patients_for_admin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_all_patients_for_admin() RETURNS TABLE(patient_id uuid, profile_id uuid, first_name text, last_name text, email text, phone text, date_of_birth date, has_completed_intake boolean, assigned_providers text[], treatment_types text[], medications text[], created_at timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id as patient_id,
    p.profile_id,
    prof.first_name,
    prof.last_name,
    prof.email,
    p.phone,
    p.date_of_birth,
    p.has_completed_intake,
    COALESCE(
      ARRAY_AGG(
        DISTINCT CONCAT(prov_prof.first_name, ' ', prov_prof.last_name)
      ) FILTER (WHERE pa.id IS NOT NULL),
      '{}'::TEXT[]
    ) as assigned_providers,
    COALESCE(
      ARRAY_AGG(DISTINCT pa.treatment_type) FILTER (WHERE pa.treatment_type IS NOT NULL),
      '{}'::TEXT[]
    ) as treatment_types,
    COALESCE(
      ARRAY_AGG(DISTINCT m.name) FILTER (WHERE m.name IS NOT NULL),
      '{}'::TEXT[]
    ) as medications,
    p.created_at
  FROM patients p
  INNER JOIN profiles prof ON p.profile_id = prof.id
  LEFT JOIN patient_assignments pa ON p.profile_id = pa.patient_id
  LEFT JOIN providers prov ON pa.provider_id = prov.id
  LEFT JOIN profiles prov_prof ON prov.profile_id = prov_prof.id
  LEFT JOIN patient_medication_preferences pmp ON p.id = pmp.patient_id
  LEFT JOIN medications m ON pmp.medication_id = m.id
  WHERE prof.role = 'patient'  -- Only include users with patient role
  GROUP BY p.id, p.profile_id, prof.first_name, prof.last_name, prof.email, p.phone, p.date_of_birth, p.has_completed_intake, p.created_at
  ORDER BY prof.first_name, prof.last_name;
END;
$$;


--
-- TOC entry 348 (class 1255 OID 19118)
-- Name: get_approvals_due_for_renewal(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_approvals_due_for_renewal() RETURNS TABLE(approval_id uuid, patient_name text, medication_name text, supply_days integer, estimated_delivery date, days_since_delivery integer, expires_on date)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        ma.id as approval_id,
        (p.first_name || ' ' || p.last_name) as patient_name,
        m.name as medication_name,
        ma.supply_days,
        mo.estimated_delivery::DATE as estimated_delivery,
        (CURRENT_DATE - mo.estimated_delivery::DATE) as days_since_delivery,
        (mo.estimated_delivery::DATE + INTERVAL '1 day' * ma.supply_days)::DATE as expires_on
    FROM public.medication_approvals ma
    JOIN public.medication_orders mo ON ma.id = mo.approval_id
    JOIN public.patient_medication_preferences pmp ON ma.preference_id = pmp.id
    JOIN public.medications m ON pmp.medication_id = m.id
    JOIN public.patients pt ON pmp.patient_id = pt.id
    JOIN public.profiles p ON pt.profile_id = p.id
    WHERE ma.status = 'approved'
    AND ma.supply_days IS NOT NULL
    AND mo.estimated_delivery IS NOT NULL
    AND mo.fulfillment_status = 'delivered'
    AND (mo.estimated_delivery::DATE + INTERVAL '1 day' * ma.supply_days) <= CURRENT_DATE;
END;
$$;


--
-- TOC entry 4791 (class 0 OID 0)
-- Dependencies: 348
-- Name: FUNCTION get_approvals_due_for_renewal(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_approvals_due_for_renewal() IS 'Returns list of approvals that are due for renewal based on supply expiry';


--
-- TOC entry 430 (class 1255 OID 18561)
-- Name: get_assigned_patients_for_provider(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_assigned_patients_for_provider(provider_profile_id uuid) RETURNS TABLE(patient_id uuid, profile_id uuid, first_name text, last_name text, email text, phone text, date_of_birth date, treatment_type text, assigned_date date, is_primary boolean, has_completed_intake boolean, created_at timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id as patient_id,
    p.profile_id,
    prof.first_name,
    prof.last_name,
    prof.email,
    p.phone,
    p.date_of_birth,
    pa.treatment_type,
    pa.assigned_date::DATE,
    pa.is_primary,
    p.has_completed_intake,
    p.created_at
  FROM patients p
  INNER JOIN profiles prof ON p.profile_id = prof.id
  INNER JOIN patient_assignments pa ON p.id = pa.patient_id  -- Fixed: was p.profile_id = pa.patient_id
  INNER JOIN providers prov ON pa.provider_id = prov.id
  WHERE prov.profile_id = provider_profile_id
  ORDER BY pa.assigned_date DESC, prof.first_name, prof.last_name;
END;
$$;


--
-- TOC entry 433 (class 1255 OID 18988)
-- Name: get_available_slots_for_provider(uuid, date, date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text DEFAULT NULL::text) RETURNS TABLE(slot_date date, slot_start_time time without time zone, slot_end_time time without time zone, duration_minutes integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY
  WITH RECURSIVE date_series AS (
    SELECT p_start_date AS date
    UNION ALL
    SELECT date + 1
    FROM date_series
    WHERE date < p_end_date
  ),
  provider_daily_schedule AS (
    SELECT 
      ds.date,
      ps.start_time,
      ps.end_time,
      ps.slot_duration_minutes,
      ps.treatment_types
    FROM date_series ds
    CROSS JOIN provider_schedules ps
    WHERE ps.provider_id = p_provider_id
      AND ps.active = true
      AND ps.day_of_week = EXTRACT(DOW FROM ds.date)
      AND (
        p_treatment_type IS NULL 
        OR array_length(ps.treatment_types, 1) IS NULL 
        OR p_treatment_type = ANY(ps.treatment_types)
      )
  ),
  time_slots AS (
    SELECT 
      pds.date,
      slot_time::TIME AS start_time,
      (slot_time + (pds.slot_duration_minutes || ' minutes')::INTERVAL)::TIME AS end_time,
      pds.slot_duration_minutes
    FROM provider_daily_schedule pds
    CROSS JOIN LATERAL generate_series(
      pds.date + pds.start_time,
      pds.date + pds.end_time - (pds.slot_duration_minutes || ' minutes')::INTERVAL,
      (pds.slot_duration_minutes || ' minutes')::INTERVAL
    ) AS slot_time
  )
  SELECT 
    ts.date AS slot_date,
    ts.start_time AS slot_start_time,
    ts.end_time AS slot_end_time,
    ts.slot_duration_minutes AS duration_minutes
  FROM time_slots ts
  LEFT JOIN appointments a ON (
    a.provider_id = p_provider_id
    AND a.appointment_date = ts.date
    AND a.start_time = ts.start_time
    AND a.status IN ('scheduled', 'confirmed')
    AND (a.is_reschedule_source IS NULL OR a.is_reschedule_source = false)
  )
  WHERE a.id IS NULL  -- Only return slots that don't have existing appointments
  ORDER BY ts.date, ts.start_time;
END;
$$;


--
-- TOC entry 4792 (class 0 OID 0)
-- Dependencies: 433
-- Name: FUNCTION get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text) IS 'Returns available appointment slots for a provider excluding rescheduled appointments';


--
-- TOC entry 371 (class 1255 OID 18677)
-- Name: get_patient_appointments(uuid, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean DEFAULT false) RETURNS TABLE(appointment_id uuid, provider_name text, provider_specialty text, appointment_date date, start_time time without time zone, end_time time without time zone, treatment_type text, appointment_type text, status text, patient_notes text, provider_notes text, can_cancel boolean, can_reschedule boolean, created_at timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    a.id as appointment_id,
    (prof.first_name || ' ' || prof.last_name) as provider_name,
    prov.specialty as provider_specialty,
    a.appointment_date,
    a.start_time,
    a.end_time,
    a.treatment_type,
    a.appointment_type,
    a.status,
    a.patient_notes,
    a.provider_notes,
    -- Can cancel if appointment is scheduled/confirmed and at least 24 hours away
    CASE 
      WHEN a.status IN ('scheduled', 'confirmed') 
        AND (a.appointment_date > CURRENT_DATE + INTERVAL '1 day' 
             OR (a.appointment_date = CURRENT_DATE + INTERVAL '1 day' AND a.start_time > LOCALTIME))
      THEN true
      ELSE false
    END as can_cancel,
    -- Can reschedule if appointment is scheduled/confirmed and at least 48 hours away
    CASE 
      WHEN a.status IN ('scheduled', 'confirmed') 
        AND (a.appointment_date > CURRENT_DATE + INTERVAL '2 days'
             OR (a.appointment_date = CURRENT_DATE + INTERVAL '2 days' AND a.start_time > LOCALTIME))
      THEN true
      ELSE false
    END as can_reschedule,
    a.created_at
  FROM appointments a
  INNER JOIN patients p ON a.patient_id = p.id
  INNER JOIN providers prov ON a.provider_id = prov.id
  INNER JOIN profiles prof ON prov.profile_id = prof.id
  WHERE p.profile_id = p_patient_profile_id
    AND (p_include_past = true OR a.appointment_date >= CURRENT_DATE)
  ORDER BY a.appointment_date ASC, a.start_time ASC;
END;
$$;


--
-- TOC entry 4793 (class 0 OID 0)
-- Dependencies: 371
-- Name: FUNCTION get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean) IS 'Gets all appointments for a patient with cancellation/reschedule permissions';


--
-- TOC entry 422 (class 1255 OID 18553)
-- Name: get_patient_medication_overview(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_patient_medication_overview(patient_uuid uuid) RETURNS TABLE(medication_name text, category text, preference_status text, approval_status text, order_status text, payment_status text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    m.name,
    m.category,
    pmp.status as preference_status,
    COALESCE(ma.status, 'no_review') as approval_status,
    COALESCE(mo.fulfillment_status, 'no_order') as order_status,
    COALESCE(mo.payment_status, 'no_payment') as payment_status
  FROM patient_medication_preferences pmp
  JOIN medications m ON pmp.medication_id = m.id
  LEFT JOIN medication_approvals ma ON pmp.id = ma.preference_id
  LEFT JOIN medication_orders mo ON ma.id = mo.approval_id
  WHERE pmp.patient_id = patient_uuid
  ORDER BY pmp.created_at DESC;
END;
$$;


--
-- TOC entry 349 (class 1255 OID 18558)
-- Name: get_patient_medications_detailed(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_patient_medications_detailed(patient_uuid uuid) RETURNS TABLE(medication_id uuid, medication_name text, dosage text, supply text, status text, last_payment_date timestamp with time zone, sent_to_pharmacy_date timestamp with time zone, shipped_date timestamp with time zone, tracking_number text, order_id uuid)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        m.id as medication_id,
        m.name as medication_name,
        CONCAT(m.strength, ' ', m.dosage_form) as dosage,
        CASE 
            WHEN mo.quantity > 1 THEN CONCAT(mo.quantity::TEXT, ' units')
            ELSE '30 day supply'
        END as supply,
        mo.fulfillment_status as status,
        mo.payment_date as last_payment_date,
        mo.sent_to_pharmacy as sent_to_pharmacy_date,
        mo.shipped_date as shipped_date,
        mo.tracking_number as tracking_number,
        mo.id as order_id
    FROM medication_orders mo
    JOIN medications m ON mo.medication_id = m.id
    JOIN medication_approvals ma ON mo.approval_id = ma.id
    JOIN patient_medication_preferences pmp ON ma.preference_id = pmp.id
    WHERE mo.patient_id = patient_uuid
    AND pmp.status = 'approved'
    AND ma.status = 'approved'
    ORDER BY mo.created_at DESC;
END;
$$;


--
-- TOC entry 471 (class 1255 OID 18421)
-- Name: get_provider_by_profile_id(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_provider_by_profile_id(provider_profile_id uuid) RETURNS TABLE(provider_id uuid, profile_id uuid, first_name text, last_name text, email text, specialty text, license_number text, phone text, active boolean)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    prov.id as provider_id,
    prov.profile_id,
    prof.first_name,
    prof.last_name,
    prof.email,
    prov.specialty,
    prov.license_number,
    prov.phone,
    prov.active
  FROM providers prov
  INNER JOIN profiles prof ON prov.profile_id = prof.id
  WHERE prov.profile_id = provider_profile_id
  AND prov.active = true;
END;
$$;


--
-- TOC entry 398 (class 1255 OID 18554)
-- Name: get_provider_pending_approvals(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_provider_pending_approvals(provider_uuid uuid) RETURNS TABLE(preference_id uuid, patient_name text, medication_name text, preferred_dosage text, frequency text, patient_notes text, requested_date timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    pmp.id,
    CONCAT(pr.first_name, ' ', pr.last_name),
    m.name,
    pmp.preferred_dosage,
    pmp.frequency,
    pmp.notes,
    pmp.requested_date
  FROM patient_medication_preferences pmp
  JOIN medications m ON pmp.medication_id = m.id
  JOIN patients pt ON pmp.patient_id = pt.id
  JOIN profiles pr ON pt.profile_id = pr.id
  JOIN patient_assignments pa ON pt.id = pa.patient_id
  JOIN providers prov ON pa.provider_id = prov.id
  LEFT JOIN medication_approvals ma ON pmp.id = ma.preference_id
  WHERE prov.profile_id = provider_uuid
  AND pmp.status = 'pending'
  AND ma.id IS NULL -- No approval exists yet
  ORDER BY pmp.requested_date ASC;
END;
$$;


--
-- TOC entry 495 (class 1255 OID 18414)
-- Name: get_user_role(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_user_role(user_id uuid DEFAULT auth.uid()) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN (
    SELECT role 
    FROM profiles 
    WHERE id = user_id
  );
END;
$$;


--
-- TOC entry 441 (class 1255 OID 19022)
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    user_role TEXT;
    first_name TEXT;
    last_name TEXT;
    phone_val TEXT;
    specialty_val TEXT;
    license_number_val TEXT;
    new_provider_id UUID;
BEGIN
    -- Extract data from raw_user_meta_data only
    user_role := COALESCE(NEW.raw_user_meta_data->>'role', 'patient');
    first_name := COALESCE(
        NEW.raw_user_meta_data->>'first_name',
        NEW.raw_user_meta_data->>'firstName', 
        'User'
    );
    last_name := COALESCE(
        NEW.raw_user_meta_data->>'last_name',
        NEW.raw_user_meta_data->>'lastName', 
        'Unknown'
    );
    phone_val := NEW.raw_user_meta_data->>'phone';
    specialty_val := NEW.raw_user_meta_data->>'specialty';
    license_number_val := COALESCE(
        NEW.raw_user_meta_data->>'license_number',
        NEW.raw_user_meta_data->>'licenseNumber'
    );

    -- Create profile first with explicit schema reference
    INSERT INTO public.profiles (id, email, first_name, last_name, role, created_at, updated_at)
    VALUES (NEW.id, NEW.email, first_name, last_name, user_role, NOW(), NOW());

    -- Create role-specific records with explicit schema references
    IF user_role = 'patient' THEN
        INSERT INTO public.patients (profile_id, phone, has_completed_intake, created_at, updated_at)
        VALUES (NEW.id, phone_val, false, NOW(), NOW());

    ELSIF user_role = 'provider' THEN
        -- Create provider record and capture the ID for schedule creation
        INSERT INTO public.providers (profile_id, specialty, license_number, phone, active, created_at, updated_at)
        VALUES (NEW.id, specialty_val, license_number_val, phone_val, true, NOW(), NOW())
        RETURNING id INTO new_provider_id;

        -- Create default provider schedule (Monday-Friday, 9 AM - 5 PM)
        INSERT INTO public.provider_schedules (provider_id, day_of_week, start_time, end_time, treatment_types, active, created_at, updated_at)
        VALUES
            (new_provider_id, 1, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 2, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 3, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 4, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 5, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW());

    ELSIF user_role = 'admin' THEN
        INSERT INTO public.admins (profile_id, permissions, active, created_at, updated_at)
        VALUES (NEW.id, ARRAY['dashboard', 'patients', 'providers', 'assignments'], true, NOW(), NOW());
    END IF;

    RETURN NEW;
EXCEPTION
    WHEN OTHERS THEN
        RAISE LOG 'Error in handle_new_user trigger for user %: % - %', NEW.id, SQLSTATE, SQLERRM;
        RAISE;
END;
$$;


--
-- TOC entry 498 (class 1255 OID 18673)
-- Name: log_appointment_changes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.log_appointment_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Insert into appointment_history
  INSERT INTO appointment_history (
    appointment_id,
    action,
    performed_by,
    performed_by_user_id,
    old_values,
    new_values,
    reason
  ) VALUES (
    COALESCE(NEW.id, OLD.id),
    CASE 
      WHEN TG_OP = 'INSERT' THEN 'created'
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'cancelled' AND OLD.status != 'cancelled' THEN 'cancelled'
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'completed' AND OLD.status != 'completed' THEN 'completed'  
      WHEN TG_OP = 'UPDATE' AND (NEW.appointment_date != OLD.appointment_date OR NEW.start_time != OLD.start_time) THEN 'rescheduled'
      WHEN TG_OP = 'UPDATE' THEN 'updated'
      WHEN TG_OP = 'DELETE' THEN 'deleted'
    END,
    COALESCE(
      current_setting('app.current_user_role', true),
      'system'
    ),
    CASE 
      WHEN current_setting('app.current_user_id', true) != '' 
      THEN current_setting('app.current_user_id', true)::UUID
      ELSE NULL
    END,
    CASE WHEN TG_OP != 'INSERT' THEN to_jsonb(OLD) ELSE NULL END,
    CASE WHEN TG_OP != 'DELETE' THEN to_jsonb(NEW) ELSE NULL END,
    CASE 
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'cancelled' THEN NEW.cancellation_reason
      ELSE NULL
    END
  );
  
  RETURN COALESCE(NEW, OLD);
END;
$$;


--
-- TOC entry 376 (class 1255 OID 18876)
-- Name: repair_missing_profiles(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.repair_missing_profiles() RETURNS TABLE(user_id uuid, action_taken text, success boolean, error_message text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    user_rec RECORD;
    new_provider_id UUID;
    schedule_count INTEGER;
BEGIN
    -- Find users without profiles
    FOR user_rec IN (
        SELECT u.id, u.email, u.created_at, u.raw_user_meta_data
        FROM auth.users u
        LEFT JOIN public.profiles p ON u.id = p.id
        WHERE p.id IS NULL
        ORDER BY u.created_at DESC
    ) LOOP
        BEGIN
            -- Extract role and create profile
            DECLARE
                user_role TEXT := COALESCE(user_rec.raw_user_meta_data->>'role', 'patient');
                first_name_val TEXT := COALESCE(
                    user_rec.raw_user_meta_data->>'firstName',
                    user_rec.raw_user_meta_data->>'first_name',
                    split_part(user_rec.email, '@', 1)
                );
                last_name_val TEXT := COALESCE(
                    user_rec.raw_user_meta_data->>'lastName',
                    user_rec.raw_user_meta_data->>'last_name',
                    'User'
                );
            BEGIN
                -- Create profile
                INSERT INTO public.profiles (id, email, role, first_name, last_name, created_at)
                VALUES (user_rec.id, user_rec.email, user_role, first_name_val, last_name_val, user_rec.created_at);
                
                -- Create role-specific records
                IF user_role = 'provider' THEN
                    INSERT INTO public.providers (profile_id, specialty, license_number, active, created_at)
                    VALUES (user_rec.id, 'General Practice', 'REPAIRED', true, user_rec.created_at)
                    RETURNING id INTO new_provider_id;
                    
                    -- Create schedules
                    INSERT INTO public.provider_schedules (provider_id, day_of_week, start_time, end_time, active, created_at)
                    SELECT new_provider_id, day_num, '09:00:00'::TIME, '17:00:00'::TIME, true, user_rec.created_at
                    FROM generate_series(1, 5) AS day_num;
                    
                    GET DIAGNOSTICS schedule_count = ROW_COUNT;
                    
                    RETURN QUERY SELECT 
                        user_rec.id,
                        format('Created profile, provider, and %s schedules', schedule_count),
                        true,
                        NULL::TEXT;
                        
                ELSIF user_role = 'patient' THEN
                    INSERT INTO public.patients (profile_id, has_completed_intake, created_at)
                    VALUES (user_rec.id, false, user_rec.created_at);
                    
                    RETURN QUERY SELECT 
                        user_rec.id,
                        'Created profile and patient record',
                        true,
                        NULL::TEXT;
                        
                ELSIF user_role = 'admin' THEN
                    INSERT INTO public.admins (profile_id, permissions, active, created_at)
                    VALUES (user_rec.id, ARRAY['dashboard', 'patients', 'providers'], true, user_rec.created_at);
                    
                    RETURN QUERY SELECT 
                        user_rec.id,
                        'Created profile and admin record',
                        true,
                        NULL::TEXT;
                ELSE
                    RETURN QUERY SELECT 
                        user_rec.id,
                        'Created profile only',
                        true,
                        NULL::TEXT;
                END IF;
                
            EXCEPTION WHEN OTHERS THEN
                RETURN QUERY SELECT 
                    user_rec.id,
                    'Failed to repair',
                    false,
                    SQLERRM;
            END;
        END;
    END LOOP;
END;
$$;


--
-- TOC entry 511 (class 1255 OID 19136)
-- Name: request_prescription_refill(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.request_prescription_refill(p_preference_id uuid, p_patient_profile_id uuid) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_preference_record RECORD;
    v_patient_id UUID;
    v_days_until_due INTEGER;
BEGIN
    -- Get patient ID from profile
    SELECT id INTO v_patient_id 
    FROM patients 
    WHERE profile_id = p_patient_profile_id;
    
    IF v_patient_id IS NULL THEN
        RETURN json_build_object(
            'success', false,
            'error', 'Patient not found'
        );
    END IF;
    
    -- Get the preference record
    SELECT 
        id, 
        patient_id, 
        status, 
        next_prescription_due,
        medication_id,
        preferred_dosage,
        frequency
    INTO v_preference_record
    FROM patient_medication_preferences 
    WHERE id = p_preference_id 
      AND patient_id = v_patient_id;
    
    IF v_preference_record.id IS NULL THEN
        RETURN json_build_object(
            'success', false,
            'error', 'Medication preference not found or access denied'
        );
    END IF;
    
    -- Check if preference is currently approved
    IF v_preference_record.status != 'approved' THEN
        RETURN json_build_object(
            'success', false,
            'error', 'Can only request refills for approved medications'
        );
    END IF;
    
    -- Check if next_prescription_due exists
    IF v_preference_record.next_prescription_due IS NULL THEN
        RETURN json_build_object(
            'success', false,
            'error', 'No prescription due date found'
        );
    END IF;
    
    -- Calculate days until due
    v_days_until_due := v_preference_record.next_prescription_due::date - CURRENT_DATE;
    
    -- Only allow refill requests within 3 days of due date (or past due)
    IF v_days_until_due > 3 THEN
        RETURN json_build_object(
            'success', false,
            'error', 'Refill can only be requested within 3 days of due date'
        );
    END IF;
    
    -- Update preference status to pending AND set refill_requested = TRUE
    UPDATE patient_medication_preferences 
    SET 
        status = 'pending',
        refill_requested = TRUE,  -- Mark as patient-requested refill
        notes = COALESCE(notes, '') || 
                CASE 
                    WHEN notes IS NULL OR notes = '' THEN 
                        'Refill requested on ' || CURRENT_DATE::text
                    ELSE 
                        '; Refill requested on ' || CURRENT_DATE::text
                END,
        updated_at = NOW()
    WHERE id = p_preference_id;
    
    RETURN json_build_object(
        'success', true,
        'message', 'Refill request submitted successfully',
        'preference_id', p_preference_id,
        'new_status', 'pending',
        'refill_requested', true,
        'days_until_due', v_days_until_due
    );
    
EXCEPTION WHEN OTHERS THEN
    RETURN json_build_object(
        'success', false,
        'error', 'An error occurred while processing the refill request: ' || SQLERRM
    );
END;
$$;


--
-- TOC entry 4794 (class 0 OID 0)
-- Dependencies: 511
-- Name: FUNCTION request_prescription_refill(p_preference_id uuid, p_patient_profile_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.request_prescription_refill(p_preference_id uuid, p_patient_profile_id uuid) IS 'Allows patients to request prescription refills within 3 days of due date, sets refill_requested=TRUE for provider approval filtering';


--
-- TOC entry 373 (class 1255 OID 18962)
-- Name: reschedule_appointment(uuid, date, time without time zone, text, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text DEFAULT 'patient'::text, p_rescheduled_by_user_id uuid DEFAULT NULL::uuid, p_reason text DEFAULT NULL::text) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_old_appointment appointments%ROWTYPE;
  v_new_appointment_id UUID;
  v_new_end_time TIME;
  v_duration_minutes INTEGER;
BEGIN
  -- Get the original appointment
  SELECT * INTO v_old_appointment 
  FROM appointments 
  WHERE id = p_appointment_id AND status NOT IN ('cancelled', 'completed');
  
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Appointment not found or cannot be rescheduled'
    );
  END IF;
  
  -- Check if the new slot is available
  IF EXISTS (
    SELECT 1 FROM appointments a
    WHERE a.provider_id = v_old_appointment.provider_id
      AND a.appointment_date = p_new_date
      AND a.start_time = p_new_time
      AND a.status NOT IN ('cancelled', 'no_show')
      AND a.id != p_appointment_id
  ) THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Selected time slot is already booked'
    );
  END IF;
  
  -- Calculate new end time (preserve original duration)
  v_duration_minutes := COALESCE(v_old_appointment.duration_minutes, 30);
  v_new_end_time := p_new_time + (v_duration_minutes || ' minutes')::INTERVAL;
  
  -- Start transaction
  BEGIN
    -- Mark the original appointment as rescheduled
    UPDATE appointments 
    SET 
      status = 'rescheduled',
      updated_at = NOW()
    WHERE id = p_appointment_id;
    
    -- Create new appointment
    INSERT INTO appointments (
      patient_id,
      provider_id,
      assignment_id,
      appointment_date,
      start_time,
      end_time,
      duration_minutes,
      treatment_type,
      appointment_type,
      status,
      patient_notes,
      provider_notes,
      admin_notes,
      booked_by,
      booked_by_user_id
    ) VALUES (
      v_old_appointment.patient_id,
      v_old_appointment.provider_id,
      v_old_appointment.assignment_id,
      p_new_date,
      p_new_time,
      v_new_end_time,
      v_duration_minutes,
      v_old_appointment.treatment_type,
      v_old_appointment.appointment_type,
      'scheduled',
      v_old_appointment.patient_notes,
      v_old_appointment.provider_notes,
      'Rescheduled from ' || v_old_appointment.appointment_date || ' ' || v_old_appointment.start_time,
      p_rescheduled_by,
      p_rescheduled_by_user_id
    ) RETURNING id INTO v_new_appointment_id;
    
    -- Return success
    RETURN json_build_object(
      'success', true,
      'old_appointment_id', p_appointment_id,
      'new_appointment_id', v_new_appointment_id,
      'message', 'Appointment successfully rescheduled'
    );
    
  EXCEPTION WHEN OTHERS THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Failed to reschedule appointment: ' || SQLERRM
    );
  END;
END;
$$;


--
-- TOC entry 4795 (class 0 OID 0)
-- Dependencies: 373
-- Name: FUNCTION reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text, p_rescheduled_by_user_id uuid, p_reason text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text, p_rescheduled_by_user_id uuid, p_reason text) IS 'Reschedule an appointment to a new date and time';


--
-- TOC entry 346 (class 1255 OID 19117)
-- Name: reset_expired_approvals(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reset_expired_approvals() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    rows_updated INTEGER;
BEGIN
    -- Reset patient preferences to pending when supply period has elapsed
    -- This way they show up in the provider dashboard as new approval requests
    UPDATE public.patient_medication_preferences
    SET
        status = 'pending',
        updated_at = NOW()
    FROM public.medication_approvals ma
    JOIN public.medication_orders mo ON ma.id = mo.approval_id
    WHERE patient_medication_preferences.id = ma.preference_id
    AND ma.status = 'approved'
    AND ma.supply_days IS NOT NULL
    AND mo.estimated_delivery IS NOT NULL
    AND mo.fulfillment_status = 'delivered'
    AND (mo.estimated_delivery::DATE + INTERVAL '1 day' * ma.supply_days) <= CURRENT_DATE;

    GET DIAGNOSTICS rows_updated = ROW_COUNT;

    -- Log the action for debugging
    INSERT INTO public.auth_trigger_logs (trigger_stage, success, error_message, metadata, created_at)
    VALUES (
        'APPROVAL_RESET',
        true,
        format('Reset %s expired preferences to pending status', rows_updated),
        jsonb_build_object('reset_count', rows_updated, 'reset_date', CURRENT_DATE),
        NOW()
    );

    RETURN rows_updated;
END;
$$;


--
-- TOC entry 4796 (class 0 OID 0)
-- Dependencies: 346
-- Name: FUNCTION reset_expired_approvals(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.reset_expired_approvals() IS 'Reset expired patient preferences to pending status so they appear in provider dashboard';


--
-- TOC entry 406 (class 1255 OID 19128)
-- Name: run_daily_maintenance(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.run_daily_maintenance() RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    reset_count INTEGER;
    expired_count INTEGER;
    result JSONB;
BEGIN
    -- Run the daily approval reset check
    reset_count := public.daily_approval_reset_check();
    
    -- Get count of approvals that are currently expired but not yet reset
    SELECT COUNT(*)::INTEGER INTO expired_count
    FROM public.approval_renewal_status
    WHERE renewal_status = 'EXPIRED' AND status = 'approved';
    
    -- Return summary
    result := jsonb_build_object(
        'approvals_reset', reset_count,
        'approvals_still_expired', expired_count,
        'run_date', CURRENT_DATE,
        'run_time', NOW()
    );
    
    RETURN result;
END;
$$;


--
-- TOC entry 4797 (class 0 OID 0)
-- Dependencies: 406
-- Name: FUNCTION run_daily_maintenance(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.run_daily_maintenance() IS 'Main maintenance function to be called daily from application or cron';


--
-- TOC entry 393 (class 1255 OID 18682)
-- Name: set_appointment_context(text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_appointment_context(p_user_role text, p_user_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  PERFORM set_config('app.current_user_role', p_user_role, true);
  PERFORM set_config('app.current_user_id', p_user_id::TEXT, true);
END;
$$;


--
-- TOC entry 4798 (class 0 OID 0)
-- Dependencies: 393
-- Name: FUNCTION set_appointment_context(p_user_role text, p_user_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.set_appointment_context(p_user_role text, p_user_id uuid) IS 'Sets security context for appointment operations';


--
-- TOC entry 411 (class 1255 OID 19119)
-- Name: trigger_approval_reset(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trigger_approval_reset() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN public.reset_expired_approvals();
END;
$$;


--
-- TOC entry 4799 (class 0 OID 0)
-- Dependencies: 411
-- Name: FUNCTION trigger_approval_reset(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.trigger_approval_reset() IS 'Manually triggers the approval reset process for testing';


--
-- TOC entry 381 (class 1255 OID 18812)
-- Name: update_clinical_note_editor(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_clinical_note_editor() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Set last_updated_by to current user if available
  IF current_setting('app.current_user_id', true) != '' THEN
    NEW.last_updated_by = current_setting('app.current_user_id', true)::UUID;
  END IF;
  
  RETURN NEW;
END;
$$;


--
-- TOC entry 473 (class 1255 OID 19134)
-- Name: update_next_due_from_supply_and_fax(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_next_due_from_supply_and_fax() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    preference_record RECORD;
    v_calculated_due_date DATE;
    v_updated_count INTEGER := 0;
BEGIN
    -- Loop through all preferences that have supply_days and faxed date but no next_prescription_due
    FOR preference_record IN 
        SELECT id, supply_days, faxed::date as faxed_date
        FROM patient_medication_preferences 
        WHERE supply_days IS NOT NULL 
          AND supply_days > 0 
          AND faxed IS NOT NULL
          AND (next_prescription_due IS NULL OR next_prescription_due < CURRENT_DATE)
    LOOP
        -- Calculate next due date using faxed date from preferences
        v_calculated_due_date := preference_record.faxed_date + preference_record.supply_days;
        
        UPDATE patient_medication_preferences 
        SET 
            next_prescription_due = v_calculated_due_date,
            updated_at = NOW()
        WHERE id = preference_record.id;
        
        v_updated_count := v_updated_count + 1;
    END LOOP;
    
    RETURN v_updated_count;
END;
$$;


--
-- TOC entry 4800 (class 0 OID 0)
-- Dependencies: 473
-- Name: FUNCTION update_next_due_from_supply_and_fax(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.update_next_due_from_supply_and_fax() IS 'Updates next_prescription_due for preferences with supply_days based on faxed date from preferences table';


--
-- TOC entry 455 (class 1255 OID 19132)
-- Name: update_preference_on_medication_adjustment(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_preference_on_medication_adjustment() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_fax_date DATE;
    v_calculated_due_date DATE;
    v_preference_record RECORD;
BEGIN
    -- Only proceed if this is an approval (new_status = 'approved')
    IF NEW.new_status = 'approved' THEN
        -- Update the preference with the new values from the adjustment
        UPDATE patient_medication_preferences 
        SET 
            preferred_dosage = COALESCE(NEW.new_dosage, preferred_dosage),
            frequency = COALESCE(NEW.new_frequency, frequency),
            status = NEW.new_status,
            supply_days = COALESCE(NEW.new_supply_days, supply_days),
            notes = COALESCE(NEW.new_provider_notes, notes),
            updated_at = NOW()
        WHERE id = NEW.preference_id;
        
        -- If supply_days was provided, calculate and update next_prescription_due
        -- using the faxed field from the preference itself
        IF NEW.new_supply_days IS NOT NULL AND NEW.new_supply_days > 0 THEN
            -- Get the preference record to access the faxed field
            SELECT faxed::date
            INTO v_fax_date
            FROM patient_medication_preferences 
            WHERE id = NEW.preference_id;
            
            -- If we have a fax date, calculate next due date
            IF v_fax_date IS NOT NULL THEN
                v_calculated_due_date := v_fax_date + NEW.new_supply_days;
                
                -- Update the preference with the calculated due date
                UPDATE patient_medication_preferences 
                SET 
                    next_prescription_due = v_calculated_due_date,
                    updated_at = NOW()
                WHERE id = NEW.preference_id;
                
                -- Log the calculation for debugging (if logging table exists)
                BEGIN
                    INSERT INTO auth_trigger_logs (
                        step, 
                        status, 
                        message, 
                        metadata
                    ) VALUES (
                        'SUPPLY_CALCULATION', 
                        'SUCCESS', 
                        'Updated next prescription due based on preference fax date and supply',
                        jsonb_build_object(
                            'preference_id', NEW.preference_id,
                            'fax_date', v_fax_date,
                            'supply_days', NEW.new_supply_days,
                            'calculated_due_date', v_calculated_due_date
                        )
                    );
                EXCEPTION WHEN OTHERS THEN
                    -- Ignore logging errors, don't fail the main operation
                    NULL;
                END;
            ELSE
                -- Log that no fax date was found (if logging table exists)
                BEGIN
                    INSERT INTO auth_trigger_logs (
                        step, 
                        status, 
                        message, 
                        metadata
                    ) VALUES (
                        'SUPPLY_CALCULATION', 
                        'WARNING', 
                        'No fax date found in preference, cannot calculate next due date',
                        jsonb_build_object(
                            'preference_id', NEW.preference_id,
                            'supply_days', NEW.new_supply_days
                        )
                    );
                EXCEPTION WHEN OTHERS THEN
                    -- Ignore logging errors, don't fail the main operation
                    NULL;
                END;
            END IF;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- TOC entry 4801 (class 0 OID 0)
-- Dependencies: 455
-- Name: FUNCTION update_preference_on_medication_adjustment(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.update_preference_on_medication_adjustment() IS 'Updates patient_medication_preferences when medication adjustments are approved, using faxed date from preferences table for next_prescription_due calculation';


--
-- TOC entry 446 (class 1255 OID 19067)
-- Name: update_prescription_due_date(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_prescription_due_date() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    approval_record RECORD;
    preference_id UUID;
    approved_freq TEXT;
BEGIN
    -- Only proceed if delivery date was just set (order delivered)
    IF OLD.estimated_delivery IS NULL AND NEW.estimated_delivery IS NOT NULL THEN
        -- Get the approval and preference info
        SELECT ma.preference_id, ma.approved_frequency
        INTO preference_id, approved_freq
        FROM public.medication_approvals ma
        WHERE ma.id = NEW.approval_id;

        IF preference_id IS NOT NULL THEN
            -- Update the next prescription due date
            UPDATE public.patient_medication_preferences
            SET next_prescription_due = public.calculate_next_prescription_due(
                preference_id,
                NEW.estimated_delivery::DATE,
                approved_freq
            )
            WHERE id = preference_id;
        END IF;
    END IF;

    RETURN NEW;
END;
$$;


--
-- TOC entry 4802 (class 0 OID 0)
-- Dependencies: 446
-- Name: FUNCTION update_prescription_due_date(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.update_prescription_due_date() IS 'Updates prescription due date when medication order delivery date is set (fixed variable naming to avoid ambiguity)';


--
-- TOC entry 418 (class 1255 OID 18391)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


--
-- TOC entry 485 (class 1255 OID 18706)
-- Name: validate_appointment_business_rules(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_appointment_business_rules() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Prevent booking conflicts
  IF EXISTS (
    SELECT 1 FROM appointments a
    WHERE a.provider_id = NEW.provider_id
      AND a.appointment_date = NEW.appointment_date
      AND a.start_time = NEW.start_time
      AND a.id != COALESCE(NEW.id, '00000000-0000-0000-0000-000000000000'::UUID)
      AND a.status NOT IN ('cancelled', 'no_show')
  ) THEN
    RAISE EXCEPTION 'Appointment slot already booked';
  END IF;
  
  -- Validate appointment is within provider's schedule
  IF NOT EXISTS (
    SELECT 1 FROM provider_schedules ps
    WHERE ps.provider_id = NEW.provider_id
      AND ps.day_of_week = EXTRACT(DOW FROM NEW.appointment_date)
      AND ps.start_time <= NEW.start_time
      AND ps.end_time >= NEW.end_time
      AND ps.active = true
  ) THEN
    RAISE EXCEPTION 'Appointment outside provider schedule';
  END IF;
  
  -- Check for availability overrides that block this time
  IF EXISTS (
    SELECT 1 FROM provider_availability_overrides pao
    WHERE pao.provider_id = NEW.provider_id
      AND pao.date = NEW.appointment_date
      AND pao.available = false
      AND (pao.start_time IS NULL OR NEW.start_time >= pao.start_time)
      AND (pao.end_time IS NULL OR NEW.end_time <= pao.end_time)
  ) THEN
    RAISE EXCEPTION 'Provider not available at requested time';
  END IF;
  
  RETURN NEW;
END;
$$;


--
-- TOC entry 501 (class 1255 OID 16925)
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_;

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


--
-- TOC entry 467 (class 1255 OID 17004)
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


--
-- TOC entry 385 (class 1255 OID 16937)
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


--
-- TOC entry 510 (class 1255 OID 16887)
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
    declare
      res jsonb;
    begin
      execute format('select to_jsonb(%L::'|| type_::text || ')', val)  into res;
      return res;
    end
    $$;


--
-- TOC entry 487 (class 1255 OID 16882)
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


--
-- TOC entry 447 (class 1255 OID 16933)
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


--
-- TOC entry 367 (class 1255 OID 16944)
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS SETOF realtime.wal_rls
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
      with pub as (
        select
          concat_ws(
            ',',
            case when bool_or(pubinsert) then 'insert' else null end,
            case when bool_or(pubupdate) then 'update' else null end,
            case when bool_or(pubdelete) then 'delete' else null end
          ) as w2j_actions,
          coalesce(
            string_agg(
              realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
              ','
            ) filter (where ppt.tablename is not null and ppt.tablename not like '% %'),
            ''
          ) w2j_add_tables
        from
          pg_publication pp
          left join pg_publication_tables ppt
            on pp.pubname = ppt.pubname
        where
          pp.pubname = publication
        group by
          pp.pubname
        limit 1
      ),
      w2j as (
        select
          x.*, pub.w2j_add_tables
        from
          pub,
          pg_logical_slot_get_changes(
            slot_name, null, max_changes,
            'include-pk', 'true',
            'include-transaction', 'false',
            'include-timestamp', 'true',
            'include-type-oids', 'true',
            'format-version', '2',
            'actions', pub.w2j_actions,
            'add-tables', pub.w2j_add_tables
          ) x
      )
      select
        xyz.wal,
        xyz.is_rls_enabled,
        xyz.subscription_ids,
        xyz.errors
      from
        w2j,
        realtime.apply_rls(
          wal := w2j.data::jsonb,
          max_record_bytes := max_record_bytes
        ) xyz(wal, is_rls_enabled, subscription_ids, errors)
      where
        w2j.w2j_add_tables <> ''
        and xyz.subscription_ids[1] is not null
    $$;


--
-- TOC entry 400 (class 1255 OID 16881)
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


--
-- TOC entry 504 (class 1255 OID 17003)
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  BEGIN
    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (payload, event, topic, private, extension)
    VALUES (payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      RAISE WARNING 'ErrorSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- TOC entry 499 (class 1255 OID 16879)
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


--
-- TOC entry 470 (class 1255 OID 16914)
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


--
-- TOC entry 351 (class 1255 OID 16997)
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


--
-- TOC entry 363 (class 1255 OID 17865)
-- Name: add_prefixes(text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.add_prefixes(_bucket_id text, _name text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    prefixes text[];
BEGIN
    prefixes := "storage"."get_prefixes"("_name");

    IF array_length(prefixes, 1) > 0 THEN
        INSERT INTO storage.prefixes (name, bucket_id)
        SELECT UNNEST(prefixes) as name, "_bucket_id" ON CONFLICT DO NOTHING;
    END IF;
END;
$$;


--
-- TOC entry 378 (class 1255 OID 17791)
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


--
-- TOC entry 462 (class 1255 OID 17866)
-- Name: delete_prefix(text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.delete_prefix(_bucket_id text, _name text) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    -- Check if we can delete the prefix
    IF EXISTS(
        SELECT FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name") + 1
          AND "prefixes"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    )
    OR EXISTS(
        SELECT FROM "storage"."objects"
        WHERE "objects"."bucket_id" = "_bucket_id"
          AND "storage"."get_level"("objects"."name") = "storage"."get_level"("_name") + 1
          AND "objects"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    ) THEN
    -- There are sub-objects, skip deletion
    RETURN false;
    ELSE
        DELETE FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name")
          AND "prefixes"."name" = "_name";
        RETURN true;
    END IF;
END;
$$;


--
-- TOC entry 451 (class 1255 OID 17869)
-- Name: delete_prefix_hierarchy_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.delete_prefix_hierarchy_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    prefix text;
BEGIN
    prefix := "storage"."get_prefix"(OLD."name");

    IF coalesce(prefix, '') != '' THEN
        PERFORM "storage"."delete_prefix"(OLD."bucket_id", prefix);
    END IF;

    RETURN OLD;
END;
$$;


--
-- TOC entry 409 (class 1255 OID 17884)
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


--
-- TOC entry 382 (class 1255 OID 17765)
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    SELECT _parts[array_length(_parts,1)] INTO _filename;
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


--
-- TOC entry 502 (class 1255 OID 17764)
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


--
-- TOC entry 380 (class 1255 OID 17763)
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


--
-- TOC entry 390 (class 1255 OID 17847)
-- Name: get_level(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_level(name text) RETURNS integer
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
SELECT array_length(string_to_array("name", '/'), 1);
$$;


--
-- TOC entry 388 (class 1255 OID 17863)
-- Name: get_prefix(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_prefix(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
SELECT
    CASE WHEN strpos("name", '/') > 0 THEN
             regexp_replace("name", '[\/]{1}[^\/]+\/?$', '')
         ELSE
             ''
        END;
$_$;


--
-- TOC entry 438 (class 1255 OID 17864)
-- Name: get_prefixes(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_prefixes(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $$
DECLARE
    parts text[];
    prefixes text[];
    prefix text;
BEGIN
    -- Split the name into parts by '/'
    parts := string_to_array("name", '/');
    prefixes := '{}';

    -- Construct the prefixes, stopping one level below the last part
    FOR i IN 1..array_length(parts, 1) - 1 LOOP
            prefix := array_to_string(parts[1:i], '/');
            prefixes := array_append(prefixes, prefix);
    END LOOP;

    RETURN prefixes;
END;
$$;


--
-- TOC entry 394 (class 1255 OID 17882)
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


--
-- TOC entry 448 (class 1255 OID 17830)
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


--
-- TOC entry 454 (class 1255 OID 17793)
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(name COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                        substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1)))
                    ELSE
                        name
                END AS name, id, metadata, updated_at
            FROM
                storage.objects
            WHERE
                bucket_id = $5 AND
                name ILIKE $1 || ''%'' AND
                CASE
                    WHEN $6 != '''' THEN
                    name COLLATE "C" > $6
                ELSE true END
                AND CASE
                    WHEN $4 != '''' THEN
                        CASE
                            WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                                substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                name COLLATE "C" > $4
                            END
                    ELSE
                        true
                END
            ORDER BY
                name COLLATE "C" ASC) as e order by name COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_token, bucket_id, start_after;
END;
$_$;


--
-- TOC entry 492 (class 1255 OID 17868)
-- Name: objects_insert_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.objects_insert_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    NEW.level := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


--
-- TOC entry 374 (class 1255 OID 17883)
-- Name: objects_update_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.objects_update_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    old_prefixes TEXT[];
BEGIN
    -- Ensure this is an update operation and the name has changed
    IF TG_OP = 'UPDATE' AND (NEW."name" <> OLD."name" OR NEW."bucket_id" <> OLD."bucket_id") THEN
        -- Retrieve old prefixes
        old_prefixes := "storage"."get_prefixes"(OLD."name");

        -- Remove old prefixes that are only used by this object
        WITH all_prefixes as (
            SELECT unnest(old_prefixes) as prefix
        ),
        can_delete_prefixes as (
             SELECT prefix
             FROM all_prefixes
             WHERE NOT EXISTS (
                 SELECT 1 FROM "storage"."objects"
                 WHERE "bucket_id" = OLD."bucket_id"
                   AND "name" <> OLD."name"
                   AND "name" LIKE (prefix || '%')
             )
         )
        DELETE FROM "storage"."prefixes" WHERE name IN (SELECT prefix FROM can_delete_prefixes);

        -- Add new prefixes
        PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    END IF;
    -- Set the new level
    NEW."level" := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


--
-- TOC entry 486 (class 1255 OID 17846)
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


--
-- TOC entry 445 (class 1255 OID 17867)
-- Name: prefixes_insert_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.prefixes_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    RETURN NEW;
END;
$$;


--
-- TOC entry 440 (class 1255 OID 17780)
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql
    AS $$
declare
    can_bypass_rls BOOLEAN;
begin
    SELECT rolbypassrls
    INTO can_bypass_rls
    FROM pg_roles
    WHERE rolname = coalesce(nullif(current_setting('role', true), 'none'), current_user);

    IF can_bypass_rls THEN
        RETURN QUERY SELECT * FROM storage.search_v1_optimised(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    ELSE
        RETURN QUERY SELECT * FROM storage.search_legacy_v1(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    END IF;
end;
$$;


--
-- TOC entry 488 (class 1255 OID 17880)
-- Name: search_legacy_v1(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_legacy_v1(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select path_tokens[$1] as folder
           from storage.objects
             where objects.name ilike $2 || $3 || ''%''
               and bucket_id = $4
               and array_length(objects.path_tokens, 1) <> $1
           group by folder
           order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(objects.path_tokens, 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


--
-- TOC entry 404 (class 1255 OID 17879)
-- Name: search_v1_optimised(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v1_optimised(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select (string_to_array(name, ''/''))[level] as name
           from storage.prefixes
             where lower(prefixes.name) like lower($2 || $3) || ''%''
               and bucket_id = $4
               and level = $1
           order by name ' || v_sort_order || '
     )
     (select name,
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[level] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where lower(objects.name) like lower($2 || $3) || ''%''
       and bucket_id = $4
       and level = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


--
-- TOC entry 481 (class 1255 OID 17874)
-- Name: search_v2(text, text, integer, integer, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
BEGIN
    RETURN query EXECUTE
        $sql$
        SELECT * FROM (
            (
                SELECT
                    split_part(name, '/', $4) AS key,
                    name || '/' AS name,
                    NULL::uuid AS id,
                    NULL::timestamptz AS updated_at,
                    NULL::timestamptz AS created_at,
                    NULL::jsonb AS metadata
                FROM storage.prefixes
                WHERE name COLLATE "C" LIKE $1 || '%'
                AND bucket_id = $2
                AND level = $4
                AND name COLLATE "C" > $5
                ORDER BY prefixes.name COLLATE "C" LIMIT $3
            )
            UNION ALL
            (SELECT split_part(name, '/', $4) AS key,
                name,
                id,
                updated_at,
                created_at,
                metadata
            FROM storage.objects
            WHERE name COLLATE "C" LIKE $1 || '%'
                AND bucket_id = $2
                AND level = $4
                AND name COLLATE "C" > $5
            ORDER BY name COLLATE "C" LIMIT $3)
        ) obj
        ORDER BY name COLLATE "C" LIMIT $3;
        $sql$
        USING prefix, bucket_name, limits, levels, start_after;
END;
$_$;


--
-- TOC entry 482 (class 1255 OID 17781)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


--
-- TOC entry 458 (class 1255 OID 16774)
-- Name: http_request(); Type: FUNCTION; Schema: supabase_functions; Owner: -
--

CREATE FUNCTION supabase_functions.http_request() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'supabase_functions'
    AS $$
  DECLARE
    request_id bigint;
    payload jsonb;
    url text := TG_ARGV[0]::text;
    method text := TG_ARGV[1]::text;
    headers jsonb DEFAULT '{}'::jsonb;
    params jsonb DEFAULT '{}'::jsonb;
    timeout_ms integer DEFAULT 1000;
  BEGIN
    IF url IS NULL OR url = 'null' THEN
      RAISE EXCEPTION 'url argument is missing';
    END IF;

    IF method IS NULL OR method = 'null' THEN
      RAISE EXCEPTION 'method argument is missing';
    END IF;

    IF TG_ARGV[2] IS NULL OR TG_ARGV[2] = 'null' THEN
      headers = '{"Content-Type": "application/json"}'::jsonb;
    ELSE
      headers = TG_ARGV[2]::jsonb;
    END IF;

    IF TG_ARGV[3] IS NULL OR TG_ARGV[3] = 'null' THEN
      params = '{}'::jsonb;
    ELSE
      params = TG_ARGV[3]::jsonb;
    END IF;

    IF TG_ARGV[4] IS NULL OR TG_ARGV[4] = 'null' THEN
      timeout_ms = 1000;
    ELSE
      timeout_ms = TG_ARGV[4]::integer;
    END IF;

    CASE
      WHEN method = 'GET' THEN
        SELECT http_get INTO request_id FROM net.http_get(
          url,
          params,
          headers,
          timeout_ms
        );
      WHEN method = 'POST' THEN
        payload = jsonb_build_object(
          'old_record', OLD,
          'record', NEW,
          'type', TG_OP,
          'table', TG_TABLE_NAME,
          'schema', TG_TABLE_SCHEMA
        );

        SELECT http_post INTO request_id FROM net.http_post(
          url,
          payload,
          params,
          headers,
          timeout_ms
        );
      ELSE
        RAISE EXCEPTION 'method argument % is invalid', method;
    END CASE;

    INSERT INTO supabase_functions.hooks
      (hook_table_id, hook_name, request_id)
    VALUES
      (TG_RELID, TG_NAME, request_id);

    RETURN NEW;
  END
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 265 (class 1259 OID 16488)
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


--
-- TOC entry 4803 (class 0 OID 0)
-- Dependencies: 265
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- TOC entry 313 (class 1259 OID 18179)
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text NOT NULL,
    code_challenge_method auth.code_challenge_method NOT NULL,
    code_challenge text NOT NULL,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone
);


--
-- TOC entry 4804 (class 0 OID 0)
-- Dependencies: 313
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.flow_state IS 'stores metadata for pkce logins';


--
-- TOC entry 304 (class 1259 OID 17977)
-- Name: identities; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 4805 (class 0 OID 0)
-- Dependencies: 304
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- TOC entry 4806 (class 0 OID 0)
-- Dependencies: 304
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- TOC entry 264 (class 1259 OID 16481)
-- Name: instances; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- TOC entry 4807 (class 0 OID 0)
-- Dependencies: 264
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- TOC entry 308 (class 1259 OID 18066)
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


--
-- TOC entry 4808 (class 0 OID 0)
-- Dependencies: 308
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- TOC entry 307 (class 1259 OID 18054)
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


--
-- TOC entry 4809 (class 0 OID 0)
-- Dependencies: 307
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- TOC entry 306 (class 1259 OID 18041)
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid
);


--
-- TOC entry 4810 (class 0 OID 0)
-- Dependencies: 306
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- TOC entry 315 (class 1259 OID 18261)
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_id text NOT NULL,
    client_secret_hash text NOT NULL,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048))
);


--
-- TOC entry 314 (class 1259 OID 18229)
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


--
-- TOC entry 263 (class 1259 OID 16470)
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


--
-- TOC entry 4811 (class 0 OID 0)
-- Dependencies: 263
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- TOC entry 262 (class 1259 OID 16469)
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: -
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4812 (class 0 OID 0)
-- Dependencies: 262
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: -
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- TOC entry 311 (class 1259 OID 18108)
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


--
-- TOC entry 4813 (class 0 OID 0)
-- Dependencies: 311
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- TOC entry 312 (class 1259 OID 18126)
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


--
-- TOC entry 4814 (class 0 OID 0)
-- Dependencies: 312
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- TOC entry 266 (class 1259 OID 16496)
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


--
-- TOC entry 4815 (class 0 OID 0)
-- Dependencies: 266
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- TOC entry 305 (class 1259 OID 18007)
-- Name: sessions; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text
);


--
-- TOC entry 4816 (class 0 OID 0)
-- Dependencies: 305
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- TOC entry 4817 (class 0 OID 0)
-- Dependencies: 305
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- TOC entry 310 (class 1259 OID 18093)
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


--
-- TOC entry 4818 (class 0 OID 0)
-- Dependencies: 310
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- TOC entry 309 (class 1259 OID 18084)
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


--
-- TOC entry 4819 (class 0 OID 0)
-- Dependencies: 309
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- TOC entry 4820 (class 0 OID 0)
-- Dependencies: 309
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- TOC entry 261 (class 1259 OID 16458)
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


--
-- TOC entry 4821 (class 0 OID 0)
-- Dependencies: 261
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- TOC entry 4822 (class 0 OID 0)
-- Dependencies: 261
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- TOC entry 320 (class 1259 OID 18338)
-- Name: admins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admins (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    permissions text[] DEFAULT ARRAY['dashboard'::text],
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 331 (class 1259 OID 18643)
-- Name: appointment_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointment_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    appointment_id uuid NOT NULL,
    action text NOT NULL,
    performed_by text NOT NULL,
    performed_by_user_id uuid,
    old_values jsonb,
    new_values jsonb,
    reason text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT appointment_history_action_check CHECK ((action = ANY (ARRAY['created'::text, 'updated'::text, 'cancelled'::text, 'completed'::text, 'no_show'::text, 'reschedule'::text, 'rescheduled'::text]))),
    CONSTRAINT appointment_history_performed_by_check CHECK ((performed_by = ANY (ARRAY['patient'::text, 'provider'::text, 'admin'::text, 'system'::text])))
);


--
-- TOC entry 4823 (class 0 OID 0)
-- Dependencies: 331
-- Name: TABLE appointment_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.appointment_history IS 'Complete audit trail of all appointment changes';


--
-- TOC entry 330 (class 1259 OID 18605)
-- Name: appointments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    assignment_id uuid,
    appointment_date date NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    duration_minutes integer NOT NULL,
    treatment_type text NOT NULL,
    appointment_type text DEFAULT 'consultation'::text NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    patient_notes text,
    provider_notes text,
    admin_notes text,
    booked_by text NOT NULL,
    booked_by_user_id uuid,
    booking_timestamp timestamp with time zone DEFAULT now(),
    cancelled_at timestamp with time zone,
    cancelled_by text,
    cancelled_by_user_id uuid,
    cancellation_reason text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    rescheduled_from_id uuid,
    rescheduled_to_id uuid,
    is_reschedule_source boolean DEFAULT false,
    reschedule_count integer DEFAULT 0,
    CONSTRAINT appointment_in_future CHECK (((appointment_date > CURRENT_DATE) OR ((appointment_date = CURRENT_DATE) AND (start_time >= LOCALTIME)))),
    CONSTRAINT appointments_appointment_type_check CHECK ((appointment_type = ANY (ARRAY['consultation'::text, 'follow_up'::text, 'treatment'::text, 'evaluation'::text, 'review'::text]))),
    CONSTRAINT appointments_booked_by_check CHECK ((booked_by = ANY (ARRAY['patient'::text, 'provider'::text, 'admin'::text]))),
    CONSTRAINT appointments_cancelled_by_check CHECK ((cancelled_by = ANY (ARRAY['patient'::text, 'provider'::text, 'admin'::text]))),
    CONSTRAINT appointments_duration_minutes_check CHECK ((duration_minutes > 0)),
    CONSTRAINT appointments_status_check CHECK ((status = ANY (ARRAY['scheduled'::text, 'confirmed'::text, 'completed'::text, 'cancelled'::text, 'no_show'::text, 'rescheduled'::text]))),
    CONSTRAINT valid_appointment_time CHECK ((end_time > start_time)),
    CONSTRAINT valid_cancellation CHECK (((status <> 'cancelled'::text) OR ((status = 'cancelled'::text) AND (cancelled_at IS NOT NULL) AND (cancelled_by IS NOT NULL))))
);


--
-- TOC entry 4824 (class 0 OID 0)
-- Dependencies: 330
-- Name: TABLE appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.appointments IS 'Core appointments between patients and providers';


--
-- TOC entry 4825 (class 0 OID 0)
-- Dependencies: 330
-- Name: COLUMN appointments.assignment_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.assignment_id IS 'Links appointment to specific patient-provider treatment assignment';


--
-- TOC entry 4826 (class 0 OID 0)
-- Dependencies: 330
-- Name: COLUMN appointments.booked_by_user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.booked_by_user_id IS 'Profile ID of the person who booked the appointment';


--
-- TOC entry 4827 (class 0 OID 0)
-- Dependencies: 330
-- Name: COLUMN appointments.rescheduled_from_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.rescheduled_from_id IS 'Points to original appointment if this is a rescheduled appointment';


--
-- TOC entry 4828 (class 0 OID 0)
-- Dependencies: 330
-- Name: COLUMN appointments.rescheduled_to_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.rescheduled_to_id IS 'Points to new appointment if this was rescheduled';


--
-- TOC entry 4829 (class 0 OID 0)
-- Dependencies: 330
-- Name: COLUMN appointments.is_reschedule_source; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.is_reschedule_source IS 'True if this appointment was rescheduled (original slot now available)';


--
-- TOC entry 4830 (class 0 OID 0)
-- Dependencies: 330
-- Name: COLUMN appointments.reschedule_count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.reschedule_count IS 'Number of times this appointment chain has been rescheduled';


--
-- TOC entry 326 (class 1259 OID 18473)
-- Name: medication_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medication_approvals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    preference_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    status text DEFAULT 'needs_review'::text NOT NULL,
    approved_dosage text,
    approved_frequency text,
    provider_notes text,
    contraindications text,
    approval_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    provider_profile_id uuid NOT NULL,
    supply_days integer,
    CONSTRAINT check_approval_status CHECK ((status = ANY (ARRAY['approved'::text, 'denied'::text, 'needs_review'::text])))
);


--
-- TOC entry 4831 (class 0 OID 0)
-- Dependencies: 326
-- Name: COLUMN medication_approvals.provider_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_approvals.provider_profile_id IS 'Direct reference to provider auth user ID';


--
-- TOC entry 4832 (class 0 OID 0)
-- Dependencies: 326
-- Name: COLUMN medication_approvals.supply_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_approvals.supply_days IS 'Number of days the prescription supply should last (e.g., 30, 60, 90 days)';


--
-- TOC entry 327 (class 1259 OID 18494)
-- Name: medication_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medication_orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    approval_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    medication_id uuid NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    payment_status text DEFAULT 'pending'::text NOT NULL,
    payment_method text,
    payment_date timestamp with time zone,
    fulfillment_status text DEFAULT 'pending'::text NOT NULL,
    tracking_number text,
    shipped_date timestamp with time zone,
    estimated_delivery timestamp with time zone,
    admin_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    sent_to_pharmacy timestamp with time zone,
    provider_profile_id uuid NOT NULL,
    patient_profile_id uuid NOT NULL,
    CONSTRAINT check_fulfillment_status CHECK ((fulfillment_status = ANY (ARRAY['pending'::text, 'processing'::text, 'pharmacy_fulfilled'::text, 'shipped'::text, 'delivered'::text]))),
    CONSTRAINT check_payment_status CHECK ((payment_status = ANY (ARRAY['pending'::text, 'paid'::text, 'failed'::text, 'refunded'::text]))),
    CONSTRAINT check_positive_amounts CHECK (((unit_price >= (0)::numeric) AND (total_amount >= (0)::numeric) AND (quantity > 0)))
);


--
-- TOC entry 4833 (class 0 OID 0)
-- Dependencies: 327
-- Name: COLUMN medication_orders.shipped_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_orders.shipped_date IS 'Date when medication was physically shipped to patient';


--
-- TOC entry 4834 (class 0 OID 0)
-- Dependencies: 327
-- Name: COLUMN medication_orders.sent_to_pharmacy; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_orders.sent_to_pharmacy IS 'Date when prescription was sent to pharmacy for processing';


--
-- TOC entry 4835 (class 0 OID 0)
-- Dependencies: 327
-- Name: COLUMN medication_orders.provider_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_orders.provider_profile_id IS 'Direct reference to provider auth user ID';


--
-- TOC entry 4836 (class 0 OID 0)
-- Dependencies: 327
-- Name: COLUMN medication_orders.patient_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_orders.patient_profile_id IS 'Direct reference to patient auth user ID';


--
-- TOC entry 324 (class 1259 OID 18436)
-- Name: medications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    generic_name text,
    brand_name text,
    dosage_form text NOT NULL,
    strength text NOT NULL,
    description text,
    category text NOT NULL,
    unit_price numeric(10,2) DEFAULT 0 NOT NULL,
    requires_prescription boolean DEFAULT true,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 325 (class 1259 OID 18449)
-- Name: patient_medication_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patient_medication_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    medication_id uuid NOT NULL,
    preferred_dosage text,
    frequency text,
    notes text,
    status text DEFAULT 'pending'::text NOT NULL,
    requested_date timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    medication_dosage_id uuid,
    faxed timestamp with time zone,
    next_prescription_due date,
    supply_days integer,
    refill_requested boolean DEFAULT false,
    CONSTRAINT check_preference_status CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'denied'::text, 'discontinued'::text])))
);


--
-- TOC entry 4837 (class 0 OID 0)
-- Dependencies: 325
-- Name: COLUMN patient_medication_preferences.medication_dosage_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.medication_dosage_id IS 'References the specific dosage selected by the patient. New preferred method over preferred_dosage text field.';


--
-- TOC entry 4838 (class 0 OID 0)
-- Dependencies: 325
-- Name: COLUMN patient_medication_preferences.faxed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.faxed IS 'Timestamp when prescription was last faxed to pharmacy';


--
-- TOC entry 4839 (class 0 OID 0)
-- Dependencies: 325
-- Name: COLUMN patient_medication_preferences.next_prescription_due; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.next_prescription_due IS 'Calculated date when next prescription should be due based on frequency and delivery';


--
-- TOC entry 4840 (class 0 OID 0)
-- Dependencies: 325
-- Name: COLUMN patient_medication_preferences.supply_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.supply_days IS 'Number of days of medication supply when approved via medication adjustments';


--
-- TOC entry 4841 (class 0 OID 0)
-- Dependencies: 325
-- Name: COLUMN patient_medication_preferences.refill_requested; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.refill_requested IS 'TRUE when patient has explicitly requested a refill, FALSE when preference was set to pending by admin/system';


--
-- TOC entry 318 (class 1259 OID 18302)
-- Name: patients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    date_of_birth date,
    phone text,
    has_completed_intake boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 317 (class 1259 OID 18285)
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL,
    email text NOT NULL,
    first_name text,
    last_name text,
    role text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT profiles_role_check CHECK ((role = ANY (ARRAY['patient'::text, 'admin'::text, 'provider'::text])))
);


--
-- TOC entry 342 (class 1259 OID 19120)
-- Name: approval_renewal_status; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.approval_renewal_status AS
 SELECT ma.id AS approval_id,
    ma.status,
    ma.supply_days,
    ((p.first_name || ' '::text) || p.last_name) AS patient_name,
    m.name AS medication_name,
    (mo.estimated_delivery)::date AS estimated_delivery,
    mo.fulfillment_status,
        CASE
            WHEN (ma.supply_days IS NULL) THEN NULL::date
            WHEN (mo.estimated_delivery IS NULL) THEN NULL::date
            ELSE (((mo.estimated_delivery)::date + ('1 day'::interval * (ma.supply_days)::double precision)))::date
        END AS expires_on,
        CASE
            WHEN ((ma.supply_days IS NULL) OR (mo.estimated_delivery IS NULL)) THEN 'N/A'::text
            WHEN (((mo.estimated_delivery)::date + ('1 day'::interval * (ma.supply_days)::double precision)) <= CURRENT_DATE) THEN 'EXPIRED'::text
            WHEN (((mo.estimated_delivery)::date + ('1 day'::interval * (ma.supply_days)::double precision)) <= (CURRENT_DATE + '7 days'::interval)) THEN 'EXPIRING_SOON'::text
            ELSE 'ACTIVE'::text
        END AS renewal_status
   FROM (((((public.medication_approvals ma
     JOIN public.medication_orders mo ON ((ma.id = mo.approval_id)))
     JOIN public.patient_medication_preferences pmp ON ((ma.preference_id = pmp.id)))
     JOIN public.medications m ON ((pmp.medication_id = m.id)))
     JOIN public.patients pt ON ((pmp.patient_id = pt.id)))
     JOIN public.profiles p ON ((pt.profile_id = p.id)))
  WHERE (ma.status = ANY (ARRAY['approved'::text, 'pending'::text]));


--
-- TOC entry 4842 (class 0 OID 0)
-- Dependencies: 342
-- Name: VIEW approval_renewal_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.approval_renewal_status IS 'View showing renewal status of all medication approvals';


--
-- TOC entry 323 (class 1259 OID 18427)
-- Name: assignment_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assignment_log (
    id integer NOT NULL,
    message text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- TOC entry 322 (class 1259 OID 18426)
-- Name: assignment_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assignment_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4843 (class 0 OID 0)
-- Dependencies: 322
-- Name: assignment_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assignment_log_id_seq OWNED BY public.assignment_log.id;


--
-- TOC entry 340 (class 1259 OID 18967)
-- Name: auth_trigger_debug_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_trigger_debug_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    step text,
    status text,
    error_message text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 337 (class 1259 OID 18857)
-- Name: auth_trigger_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_trigger_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    trigger_stage text NOT NULL,
    success boolean NOT NULL,
    error_message text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 334 (class 1259 OID 18720)
-- Name: clinical_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clinical_notes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    appointment_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    allergies text[] DEFAULT '{}'::text[],
    previous_medications text[] DEFAULT '{}'::text[],
    current_medications text[] DEFAULT '{}'::text[],
    clinical_note text DEFAULT ''::text,
    internal_note text DEFAULT ''::text,
    visit_summary text DEFAULT ''::text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    created_by uuid,
    last_updated_by uuid
);


--
-- TOC entry 4844 (class 0 OID 0)
-- Dependencies: 334
-- Name: TABLE clinical_notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.clinical_notes IS 'Clinical notes and medical information recorded during patient visits';


--
-- TOC entry 4845 (class 0 OID 0)
-- Dependencies: 334
-- Name: COLUMN clinical_notes.appointment_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.appointment_id IS 'Links clinical note to specific appointment';


--
-- TOC entry 4846 (class 0 OID 0)
-- Dependencies: 334
-- Name: COLUMN clinical_notes.allergies; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.allergies IS 'Array of patient allergies recorded during visit';


--
-- TOC entry 4847 (class 0 OID 0)
-- Dependencies: 334
-- Name: COLUMN clinical_notes.previous_medications; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.previous_medications IS 'Array of previous medications mentioned during visit';


--
-- TOC entry 4848 (class 0 OID 0)
-- Dependencies: 334
-- Name: COLUMN clinical_notes.current_medications; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.current_medications IS 'Array of current medications mentioned during visit';


--
-- TOC entry 4849 (class 0 OID 0)
-- Dependencies: 334
-- Name: COLUMN clinical_notes.clinical_note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.clinical_note IS 'Main clinical observations and notes';


--
-- TOC entry 4850 (class 0 OID 0)
-- Dependencies: 334
-- Name: COLUMN clinical_notes.internal_note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.internal_note IS 'Internal provider notes, not visible to patients';


--
-- TOC entry 4851 (class 0 OID 0)
-- Dependencies: 334
-- Name: COLUMN clinical_notes.visit_summary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.visit_summary IS 'Auto-generated or custom summary of the visit';


--
-- TOC entry 341 (class 1259 OID 19024)
-- Name: faxes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.faxes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    approval_id uuid NOT NULL,
    preference_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    fax_number text NOT NULL,
    fax_content text,
    fax_status text DEFAULT 'sent'::text NOT NULL,
    faxed_at timestamp with time zone DEFAULT now() NOT NULL,
    delivery_confirmation_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    provider_profile_id uuid NOT NULL,
    patient_profile_id uuid NOT NULL,
    CONSTRAINT faxes_fax_status_check CHECK ((fax_status = ANY (ARRAY['sent'::text, 'delivered'::text, 'failed'::text, 'pending'::text])))
);


--
-- TOC entry 4852 (class 0 OID 0)
-- Dependencies: 341
-- Name: TABLE faxes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.faxes IS 'Tracks all fax communications for medication prescriptions';


--
-- TOC entry 4853 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.approval_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.approval_id IS 'Reference to the medication approval that was faxed';


--
-- TOC entry 4854 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.preference_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.preference_id IS 'Reference to the patient medication preference';


--
-- TOC entry 4855 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.fax_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.fax_number IS 'Phone number or fax identifier where prescription was sent';


--
-- TOC entry 4856 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.fax_content; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.fax_content IS 'Content or description of what was faxed';


--
-- TOC entry 4857 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.fax_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.fax_status IS 'Status of the fax transmission';


--
-- TOC entry 4858 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.faxed_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.faxed_at IS 'When the fax was sent';


--
-- TOC entry 4859 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.delivery_confirmation_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.delivery_confirmation_at IS 'When delivery was confirmed';


--
-- TOC entry 4860 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.provider_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.provider_profile_id IS 'Direct reference to provider auth user ID';


--
-- TOC entry 4861 (class 0 OID 0)
-- Dependencies: 341
-- Name: COLUMN faxes.patient_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.faxes.patient_profile_id IS 'Direct reference to patient auth user ID';


--
-- TOC entry 338 (class 1259 OID 18890)
-- Name: medication_dosages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medication_dosages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    medication_id uuid NOT NULL,
    strength text NOT NULL,
    unit_price numeric(10,2) DEFAULT 0 NOT NULL,
    available boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 4862 (class 0 OID 0)
-- Dependencies: 338
-- Name: TABLE medication_dosages; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.medication_dosages IS 'Stores multiple dosage options for each medication. Replaces the single strength field in medications table.';


--
-- TOC entry 343 (class 1259 OID 19161)
-- Name: medication_tracking_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medication_tracking_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    medication_preference_id uuid NOT NULL,
    taken_date date NOT NULL,
    taken_time time without time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 321 (class 1259 OID 18357)
-- Name: patient_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patient_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    treatment_type text DEFAULT 'general_care'::text,
    is_primary boolean DEFAULT false,
    assigned_date timestamp with time zone DEFAULT now(),
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 344 (class 1259 OID 19192)
-- Name: patient_health_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patient_health_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    metric_type text NOT NULL,
    value numeric NOT NULL,
    unit text NOT NULL,
    recorded_at timestamp with time zone DEFAULT now() NOT NULL,
    synced_from text DEFAULT 'manual'::text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT patient_health_metrics_metric_type_check CHECK ((metric_type = ANY (ARRAY['weight'::text, 'heart_rate'::text, 'blood_pressure'::text, 'steps'::text, 'sleep'::text, 'blood_glucose'::text, 'exercise_minutes'::text, 'calories'::text, 'protein'::text, 'sugar'::text, 'water'::text]))),
    CONSTRAINT patient_health_metrics_synced_from_check CHECK ((synced_from = ANY (ARRAY['healthkit'::text, 'manual'::text, 'device'::text, 'provider'::text]))),
    CONSTRAINT patient_health_metrics_value_check CHECK ((value >= (0)::numeric))
);


--
-- TOC entry 329 (class 1259 OID 18588)
-- Name: provider_availability_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provider_availability_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid NOT NULL,
    date date NOT NULL,
    start_time time without time zone,
    end_time time without time zone,
    available boolean NOT NULL,
    reason text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_override_time CHECK (((available = false) OR ((available = true) AND (start_time IS NOT NULL) AND (end_time IS NOT NULL) AND (end_time > start_time))))
);


--
-- TOC entry 4863 (class 0 OID 0)
-- Dependencies: 329
-- Name: TABLE provider_availability_overrides; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.provider_availability_overrides IS 'Date-specific availability changes (vacations, special hours, etc.)';


--
-- TOC entry 4864 (class 0 OID 0)
-- Dependencies: 329
-- Name: COLUMN provider_availability_overrides.available; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provider_availability_overrides.available IS 'false=unavailable, true=special availability override';


--
-- TOC entry 328 (class 1259 OID 18565)
-- Name: provider_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provider_schedules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid NOT NULL,
    day_of_week integer NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    slot_duration_minutes integer DEFAULT 30 NOT NULL,
    treatment_types text[] DEFAULT '{}'::text[],
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT provider_schedules_day_of_week_check CHECK (((day_of_week >= 0) AND (day_of_week <= 6))),
    CONSTRAINT provider_schedules_slot_duration_minutes_check CHECK ((slot_duration_minutes > 0)),
    CONSTRAINT valid_time_range CHECK ((end_time > start_time))
);


--
-- TOC entry 4865 (class 0 OID 0)
-- Dependencies: 328
-- Name: TABLE provider_schedules; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.provider_schedules IS 'Recurring weekly availability schedules for providers';


--
-- TOC entry 4866 (class 0 OID 0)
-- Dependencies: 328
-- Name: COLUMN provider_schedules.day_of_week; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provider_schedules.day_of_week IS '0=Sunday, 1=Monday, ..., 6=Saturday';


--
-- TOC entry 4867 (class 0 OID 0)
-- Dependencies: 328
-- Name: COLUMN provider_schedules.treatment_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provider_schedules.treatment_types IS 'Empty array means available for all treatment types';


--
-- TOC entry 319 (class 1259 OID 18320)
-- Name: providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    specialty text,
    license_number text,
    phone text,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 332 (class 1259 OID 18709)
-- Name: provider_availability_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.provider_availability_summary AS
 SELECT p.id AS provider_id,
    ((prof.first_name || ' '::text) || prof.last_name) AS provider_name,
    ps.day_of_week,
        CASE ps.day_of_week
            WHEN 0 THEN 'Sunday'::text
            WHEN 1 THEN 'Monday'::text
            WHEN 2 THEN 'Tuesday'::text
            WHEN 3 THEN 'Wednesday'::text
            WHEN 4 THEN 'Thursday'::text
            WHEN 5 THEN 'Friday'::text
            WHEN 6 THEN 'Saturday'::text
            ELSE NULL::text
        END AS day_name,
    ps.start_time,
    ps.end_time,
    ps.slot_duration_minutes,
    ps.treatment_types,
    ps.active
   FROM ((public.providers p
     JOIN public.profiles prof ON ((p.profile_id = prof.id)))
     JOIN public.provider_schedules ps ON ((p.id = ps.provider_id)))
  ORDER BY p.id, ps.day_of_week, ps.start_time;


--
-- TOC entry 4868 (class 0 OID 0)
-- Dependencies: 332
-- Name: VIEW provider_availability_summary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.provider_availability_summary IS 'Easy view of all provider schedules with readable day names';


--
-- TOC entry 333 (class 1259 OID 18714)
-- Name: upcoming_appointments_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.upcoming_appointments_summary AS
 SELECT a.id AS appointment_id,
    ((patient_prof.first_name || ' '::text) || patient_prof.last_name) AS patient_name,
    ((provider_prof.first_name || ' '::text) || provider_prof.last_name) AS provider_name,
    a.appointment_date,
    a.start_time,
    a.end_time,
    a.treatment_type,
    a.appointment_type,
    a.status,
    a.created_at
   FROM ((((public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
     JOIN public.profiles patient_prof ON ((p.profile_id = patient_prof.id)))
     JOIN public.providers prov ON ((a.provider_id = prov.id)))
     JOIN public.profiles provider_prof ON ((prov.profile_id = provider_prof.id)))
  WHERE (a.appointment_date >= CURRENT_DATE)
  ORDER BY a.appointment_date, a.start_time;


--
-- TOC entry 4869 (class 0 OID 0)
-- Dependencies: 333
-- Name: VIEW upcoming_appointments_summary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.upcoming_appointments_summary IS 'Overview of all upcoming appointments with patient and provider names';


--
-- TOC entry 339 (class 1259 OID 18920)
-- Name: visit_addendums; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visit_addendums (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    visit_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT visit_addendums_content_not_empty CHECK ((length(TRIM(BOTH FROM content)) > 0))
);


--
-- TOC entry 4870 (class 0 OID 0)
-- Dependencies: 339
-- Name: TABLE visit_addendums; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.visit_addendums IS 'Addendums to previous visits for additional notes or corrections';


--
-- TOC entry 4871 (class 0 OID 0)
-- Dependencies: 339
-- Name: COLUMN visit_addendums.visit_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_addendums.visit_id IS 'Links addendum to specific appointment/visit';


--
-- TOC entry 4872 (class 0 OID 0)
-- Dependencies: 339
-- Name: COLUMN visit_addendums.provider_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_addendums.provider_id IS 'Provider who created the addendum';


--
-- TOC entry 4873 (class 0 OID 0)
-- Dependencies: 339
-- Name: COLUMN visit_addendums.content; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_addendums.content IS 'Content of the addendum';


--
-- TOC entry 4874 (class 0 OID 0)
-- Dependencies: 339
-- Name: COLUMN visit_addendums.created_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_addendums.created_at IS 'When the addendum was created';


--
-- TOC entry 336 (class 1259 OID 18778)
-- Name: visit_interactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visit_interactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinical_note_id uuid NOT NULL,
    appointment_id uuid NOT NULL,
    interaction_type text NOT NULL,
    details text,
    provider_notes text,
    created_at timestamp with time zone DEFAULT now(),
    performed_by uuid NOT NULL,
    medication_id uuid,
    medication_name text,
    previous_dosage text,
    new_dosage text,
    previous_frequency text,
    new_frequency text,
    previous_status text,
    new_status text,
    CONSTRAINT visit_interactions_interaction_type_check CHECK ((interaction_type = ANY (ARRAY['treatment_plan_update'::text, 'follow_up_scheduled'::text, 'referral_made'::text, 'lab_ordered'::text, 'allergy_noted'::text, 'vital_signs_recorded'::text]))),
    CONSTRAINT visit_interactions_new_status_check CHECK (((new_status IS NULL) OR (new_status = ANY (ARRAY['pending'::text, 'approved'::text, 'denied'::text, 'discontinued'::text]))))
);


--
-- TOC entry 4875 (class 0 OID 0)
-- Dependencies: 336
-- Name: TABLE visit_interactions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.visit_interactions IS 'General interactions and activities during visits (non-medication)';


--
-- TOC entry 4876 (class 0 OID 0)
-- Dependencies: 336
-- Name: COLUMN visit_interactions.interaction_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_interactions.interaction_type IS 'Type of interaction: treatment_plan_update, follow_up_scheduled, etc.';


--
-- TOC entry 4877 (class 0 OID 0)
-- Dependencies: 336
-- Name: COLUMN visit_interactions.details; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_interactions.details IS 'General details about the interaction';


--
-- TOC entry 335 (class 1259 OID 18753)
-- Name: visit_medication_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visit_medication_adjustments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinical_note_id uuid NOT NULL,
    appointment_id uuid NOT NULL,
    preference_id uuid NOT NULL,
    previous_dosage text,
    previous_frequency text,
    previous_status text,
    previous_provider_notes text,
    new_dosage text,
    new_frequency text,
    new_status text,
    new_provider_notes text,
    adjustment_reason text,
    provider_notes text,
    created_at timestamp with time zone DEFAULT now(),
    performed_by uuid NOT NULL,
    new_supply_days integer,
    CONSTRAINT visit_medication_adjustments_new_status_check CHECK ((new_status = ANY (ARRAY['pending'::text, 'approved'::text, 'denied'::text, 'discontinued'::text])))
);


--
-- TOC entry 4878 (class 0 OID 0)
-- Dependencies: 335
-- Name: TABLE visit_medication_adjustments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.visit_medication_adjustments IS 'Medication adjustments made during visits, links to patient_medication_preferences';


--
-- TOC entry 4879 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN visit_medication_adjustments.preference_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_medication_adjustments.preference_id IS 'Links to existing patient_medication_preferences table';


--
-- TOC entry 4880 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN visit_medication_adjustments.adjustment_reason; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_medication_adjustments.adjustment_reason IS 'Reason for the medication adjustment';


--
-- TOC entry 4881 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN visit_medication_adjustments.new_supply_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_medication_adjustments.new_supply_days IS 'Number of days of medication supply when approved via medication adjustments';


--
-- TOC entry 292 (class 1259 OID 17007)
-- Name: messages; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
)
PARTITION BY RANGE (inserted_at);


--
-- TOC entry 293 (class 1259 OID 17024)
-- Name: messages_2025_10_05; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_10_05 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 294 (class 1259 OID 17036)
-- Name: messages_2025_10_06; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_10_06 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 295 (class 1259 OID 17048)
-- Name: messages_2025_10_07; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_10_07 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 296 (class 1259 OID 17060)
-- Name: messages_2025_10_08; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_10_08 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 297 (class 1259 OID 17072)
-- Name: messages_2025_10_09; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_10_09 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 286 (class 1259 OID 16844)
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


--
-- TOC entry 289 (class 1259 OID 16867)
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);


--
-- TOC entry 288 (class 1259 OID 16866)
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: -
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 267 (class 1259 OID 16509)
-- Name: buckets; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


--
-- TOC entry 4882 (class 0 OID 0)
-- Dependencies: 267
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 301 (class 1259 OID 17892)
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_analytics (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 302 (class 1259 OID 17903)
-- Name: iceberg_namespaces; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.iceberg_namespaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 303 (class 1259 OID 17919)
-- Name: iceberg_tables; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.iceberg_tables (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    namespace_id uuid NOT NULL,
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    location text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 269 (class 1259 OID 16551)
-- Name: migrations; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 268 (class 1259 OID 16524)
-- Name: objects; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb,
    level integer
);


--
-- TOC entry 4883 (class 0 OID 0)
-- Dependencies: 268
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 300 (class 1259 OID 17848)
-- Name: prefixes; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.prefixes (
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    level integer GENERATED ALWAYS AS (storage.get_level(name)) STORED NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 298 (class 1259 OID 17795)
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb
);


--
-- TOC entry 299 (class 1259 OID 17809)
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 282 (class 1259 OID 16763)
-- Name: hooks; Type: TABLE; Schema: supabase_functions; Owner: -
--

CREATE TABLE supabase_functions.hooks (
    id bigint NOT NULL,
    hook_table_id integer NOT NULL,
    hook_name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    request_id bigint
);


--
-- TOC entry 4884 (class 0 OID 0)
-- Dependencies: 282
-- Name: TABLE hooks; Type: COMMENT; Schema: supabase_functions; Owner: -
--

COMMENT ON TABLE supabase_functions.hooks IS 'Supabase Functions Hooks: Audit trail for triggered hooks.';


--
-- TOC entry 281 (class 1259 OID 16762)
-- Name: hooks_id_seq; Type: SEQUENCE; Schema: supabase_functions; Owner: -
--

CREATE SEQUENCE supabase_functions.hooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4885 (class 0 OID 0)
-- Dependencies: 281
-- Name: hooks_id_seq; Type: SEQUENCE OWNED BY; Schema: supabase_functions; Owner: -
--

ALTER SEQUENCE supabase_functions.hooks_id_seq OWNED BY supabase_functions.hooks.id;


--
-- TOC entry 280 (class 1259 OID 16754)
-- Name: migrations; Type: TABLE; Schema: supabase_functions; Owner: -
--

CREATE TABLE supabase_functions.migrations (
    version text NOT NULL,
    inserted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 3778 (class 0 OID 0)
-- Name: messages_2025_10_05; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_05 FOR VALUES FROM ('2025-10-05 00:00:00') TO ('2025-10-06 00:00:00');


--
-- TOC entry 3779 (class 0 OID 0)
-- Name: messages_2025_10_06; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_06 FOR VALUES FROM ('2025-10-06 00:00:00') TO ('2025-10-07 00:00:00');


--
-- TOC entry 3780 (class 0 OID 0)
-- Name: messages_2025_10_07; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_07 FOR VALUES FROM ('2025-10-07 00:00:00') TO ('2025-10-08 00:00:00');


--
-- TOC entry 3781 (class 0 OID 0)
-- Name: messages_2025_10_08; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_08 FOR VALUES FROM ('2025-10-08 00:00:00') TO ('2025-10-09 00:00:00');


--
-- TOC entry 3782 (class 0 OID 0)
-- Name: messages_2025_10_09; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_09 FOR VALUES FROM ('2025-10-09 00:00:00') TO ('2025-10-10 00:00:00');


--
-- TOC entry 3792 (class 2604 OID 16473)
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- TOC entry 3881 (class 2604 OID 18430)
-- Name: assignment_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assignment_log ALTER COLUMN id SET DEFAULT nextval('public.assignment_log_id_seq'::regclass);


--
-- TOC entry 3806 (class 2604 OID 16766)
-- Name: hooks id; Type: DEFAULT; Schema: supabase_functions; Owner: -
--

ALTER TABLE ONLY supabase_functions.hooks ALTER COLUMN id SET DEFAULT nextval('supabase_functions.hooks_id_seq'::regclass);


--
-- TOC entry 4710 (class 0 OID 16488)
-- Dependencies: 265
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
00000000-0000-0000-0000-000000000000	e39f6cd5-559c-40ce-95df-7aca8d61a50a	{"action":"user_signedup","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"team","traits":{"provider":"email"}}	2025-10-06 03:35:13.028922+00	
00000000-0000-0000-0000-000000000000	f2decdc8-674a-4b38-bf99-e8689006ebfc	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 03:35:13.031342+00	
00000000-0000-0000-0000-000000000000	becaa728-512a-46be-b660-c9f0f823f2c6	{"action":"logout","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-06 03:35:20.747516+00	
00000000-0000-0000-0000-000000000000	c1147ce0-c757-453b-a8fd-f90cd621e0ba	{"action":"user_signedup","actor_id":"94700da3-b8bf-43a6-8e00-866059953329","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"team","traits":{"provider":"email"}}	2025-10-06 03:36:00.51381+00	
00000000-0000-0000-0000-000000000000	4b1f504b-f6fd-4f67-9cbd-9f868baca6f1	{"action":"login","actor_id":"94700da3-b8bf-43a6-8e00-866059953329","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 03:36:00.515947+00	
00000000-0000-0000-0000-000000000000	50633ccf-e77c-4774-8b1b-b7b53f21fc5e	{"action":"logout","actor_id":"94700da3-b8bf-43a6-8e00-866059953329","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-06 03:36:04.368691+00	
00000000-0000-0000-0000-000000000000	cb946c38-ab20-4df5-9584-3c3ca9d8dc48	{"action":"user_signedup","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"team","traits":{"provider":"email"}}	2025-10-06 03:36:28.415232+00	
00000000-0000-0000-0000-000000000000	007147f5-d032-48d5-a785-2007b4d3ae14	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 03:36:28.416788+00	
00000000-0000-0000-0000-000000000000	cba84f81-74b4-4e8a-8e8f-94821d6ea235	{"action":"logout","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-06 03:36:30.600284+00	
00000000-0000-0000-0000-000000000000	71bdbaeb-fe6e-4dbe-99d5-f1c7859c6d36	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 03:38:44.889575+00	
00000000-0000-0000-0000-000000000000	cf0e6d30-3c3c-481b-bb2c-5c63faae1263	{"action":"logout","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-06 03:39:02.752443+00	
00000000-0000-0000-0000-000000000000	cd156dae-7859-447e-90b9-22ba883bf26b	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 03:39:10.887603+00	
00000000-0000-0000-0000-000000000000	f3b8a2c3-f99a-4c2c-bc46-de721225608a	{"action":"logout","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-06 03:40:08.008355+00	
00000000-0000-0000-0000-000000000000	b0e0cf8f-825b-4681-ae20-1e956997ee7f	{"action":"login","actor_id":"94700da3-b8bf-43a6-8e00-866059953329","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 03:40:15.474695+00	
00000000-0000-0000-0000-000000000000	df2420b2-4f86-432d-a4be-166855ebc271	{"action":"login","actor_id":"94700da3-b8bf-43a6-8e00-866059953329","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 03:43:01.300565+00	
00000000-0000-0000-0000-000000000000	c5ec6e16-ec66-4c74-af09-6c4874ba186a	{"action":"logout","actor_id":"94700da3-b8bf-43a6-8e00-866059953329","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-06 03:43:27.842817+00	
00000000-0000-0000-0000-000000000000	6c46eec1-5ab8-41d5-8dbe-106eb72fda9d	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 03:43:35.94967+00	
00000000-0000-0000-0000-000000000000	81276990-7069-429f-a0c9-2cda2a29349d	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 03:59:41.177947+00	
00000000-0000-0000-0000-000000000000	affbff28-d739-4485-aedc-992cf7e81dc2	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 04:03:38.95853+00	
00000000-0000-0000-0000-000000000000	39dac693-e5b2-45b3-ad41-7cd4ce57fe5a	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 04:05:22.157423+00	
00000000-0000-0000-0000-000000000000	4cf49997-a168-4591-8858-89bafd7a7257	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 04:11:01.160403+00	
00000000-0000-0000-0000-000000000000	8b5aa17a-75fb-4e1c-9301-bbec2b68c012	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 04:15:44.933127+00	
00000000-0000-0000-0000-000000000000	551e6fe5-5e1c-410c-acb5-df4257293fdf	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 04:21:25.410447+00	
00000000-0000-0000-0000-000000000000	73ec61a7-22fe-4110-be81-a1707fa128a3	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 04:26:28.34709+00	
00000000-0000-0000-0000-000000000000	32d74b61-f6b6-4e14-bd50-37afb8451e86	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 04:30:28.170744+00	
00000000-0000-0000-0000-000000000000	e9511043-84f9-4674-9e19-7ac8eb36b104	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 04:33:01.73116+00	
00000000-0000-0000-0000-000000000000	85eed1a0-7f01-4209-9958-36e9ff3c7694	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 04:35:45.858011+00	
00000000-0000-0000-0000-000000000000	a9321aa1-c03e-4258-a5a9-751ff0977f4e	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 04:37:59.02141+00	
00000000-0000-0000-0000-000000000000	87ef86d5-b034-4c2b-8a6e-9a4a924874ed	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 04:46:16.860773+00	
00000000-0000-0000-0000-000000000000	09a81be6-4dec-4308-ad49-e4c18d1cad30	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 05:05:15.56305+00	
00000000-0000-0000-0000-000000000000	4be5f208-4bf5-4c9c-8342-c8477a940774	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 05:11:00.130781+00	
00000000-0000-0000-0000-000000000000	f251f603-27f5-4041-95d4-6ad5e149779c	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 05:38:25.048072+00	
00000000-0000-0000-0000-000000000000	3286fbe1-e0c6-4e21-b4c5-256423d9fad5	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 05:53:47.87463+00	
00000000-0000-0000-0000-000000000000	e8e50080-ee42-4bb4-89f0-12239396e5b4	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 06:11:35.213211+00	
00000000-0000-0000-0000-000000000000	dfeaf7b6-60b8-449e-9967-496632791bb0	{"action":"logout","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-06 06:11:54.332755+00	
00000000-0000-0000-0000-000000000000	602c247d-bbbb-4d2b-83b2-27db48d92074	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 06:12:01.809645+00	
00000000-0000-0000-0000-000000000000	68d4cd06-9f4c-425a-b4da-a5b0d3ed018d	{"action":"logout","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-06 06:12:21.208691+00	
00000000-0000-0000-0000-000000000000	a94f35fd-cfa5-4be2-aa70-964513443312	{"action":"login","actor_id":"94700da3-b8bf-43a6-8e00-866059953329","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 06:12:28.629593+00	
00000000-0000-0000-0000-000000000000	d594bc53-1499-477d-9c0c-ee08e3af7bf7	{"action":"logout","actor_id":"94700da3-b8bf-43a6-8e00-866059953329","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-06 06:12:44.684978+00	
00000000-0000-0000-0000-000000000000	28794a1b-db33-44d1-8a02-e7f93e862f45	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 06:12:52.856644+00	
00000000-0000-0000-0000-000000000000	a002d458-a4be-45ff-941e-839a49d896ac	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 06:18:48.883235+00	
00000000-0000-0000-0000-000000000000	a67e64d3-7194-46cb-8b13-9923c869349a	{"action":"token_refreshed","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-06 15:28:13.913225+00	
00000000-0000-0000-0000-000000000000	d47493f4-4444-48a3-8007-1f00945f6025	{"action":"token_revoked","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-06 15:28:13.91399+00	
00000000-0000-0000-0000-000000000000	d327aaf2-333c-40c5-8a03-66f4efd889fc	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 15:40:04.720192+00	
00000000-0000-0000-0000-000000000000	8394b861-18ab-43c9-b5ed-0a39788ba548	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 15:46:34.205521+00	
00000000-0000-0000-0000-000000000000	f3d69919-ce27-4fd3-8dbc-76f83c4305b0	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 15:51:24.502383+00	
00000000-0000-0000-0000-000000000000	5697992a-e2f5-4096-9d82-27abf4df35ed	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 16:16:46.200798+00	
00000000-0000-0000-0000-000000000000	6d636f3a-1d45-4684-b293-7de58f214a89	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 16:28:23.354229+00	
00000000-0000-0000-0000-000000000000	dc58891c-3580-4844-bca8-314f11ec5839	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 17:34:41.31836+00	
00000000-0000-0000-0000-000000000000	0660f40c-717c-468e-b5ca-02935d3b8234	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 17:38:45.250422+00	
00000000-0000-0000-0000-000000000000	2cbc87ad-c39d-4a6d-a6ef-f4f8c1c98642	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 19:24:15.527523+00	
00000000-0000-0000-0000-000000000000	8ed1da63-dd9e-49bb-a505-dbedda07565b	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 19:33:32.308089+00	
00000000-0000-0000-0000-000000000000	f9e7d3d4-9da6-4b04-bcca-abd92a74153a	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 22:32:09.362444+00	
00000000-0000-0000-0000-000000000000	460eca1b-77d0-441e-9170-6350d7962634	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 22:44:10.776986+00	
00000000-0000-0000-0000-000000000000	9e720d62-8524-48cc-b456-95621dbdbffd	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 22:49:59.980626+00	
00000000-0000-0000-0000-000000000000	a935486b-c5bf-4e76-b4e0-d21111b58399	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 22:56:05.25908+00	
00000000-0000-0000-0000-000000000000	675d9058-0447-4e8b-9600-b97c3fc82d25	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 23:05:14.126235+00	
00000000-0000-0000-0000-000000000000	1fa31c32-6e4c-4cf7-aab4-33b18aaa4a3b	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 23:09:42.256249+00	
00000000-0000-0000-0000-000000000000	f8dc96ae-ba21-475d-802d-186fc2e5435f	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 23:17:23.742952+00	
00000000-0000-0000-0000-000000000000	17b43bd4-4ccc-4e09-8ce6-e3501f0456f7	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 23:22:17.666364+00	
00000000-0000-0000-0000-000000000000	23d78984-6494-43c0-9e98-2905790cc9d9	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 23:25:36.005839+00	
00000000-0000-0000-0000-000000000000	ab78f6a3-dc23-4f31-baa9-bc9bab672ab6	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 23:31:11.309897+00	
00000000-0000-0000-0000-000000000000	ce2336c9-aee7-4fb7-8f87-22148e1b7d71	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 23:38:38.515234+00	
00000000-0000-0000-0000-000000000000	cf31d98d-ad8b-4071-8fb9-7e8d3b632847	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 23:43:31.120598+00	
00000000-0000-0000-0000-000000000000	1cbcb0c2-2084-4ddf-9d4e-3cee675bc2c8	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 23:51:18.230731+00	
00000000-0000-0000-0000-000000000000	3c1f47ba-9431-4f47-a1ae-df17a9894d8a	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 23:54:01.354114+00	
00000000-0000-0000-0000-000000000000	f43f3c58-a778-4043-9430-ea2c41a3752f	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 23:56:12.209836+00	
00000000-0000-0000-0000-000000000000	d65f10df-6a1a-4555-8097-db3da34be657	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-06 23:59:09.968241+00	
00000000-0000-0000-0000-000000000000	75519ca0-1022-40a3-ac45-14307d5dce99	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 00:05:05.406465+00	
00000000-0000-0000-0000-000000000000	d8303973-169f-4b66-b322-a3d081350b94	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 00:08:36.775611+00	
00000000-0000-0000-0000-000000000000	f7654748-6311-4247-85c9-00dbd86716d0	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 00:17:19.812139+00	
00000000-0000-0000-0000-000000000000	01dd62a9-90d7-4066-b3d6-8526b0524d08	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 00:29:12.020474+00	
00000000-0000-0000-0000-000000000000	58a24775-cf66-48d9-b28d-de7d82214aef	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 00:47:58.958904+00	
00000000-0000-0000-0000-000000000000	9db006ac-60a1-4c8d-925e-19de0c87f8d0	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 00:53:32.150037+00	
00000000-0000-0000-0000-000000000000	b981e08f-01ad-4b1d-b96a-1539b45a3503	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 02:04:04.068086+00	
00000000-0000-0000-0000-000000000000	9e438398-6b7b-4cf1-9162-a5de33463a92	{"action":"token_refreshed","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-07 02:07:15.581504+00	
00000000-0000-0000-0000-000000000000	68c9fa6d-ad81-4bea-9e5d-c47b0729493f	{"action":"token_revoked","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-07 02:07:15.583142+00	
00000000-0000-0000-0000-000000000000	51479b72-9ceb-464d-9fcb-92195734ee09	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 02:08:19.507692+00	
00000000-0000-0000-0000-000000000000	17f25ad3-d120-44ea-ac19-f317b7cb9a8a	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 02:19:17.285362+00	
00000000-0000-0000-0000-000000000000	b55a8ce8-58bf-42b6-98b7-e0bd65f210b8	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 02:32:51.634507+00	
00000000-0000-0000-0000-000000000000	2c37a6ce-b3fa-4d3e-bb13-3d6a51969694	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 02:36:47.540091+00	
00000000-0000-0000-0000-000000000000	685cf6d5-ca4b-4da3-9422-1e97c1f237f2	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 02:39:14.530863+00	
00000000-0000-0000-0000-000000000000	9631a2a3-29ab-415b-bbd2-c7bf02a0717f	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 02:41:20.272834+00	
00000000-0000-0000-0000-000000000000	cca060a4-c458-48b8-b1e2-7a84f475a638	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 02:52:00.639856+00	
00000000-0000-0000-0000-000000000000	446ff43d-472d-435c-be62-5f2d707d630d	{"action":"token_refreshed","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-07 03:59:03.418726+00	
00000000-0000-0000-0000-000000000000	b9df809f-0df0-4339-a3dd-b19f1ef108c1	{"action":"token_revoked","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-07 03:59:03.419051+00	
00000000-0000-0000-0000-000000000000	1ce9f7d5-ea1a-4eda-9302-1b10cc2b435e	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 04:03:58.694302+00	
00000000-0000-0000-0000-000000000000	22ea9041-2ffa-40ca-a1f1-bf38be772ae3	{"action":"logout","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-07 04:04:53.352855+00	
00000000-0000-0000-0000-000000000000	e0646dc2-78a3-4233-9b3d-e9e3ae041f8a	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 04:05:08.173855+00	
00000000-0000-0000-0000-000000000000	615dd65c-c5fd-4924-9e24-e3e8a638df84	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 04:09:20.093255+00	
00000000-0000-0000-0000-000000000000	3fa2e7a8-288a-49a4-9a6a-0a49e5032be1	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 04:14:09.285044+00	
00000000-0000-0000-0000-000000000000	a4bcd702-c25e-450b-b418-e038eadf6272	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 04:17:47.093066+00	
00000000-0000-0000-0000-000000000000	5ff79ea5-cbc2-43a3-b58a-f18372a64050	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 04:19:29.747657+00	
00000000-0000-0000-0000-000000000000	bd42edf8-0124-4994-8873-7ecd84ae379a	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 04:22:00.185897+00	
00000000-0000-0000-0000-000000000000	215be5f7-1642-4ab0-9e9d-520376836ddb	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 04:23:48.441637+00	
00000000-0000-0000-0000-000000000000	ee8951f6-eb8e-43e4-a283-2f0b1adc5c52	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 04:26:54.360068+00	
00000000-0000-0000-0000-000000000000	a4f89eb0-2bb3-46f1-a3f2-77b43429d060	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 04:28:59.368655+00	
00000000-0000-0000-0000-000000000000	c55e91f2-b926-4d27-84a5-0a790e18dd35	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 04:33:16.17215+00	
00000000-0000-0000-0000-000000000000	d701777f-2fab-4492-af86-590ccfbf45b1	{"action":"logout","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-07 04:33:16.186445+00	
00000000-0000-0000-0000-000000000000	74aba245-72cf-4feb-9a76-938505b3b227	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 04:33:21.028147+00	
00000000-0000-0000-0000-000000000000	9de8587c-1829-446b-a8a8-0fe51b408a28	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 04:42:10.660585+00	
00000000-0000-0000-0000-000000000000	d9ace2f4-f332-45ca-b39d-0c6231e2c874	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 04:57:53.13498+00	
00000000-0000-0000-0000-000000000000	80d7a012-333f-4e8b-8135-df7800a7d151	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 05:02:52.030951+00	
00000000-0000-0000-0000-000000000000	aed612ad-3c27-4384-8c25-e3c65df4e294	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 05:11:25.769808+00	
00000000-0000-0000-0000-000000000000	0919ccab-d39c-4b95-8cd4-7ecf3760c6ca	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 05:14:23.953737+00	
00000000-0000-0000-0000-000000000000	b2cf4744-a885-4c35-a278-97ee38570df6	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 05:16:50.079003+00	
00000000-0000-0000-0000-000000000000	1eb5e47a-fd1d-4099-9bfe-bdb1e84ab27f	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 05:18:56.190061+00	
00000000-0000-0000-0000-000000000000	3ad426a1-64b3-4aa3-9696-4309602639af	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 05:22:35.893012+00	
00000000-0000-0000-0000-000000000000	e0676ff7-cb98-4169-b09f-3401e452597a	{"action":"user_modified","actor_id":"00000000-0000-0000-0000-000000000000","actor_username":"service_role","actor_via_sso":false,"log_type":"user","traits":{"user_email":"providerexample@test.com","user_id":"305d1547-37d4-4852-8ff0-f63199270616","user_phone":""}}	2025-10-07 05:50:36.091811+00	
00000000-0000-0000-0000-000000000000	8f6cba85-6d12-43c2-a2ae-514a5177353d	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 05:50:36.148376+00	
00000000-0000-0000-0000-000000000000	3fb72664-3c7c-4045-9cb2-7c8528cb2baa	{"action":"logout","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-07 05:50:36.162286+00	
00000000-0000-0000-0000-000000000000	b4f1ce56-86b0-4cc2-acda-0dad286bbe5f	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 05:51:08.669901+00	
00000000-0000-0000-0000-000000000000	c4825258-1f84-43d7-8691-0bad96dc82fc	{"action":"logout","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-07 05:51:08.698968+00	
00000000-0000-0000-0000-000000000000	358884e9-f2a7-4482-931a-f992bbd8032b	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 05:58:25.833275+00	
00000000-0000-0000-0000-000000000000	acec013b-7830-4a27-a23a-1f9dd885f1be	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 06:05:41.724224+00	
00000000-0000-0000-0000-000000000000	ba69ab98-0c13-413d-bd0d-f9896dcafd1b	{"action":"token_refreshed","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-07 15:38:09.42846+00	
00000000-0000-0000-0000-000000000000	5b710a74-0573-487c-b562-f59c55b99446	{"action":"token_revoked","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-07 15:38:09.429186+00	
00000000-0000-0000-0000-000000000000	9a64447c-f5c1-430a-8dac-514b17485d82	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 16:01:20.938003+00	
00000000-0000-0000-0000-000000000000	d36c42d7-9b78-4778-862e-2290c0dda2a2	{"action":"logout","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-07 16:01:20.950101+00	
00000000-0000-0000-0000-000000000000	68f39f15-d5aa-45ba-8c5b-2e432b5fa6f4	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 16:22:34.43142+00	
00000000-0000-0000-0000-000000000000	cd2a24ae-6866-4121-9a4c-91e680d99aa5	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 16:24:56.558954+00	
00000000-0000-0000-0000-000000000000	fdf06b74-a90b-4120-9e24-d26f118302cd	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 17:01:57.576567+00	
00000000-0000-0000-0000-000000000000	e3486bcd-9243-4075-9413-e3e2d286c065	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 17:07:59.589501+00	
00000000-0000-0000-0000-000000000000	40913c9d-d0e5-45c2-abb8-2bbef2152ab6	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 17:12:19.231991+00	
00000000-0000-0000-0000-000000000000	d4e1c903-b1eb-4f9e-92d3-4a3d7de1838d	{"action":"token_refreshed","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-07 21:40:30.088304+00	
00000000-0000-0000-0000-000000000000	5f4871bd-024e-4466-90d0-3eecc965a6c2	{"action":"token_revoked","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-07 21:40:30.088622+00	
00000000-0000-0000-0000-000000000000	816bf0b8-b87f-4336-a217-bcf68743c2ad	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 21:42:45.481594+00	
00000000-0000-0000-0000-000000000000	8c9a6e55-8c1e-46a2-8ba1-e16e17d2bee3	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 21:58:44.654412+00	
00000000-0000-0000-0000-000000000000	195c41db-cf44-4463-a194-44e1e1485ed7	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 22:07:21.863065+00	
00000000-0000-0000-0000-000000000000	875e6a0b-1ded-4bfb-8b4a-77e40dcf097d	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 22:17:07.038729+00	
00000000-0000-0000-0000-000000000000	635bfce1-efe5-44b7-b8a8-2ed1ab58512b	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 22:32:12.993715+00	
00000000-0000-0000-0000-000000000000	e4fc7681-f186-431a-b747-c0880d048588	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 22:36:42.360665+00	
00000000-0000-0000-0000-000000000000	712f0ac9-dec6-41bb-a02c-6ef9fa29d4a2	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 22:43:13.376456+00	
00000000-0000-0000-0000-000000000000	2923721c-d015-43df-bd5f-d41ebcfbe5c0	{"action":"logout","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-07 22:44:38.945832+00	
00000000-0000-0000-0000-000000000000	4fd50651-c920-4bbe-ae37-268ee44fd7cf	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 22:44:52.084811+00	
00000000-0000-0000-0000-000000000000	b4b7b20e-0ae9-4393-8875-7bbd79dcd550	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 22:51:02.250613+00	
00000000-0000-0000-0000-000000000000	e8b89fa1-173b-4c31-93c6-744d6b067ce0	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 23:00:18.519415+00	
00000000-0000-0000-0000-000000000000	3b990724-61ed-4c0a-8723-eb489547f589	{"action":"token_refreshed","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-07 23:11:22.02107+00	
00000000-0000-0000-0000-000000000000	d1474a2b-7898-4627-acda-f9ed03b2cb92	{"action":"token_revoked","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-07 23:11:22.021761+00	
00000000-0000-0000-0000-000000000000	725ace6d-0121-447e-baac-f15b547ec534	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 23:12:20.090363+00	
00000000-0000-0000-0000-000000000000	a61a34cf-4dc3-4464-944b-bbe5a470e3db	{"action":"logout","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-07 23:13:14.899875+00	
00000000-0000-0000-0000-000000000000	7d315c08-a0f4-4302-8dda-7b6fa49ad3e8	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 23:13:27.186325+00	
00000000-0000-0000-0000-000000000000	917983a7-2bb4-48fc-9155-273ba947aeb1	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 23:19:08.933695+00	
00000000-0000-0000-0000-000000000000	75935ce1-d2e3-424d-ab0b-f5eaaa5b2afb	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 23:49:47.800555+00	
00000000-0000-0000-0000-000000000000	9f29c155-10cd-4bfd-b5bc-c226c93ef790	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-07 23:54:43.505311+00	
00000000-0000-0000-0000-000000000000	c2937a54-ea96-4c09-879a-c13832edd377	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-08 00:07:54.981769+00	
00000000-0000-0000-0000-000000000000	8fe37eb4-3afa-4a14-87d0-9e43e53bb94e	{"action":"token_refreshed","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-08 01:32:56.908612+00	
00000000-0000-0000-0000-000000000000	16b1dc36-1864-4be1-ba0e-7732322c25e4	{"action":"token_revoked","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-08 01:32:56.909604+00	
00000000-0000-0000-0000-000000000000	9ff8952c-a498-42f1-afd9-d89b16d1d70f	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-08 01:33:13.659586+00	
00000000-0000-0000-0000-000000000000	a70b132e-b084-4be7-b508-9959369e37f1	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-08 02:13:30.20048+00	
00000000-0000-0000-0000-000000000000	ea7596e3-c8f5-4480-be64-fe4da8dfaf33	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-08 02:23:32.070143+00	
00000000-0000-0000-0000-000000000000	5914427a-e348-404c-b10d-6a9e349a43a6	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-08 02:29:07.573904+00	
00000000-0000-0000-0000-000000000000	efaf0a2c-81d9-488b-b387-e0eaeadffb60	{"action":"logout","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-10-08 02:29:07.588311+00	
00000000-0000-0000-0000-000000000000	9988f6ad-c1f2-4225-bff2-4673ca2ed634	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-08 02:29:20.312292+00	
00000000-0000-0000-0000-000000000000	b50d895f-faa2-4980-b1ed-02169151206c	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-08 02:42:14.094109+00	
00000000-0000-0000-0000-000000000000	4f6ca561-1955-4eaf-b88e-c77137e19591	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-08 02:52:17.510482+00	
00000000-0000-0000-0000-000000000000	14e2eb2c-3360-4613-9548-9ae7c0f5f48b	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-08 02:54:25.485138+00	
00000000-0000-0000-0000-000000000000	4a043476-a18f-41d0-9a93-bf12dc1de4f5	{"action":"token_refreshed","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-08 03:53:44.688838+00	
00000000-0000-0000-0000-000000000000	5f161a70-8e4f-4d48-aef5-fbb48752a858	{"action":"token_revoked","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-08 03:53:44.689133+00	
00000000-0000-0000-0000-000000000000	4a6065d3-5b37-4098-8449-6793df6dc452	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-08 04:07:18.999147+00	
00000000-0000-0000-0000-000000000000	18e94e6d-d8ab-4229-8a7c-34ceeb14d569	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-08 04:31:37.678496+00	
00000000-0000-0000-0000-000000000000	8d872238-5bac-465d-b140-81d28062333f	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-08 16:36:53.809241+00	
00000000-0000-0000-0000-000000000000	a084f3ce-07c0-4dd0-8670-10183355d6db	{"action":"login","actor_id":"305d1547-37d4-4852-8ff0-f63199270616","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-08 16:50:49.368983+00	
00000000-0000-0000-0000-000000000000	e99471f8-1123-4c44-a65d-a6be02cd2c83	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-09 14:38:49.980498+00	
00000000-0000-0000-0000-000000000000	b745bd52-f7e1-4f34-983e-011dccbbff8c	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-09 14:41:32.169122+00	
00000000-0000-0000-0000-000000000000	db083ece-0f9c-493f-b1ef-82a1c9da3ceb	{"action":"token_refreshed","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-09 17:04:42.02513+00	
00000000-0000-0000-0000-000000000000	640ac83b-2ed7-46d4-96e1-f623e6c4cc38	{"action":"token_revoked","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-09 17:04:42.025609+00	
00000000-0000-0000-0000-000000000000	93bfea11-8f68-4db4-8cbd-e5607e375964	{"action":"token_refreshed","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-09 18:06:42.224446+00	
00000000-0000-0000-0000-000000000000	ac4990fc-add2-49e8-a29a-f476da852683	{"action":"token_revoked","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-09 18:06:42.224818+00	
00000000-0000-0000-0000-000000000000	c1072272-9538-4c21-8b80-0fb5e6c9f912	{"action":"token_refreshed","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-09 20:44:45.73179+00	
00000000-0000-0000-0000-000000000000	94529d89-a035-4d69-b547-1a2b9b64f8d9	{"action":"token_revoked","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-09 20:44:45.732461+00	
00000000-0000-0000-0000-000000000000	ead83697-03fc-4b55-b5d3-f56e83a09665	{"action":"token_refreshed","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-09 22:14:20.89846+00	
00000000-0000-0000-0000-000000000000	424a8d30-b693-4bdf-9ccc-ae0436c60e5a	{"action":"token_revoked","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-09 22:14:20.89899+00	
00000000-0000-0000-0000-000000000000	d8e3d165-10af-4566-a2f4-e52a18369af3	{"action":"token_refreshed","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-09 23:14:07.58029+00	
00000000-0000-0000-0000-000000000000	9f09729d-c5bd-4c6b-849a-5d36596adbe6	{"action":"token_revoked","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-09 23:14:07.580853+00	
00000000-0000-0000-0000-000000000000	5e39c167-3bbc-44fe-b5fb-063c7b98bd44	{"action":"token_refreshed","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-10 01:26:36.329286+00	
00000000-0000-0000-0000-000000000000	a647fbb1-e251-4841-b943-fda5359b992b	{"action":"token_revoked","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-10 01:26:36.329695+00	
00000000-0000-0000-0000-000000000000	f235079d-7a77-4fa9-a86a-6de4af70768a	{"action":"token_refreshed","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-10 02:25:31.777943+00	
00000000-0000-0000-0000-000000000000	d19274a7-5a33-4d44-aa81-ddddcdb99da3	{"action":"token_revoked","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-10 02:25:31.778318+00	
00000000-0000-0000-0000-000000000000	1e9d07f9-b528-40c7-a191-37fbb5046b4f	{"action":"token_refreshed","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-10 04:06:37.145552+00	
00000000-0000-0000-0000-000000000000	011af1d6-f8c4-4330-ba06-3f58760ee580	{"action":"token_revoked","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-10 04:06:37.146069+00	
00000000-0000-0000-0000-000000000000	6fd51e73-2a3b-4d63-8d06-fa3d0afcbbe1	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-10 22:04:09.410719+00	
00000000-0000-0000-0000-000000000000	63e8db72-94a0-4c3b-ae7e-82300c00ab87	{"action":"token_refreshed","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-11 00:08:53.998823+00	
00000000-0000-0000-0000-000000000000	8ab852f2-e9ce-47e3-882c-96f7c68965b7	{"action":"token_revoked","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-11 00:08:53.999296+00	
00000000-0000-0000-0000-000000000000	9d21d974-2c43-4dde-b2cf-fa2c4789cd95	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-11 21:48:47.927447+00	
00000000-0000-0000-0000-000000000000	c8b39aa9-72ab-4054-9c7b-3d6aea67de0e	{"action":"token_refreshed","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-12 02:38:26.092007+00	
00000000-0000-0000-0000-000000000000	1f3d448f-abaa-4297-be0f-40b82e8fb1b4	{"action":"token_revoked","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-12 02:38:26.093122+00	
00000000-0000-0000-0000-000000000000	51674b76-44ab-42cb-aa01-f66718d1be8a	{"action":"token_refreshed","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-12 03:45:55.044591+00	
00000000-0000-0000-0000-000000000000	2d870804-8c92-4200-a463-055abb94c7f0	{"action":"token_revoked","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-12 03:45:55.044935+00	
00000000-0000-0000-0000-000000000000	7ed822e4-7d33-4f6b-87ac-934d367bbb83	{"action":"token_refreshed","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-12 22:54:23.560815+00	
00000000-0000-0000-0000-000000000000	e5bd6db3-c13a-46bb-be95-67c61d0d7aca	{"action":"token_revoked","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-12 22:54:23.561361+00	
00000000-0000-0000-0000-000000000000	d7c0d384-1831-4790-b25d-799316a79ef2	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-12 22:59:30.924203+00	
00000000-0000-0000-0000-000000000000	4fd9baeb-2f30-45ec-9867-f7f9fe0f91c9	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-12 23:50:48.857048+00	
00000000-0000-0000-0000-000000000000	c5853842-1e13-4aa2-86a2-b59763939638	{"action":"token_refreshed","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-13 00:48:04.733236+00	
00000000-0000-0000-0000-000000000000	fecc4da7-2e8c-4f8d-9901-f946d8cc3d90	{"action":"token_revoked","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-10-13 00:48:04.733768+00	
00000000-0000-0000-0000-000000000000	f1b74bd4-a7bc-4dff-ab85-7fce1609b426	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-13 00:59:47.412064+00	
00000000-0000-0000-0000-000000000000	b8ba3189-05c4-4656-a579-5c0cabdaef0d	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-13 01:17:20.15323+00	
00000000-0000-0000-0000-000000000000	003cb5f6-e876-4e35-b83b-343f2ef40bec	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-13 01:31:52.136702+00	
00000000-0000-0000-0000-000000000000	fafbb1a6-e109-40de-8e4c-b85a47e96413	{"action":"login","actor_id":"b095ab96-69c1-4bbd-bf63-8098b530ab69","actor_username":"patientexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-10-13 01:45:14.519439+00	
\.


--
-- TOC entry 4741 (class 0 OID 18179)
-- Dependencies: 313
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at) FROM stdin;
\.


--
-- TOC entry 4732 (class 0 OID 17977)
-- Dependencies: 304
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
b095ab96-69c1-4bbd-bf63-8098b530ab69	b095ab96-69c1-4bbd-bf63-8098b530ab69	{"sub": "b095ab96-69c1-4bbd-bf63-8098b530ab69", "role": "patient", "email": "patientexample@test.com", "last_name": "example", "first_name": "patient", "email_verified": false, "phone_verified": false}	email	2025-10-06 03:35:13.027853+00	2025-10-06 03:35:13.027867+00	2025-10-06 03:35:13.027867+00	f3e7fca5-02e0-48ce-ac06-ef519342aa0b
94700da3-b8bf-43a6-8e00-866059953329	94700da3-b8bf-43a6-8e00-866059953329	{"sub": "94700da3-b8bf-43a6-8e00-866059953329", "role": "admin", "email": "adminexample@test.com", "last_name": "example", "first_name": "admin", "email_verified": false, "phone_verified": false}	email	2025-10-06 03:36:00.513047+00	2025-10-06 03:36:00.513061+00	2025-10-06 03:36:00.513061+00	20e4ca36-adb0-4e64-89ed-0a39a0a7007a
305d1547-37d4-4852-8ff0-f63199270616	305d1547-37d4-4852-8ff0-f63199270616	{"sub": "305d1547-37d4-4852-8ff0-f63199270616", "role": "provider", "email": "providerexample@test.com", "phone": "", "last_name": "example", "specialty": "weight loss", "first_name": "provider", "email_verified": false, "license_number": "12345678", "phone_verified": false}	email	2025-10-06 03:36:28.414486+00	2025-10-06 03:36:28.414499+00	2025-10-06 03:36:28.414499+00	6339634c-b634-4f3e-8daf-13cf250458a8
\.


--
-- TOC entry 4709 (class 0 OID 16481)
-- Dependencies: 264
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4736 (class 0 OID 18066)
-- Dependencies: 308
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
d383a6f9-be7d-4558-99c3-68015902afe7	2025-10-07 23:13:27.187927+00	2025-10-07 23:13:27.187927+00	password	e9343ba7-2aa2-4e82-ba79-0d3c63a74d25
2aef57a4-6629-425a-a051-e3f74e963799	2025-10-08 02:13:30.202533+00	2025-10-08 02:13:30.202533+00	password	d3f365e8-040e-4311-958f-83a8bd72490a
153e035b-ea6a-4337-bc58-19ba6813de9f	2025-10-08 02:23:32.071302+00	2025-10-08 02:23:32.071302+00	password	fb5f8c6c-4ff0-47fd-81b8-3575596e8ae2
752fe82f-ec9b-409a-b84d-a2e0b6911f7d	2025-10-08 02:29:20.313884+00	2025-10-08 02:29:20.313884+00	password	55e6f9b5-3cd4-4c49-ae15-2845f66b5128
f12e4dac-c39b-4a3e-8251-d1b078fa410b	2025-10-08 02:42:14.095646+00	2025-10-08 02:42:14.095646+00	password	98d15fe8-cbf3-47bb-b4f2-a5c31db27e5a
9f4814d1-a47a-4826-a70e-cf83c9aea8f2	2025-10-08 02:52:17.512018+00	2025-10-08 02:52:17.512018+00	password	aa445ade-a167-42f3-8117-35d440a94cc1
e7b025e1-b55e-49a7-809d-232f0cf8700c	2025-10-08 02:54:25.486223+00	2025-10-08 02:54:25.486223+00	password	c8e08346-28c3-4535-8ca9-0e3952ac81d8
fc225b2c-cf09-4292-b731-fc0e07029c45	2025-10-08 04:07:19.000403+00	2025-10-08 04:07:19.000403+00	password	03b5b34e-db7e-4419-ae62-8dba58bfb5af
b2964c58-20d4-41db-b2b5-f93e72d5c65c	2025-10-08 04:31:37.679715+00	2025-10-08 04:31:37.679715+00	password	9231e785-2ae2-4576-a876-f6903efcf047
6abb6844-1627-4e27-a4f2-7bd55e845bcb	2025-10-08 16:36:53.8116+00	2025-10-08 16:36:53.8116+00	password	875b6c8e-c92d-4c51-9dd4-006f941eb73f
ea8b256b-1a99-411f-98b3-d20ba38e6615	2025-10-08 16:50:49.370579+00	2025-10-08 16:50:49.370579+00	password	4c96c413-2514-45cf-9bba-71d641686b87
926c963f-df30-4600-9fde-b16aab9908c9	2025-10-09 14:38:49.982555+00	2025-10-09 14:38:49.982555+00	password	22c7f5c9-63a3-4fba-a91b-b18ef018b3e2
f5abc75c-0769-439e-bd05-1f8f6641aa12	2025-10-09 14:41:32.170596+00	2025-10-09 14:41:32.170596+00	password	67e4724f-72f3-4222-a19b-db4094f6f311
ceb07b05-d410-4e26-b3c9-8dc9b41ad5da	2025-10-10 22:04:09.413077+00	2025-10-10 22:04:09.413077+00	password	5fdf43f2-cb15-40d7-bc82-bdacfd83827f
f90b3614-ed46-4530-9d6e-c0e475b5b4b0	2025-10-11 21:48:47.930171+00	2025-10-11 21:48:47.930171+00	password	b2672501-e8b3-45b8-ba10-8921bbd68151
f86b3eef-ffcd-4a58-a039-a69670db84b0	2025-10-12 22:59:30.926098+00	2025-10-12 22:59:30.926098+00	password	e196f3fd-367d-4950-be58-5a6f8e094a19
0776289c-e7b0-4412-b1f4-94222027533b	2025-10-12 23:50:48.85916+00	2025-10-12 23:50:48.85916+00	password	f411b63b-d76b-489d-854e-0b622232ef60
6a4c5a92-5a9e-4f2c-bfda-30042bceb1e5	2025-10-13 00:59:47.414087+00	2025-10-13 00:59:47.414087+00	password	b7205639-0dc6-4c2e-b138-66833c926729
793ce5a0-0a3f-4bf6-87ec-005769fcb018	2025-10-13 01:17:20.155291+00	2025-10-13 01:17:20.155291+00	password	0a79bb30-6934-48e5-9dad-402831e7ed0f
e2adc36f-1e89-4568-90bc-4e75e1e880e9	2025-10-13 01:31:52.138588+00	2025-10-13 01:31:52.138588+00	password	12865ce9-1dc9-49a5-abe1-360841dcdb4f
27b6be40-8695-426d-a674-9c49fa2635c3	2025-10-13 01:45:14.520995+00	2025-10-13 01:45:14.520995+00	password	accc5c62-b6f3-4561-b6ec-5192dd966fe7
\.


--
-- TOC entry 4735 (class 0 OID 18054)
-- Dependencies: 307
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- TOC entry 4734 (class 0 OID 18041)
-- Dependencies: 306
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid) FROM stdin;
\.


--
-- TOC entry 4743 (class 0 OID 18261)
-- Dependencies: 315
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_clients (id, client_id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- TOC entry 4742 (class 0 OID 18229)
-- Dependencies: 314
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4708 (class 0 OID 16470)
-- Dependencies: 263
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
00000000-0000-0000-0000-000000000000	127	7qb7fx722drb	305d1547-37d4-4852-8ff0-f63199270616	f	2025-10-08 02:42:14.095085+00	2025-10-08 02:42:14.095085+00	\N	f12e4dac-c39b-4a3e-8251-d1b078fa410b
00000000-0000-0000-0000-000000000000	128	imkwwnbtqwfx	b095ab96-69c1-4bbd-bf63-8098b530ab69	f	2025-10-08 02:52:17.511475+00	2025-10-08 02:52:17.511475+00	\N	9f4814d1-a47a-4826-a70e-cf83c9aea8f2
00000000-0000-0000-0000-000000000000	129	v2bdk3qat454	305d1547-37d4-4852-8ff0-f63199270616	t	2025-10-08 02:54:25.485835+00	2025-10-08 03:53:44.689482+00	\N	e7b025e1-b55e-49a7-809d-232f0cf8700c
00000000-0000-0000-0000-000000000000	130	uyvnkmucjgcq	305d1547-37d4-4852-8ff0-f63199270616	f	2025-10-08 03:53:44.689691+00	2025-10-08 03:53:44.689691+00	v2bdk3qat454	e7b025e1-b55e-49a7-809d-232f0cf8700c
00000000-0000-0000-0000-000000000000	131	ahxt2fllgmrb	305d1547-37d4-4852-8ff0-f63199270616	f	2025-10-08 04:07:18.999922+00	2025-10-08 04:07:18.999922+00	\N	fc225b2c-cf09-4292-b731-fc0e07029c45
00000000-0000-0000-0000-000000000000	132	fz32peesyyaf	305d1547-37d4-4852-8ff0-f63199270616	f	2025-10-08 04:31:37.679227+00	2025-10-08 04:31:37.679227+00	\N	b2964c58-20d4-41db-b2b5-f93e72d5c65c
00000000-0000-0000-0000-000000000000	133	342cdkimzkym	b095ab96-69c1-4bbd-bf63-8098b530ab69	f	2025-10-08 16:36:53.810704+00	2025-10-08 16:36:53.810704+00	\N	6abb6844-1627-4e27-a4f2-7bd55e845bcb
00000000-0000-0000-0000-000000000000	134	mttyt3gn6efc	305d1547-37d4-4852-8ff0-f63199270616	f	2025-10-08 16:50:49.370017+00	2025-10-08 16:50:49.370017+00	\N	ea8b256b-1a99-411f-98b3-d20ba38e6615
00000000-0000-0000-0000-000000000000	135	sbc3xqcpal2j	b095ab96-69c1-4bbd-bf63-8098b530ab69	f	2025-10-09 14:38:49.981778+00	2025-10-09 14:38:49.981778+00	\N	926c963f-df30-4600-9fde-b16aab9908c9
00000000-0000-0000-0000-000000000000	136	6alaljne7vov	b095ab96-69c1-4bbd-bf63-8098b530ab69	t	2025-10-09 14:41:32.170062+00	2025-10-09 17:04:42.025857+00	\N	f5abc75c-0769-439e-bd05-1f8f6641aa12
00000000-0000-0000-0000-000000000000	137	2z4sxynzzwrp	b095ab96-69c1-4bbd-bf63-8098b530ab69	t	2025-10-09 17:04:42.026167+00	2025-10-09 18:06:42.225077+00	6alaljne7vov	f5abc75c-0769-439e-bd05-1f8f6641aa12
00000000-0000-0000-0000-000000000000	138	jmzbaidv3lkd	b095ab96-69c1-4bbd-bf63-8098b530ab69	t	2025-10-09 18:06:42.225281+00	2025-10-09 20:44:45.732667+00	2z4sxynzzwrp	f5abc75c-0769-439e-bd05-1f8f6641aa12
00000000-0000-0000-0000-000000000000	139	44dahz6bnysu	b095ab96-69c1-4bbd-bf63-8098b530ab69	t	2025-10-09 20:44:45.732986+00	2025-10-09 22:14:20.899315+00	jmzbaidv3lkd	f5abc75c-0769-439e-bd05-1f8f6641aa12
00000000-0000-0000-0000-000000000000	140	ny3kto7vcdb4	b095ab96-69c1-4bbd-bf63-8098b530ab69	t	2025-10-09 22:14:20.899588+00	2025-10-09 23:14:07.581168+00	44dahz6bnysu	f5abc75c-0769-439e-bd05-1f8f6641aa12
00000000-0000-0000-0000-000000000000	141	7b3frlve6yp6	b095ab96-69c1-4bbd-bf63-8098b530ab69	t	2025-10-09 23:14:07.581454+00	2025-10-10 01:26:36.329919+00	ny3kto7vcdb4	f5abc75c-0769-439e-bd05-1f8f6641aa12
00000000-0000-0000-0000-000000000000	142	kee445mxx65r	b095ab96-69c1-4bbd-bf63-8098b530ab69	t	2025-10-10 01:26:36.330147+00	2025-10-10 02:25:31.778573+00	7b3frlve6yp6	f5abc75c-0769-439e-bd05-1f8f6641aa12
00000000-0000-0000-0000-000000000000	143	dpk7k2z76t3y	b095ab96-69c1-4bbd-bf63-8098b530ab69	t	2025-10-10 02:25:31.77874+00	2025-10-10 04:06:37.146396+00	kee445mxx65r	f5abc75c-0769-439e-bd05-1f8f6641aa12
00000000-0000-0000-0000-000000000000	144	hfholmt76z3y	b095ab96-69c1-4bbd-bf63-8098b530ab69	f	2025-10-10 04:06:37.146556+00	2025-10-10 04:06:37.146556+00	dpk7k2z76t3y	f5abc75c-0769-439e-bd05-1f8f6641aa12
00000000-0000-0000-0000-000000000000	145	e5qjwirmb2wi	b095ab96-69c1-4bbd-bf63-8098b530ab69	t	2025-10-10 22:04:09.412341+00	2025-10-11 00:08:53.999695+00	\N	ceb07b05-d410-4e26-b3c9-8dc9b41ad5da
00000000-0000-0000-0000-000000000000	146	insteouwitrv	b095ab96-69c1-4bbd-bf63-8098b530ab69	f	2025-10-11 00:08:53.999964+00	2025-10-11 00:08:53.999964+00	e5qjwirmb2wi	ceb07b05-d410-4e26-b3c9-8dc9b41ad5da
00000000-0000-0000-0000-000000000000	147	c7bcwvutfxp5	b095ab96-69c1-4bbd-bf63-8098b530ab69	t	2025-10-11 21:48:47.929363+00	2025-10-12 02:38:26.093563+00	\N	f90b3614-ed46-4530-9d6e-c0e475b5b4b0
00000000-0000-0000-0000-000000000000	148	3fujo7cjqjof	b095ab96-69c1-4bbd-bf63-8098b530ab69	t	2025-10-12 02:38:26.09407+00	2025-10-12 03:45:55.045148+00	c7bcwvutfxp5	f90b3614-ed46-4530-9d6e-c0e475b5b4b0
00000000-0000-0000-0000-000000000000	149	s7ytzfh3ova3	b095ab96-69c1-4bbd-bf63-8098b530ab69	t	2025-10-12 03:45:55.045276+00	2025-10-12 22:54:23.561717+00	3fujo7cjqjof	f90b3614-ed46-4530-9d6e-c0e475b5b4b0
00000000-0000-0000-0000-000000000000	150	4h2kivebajte	b095ab96-69c1-4bbd-bf63-8098b530ab69	f	2025-10-12 22:54:23.562286+00	2025-10-12 22:54:23.562286+00	s7ytzfh3ova3	f90b3614-ed46-4530-9d6e-c0e475b5b4b0
00000000-0000-0000-0000-000000000000	151	fqcw2kpkdop3	b095ab96-69c1-4bbd-bf63-8098b530ab69	f	2025-10-12 22:59:30.925492+00	2025-10-12 22:59:30.925492+00	\N	f86b3eef-ffcd-4a58-a039-a69670db84b0
00000000-0000-0000-0000-000000000000	152	ajhz3vjyfsvh	b095ab96-69c1-4bbd-bf63-8098b530ab69	t	2025-10-12 23:50:48.858457+00	2025-10-13 00:48:04.734039+00	\N	0776289c-e7b0-4412-b1f4-94222027533b
00000000-0000-0000-0000-000000000000	153	hzqqupgrut5q	b095ab96-69c1-4bbd-bf63-8098b530ab69	f	2025-10-13 00:48:04.734343+00	2025-10-13 00:48:04.734343+00	ajhz3vjyfsvh	0776289c-e7b0-4412-b1f4-94222027533b
00000000-0000-0000-0000-000000000000	154	hgydvrrmd63m	b095ab96-69c1-4bbd-bf63-8098b530ab69	f	2025-10-13 00:59:47.413513+00	2025-10-13 00:59:47.413513+00	\N	6a4c5a92-5a9e-4f2c-bfda-30042bceb1e5
00000000-0000-0000-0000-000000000000	155	v5vhak62il3f	b095ab96-69c1-4bbd-bf63-8098b530ab69	f	2025-10-13 01:17:20.154712+00	2025-10-13 01:17:20.154712+00	\N	793ce5a0-0a3f-4bf6-87ec-005769fcb018
00000000-0000-0000-0000-000000000000	156	y5fcfxgghno2	b095ab96-69c1-4bbd-bf63-8098b530ab69	f	2025-10-13 01:31:52.137983+00	2025-10-13 01:31:52.137983+00	\N	e2adc36f-1e89-4568-90bc-4e75e1e880e9
00000000-0000-0000-0000-000000000000	157	5d5gf6rb7zpw	b095ab96-69c1-4bbd-bf63-8098b530ab69	f	2025-10-13 01:45:14.520439+00	2025-10-13 01:45:14.520439+00	\N	27b6be40-8695-426d-a674-9c49fa2635c3
00000000-0000-0000-0000-000000000000	116	pd3u4obsoxyj	305d1547-37d4-4852-8ff0-f63199270616	f	2025-10-07 23:13:27.18731+00	2025-10-07 23:13:27.18731+00	\N	d383a6f9-be7d-4558-99c3-68015902afe7
00000000-0000-0000-0000-000000000000	123	b3z3o3xk5ucp	305d1547-37d4-4852-8ff0-f63199270616	f	2025-10-08 02:13:30.201722+00	2025-10-08 02:13:30.201722+00	\N	2aef57a4-6629-425a-a051-e3f74e963799
00000000-0000-0000-0000-000000000000	124	k3enc7lf37qi	305d1547-37d4-4852-8ff0-f63199270616	f	2025-10-08 02:23:32.070883+00	2025-10-08 02:23:32.070883+00	\N	153e035b-ea6a-4337-bc58-19ba6813de9f
00000000-0000-0000-0000-000000000000	126	3sy545cwlr5z	305d1547-37d4-4852-8ff0-f63199270616	f	2025-10-08 02:29:20.313339+00	2025-10-08 02:29:20.313339+00	\N	752fe82f-ec9b-409a-b84d-a2e0b6911f7d
\.


--
-- TOC entry 4739 (class 0 OID 18108)
-- Dependencies: 311
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- TOC entry 4740 (class 0 OID 18126)
-- Dependencies: 312
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- TOC entry 4711 (class 0 OID 16496)
-- Dependencies: 266
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
\.


--
-- TOC entry 4733 (class 0 OID 18007)
-- Dependencies: 305
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag) FROM stdin;
ceb07b05-d410-4e26-b3c9-8dc9b41ad5da	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-10 22:04:09.411581+00	2025-10-11 00:08:54.000913+00	\N	aal1	\N	2025-10-11 00:08:54.000896	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
f90b3614-ed46-4530-9d6e-c0e475b5b4b0	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-11 21:48:47.928465+00	2025-10-12 22:54:23.563489+00	\N	aal1	\N	2025-10-12 22:54:23.563469	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
f86b3eef-ffcd-4a58-a039-a69670db84b0	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-12 22:59:30.92485+00	2025-10-12 22:59:30.92485+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
0776289c-e7b0-4412-b1f4-94222027533b	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-12 23:50:48.857649+00	2025-10-13 00:48:04.735052+00	\N	aal1	\N	2025-10-13 00:48:04.735027	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
6a4c5a92-5a9e-4f2c-bfda-30042bceb1e5	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-13 00:59:47.412714+00	2025-10-13 00:59:47.412714+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
793ce5a0-0a3f-4bf6-87ec-005769fcb018	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-13 01:17:20.15413+00	2025-10-13 01:17:20.15413+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
e2adc36f-1e89-4568-90bc-4e75e1e880e9	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-13 01:31:52.137334+00	2025-10-13 01:31:52.137334+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
27b6be40-8695-426d-a674-9c49fa2635c3	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-13 01:45:14.52006+00	2025-10-13 01:45:14.52006+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
f5abc75c-0769-439e-bd05-1f8f6641aa12	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-09 14:41:32.169615+00	2025-10-10 04:06:37.147336+00	\N	aal1	\N	2025-10-10 04:06:37.147317	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
d383a6f9-be7d-4558-99c3-68015902afe7	305d1547-37d4-4852-8ff0-f63199270616	2025-10-07 23:13:27.186896+00	2025-10-07 23:13:27.186896+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
2aef57a4-6629-425a-a051-e3f74e963799	305d1547-37d4-4852-8ff0-f63199270616	2025-10-08 02:13:30.201215+00	2025-10-08 02:13:30.201215+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
153e035b-ea6a-4337-bc58-19ba6813de9f	305d1547-37d4-4852-8ff0-f63199270616	2025-10-08 02:23:32.070529+00	2025-10-08 02:23:32.070529+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
752fe82f-ec9b-409a-b84d-a2e0b6911f7d	305d1547-37d4-4852-8ff0-f63199270616	2025-10-08 02:29:20.313+00	2025-10-08 02:29:20.313+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
f12e4dac-c39b-4a3e-8251-d1b078fa410b	305d1547-37d4-4852-8ff0-f63199270616	2025-10-08 02:42:14.094718+00	2025-10-08 02:42:14.094718+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
9f4814d1-a47a-4826-a70e-cf83c9aea8f2	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-08 02:52:17.511096+00	2025-10-08 02:52:17.511096+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
e7b025e1-b55e-49a7-809d-232f0cf8700c	305d1547-37d4-4852-8ff0-f63199270616	2025-10-08 02:54:25.485535+00	2025-10-08 03:53:44.690645+00	\N	aal1	\N	2025-10-08 03:53:44.69062	Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	172.217.12.106	\N
fc225b2c-cf09-4292-b731-fc0e07029c45	305d1547-37d4-4852-8ff0-f63199270616	2025-10-08 04:07:18.999576+00	2025-10-08 04:07:18.999576+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
b2964c58-20d4-41db-b2b5-f93e72d5c65c	305d1547-37d4-4852-8ff0-f63199270616	2025-10-08 04:31:37.678919+00	2025-10-08 04:31:37.678919+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
6abb6844-1627-4e27-a4f2-7bd55e845bcb	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-08 16:36:53.810076+00	2025-10-08 16:36:53.810076+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
ea8b256b-1a99-411f-98b3-d20ba38e6615	305d1547-37d4-4852-8ff0-f63199270616	2025-10-08 16:50:49.369585+00	2025-10-08 16:50:49.369585+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
926c963f-df30-4600-9fde-b16aab9908c9	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-09 14:38:49.981282+00	2025-10-09 14:38:49.981282+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	172.217.12.106	\N
\.


--
-- TOC entry 4738 (class 0 OID 18093)
-- Dependencies: 310
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4737 (class 0 OID 18084)
-- Dependencies: 309
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- TOC entry 4706 (class 0 OID 16458)
-- Dependencies: 261
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\N	22222222-2222-2222-2222-222222222222	\N	\N	michael.r@test.com	$2a$10$dummyhashformichaelroberts	2025-10-06 03:29:33.16878+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	33333333-3333-3333-3333-333333333333	\N	\N	jennifer.m@test.com	$2a$10$dummyhashforjennifermartinez	2025-10-06 03:29:33.16878+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	44444444-4444-4444-4444-444444444444	\N	\N	david.a@test.com	$2a$10$dummyhashfordavidanderson	2025-10-06 03:29:33.16878+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb	\N	\N	dr.watson@test.com	$2a$10$dummyhashfordrwatson	2025-10-06 03:29:33.16878+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	cccccccc-cccc-cccc-cccc-cccccccccccc	\N	\N	dr.wilson@test.com	$2a$10$dummyhashfordrwilson	2025-10-06 03:29:33.16878+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa	\N	\N	admin@test.com	admin123	2025-10-06 03:29:33.177134+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"role": "admin", "last_name": "User", "first_name": "Admin"}	\N	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.177134+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	11111111-1111-1111-1111-111111111111	\N	\N	sarah.j@test.com	patient123	2025-10-06 03:29:33.177134+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"role": "patient", "last_name": "Johnson", "first_name": "Sarah"}	\N	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.177134+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	305d1547-37d4-4852-8ff0-f63199270616	authenticated	authenticated	providerexample@test.com	$2a$10$1cGc9/3GycVeSv450cRC5Ot3dDlNOd/MTch2cT1aj2uV5IjFZnJ7q	2025-10-06 03:36:28.415489+00	\N		\N		\N			\N	2025-10-08 16:50:49.369549+00	{"provider": "email", "providers": ["email"]}	{"sub": "305d1547-37d4-4852-8ff0-f63199270616", "role": "provider", "email": "providerexample@test.com", "phone": "", "last_name": "example", "specialty": "weight loss", "first_name": "provider", "email_verified": true, "license_number": "12345678", "phone_verified": false}	\N	2025-10-06 03:36:28.412716+00	2025-10-08 16:50:49.370456+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	94700da3-b8bf-43a6-8e00-866059953329	authenticated	authenticated	adminexample@test.com	$2a$10$twTUMFzKl0QeshpIe/.5SO3t/XeTwRAsYxTpAZ6ZJML1VuxcJeisC	2025-10-06 03:36:00.514094+00	\N		\N		\N			\N	2025-10-06 06:12:28.630114+00	{"provider": "email", "providers": ["email"]}	{"sub": "94700da3-b8bf-43a6-8e00-866059953329", "role": "admin", "email": "adminexample@test.com", "last_name": "example", "first_name": "admin", "email_verified": true, "phone_verified": false}	\N	2025-10-06 03:36:00.511411+00	2025-10-06 06:12:28.630993+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	b095ab96-69c1-4bbd-bf63-8098b530ab69	authenticated	authenticated	patientexample@test.com	$2a$10$uTOx2mzTAA7vwUHlww2Yp.jbKXKsscUsSIw0lgDTfR.nmeWiDekW2	2025-10-06 03:35:13.029385+00	\N		\N		\N			\N	2025-10-13 01:45:14.520027+00	{"provider": "email", "providers": ["email"]}	{"sub": "b095ab96-69c1-4bbd-bf63-8098b530ab69", "role": "patient", "email": "patientexample@test.com", "last_name": "example", "first_name": "patient", "email_verified": true, "phone_verified": false}	\N	2025-10-06 03:35:13.025271+00	2025-10-13 01:45:14.520877+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- TOC entry 4747 (class 0 OID 18338)
-- Dependencies: 320
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admins (id, profile_id, permissions, active, created_at, updated_at) FROM stdin;
d9cb8003-3782-425a-a3cb-c62505f03179	94700da3-b8bf-43a6-8e00-866059953329	{dashboard,patients,providers,assignments}	t	2025-10-06 03:36:00.511221+00	2025-10-06 03:36:00.511221+00
\.


--
-- TOC entry 4758 (class 0 OID 18643)
-- Dependencies: 331
-- Data for Name: appointment_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appointment_history (id, appointment_id, action, performed_by, performed_by_user_id, old_values, new_values, reason, created_at) FROM stdin;
51a3eabd-7e51-49af-a501-614d54f1a1cf	649c3582-a89e-4122-bc91-7d83ff2ea6d0	created	system	\N	\N	{"id": "649c3582-a89e-4122-bc91-7d83ff2ea6d0", "status": "scheduled", "end_time": "09:30:00", "booked_by": "patient", "created_at": "2025-10-06T06:11:51.166605+00:00", "patient_id": "4c3c0e97-7074-4bc0-97b6-654bcfa584a5", "start_time": "09:00:00", "updated_at": "2025-10-06T06:11:51.166605+00:00", "admin_notes": null, "provider_id": "e7fcaca9-bde3-4cb9-8e57-2d1813fe1551", "cancelled_at": null, "cancelled_by": null, "assignment_id": "c8bb6c07-65ff-4dae-b0ae-b47855e5a315", "patient_notes": "Initial consultation for Semaglutide Visit", "provider_notes": null, "treatment_type": "weight_loss", "appointment_date": "2025-10-09", "appointment_type": "consultation", "duration_minutes": 30, "reschedule_count": 0, "booked_by_user_id": "b095ab96-69c1-4bbd-bf63-8098b530ab69", "booking_timestamp": "2025-10-06T06:11:51.166605+00:00", "rescheduled_to_id": null, "cancellation_reason": null, "rescheduled_from_id": null, "cancelled_by_user_id": null, "is_reschedule_source": false}	\N	2025-10-06 06:11:51.166605+00
afa090fb-1b46-42c4-9743-d33ab69d361d	cfc43414-8428-4bd6-9970-e909e9d134dc	created	system	\N	\N	{"id": "cfc43414-8428-4bd6-9970-e909e9d134dc", "status": "scheduled", "end_time": "09:30:00", "booked_by": "patient", "created_at": "2025-10-07T04:04:47.140857+00:00", "patient_id": "4c3c0e97-7074-4bc0-97b6-654bcfa584a5", "start_time": "09:00:00", "updated_at": "2025-10-07T04:04:47.140857+00:00", "admin_notes": null, "provider_id": "e7fcaca9-bde3-4cb9-8e57-2d1813fe1551", "cancelled_at": null, "cancelled_by": null, "assignment_id": "c8bb6c07-65ff-4dae-b0ae-b47855e5a315", "patient_notes": "Initial consultation for Tirzepatide Visit", "provider_notes": null, "treatment_type": "weight_loss", "appointment_date": "2025-11-06", "appointment_type": "consultation", "duration_minutes": 30, "reschedule_count": 0, "booked_by_user_id": "b095ab96-69c1-4bbd-bf63-8098b530ab69", "booking_timestamp": "2025-10-07T04:04:47.140857+00:00", "rescheduled_to_id": null, "cancellation_reason": null, "rescheduled_from_id": null, "cancelled_by_user_id": null, "is_reschedule_source": false}	\N	2025-10-07 04:04:47.140857+00
851dfc6e-772c-4b1c-8821-94fe8ad5a90c	ff6d542e-7c6e-4140-a188-616c8b9785a8	created	system	\N	\N	{"id": "ff6d542e-7c6e-4140-a188-616c8b9785a8", "status": "scheduled", "end_time": "10:00:00", "booked_by": "patient", "created_at": "2025-10-08T16:37:15.705274+00:00", "patient_id": "4c3c0e97-7074-4bc0-97b6-654bcfa584a5", "start_time": "09:30:00", "updated_at": "2025-10-08T16:37:15.705274+00:00", "admin_notes": null, "provider_id": "e7fcaca9-bde3-4cb9-8e57-2d1813fe1551", "cancelled_at": null, "cancelled_by": null, "assignment_id": "c8bb6c07-65ff-4dae-b0ae-b47855e5a315", "patient_notes": "Initial consultation for Tirzepatide Visit", "provider_notes": null, "treatment_type": "weight_loss", "appointment_date": "2025-10-09", "appointment_type": "consultation", "duration_minutes": 30, "reschedule_count": 0, "booked_by_user_id": "b095ab96-69c1-4bbd-bf63-8098b530ab69", "booking_timestamp": "2025-10-08T16:37:15.705274+00:00", "rescheduled_to_id": null, "cancellation_reason": null, "rescheduled_from_id": null, "cancelled_by_user_id": null, "is_reschedule_source": false}	\N	2025-10-08 16:37:15.705274+00
582c3373-fcd4-40fd-8c4f-dbef7ca84f86	60b937ba-0e3c-4881-b751-76197b9654ac	created	system	\N	\N	{"id": "60b937ba-0e3c-4881-b751-76197b9654ac", "status": "scheduled", "end_time": "09:30:00", "booked_by": "patient", "created_at": "2025-10-09T14:39:06.425849+00:00", "patient_id": "4c3c0e97-7074-4bc0-97b6-654bcfa584a5", "start_time": "09:00:00", "updated_at": "2025-10-09T14:39:06.425849+00:00", "admin_notes": null, "provider_id": "e7fcaca9-bde3-4cb9-8e57-2d1813fe1551", "cancelled_at": null, "cancelled_by": null, "assignment_id": "c8bb6c07-65ff-4dae-b0ae-b47855e5a315", "patient_notes": "Initial consultation for Tirzepatide Visit", "provider_notes": null, "treatment_type": "weight_loss", "appointment_date": "2025-10-10", "appointment_type": "consultation", "duration_minutes": 30, "reschedule_count": 0, "booked_by_user_id": "b095ab96-69c1-4bbd-bf63-8098b530ab69", "booking_timestamp": "2025-10-09T14:39:06.425849+00:00", "rescheduled_to_id": null, "cancellation_reason": null, "rescheduled_from_id": null, "cancelled_by_user_id": null, "is_reschedule_source": false}	\N	2025-10-09 14:39:06.425849+00
58601352-9bb7-4d96-85cc-c954c77bac12	fcff189e-4079-41e2-a493-f462810b3518	created	system	\N	\N	{"id": "fcff189e-4079-41e2-a493-f462810b3518", "status": "scheduled", "end_time": "09:30:00", "booked_by": "patient", "created_at": "2025-10-11T21:48:59.22904+00:00", "patient_id": "4c3c0e97-7074-4bc0-97b6-654bcfa584a5", "start_time": "09:00:00", "updated_at": "2025-10-11T21:48:59.22904+00:00", "admin_notes": null, "provider_id": "e7fcaca9-bde3-4cb9-8e57-2d1813fe1551", "cancelled_at": null, "cancelled_by": null, "assignment_id": "c8bb6c07-65ff-4dae-b0ae-b47855e5a315", "patient_notes": "Initial consultation for Tirzepatide Visit", "provider_notes": null, "treatment_type": "weight_loss", "appointment_date": "2025-10-13", "appointment_type": "consultation", "duration_minutes": 30, "reschedule_count": 0, "booked_by_user_id": "b095ab96-69c1-4bbd-bf63-8098b530ab69", "booking_timestamp": "2025-10-11T21:48:59.22904+00:00", "rescheduled_to_id": null, "cancellation_reason": null, "rescheduled_from_id": null, "cancelled_by_user_id": null, "is_reschedule_source": false}	\N	2025-10-11 21:48:59.22904+00
\.


--
-- TOC entry 4757 (class 0 OID 18605)
-- Dependencies: 330
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appointments (id, patient_id, provider_id, assignment_id, appointment_date, start_time, end_time, duration_minutes, treatment_type, appointment_type, status, patient_notes, provider_notes, admin_notes, booked_by, booked_by_user_id, booking_timestamp, cancelled_at, cancelled_by, cancelled_by_user_id, cancellation_reason, created_at, updated_at, rescheduled_from_id, rescheduled_to_id, is_reschedule_source, reschedule_count) FROM stdin;
74160da6-7cb9-4495-9bd2-d6a26b6ac172	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	e7fcaca9-bde3-4cb9-8e57-2d1813fe1551	c8bb6c07-65ff-4dae-b0ae-b47855e5a315	2025-10-08	09:00:00	09:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Semaglutide Visit	\N	\N	patient	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-06 03:38:50.594977+00	\N	\N	\N	\N	2025-10-06 03:38:50.594977+00	2025-10-06 03:38:50.594977+00	\N	\N	f	0
15cc25ca-cf2c-4a09-8c70-f65c31ea6963	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	e7fcaca9-bde3-4cb9-8e57-2d1813fe1551	c8bb6c07-65ff-4dae-b0ae-b47855e5a315	2025-10-08	09:30:00	10:00:00	30	weight_loss	consultation	scheduled	Initial consultation for Semaglutide Visit	\N	\N	patient	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-06 03:43:47.581232+00	\N	\N	\N	\N	2025-10-06 03:43:47.581232+00	2025-10-06 03:43:47.581232+00	\N	\N	f	0
649c3582-a89e-4122-bc91-7d83ff2ea6d0	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	e7fcaca9-bde3-4cb9-8e57-2d1813fe1551	c8bb6c07-65ff-4dae-b0ae-b47855e5a315	2025-10-09	09:00:00	09:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Semaglutide Visit	\N	\N	patient	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-06 06:11:51.166605+00	\N	\N	\N	\N	2025-10-06 06:11:51.166605+00	2025-10-06 06:11:51.166605+00	\N	\N	f	0
cfc43414-8428-4bd6-9970-e909e9d134dc	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	e7fcaca9-bde3-4cb9-8e57-2d1813fe1551	c8bb6c07-65ff-4dae-b0ae-b47855e5a315	2025-11-06	09:00:00	09:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-07 04:04:47.140857+00	\N	\N	\N	\N	2025-10-07 04:04:47.140857+00	2025-10-07 04:04:47.140857+00	\N	\N	f	0
ff6d542e-7c6e-4140-a188-616c8b9785a8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	e7fcaca9-bde3-4cb9-8e57-2d1813fe1551	c8bb6c07-65ff-4dae-b0ae-b47855e5a315	2025-10-09	09:30:00	10:00:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-08 16:37:15.705274+00	\N	\N	\N	\N	2025-10-08 16:37:15.705274+00	2025-10-08 16:37:15.705274+00	\N	\N	f	0
60b937ba-0e3c-4881-b751-76197b9654ac	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	e7fcaca9-bde3-4cb9-8e57-2d1813fe1551	c8bb6c07-65ff-4dae-b0ae-b47855e5a315	2025-10-10	09:00:00	09:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-09 14:39:06.425849+00	\N	\N	\N	\N	2025-10-09 14:39:06.425849+00	2025-10-09 14:39:06.425849+00	\N	\N	f	0
fcff189e-4079-41e2-a493-f462810b3518	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	e7fcaca9-bde3-4cb9-8e57-2d1813fe1551	c8bb6c07-65ff-4dae-b0ae-b47855e5a315	2025-10-13	09:00:00	09:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	b095ab96-69c1-4bbd-bf63-8098b530ab69	2025-10-11 21:48:59.22904+00	\N	\N	\N	\N	2025-10-11 21:48:59.22904+00	2025-10-11 21:48:59.22904+00	\N	\N	f	0
\.


--
-- TOC entry 4750 (class 0 OID 18427)
-- Dependencies: 323
-- Data for Name: assignment_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assignment_log (id, message, created_at) FROM stdin;
1	Starting provider assignment process	2025-10-06 03:29:33.154694
2	Provider assignment process completed	2025-10-06 03:29:33.154694
\.


--
-- TOC entry 4765 (class 0 OID 18967)
-- Dependencies: 340
-- Data for Name: auth_trigger_debug_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_trigger_debug_log (id, user_id, step, status, error_message, metadata, created_at) FROM stdin;
\.


--
-- TOC entry 4762 (class 0 OID 18857)
-- Dependencies: 337
-- Data for Name: auth_trigger_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_trigger_logs (id, user_id, trigger_stage, success, error_message, metadata, created_at) FROM stdin;
\.


--
-- TOC entry 4759 (class 0 OID 18720)
-- Dependencies: 334
-- Data for Name: clinical_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clinical_notes (id, appointment_id, patient_id, provider_id, allergies, previous_medications, current_medications, clinical_note, internal_note, visit_summary, created_at, updated_at, created_by, last_updated_by) FROM stdin;
631d4aa2-8de5-4f27-89e9-20d0f24b2257	649c3582-a89e-4122-bc91-7d83ff2ea6d0	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	e7fcaca9-bde3-4cb9-8e57-2d1813fe1551	{}	{}	{}				2025-10-06 06:12:18.745+00	2025-10-06 06:12:18.745+00	\N	\N
\.


--
-- TOC entry 4766 (class 0 OID 19024)
-- Dependencies: 341
-- Data for Name: faxes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.faxes (id, approval_id, preference_id, patient_id, provider_id, fax_number, fax_content, fax_status, faxed_at, delivery_confirmation_at, notes, created_at, updated_at, provider_profile_id, patient_profile_id) FROM stdin;
1cd336e3-e202-4fc0-a04f-e14e3a257072	3e652077-8c7b-4a7e-b673-7089dcb108c3	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	e7fcaca9-bde3-4cb9-8e57-2d1813fe1551	1-800-PHARMACY	Prescription for Tirzepatide 2.5mg	sent	2025-10-06 06:12:18.822+00	\N	\N	2025-10-06 06:12:18.820533+00	2025-10-06 06:12:18.820533+00	305d1547-37d4-4852-8ff0-f63199270616	b095ab96-69c1-4bbd-bf63-8098b530ab69
\.


--
-- TOC entry 4753 (class 0 OID 18473)
-- Dependencies: 326
-- Data for Name: medication_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medication_approvals (id, preference_id, provider_id, status, approved_dosage, approved_frequency, provider_notes, contraindications, approval_date, created_at, updated_at, provider_profile_id, supply_days) FROM stdin;
3e652077-8c7b-4a7e-b673-7089dcb108c3	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	e7fcaca9-bde3-4cb9-8e57-2d1813fe1551	approved	\N	\N	Approved and faxed during clinical visit	\N	2025-10-06 06:12:18.808+00	2025-10-06 06:12:18.806518+00	2025-10-06 06:12:18.806518+00	305d1547-37d4-4852-8ff0-f63199270616	10
\.


--
-- TOC entry 4763 (class 0 OID 18890)
-- Dependencies: 338
-- Data for Name: medication_dosages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medication_dosages (id, medication_id, strength, unit_price, available, sort_order, created_at, updated_at) FROM stdin;
2f576dbd-3d35-425c-92b3-dcc5655752eb	027330e6-b34a-4395-a8b6-18021096d2e2	250mg/ml	219.99	t	1	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
91cabd1d-86c6-49e4-9eee-8a1dfe411037	2b7af324-79c7-4ecd-99b8-c2c3eecfe4ab	20mg	99.99	t	1	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
4d48bc88-0af7-4f68-ba87-bb00bdd1ba99	4e4cefd5-6948-4415-84cf-e268f81c60ff	1.0mg	1299.99	t	1	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
86fa9e07-7e36-48ff-9999-4d2909218c53	5252a851-4e86-40d5-b91a-4d72b2076728	1mg	79.99	t	1	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
ebeed22a-9378-4e9d-914a-9cfc145a3b15	6779fca6-1951-45cc-a54c-f0fec69d43e5	120mg	199.99	t	1	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
af021d42-f5b4-423f-b949-324c410ea17f	72ea2dc1-23e0-458b-a556-5dd6cd3041ea	0.5mg	899.99	t	1	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
4a26d8f3-d982-4fae-ab50-40ab570b9eaa	77c41b69-f3b6-4194-98f0-118f1c7aecef	2.5mg	1199.99	t	1	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
2e13b3b4-958e-49fd-a50a-d75fb5bbdc11	9f849752-50a2-4ec4-b28f-0373977622a2	200mg/ml	199.99	t	1	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
670444be-c378-47ac-b78f-3a50b1f80666	b894c70d-d2cc-466b-b6c2-2e1a1b16038c	1.62%	299.99	t	1	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
005df66d-004b-43e7-a883-d19cc6a62277	c2182baa-3d29-49a7-90ab-f94cd0c1fc5b	37.5mg	89.99	t	1	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
fc2e13f3-2b39-4e54-8256-deb255ec700d	e98cd3af-253a-4e24-8ff0-b82408c81e76	50mg	89.99	t	1	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
8ea27b9d-da87-4418-8fbd-dd9405241bea	ea09be10-40e7-4521-8954-3b6a62f60f0a	5000 IU	149.99	t	1	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
94f3126d-d235-42f0-a63c-eb28526b1070	f5a3423a-7d85-4447-8374-0901ae733364	3.0mg	1099.99	t	1	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
e38381c6-4754-4bb6-8743-e671e188da45	77c41b69-f3b6-4194-98f0-118f1c7aecef	5.0mg	1399.99	t	10	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
ed74c265-2be1-4387-a1ce-6e06cbb64d95	77c41b69-f3b6-4194-98f0-118f1c7aecef	7.5mg	1599.99	t	20	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
6f4c890b-cf90-4fe5-a29b-ece5d2a3b76d	77c41b69-f3b6-4194-98f0-118f1c7aecef	10mg	1799.99	t	30	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
20dfbf72-ec92-4568-8813-28f5df15ada3	77c41b69-f3b6-4194-98f0-118f1c7aecef	12.5mg	1999.99	t	40	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
0ccee88f-d32a-4c96-85a9-87d4b79fabb1	77c41b69-f3b6-4194-98f0-118f1c7aecef	15mg	2199.99	t	50	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
11de3659-f7e5-4c43-9218-a15578120007	72ea2dc1-23e0-458b-a556-5dd6cd3041ea	0.25mg	799.99	t	1	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
85af5b6e-6049-4dea-bf1b-484fc0ef9a48	72ea2dc1-23e0-458b-a556-5dd6cd3041ea	1.0mg	999.99	t	11	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
5c2c6f91-a971-4086-9855-6c06efa36f55	72ea2dc1-23e0-458b-a556-5dd6cd3041ea	2.0mg	1199.99	t	21	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
75d9f7e6-bc8c-4698-8db3-a55f661169c4	9f849752-50a2-4ec4-b28f-0373977622a2	100mg/ml	159.99	t	5	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
07091091-5b99-4aff-a8aa-e5f9c6ee76e2	9f849752-50a2-4ec4-b28f-0373977622a2	250mg/ml	239.99	t	15	2025-10-06 03:29:36.319463+00	2025-10-06 03:29:36.319463+00
\.


--
-- TOC entry 4754 (class 0 OID 18494)
-- Dependencies: 327
-- Data for Name: medication_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medication_orders (id, approval_id, patient_id, medication_id, quantity, unit_price, total_amount, payment_status, payment_method, payment_date, fulfillment_status, tracking_number, shipped_date, estimated_delivery, admin_notes, created_at, updated_at, sent_to_pharmacy, provider_profile_id, patient_profile_id) FROM stdin;
db96903c-47e9-4de0-8c21-75a95c9de3df	3e652077-8c7b-4a7e-b673-7089dcb108c3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	77c41b69-f3b6-4194-98f0-118f1c7aecef	1	1199.99	1199.99	pending		\N	pharmacy_fulfilled		\N	\N		2025-10-06 06:12:18.820533+00	2025-10-06 06:12:40.955977+00	\N	305d1547-37d4-4852-8ff0-f63199270616	b095ab96-69c1-4bbd-bf63-8098b530ab69
\.


--
-- TOC entry 4767 (class 0 OID 19161)
-- Dependencies: 343
-- Data for Name: medication_tracking_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medication_tracking_entries (id, patient_id, medication_preference_id, taken_date, taken_time, notes, created_at, updated_at) FROM stdin;
260340c6-7685-4116-8a5a-36f80b5a798e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-09-18	23:12:00	\N	2025-10-06 06:13:09.46083+00	2025-10-06 23:44:29.927+00
09d1c0c3-e889-4217-9165-a90007d5286f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-01-09	10:40:00	No side effects	2025-01-09 13:19:08.704+00	2025-01-09 03:41:06.743+00
50828e7f-a58e-4303-9764-0550b04c596e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-01-11	08:21:00	Forgot morning dose, took at lunch	2025-01-11 21:29:54.103+00	2025-01-11 16:55:44.652+00
cad80c02-684d-48ba-aa5b-b8f6fbdf23d7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-01-13	08:31:00	Forgot morning dose, took at lunch	2025-01-13 03:47:49.699+00	2025-01-13 05:04:33.023+00
eb47f6dc-f1ed-47f4-ac8f-16d3e7d5887a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-01-15	08:36:00	Good day overall	2025-01-15 20:36:54.473+00	2025-01-15 09:49:20.09+00
4390eb6b-e0d4-43c0-b0a5-9d3233ddbd65	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-01-17	10:39:00	Took with dinner instead	2025-01-17 19:27:20.279+00	2025-01-17 13:12:26.213+00
c31f6356-5c99-4856-88bc-50d14ed18086	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-01-19	07:12:00	Took with dinner instead	2025-01-19 09:39:18.736+00	2025-01-19 12:16:50.616+00
a9e05430-a51c-45e8-b302-861397fede58	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-01-21	07:38:00	Feeling good today	2025-01-21 05:22:28.116+00	2025-01-21 16:00:25.671+00
9c4818bc-e0f1-428c-acc9-e57ee10668e6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-01-23	08:56:00	Feeling good today	2025-01-23 17:56:16.178+00	2025-01-23 18:07:47.153+00
ddd4a46a-e2ce-4ab6-a66f-4dffb80de95c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-01-25	07:49:00	\N	2025-01-25 13:48:20.01+00	2025-01-25 09:27:18.79+00
af7a02d1-b776-4854-a61b-ca50bca75f7e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-01-27	09:57:00	Took with dinner instead	2025-01-27 21:07:19.321+00	2025-01-27 23:20:10.399+00
86cd6e13-083a-42d1-80d3-3c9d048e0d26	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-01-29	10:13:00	Forgot morning dose, took at lunch	2025-01-29 19:45:29.56+00	2025-01-29 00:53:21.402+00
223ac7f7-44af-41d6-b630-020df0127a93	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-01-31	09:44:00	Forgot morning dose, took at lunch	2025-01-31 00:30:23.087+00	2025-01-31 21:51:58.181+00
e72384aa-f1b7-4ad5-affa-f66024e162e5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-02-02	09:23:00	Took with dinner instead	2025-02-02 17:35:49.651+00	2025-02-02 03:31:30.644+00
38a068b4-1834-4166-83e2-cb84c580b7cb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-02-04	07:51:00	Took with breakfast	2025-02-04 10:28:06.61+00	2025-02-04 16:09:10.282+00
a7f7a1b9-d694-4410-a420-66f3e6ccb456	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-02-08	10:03:00	Good day overall	2025-02-08 12:32:06.962+00	2025-02-08 09:03:01.965+00
58d193a8-1127-4bb8-bff5-fefd225aed3a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-02-10	08:42:00	Good day overall	2025-02-10 00:11:07.988+00	2025-02-10 05:04:42.325+00
cbbe0178-b64a-4cd4-b695-b38bd0b7ba6c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-02-12	08:30:00	Good day overall	2025-02-12 16:24:34.765+00	2025-02-12 14:23:12.96+00
60b85859-b9bf-4d0c-b35a-19221453d080	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-02-16	07:47:00	\N	2025-02-16 07:44:48.219+00	2025-02-16 06:19:11.329+00
c7a2d77b-bd60-4e1d-9ac0-788dfaca63f7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-02-18	08:51:00	No side effects	2025-02-18 00:40:47.464+00	2025-02-18 01:59:42.51+00
fb49641f-0fba-44ed-b3fd-5b147cb1f11d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-02-20	09:48:00	Took with breakfast	2025-02-20 00:46:55.125+00	2025-02-20 02:05:27.927+00
664f98de-01d0-4976-bd29-6dcdca818545	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-02-28	07:47:00	Feeling good today	2025-02-28 15:28:35.28+00	2025-02-28 11:26:13.285+00
0aaf8c91-63af-43e1-886d-a8f2aa42f415	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-03-02	10:24:00	Feeling good today	2025-03-02 06:23:44.615+00	2025-03-02 20:40:01.403+00
17bfc262-7cc8-4606-9011-1b65fcdc7e27	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-03-04	08:15:00	Feeling more energetic	2025-03-04 09:11:44.113+00	2025-03-04 01:12:50.266+00
21dc7e09-388b-422f-a40e-505785cc28fb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-03-06	08:50:00	\N	2025-03-06 15:41:08.868+00	2025-03-06 06:25:18.624+00
2e760021-3ce0-47d7-a654-8462f832ff55	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-03-08	09:27:00	Good day overall	2025-03-08 10:46:44.383+00	2025-03-08 15:16:37.329+00
cf899192-ee1e-4d05-a551-d1eb993c2163	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-03-09	07:26:00	No side effects	2025-03-10 12:58:03.652+00	2025-03-10 15:49:02.777+00
70837c65-090f-41d3-9bb3-74c2db2ad089	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-03-11	08:48:00	No side effects	2025-03-12 15:14:23.274+00	2025-03-12 17:50:31.948+00
6b538a20-294d-4a71-a861-4f1419aebe44	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-03-13	10:54:00	Feeling good today	2025-03-14 07:34:16.89+00	2025-03-14 06:39:37.949+00
b916f54a-6a8e-4d8f-aca8-45648560c82a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-03-15	09:40:00	Almost forgot but remembered	2025-03-16 12:00:41.947+00	2025-03-16 12:53:17.097+00
8cb49313-9a32-4f77-9777-e61c6a3167b8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-03-17	08:40:00	Good day overall	2025-03-18 00:17:35.16+00	2025-03-18 20:06:33.592+00
7424911d-6b55-4a0c-987f-08bb91a87308	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-03-19	08:35:00	\N	2025-03-20 12:42:43.878+00	2025-03-20 09:09:29.473+00
73d097a2-acc6-4f41-a528-e95c8f5237ee	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-03-21	08:21:00	Took with dinner instead	2025-03-22 04:48:58.654+00	2025-03-22 01:30:07.123+00
756edbaa-927b-4420-8d5d-c215079fe9d3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-03-23	07:34:00	Took with dinner instead	2025-03-24 00:05:59.036+00	2025-03-24 10:38:36.873+00
049492d6-89e0-4e25-8e85-703e98876fbe	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-03-25	07:09:00	Good day overall	2025-03-26 12:56:01.651+00	2025-03-26 02:49:55.119+00
145d772b-294f-4caa-b9b0-263668be85ec	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-03-31	09:19:00	Slight nausea	2025-04-01 15:22:50.838+00	2025-04-01 19:37:08.34+00
b989f2c6-e0d3-4ddf-89ea-43e92fdc1dda	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-04-02	07:48:00	Good day overall	2025-04-03 01:20:16.212+00	2025-04-03 13:51:03.844+00
cf3bec9f-3d7c-4015-97b5-be77c38f5964	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-04-04	08:01:00	\N	2025-04-05 02:44:43.471+00	2025-04-05 19:23:47.445+00
38203997-ff56-43f5-b52f-26902ffd42bb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-04-06	09:50:00	Feeling more energetic	2025-04-07 02:16:49.145+00	2025-04-07 13:08:24.955+00
404df813-8b4d-4ff8-9f83-e297f884df9f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-04-08	08:57:00	Took with breakfast	2025-04-09 04:50:12.411+00	2025-04-09 22:16:44.806+00
f4a9cf38-dbd0-4651-a7a2-fe3601353f85	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-04-10	08:42:00	Took with breakfast	2025-04-11 20:34:29.619+00	2025-04-11 02:58:51.684+00
4c27d6b5-02d7-48a3-83d8-28b04a90fd1d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-04-14	09:32:00	Feeling more energetic	2025-04-15 06:37:49.411+00	2025-04-15 16:21:18.537+00
eb152513-28c0-42d0-b361-8c07bf3e3e2b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-04-18	07:52:00	\N	2025-04-19 15:02:07.211+00	2025-04-19 21:29:44.503+00
9140fd63-74a2-449a-a279-7aa818c005d8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-04-24	10:58:00	Feeling more energetic	2025-04-25 02:00:40.121+00	2025-04-25 11:38:27.768+00
677aba39-153a-4d79-b8c6-a985d9535669	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-04-26	09:16:00	No side effects	2025-04-27 07:45:50.765+00	2025-04-27 08:16:45.955+00
042deb32-3122-4597-9855-6e9d478e49f1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-04-28	07:18:00	No side effects	2025-04-29 04:09:39.834+00	2025-04-29 21:52:31.703+00
331a00ed-a7e7-4f8b-a4cd-1d5b83146f43	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-05-02	09:29:00	\N	2025-05-03 11:20:26.834+00	2025-05-03 21:22:26.868+00
b80fdc45-93d1-4890-ab25-664a4fc135a7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-05-04	09:24:00	\N	2025-05-05 03:21:52.144+00	2025-05-05 01:57:21.681+00
c00cfb7b-850c-48bf-8ca2-952f76be2828	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-05-06	10:55:00	Good day overall	2025-05-07 03:41:47.167+00	2025-05-07 21:34:05.577+00
9f1e858a-78bc-4eac-858f-76d2ddc1b609	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-05-10	09:19:00	Almost forgot but remembered	2025-05-11 07:17:35.843+00	2025-05-10 23:14:17.425+00
f2cd9f70-ada4-43c8-a977-2f9aa04336d8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-05-12	07:19:00	\N	2025-05-13 18:16:54.706+00	2025-05-13 19:37:40.34+00
ddc5ba36-f425-495e-97c9-ca59a5c11de4	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-05-16	07:21:00	Slight nausea	2025-05-17 15:11:40.967+00	2025-05-17 18:46:14.618+00
4cae9f96-749d-472a-97b3-7079d7f9f952	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-05-20	08:41:00	\N	2025-05-21 07:10:54.249+00	2025-05-21 14:06:31.273+00
1010c75a-5180-4b34-8eed-a4618416625e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-05-24	10:41:00	\N	2025-05-25 04:51:24.114+00	2025-05-25 06:32:15.301+00
905e865a-0000-4816-88bd-c120a1e45469	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-05-26	09:21:00	\N	2025-05-27 12:39:38.172+00	2025-05-27 12:32:01.662+00
52e8b7ac-b46e-477e-b60a-e652fc0b7f03	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-05-28	07:36:00	Slight nausea	2025-05-29 21:45:13.359+00	2025-05-29 18:20:46.732+00
b394dfa8-3c04-4b12-8d55-846af21edf72	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-05-30	09:32:00	No side effects	2025-05-31 12:13:09.319+00	2025-05-31 08:44:48.777+00
f505be1d-d9e3-4dd6-af7e-5fe0ea887646	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-06-01	07:12:00	\N	2025-06-02 18:21:39.598+00	2025-06-02 02:23:20.908+00
564a04f1-6eee-4c11-a762-e7206c6eae5e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-06-05	08:00:00	Good day overall	2025-06-06 11:09:34.263+00	2025-06-06 11:51:08.789+00
124429b8-26c6-40b2-a0fb-04abc3ed7d19	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-06-07	09:26:00	Almost forgot but remembered	2025-06-08 15:07:32.659+00	2025-06-08 18:55:18.982+00
a6f4e8f5-d490-4a1d-9ca8-0c1f9b2ae1cc	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-06-11	08:51:00	Feeling more energetic	2025-06-12 02:26:58.392+00	2025-06-12 00:35:43.685+00
559bd0ed-5c8f-499f-858f-a3a68d9b649f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-06-13	08:00:00	No side effects	2025-06-14 14:30:10.707+00	2025-06-14 03:17:22.345+00
004671b9-e18c-4f02-a5a9-bc3ea3c125c7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-06-15	08:15:00	Feeling more energetic	2025-06-16 21:50:47.404+00	2025-06-16 14:09:14.513+00
d9c65a5a-d7fa-4bfa-b0a3-eda1c2a4aeed	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-06-17	07:43:00	Good day overall	2025-06-18 08:59:31.777+00	2025-06-18 15:09:35.307+00
5f9792e3-d282-4442-a9d9-abca92660911	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-06-21	07:17:00	Took with dinner instead	2025-06-21 23:53:18.324+00	2025-06-22 18:26:29.546+00
404e808f-8e22-4fac-aaae-eed853b2eee9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-06-23	09:25:00	No side effects	2025-06-24 15:02:02.483+00	2025-06-24 05:52:10.778+00
a1ab2c74-10d4-40d8-aca2-21b4a04d66fc	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-06-25	07:47:00	Feeling good today	2025-06-26 07:31:09.992+00	2025-06-26 04:15:12.802+00
7470cd9d-e69a-4a09-8fb8-675b60a34371	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-06-27	07:00:00	Good day overall	2025-06-28 12:51:00.263+00	2025-06-28 12:14:59.477+00
920360cf-a762-4549-9e0e-0b52c43c95af	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-06-29	07:35:00	\N	2025-06-30 08:37:34.27+00	2025-06-30 17:35:25.232+00
f20acdfe-1f51-442c-9f9a-82280a97bd45	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-07-01	10:50:00	\N	2025-07-02 16:15:16.668+00	2025-07-02 12:50:59.59+00
37995367-12df-40d8-bf9b-96d8bbcc8c1a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-07-03	08:37:00	No side effects	2025-07-03 23:05:29.798+00	2025-07-04 13:23:54.471+00
11158b0e-95c6-41fa-9072-2c6939dbff71	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-07-07	08:49:00	Forgot morning dose, took at lunch	2025-07-08 11:38:19.834+00	2025-07-08 17:37:39.439+00
774e6ddc-9141-46ee-a767-576413ead1d6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-07-09	07:58:00	Feeling more energetic	2025-07-10 04:17:08.431+00	2025-07-10 08:23:24.136+00
36699d4a-f59f-462b-880c-56388404c0fc	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-07-11	07:46:00	Good day overall	2025-07-12 22:36:49.056+00	2025-07-12 01:28:08.493+00
60a67b84-1884-4af8-85a1-d8eb6ede0f03	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-07-13	08:54:00	\N	2025-07-14 17:02:03.526+00	2025-07-14 08:02:19.897+00
95fb02f7-a827-4b83-a369-79ceac5dd67e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-07-17	10:58:00	Feeling good today	2025-07-18 22:44:07.983+00	2025-07-18 02:48:02.794+00
1cc5d371-14b0-400a-9176-841d9194a31f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-07-21	10:25:00	Feeling good today	2025-07-22 00:32:38.678+00	2025-07-22 22:23:18.923+00
dea8604d-d0b2-49a5-b989-6672dbeb1d52	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-07-23	09:40:00	\N	2025-07-24 01:38:31.103+00	2025-07-24 00:43:07.361+00
9159ff14-ad82-405d-9445-deb1dc04e83d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-07-25	10:56:00	\N	2025-07-26 00:18:44.576+00	2025-07-26 09:53:20.224+00
1bb4b0b9-b56f-433a-9987-3ba523272bb0	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-07-27	08:39:00	\N	2025-07-28 20:29:06.501+00	2025-07-28 03:26:36.92+00
4e9bd674-9d84-4c51-b3a0-021380e50849	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-07-29	08:18:00	Feeling good today	2025-07-30 15:27:31.012+00	2025-07-30 12:48:51.135+00
9ef74b36-37f1-49e3-bdaf-fd328605a2c1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-07-31	09:28:00	\N	2025-08-01 00:31:08.65+00	2025-08-01 09:49:28.533+00
49e9af55-ec82-4258-8fa4-47beef79ced1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-08-02	10:03:00	\N	2025-08-03 12:41:05.211+00	2025-08-03 17:56:30.297+00
73e8b9b4-4fce-4529-840b-54522dea1e03	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-08-06	09:30:00	No side effects	2025-08-07 13:05:10.381+00	2025-08-07 11:30:58.348+00
e1c57b9b-1e22-4e2e-b820-dce7e8174dee	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-08-08	07:00:00	\N	2025-08-09 14:15:12.796+00	2025-08-09 03:40:48.102+00
ff9c727d-fecf-4b12-a82e-93be32de5be1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-08-10	07:20:00	\N	2025-08-11 12:37:00.956+00	2025-08-11 16:04:00.564+00
c208628b-ca06-48c5-8001-0793458ad1e1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-08-12	10:27:00	Took with breakfast	2025-08-13 22:35:01.857+00	2025-08-13 08:08:57.508+00
aa01b97f-6cd3-448f-95b9-9cb6734a77fd	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-08-14	07:07:00	No side effects	2025-08-15 10:58:23.366+00	2025-08-15 20:06:40.843+00
733211a8-cbf7-4956-8cb7-8eaee9707361	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-08-16	10:56:00	Almost forgot but remembered	2025-08-17 02:11:20.253+00	2025-08-17 07:12:45.925+00
5f2289c3-94d2-48fc-8cee-245e0cf0f7e4	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-08-18	07:24:00	No side effects	2025-08-19 09:53:26.706+00	2025-08-19 06:41:36.438+00
53a4a173-126d-439e-ab5e-4c27a014acaf	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-08-22	09:49:00	\N	2025-08-23 22:32:42.639+00	2025-08-23 06:51:59.323+00
c5b7e170-7498-46c9-8793-e0356db32e1d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-08-24	08:27:00	Took with dinner instead	2025-08-25 13:18:23.667+00	2025-08-25 08:06:24.149+00
1b7be21c-a835-423f-8b56-38194e0dbef6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-08-26	07:51:00	Almost forgot but remembered	2025-08-27 20:06:26.659+00	2025-08-27 00:59:02.728+00
37b3a899-c1d4-4302-835c-25fadafc3978	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-08-28	07:35:00	Slight nausea	2025-08-29 13:30:04.481+00	2025-08-29 08:46:01.504+00
4a7afc73-dc1c-4b80-bcf2-7963ebb08bc8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-09-01	08:04:00	Forgot morning dose, took at lunch	2025-09-02 06:58:28.828+00	2025-09-02 03:02:29.331+00
c098e3b0-1399-46ef-ba91-16d65a92be60	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-09-03	09:48:00	\N	2025-09-04 07:27:26.744+00	2025-09-04 02:44:01.809+00
bbda8f8c-8618-4046-9c31-bb88de3c2165	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-09-09	09:52:00	Feeling more energetic	2025-09-10 10:52:18.564+00	2025-09-10 06:09:44.58+00
b6c956f5-5cfa-4b3c-a749-2ceaaffd3712	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-09-11	08:40:00	Almost forgot but remembered	2025-09-12 10:38:33.951+00	2025-09-12 02:57:58.383+00
fe2fb2e6-b99a-415c-a043-7e6222e79681	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-09-13	10:08:00	Slight nausea	2025-09-14 12:04:23.193+00	2025-09-14 22:37:34.336+00
5189a788-1aa8-4a02-9f23-ca4a198d5249	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-09-15	08:39:00	\N	2025-09-16 13:35:37.404+00	2025-09-16 10:02:17.996+00
730e83ac-a9e9-4801-b1c5-f7bc1704c9ca	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-09-17	09:12:00	Feeling good today	2025-09-18 14:47:03.676+00	2025-09-18 07:31:34.75+00
05bef635-6903-42f8-88bb-3201140a52c7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-09-19	09:26:00	Forgot morning dose, took at lunch	2025-09-20 13:50:19.678+00	2025-09-20 01:15:51.354+00
b8eeee30-5da5-4752-9d41-8d1b1209e81f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-09-21	10:21:00	No side effects	2025-09-22 01:09:31.902+00	2025-09-22 12:01:29.915+00
ebbb0a5f-04e9-4e58-a8e6-dccceb9e2980	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-09-23	08:25:00	Took with dinner instead	2025-09-24 15:46:27.884+00	2025-09-24 11:14:37.223+00
46a24d3b-d010-43b2-ab42-1a8a5fea7389	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-09-25	07:50:00	Feeling more energetic	2025-09-26 10:53:20.805+00	2025-09-26 15:44:36.384+00
a1ec4ace-8f92-434e-95c8-a77f9f5630c7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-09-29	10:42:00	\N	2025-09-30 01:24:09.689+00	2025-09-30 09:57:22.627+00
efa40d62-6c0a-462c-8131-9230c3fb59cc	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-10-01	10:47:00	Feeling good today	2025-10-02 16:53:08.59+00	2025-10-02 12:57:48.664+00
a8993d36-30ed-4555-8dc8-c807330a3e7d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-10-03	09:13:00	\N	2025-10-04 01:54:17.476+00	2025-10-04 15:02:36.383+00
7db1fe56-1ee6-4e93-a67a-fa909efbb293	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-10-05	08:27:00	Took with breakfast	2025-10-06 19:37:03.075+00	2025-10-05 23:38:00.015+00
054d9681-8ef6-4c41-b046-6d65cca7a84b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	2025-10-07	09:23:00	Forgot morning dose, took at lunch	2025-10-08 14:46:24.933+00	2025-10-08 14:23:47.015+00
\.


--
-- TOC entry 4751 (class 0 OID 18436)
-- Dependencies: 324
-- Data for Name: medications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medications (id, name, generic_name, brand_name, dosage_form, strength, description, category, unit_price, requires_prescription, active, created_at, updated_at) FROM stdin;
72ea2dc1-23e0-458b-a556-5dd6cd3041ea	Semaglutide	Semaglutide	Ozempic	injection	0.5mg	GLP-1 receptor agonist for weight management and diabetes	weight_loss	899.99	t	t	2025-10-06 03:29:33.162981+00	2025-10-06 03:29:33.162981+00
4e4cefd5-6948-4415-84cf-e268f81c60ff	Semaglutide	Semaglutide	Wegovy	injection	1.0mg	GLP-1 receptor agonist specifically for chronic weight management	weight_loss	1299.99	t	t	2025-10-06 03:29:33.162981+00	2025-10-06 03:29:33.162981+00
77c41b69-f3b6-4194-98f0-118f1c7aecef	Tirzepatide	Tirzepatide	Mounjaro	injection	2.5mg	Dual GIP/GLP-1 receptor agonist for weight loss	weight_loss	1199.99	t	t	2025-10-06 03:29:33.162981+00	2025-10-06 03:29:33.162981+00
f5a3423a-7d85-4447-8374-0901ae733364	Liraglutide	Liraglutide	Saxenda	injection	3.0mg	GLP-1 receptor agonist for weight management	weight_loss	1099.99	t	t	2025-10-06 03:29:33.162981+00	2025-10-06 03:29:33.162981+00
6779fca6-1951-45cc-a54c-f0fec69d43e5	Orlistat	Orlistat	Xenical	capsule	120mg	Lipase inhibitor for weight loss	weight_loss	199.99	t	t	2025-10-06 03:29:33.162981+00	2025-10-06 03:29:33.162981+00
c2182baa-3d29-49a7-90ab-f94cd0c1fc5b	Phentermine	Phentermine	Adipex-P	tablet	37.5mg	Appetite suppressant for short-term weight loss	weight_loss	89.99	t	t	2025-10-06 03:29:33.162981+00	2025-10-06 03:29:33.162981+00
9f849752-50a2-4ec4-b28f-0373977622a2	Testosterone Cypionate	Testosterone Cypionate	Depo-Testosterone	injection	200mg/ml	Testosterone replacement therapy for hypogonadism	mens_health	199.99	t	t	2025-10-06 03:29:33.162981+00	2025-10-06 03:29:33.162981+00
027330e6-b34a-4395-a8b6-18021096d2e2	Testosterone Enanthate	Testosterone Enanthate	Delatestryl	injection	250mg/ml	Long-acting testosterone for hormone replacement	mens_health	219.99	t	t	2025-10-06 03:29:33.162981+00	2025-10-06 03:29:33.162981+00
b894c70d-d2cc-466b-b6c2-2e1a1b16038c	Testosterone Gel	Testosterone	AndroGel	gel	1.62%	Topical testosterone replacement therapy	mens_health	299.99	t	t	2025-10-06 03:29:33.162981+00	2025-10-06 03:29:33.162981+00
e98cd3af-253a-4e24-8ff0-b82408c81e76	Sildenafil	Sildenafil	Viagra	tablet	50mg	PDE5 inhibitor for erectile dysfunction	mens_health	89.99	t	t	2025-10-06 03:29:33.162981+00	2025-10-06 03:29:33.162981+00
2b7af324-79c7-4ecd-99b8-c2c3eecfe4ab	Tadalafil	Tadalafil	Cialis	tablet	20mg	Long-acting PDE5 inhibitor for erectile dysfunction	mens_health	99.99	t	t	2025-10-06 03:29:33.162981+00	2025-10-06 03:29:33.162981+00
5252a851-4e86-40d5-b91a-4d72b2076728	Finasteride	Finasteride	Propecia	tablet	1mg	5-alpha reductase inhibitor for male pattern baldness	mens_health	79.99	t	t	2025-10-06 03:29:33.162981+00	2025-10-06 03:29:33.162981+00
ea09be10-40e7-4521-8954-3b6a62f60f0a	HCG	Human Chorionic Gonadotropin	Pregnyl	injection	5000 IU	Hormone therapy to support testosterone production	mens_health	149.99	t	t	2025-10-06 03:29:33.162981+00	2025-10-06 03:29:33.162981+00
\.


--
-- TOC entry 4748 (class 0 OID 18357)
-- Dependencies: 321
-- Data for Name: patient_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patient_assignments (id, patient_id, provider_id, treatment_type, is_primary, assigned_date, active, created_at, updated_at) FROM stdin;
c8bb6c07-65ff-4dae-b0ae-b47855e5a315	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	e7fcaca9-bde3-4cb9-8e57-2d1813fe1551	weight_loss	t	2025-10-06 03:38:18.489459+00	t	2025-10-06 03:38:18.489459+00	2025-10-06 03:38:18.489459+00
\.


--
-- TOC entry 4768 (class 0 OID 19192)
-- Dependencies: 344
-- Data for Name: patient_health_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patient_health_metrics (id, patient_id, metric_type, value, unit, recorded_at, synced_from, metadata, created_at, updated_at) FROM stdin;
d6178428-cda7-4534-b587-8c48bc165c9c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	125	grams	2025-01-01 18:47:00+00	manual	{"season": "winter", "dayIndex": 0, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
988f0bba-0680-4ba8-98d5-437cb7874cf7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	162	grams	2025-01-03 00:38:00+00	manual	{"season": "winter", "dayIndex": 1, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
dd5e68d5-d3d0-4cf9-982d-4dc59c57cfca	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	69	fl oz	2025-01-03 00:37:00+00	manual	{"season": "winter", "dayIndex": 1, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
6c49b227-188a-4d5c-a16a-4908c4de3992	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2438	kcal	2025-01-03 22:32:00+00	manual	{"season": "winter", "dayIndex": 2, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
bca28af6-0cff-496b-9b1a-df0aca246a6d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	66	bpm	2025-01-04 02:11:00+00	manual	{"season": "winter", "dayIndex": 2, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
e21ff1a3-49ae-4330-bd1a-994fa3368db0	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	11190	steps	2025-01-03 16:34:00+00	manual	{"season": "winter", "dayIndex": 2, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
b7dd56a5-dcb8-45ca-8d54-d769ee6c846c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	5291	steps	2025-01-04 23:15:00+00	manual	{"season": "winter", "dayIndex": 3, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
5be1a571-d4dc-4878-a361-943f03775921	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	147	grams	2025-01-05 01:21:00+00	manual	{"season": "winter", "dayIndex": 3, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
762e4aed-3ef4-4b4d-8a76-67fcb87f3e77	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	10.4	hours	2025-01-05 22:00:00+00	manual	{"season": "winter", "dayIndex": 4, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
d076ba40-b5e4-4293-9421-5db229204960	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	119	grams	2025-01-08 00:23:00+00	manual	{"season": "winter", "dayIndex": 6, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
d27e9ed5-b606-48f6-8cf9-4e8ddb941ad4	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7.1	hours	2025-01-07 23:20:00+00	manual	{"season": "winter", "dayIndex": 6, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
0deb6b0b-822e-4b5a-9be5-f8284357eaab	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	68	bpm	2025-01-08 17:59:00+00	manual	{"season": "winter", "dayIndex": 7, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
1ca8e528-513c-4293-a8d7-942473157dab	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	141	grams	2025-01-08 16:03:00+00	manual	{"season": "winter", "dayIndex": 7, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
7f0c965c-40b9-447e-a209-89f64f925fb9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	9190	steps	2025-01-09 23:03:00+00	manual	{"season": "winter", "dayIndex": 8, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
b1068058-e588-4b31-9080-c471ee739a9a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7.7	hours	2025-01-12 01:00:00+00	manual	{"season": "winter", "dayIndex": 10, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
93f8ba0a-7af3-40d9-ad2a-79c6347ca0e0	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2188	kcal	2025-01-11 22:21:00+00	manual	{"season": "winter", "dayIndex": 10, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
4e6cea0a-6857-47b7-bf70-a06ed082e43c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	5167	steps	2025-01-11 17:18:00+00	manual	{"season": "winter", "dayIndex": 10, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
b3aa64b5-9c90-4bd3-9760-83b34154927f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7.8	hours	2025-01-14 17:19:00+00	manual	{"season": "winter", "dayIndex": 13, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
6de3b49d-521d-4334-b8fc-f1e9da37541a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	114	grams	2025-01-16 02:33:00+00	manual	{"season": "winter", "dayIndex": 14, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
220bfd23-32f0-469a-b0b7-5f65c75eafba	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	171	grams	2025-01-17 21:49:00+00	manual	{"season": "winter", "dayIndex": 16, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
ab1862e7-5819-4787-acc6-30fec66cc829	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	7839	steps	2025-01-18 03:29:00+00	manual	{"season": "winter", "dayIndex": 16, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
d3acd39c-421a-4410-b114-0509d0f94f16	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	73	bpm	2025-01-17 22:29:00+00	manual	{"season": "winter", "dayIndex": 16, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
574428e8-ce75-41d6-a9da-c13b79b9bf43	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	62	bpm	2025-01-19 01:43:00+00	manual	{"season": "winter", "dayIndex": 17, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
4aef3f48-e87d-446e-9089-8bb2d40b77fd	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	6750	steps	2025-01-18 16:52:00+00	manual	{"season": "winter", "dayIndex": 17, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
fcb2b6ff-5c2b-4d3f-9f3c-c50790f431f2	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	74	bpm	2025-01-20 01:09:00+00	manual	{"season": "winter", "dayIndex": 18, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
16cb2fcb-e690-4857-a872-af86f2a17a8c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	123	grams	2025-01-19 16:25:00+00	manual	{"season": "winter", "dayIndex": 18, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
a43e58f2-ed09-4fb1-a59c-09c06baa7d30	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.4	hours	2025-01-20 22:04:00+00	manual	{"season": "winter", "dayIndex": 19, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
04732f29-a260-4fa0-b750-15d8b56f410e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	138	grams	2025-01-21 00:37:00+00	manual	{"season": "winter", "dayIndex": 19, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
2912e04a-ca43-4395-8f5d-d83b07732919	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	1989	kcal	2025-01-23 00:40:00+00	manual	{"season": "winter", "dayIndex": 21, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
3b2ad978-2eb0-4101-984b-6964379fb333	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.8	hours	2025-01-22 22:39:00+00	manual	{"season": "winter", "dayIndex": 21, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
6f2e7fc5-303b-46e5-a1f5-1a275637b8d5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	8998	steps	2025-01-22 23:22:00+00	manual	{"season": "winter", "dayIndex": 21, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
ffa000e8-82b3-40b3-abcf-4541aab60689	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	67	fl oz	2025-01-23 02:48:00+00	manual	{"season": "winter", "dayIndex": 21, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
712f215f-46fc-4b12-a235-abb6da6c0a81	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	6984	steps	2025-01-25 17:06:00+00	manual	{"season": "winter", "dayIndex": 24, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
ec264084-38fa-4807-9843-0ef974815144	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	9.5	hours	2025-01-26 19:23:00+00	manual	{"season": "winter", "dayIndex": 25, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
b1e091f9-198d-4146-9e5a-f954de1201ac	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	139	grams	2025-01-27 01:59:00+00	manual	{"season": "winter", "dayIndex": 25, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
50aa2f68-d776-4ede-8d60-ee3514bd89bc	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	66	bpm	2025-01-26 20:55:00+00	manual	{"season": "winter", "dayIndex": 25, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
a159d506-7a5a-446f-b660-f5888e6def09	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	56	fl oz	2025-01-27 21:27:00+00	manual	{"season": "winter", "dayIndex": 26, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
c867fdfa-25d4-4167-9c7e-e1b2d481091e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	130	grams	2025-01-28 17:35:00+00	manual	{"season": "winter", "dayIndex": 27, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
1d5eba35-71e1-45ea-9697-67279654720f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	63	bpm	2025-01-29 00:23:00+00	manual	{"season": "winter", "dayIndex": 27, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
4d3f227d-b453-4caf-ac71-d066b17f953d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	6.6	hours	2025-01-28 17:14:00+00	manual	{"season": "winter", "dayIndex": 27, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
72ca5a1d-0160-4cb8-ba2a-cdd6d97f61f6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	59	fl oz	2025-02-02 01:38:00+00	manual	{"season": "winter", "dayIndex": 31, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
a3371c72-4435-4487-93e2-d82a41a13217	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	7008	steps	2025-02-01 19:13:00+00	manual	{"season": "winter", "dayIndex": 31, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
f61a429b-04d6-4227-8a44-684a97298da8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	183	grams	2025-02-03 21:35:00+00	manual	{"season": "winter", "dayIndex": 33, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
dd7e9dce-8dc0-4211-998a-801d7df63179	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7.4	hours	2025-02-04 00:30:00+00	manual	{"season": "winter", "dayIndex": 33, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
0578e0f9-9ff9-4c73-94d0-b980920cca46	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	181	grams	2025-02-04 23:42:00+00	manual	{"season": "winter", "dayIndex": 34, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
3a7edade-5430-4240-8640-4498046a7b0c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	6.8	hours	2025-02-06 03:01:00+00	manual	{"season": "winter", "dayIndex": 35, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
f60834f0-d4f3-47a8-b57a-d46e48c7bf95	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	72	bpm	2025-02-05 19:26:00+00	manual	{"season": "winter", "dayIndex": 35, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
59bcee1e-a006-497f-8718-d6e69e8eb1fd	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	66	bpm	2025-02-06 20:24:00+00	manual	{"season": "winter", "dayIndex": 36, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
0a7e6dc9-a99b-4a54-9b24-31be9462ba92	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	51	fl oz	2025-02-08 00:51:00+00	manual	{"season": "winter", "dayIndex": 37, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
0ce3e664-e895-49f0-8aed-07e9c4d8fccb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	66	bpm	2025-02-07 17:12:00+00	manual	{"season": "winter", "dayIndex": 37, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
670ed906-aa49-47be-9b3f-9ac2a479ef16	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7	hours	2025-02-10 17:23:00+00	manual	{"season": "winter", "dayIndex": 40, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
395b77bd-6dfa-4c80-82c2-794d627f13bf	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	8930	steps	2025-02-10 18:43:00+00	manual	{"season": "winter", "dayIndex": 40, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
121471dc-87c7-4a76-abe7-37a68baf892d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2513	kcal	2025-02-10 20:58:00+00	manual	{"season": "winter", "dayIndex": 40, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
9cc75d6e-bdbf-4d65-9c22-bd0eb53f0ff6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	8267	steps	2025-02-11 22:52:00+00	manual	{"season": "winter", "dayIndex": 41, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
9dbe73d0-e1b0-4169-8dc9-6164e85c5428	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.3	hours	2025-02-13 01:06:00+00	manual	{"season": "winter", "dayIndex": 42, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
99e4e826-b0f5-457c-a893-a3bdbfe7cd30	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	9790	steps	2025-02-13 03:08:00+00	manual	{"season": "winter", "dayIndex": 42, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
4a4bfb44-eb57-4fe1-9ee7-f7758c7b805a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	7199	steps	2025-02-13 16:21:00+00	manual	{"season": "winter", "dayIndex": 43, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
b484638c-67ff-40a3-962f-82f49d50919b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	130	grams	2025-02-14 20:48:00+00	manual	{"season": "winter", "dayIndex": 44, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
f60e176a-5c66-4a41-9801-7f8e157364e6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	9718	steps	2025-02-14 22:34:00+00	manual	{"season": "winter", "dayIndex": 44, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
6e55f259-6d75-4d44-950b-3af9c8300da4	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2383	kcal	2025-02-16 02:59:00+00	manual	{"season": "winter", "dayIndex": 45, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
42919085-1de4-4fde-879d-ff25a6f0e93b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.1	hours	2025-02-15 22:02:00+00	manual	{"season": "winter", "dayIndex": 45, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
d283db77-a70d-4488-8dca-51b7247b9ea0	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	65	bpm	2025-02-18 16:56:00+00	manual	{"season": "winter", "dayIndex": 48, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
609d01a4-04dd-44c9-af64-58b79ae66afb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2341	kcal	2025-02-20 22:42:00+00	manual	{"season": "winter", "dayIndex": 50, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
c1fb35fa-dfa0-4e1b-ab7d-68930d0eca61	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	66	bpm	2025-02-20 21:07:00+00	manual	{"season": "winter", "dayIndex": 50, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
74b3966c-2048-4c7f-b02e-29041dad4f88	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	59	bpm	2025-02-21 18:53:00+00	manual	{"season": "winter", "dayIndex": 51, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
57ff0ff9-1e8e-4d02-ad89-31cc452a27c3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2263	kcal	2025-02-23 02:53:00+00	manual	{"season": "winter", "dayIndex": 52, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
2b92f871-17a7-4726-b162-e8044ae94f48	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	134	grams	2025-02-23 01:42:00+00	manual	{"season": "winter", "dayIndex": 52, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
6df45082-1da7-4140-b799-92a8345ad81d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	61	bpm	2025-02-23 03:57:00+00	manual	{"season": "winter", "dayIndex": 52, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
53af7206-e0e5-4dd4-8a71-4919dd2b5b62	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2117	kcal	2025-02-24 01:56:00+00	manual	{"season": "winter", "dayIndex": 53, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
aafc2fbb-98dc-49c9-a417-730d167e5c0d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	62	bpm	2025-02-26 03:02:00+00	manual	{"season": "winter", "dayIndex": 55, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
06559661-a2d1-4e2b-af23-784b24b36ba0	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	70	fl oz	2025-02-25 22:13:00+00	manual	{"season": "winter", "dayIndex": 55, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
d74f4176-7d89-48b5-b4a5-a2120b164e2b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.5	hours	2025-02-25 22:37:00+00	manual	{"season": "winter", "dayIndex": 55, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
542a304b-c1fe-468c-b700-d9de3c6a8d7c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	171	grams	2025-02-25 22:29:00+00	manual	{"season": "winter", "dayIndex": 55, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
4dc8a6f0-8c2e-413e-a11b-6ae884f775a9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7.2	hours	2025-02-27 02:28:00+00	manual	{"season": "winter", "dayIndex": 56, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.587413+00	2025-10-07 04:47:32.587413+00
b91640ce-f705-47da-9941-586c6ddb4a18	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	165	grams	2025-04-22 19:29:00+00	manual	{"season": "spring", "dayIndex": 111, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
cd584bca-d42b-4917-bbc6-a6ffb703281b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	8632	steps	2025-04-22 23:00:00+00	manual	{"season": "spring", "dayIndex": 111, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
249d8a6a-476b-49f9-83ea-78435f0e9591	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	6.6	hours	2025-04-22 22:32:00+00	manual	{"season": "spring", "dayIndex": 111, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
502fef97-1b6f-41b7-a93e-49852c49e380	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	66	fl oz	2025-04-23 18:39:00+00	manual	{"season": "spring", "dayIndex": 112, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
40844905-a029-4be5-811b-dfbf0db7dd20	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2115	kcal	2025-04-23 23:00:00+00	manual	{"season": "spring", "dayIndex": 112, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
0eba4ab6-d1c9-4a9d-9dff-620e563f7719	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2202	kcal	2025-04-24 20:18:00+00	manual	{"season": "spring", "dayIndex": 113, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
75a60e65-0aaa-4219-bf50-2c8923aa9258	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	6.9	hours	2025-04-25 00:50:00+00	manual	{"season": "spring", "dayIndex": 113, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
12696a67-ac4e-4d92-b361-2c4a652b2a13	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	7979	steps	2025-03-02 18:47:00+00	manual	{"season": "spring", "dayIndex": 60, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
d2a7166d-2271-4be1-a716-f10dae387bda	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7.4	hours	2025-03-03 03:08:00+00	manual	{"season": "spring", "dayIndex": 60, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
2ea57e52-f65a-4c96-b20c-40c8ad3324a3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	58	fl oz	2025-03-03 19:25:00+00	manual	{"season": "spring", "dayIndex": 61, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
0662267f-934a-407b-b548-d2b4c60a7a24	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	6511	steps	2025-03-03 23:32:00+00	manual	{"season": "spring", "dayIndex": 61, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
4f8d2ea8-53e4-4bb2-9313-7f373e475d84	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	60	bpm	2025-03-03 20:36:00+00	manual	{"season": "spring", "dayIndex": 61, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
f22311ff-336e-4145-8064-fbb38a69c33a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.4	hours	2025-03-04 22:13:00+00	manual	{"season": "spring", "dayIndex": 62, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
8d11c737-74c8-4226-b05a-c1da010922a1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	173	grams	2025-03-07 00:43:00+00	manual	{"season": "spring", "dayIndex": 64, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
c7464462-cda2-4910-99ce-34d03b8543bf	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	57	fl oz	2025-03-06 19:34:00+00	manual	{"season": "spring", "dayIndex": 64, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
7c3c3ec3-aad8-4352-9580-2563c012499b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7.8	hours	2025-03-06 21:12:00+00	manual	{"season": "spring", "dayIndex": 64, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
6614f65f-5867-43d0-ad33-90cffb3ba1ed	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	71	bpm	2025-03-12 17:13:00+00	manual	{"season": "spring", "dayIndex": 70, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
482fc62b-fdd6-4bf7-ab6c-13baa9ef7868	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	102	grams	2025-03-12 16:45:00+00	manual	{"season": "spring", "dayIndex": 70, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
6c0e95e5-b1ee-43a2-bcbe-a89f6d73bb00	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	176	grams	2025-03-14 22:19:00+00	manual	{"season": "spring", "dayIndex": 72, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
fab81b5b-a096-44b6-8797-7d0b57a3d1e1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	10.1	hours	2025-03-16 21:56:00+00	manual	{"season": "spring", "dayIndex": 74, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
78a96de8-a2f0-433f-9b1f-610f182a31ad	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	76	fl oz	2025-03-17 23:21:00+00	manual	{"season": "spring", "dayIndex": 75, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
6d4573a3-2f6a-413c-abbe-fd99e122e337	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	10927	steps	2025-03-17 16:31:00+00	manual	{"season": "spring", "dayIndex": 75, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
fc73b747-9b92-4fb1-927e-ccbf280cc600	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	186	grams	2025-03-17 22:53:00+00	manual	{"season": "spring", "dayIndex": 75, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
a50210a4-2048-4e4d-94e6-005542b9f46b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2243	kcal	2025-03-18 23:58:00+00	manual	{"season": "spring", "dayIndex": 76, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
abeacb5b-6256-4403-bfb7-1458985eb6c6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	64	fl oz	2025-03-21 22:20:00+00	manual	{"season": "spring", "dayIndex": 79, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
1cd3cc90-2890-4a9b-9ec1-78633b190e0d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	116	grams	2025-03-22 18:32:00+00	manual	{"season": "spring", "dayIndex": 80, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
579494f9-7d29-420b-9f23-271d93f6a711	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2807	kcal	2025-03-22 19:13:00+00	manual	{"season": "spring", "dayIndex": 80, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
23bcc29e-01b6-441c-bf5a-a8926a2c4d3f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	54	fl oz	2025-03-22 18:33:00+00	manual	{"season": "spring", "dayIndex": 80, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
423652c3-bb7a-44d7-bbc8-4f0d8e5504bd	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	52	fl oz	2025-03-24 17:24:00+00	manual	{"season": "spring", "dayIndex": 82, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
f44bf1bc-0253-427a-b001-1c24a7525779	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	63	bpm	2025-03-26 02:27:00+00	manual	{"season": "spring", "dayIndex": 83, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
34648624-d988-42e9-9529-0e54281ad8f9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	56	fl oz	2025-03-26 16:16:00+00	manual	{"season": "spring", "dayIndex": 84, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
e48a83b4-ac51-46e6-b79d-22fc63bb0ec8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	97	grams	2025-03-26 18:52:00+00	manual	{"season": "spring", "dayIndex": 84, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
3db13b82-3375-4b57-942b-de16b60052b9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	177	grams	2025-03-27 20:34:00+00	manual	{"season": "spring", "dayIndex": 85, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
0d76bbaf-e6db-4664-96b4-aa2a0340160d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	1830	kcal	2025-03-27 22:21:00+00	manual	{"season": "spring", "dayIndex": 85, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
1714ca64-a6eb-44c2-9a00-45206d0108e3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	64	bpm	2025-03-27 19:08:00+00	manual	{"season": "spring", "dayIndex": 85, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
fcfe3e7f-bee4-417e-8a5b-385eecf65372	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	6.7	hours	2025-03-27 20:14:00+00	manual	{"season": "spring", "dayIndex": 85, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
509a0e63-5d9a-4f24-bbf9-354db317b2e0	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	7852	steps	2025-03-30 00:48:00+00	manual	{"season": "spring", "dayIndex": 87, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
c0855818-750c-4bbf-b390-a41cf044ccdb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2534	kcal	2025-03-31 20:56:00+00	manual	{"season": "spring", "dayIndex": 89, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
59e7592b-d5ae-4ef1-98da-1b5bdb4376d7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-01-01 23:18:42.763+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": null, "days_since_injection": 0}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
cca20b79-0307-405c-87b0-03af6dcec7b3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-01-02 21:14:05.766+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": null, "days_since_injection": 0}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
c0c7118f-faff-48e8-b53a-fc0f5b077280	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	20	grams	2025-01-03 01:33:58.428+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": null, "days_since_injection": 0}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
caa59394-3c3f-49a0-8f7f-aaaf64a04952	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-01-04 12:31:21.598+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": null, "days_since_injection": 0}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
a6cc4698-ca44-492b-ae8c-e19e4db56963	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-01-05 07:19:28.452+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": null, "days_since_injection": 0}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
37330d51-19f7-484e-8b86-755f149bfb52	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	21	grams	2025-01-06 07:13:40.722+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": null, "days_since_injection": 0}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
200f155d-9520-4c86-86a7-66e40819bf32	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-01-07 15:39:23.051+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": null, "days_since_injection": 0}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
32dca135-f4e6-4a46-98ab-5a76eae13e86	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-01-08 06:27:45.771+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": null, "days_since_injection": 0}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
151549d7-d2fa-4146-826f-9f5f91d28592	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-01-09 19:01:17.231+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-09", "days_since_injection": 0}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
b0699f86-6a85-4c07-8bbd-8551896070e3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-01-10 11:38:19.748+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-09", "days_since_injection": 1}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
863df2d2-b67e-4f5a-a2f0-d32fea60153f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	20	grams	2025-01-11 06:13:17.723+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-11", "days_since_injection": 0}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
ce8e9fd1-70a8-4600-9f63-6df576f6587a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-01-12 16:09:39.151+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-11", "days_since_injection": 1}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
84e48f4b-2304-4782-bd44-fcd636cae984	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	25	grams	2025-01-13 18:51:21.029+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-13", "days_since_injection": 0}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
565ff0ce-78cb-45ea-9408-90bc19b5bea8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	64	bpm	2025-03-31 22:12:00+00	manual	{"season": "spring", "dayIndex": 89, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
4386a62e-545c-4f54-bc81-7e97d77fa487	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	9	hours	2025-03-31 20:06:00+00	manual	{"season": "spring", "dayIndex": 89, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
c01eaafd-3d53-4f21-a5ad-02a579beaa7f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	118	grams	2025-03-31 17:45:00+00	manual	{"season": "spring", "dayIndex": 89, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
4443a377-3dbd-45a3-937e-134675eeac73	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	6.3	hours	2025-04-02 00:18:00+00	manual	{"season": "spring", "dayIndex": 90, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
1a6cb8b3-6ce6-47ff-b58c-bf98a92a2bdd	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	9452	steps	2025-04-01 17:12:00+00	manual	{"season": "spring", "dayIndex": 90, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
c14a7014-1aeb-4a80-b0d6-a756d97379b8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	59	bpm	2025-04-01 19:38:00+00	manual	{"season": "spring", "dayIndex": 90, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
f279126e-40ea-4cdb-8204-d9512b835441	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-01-14 18:33:13.266+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-13", "days_since_injection": 1}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
f923d1bd-e86d-4bef-9ecb-8506269aa566	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-01-15 11:11:34.322+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-15", "days_since_injection": 0}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
1955c902-8565-4516-b4c3-de963f331a13	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-01-16 07:52:22.525+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-15", "days_since_injection": 1}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
29002fa8-e4b3-444f-ae7c-5e8b88d5b019	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	12	grams	2025-01-17 20:11:20.297+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-17", "days_since_injection": 0}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
996398ec-e230-49cf-9b94-c6bc3e6586e7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-01-18 01:33:24.513+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-17", "days_since_injection": 1}	2025-10-08 00:05:43.734+00	2025-10-08 00:05:43.734+00
4967bb5a-87a4-40af-bc81-7ee9567f54a8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-01-19 04:54:49.7+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-19", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
0ab52a8a-d46c-47e4-b09f-7211d0100182	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	25	grams	2025-01-20 06:19:46.515+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-19", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
4bb18e11-ffa5-4fdd-bfd3-8efd209019c1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-01-21 08:10:34.073+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-21", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
f6a208d6-6ad2-450d-baf6-44a0530c9480	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-01-22 11:22:01.448+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-21", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
098d29f6-bc72-408b-b936-2760f9948cd2	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-01-23 07:47:31.572+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-23", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
19e992e9-92c3-4c2c-ad4d-408a8d4c5a89	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	12	grams	2025-01-24 09:42:57.439+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-23", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
2fd2fe80-30d9-4b4d-be06-217cf38ae371	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-01-25 11:28:08.531+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-25", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
ed8afbc3-0681-4576-81dc-ac4d641e709d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	22	grams	2025-01-26 00:18:10.044+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-25", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
a356bc24-fda2-4a57-8901-1ba27f1f988e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	33	grams	2025-01-27 08:30:37.214+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-27", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
106cde95-6ac2-4848-bc77-6af0bb88e6d7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-01-28 16:26:32.896+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-27", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
cf86acc9-8642-4085-ab2d-98e2cea7bfc2	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	10	grams	2025-01-29 13:00:40.768+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-29", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
6d13ac57-a08d-4c02-b451-ba2a8ba28f1f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-01-30 13:25:53.442+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-29", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
8755caad-7d6b-45e4-b350-7d8c3b59775e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-01-31 14:32:14.799+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-31", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
fa5857da-4559-40f1-84fa-81e3a6238ae0	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-02-01 06:35:10.343+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-01-31", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
d3c01d02-7cf0-43ed-91c7-731c384cbf59	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-02-02 00:52:43.927+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-02", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
dfddc1ba-f7df-4184-89e1-530edd4a6e35	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	21	grams	2025-02-03 02:51:21.97+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-02", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
4cbce6ec-53d3-4d5a-a63e-4573b0d8e3e9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-02-04 02:52:57.266+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-04", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
02f976a9-baa0-4619-ba1b-789d4bd7067b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-02-05 02:13:56.119+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-04", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
d3693580-4f3e-4f82-8336-49e2694c8abb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	14	grams	2025-02-06 21:49:50.678+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-04", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
853173c8-527e-4319-b8d9-e45740aaa164	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-02-07 23:10:17.306+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-04", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
1f7c77c5-40b2-42ec-a28a-1c83ac94378d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	12	grams	2025-02-08 12:14:36.685+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-08", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
702b8680-96a8-4af1-abe5-496c995f0c16	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-02-09 06:24:46.616+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-08", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
057af914-5f9b-441c-8268-9d1eacf877cb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	23	grams	2025-02-10 04:14:18.997+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-10", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
85730de6-a18e-43d9-a328-8ef1ef1bb8c2	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	14	grams	2025-02-11 02:21:52.698+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-10", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
6a825df9-ee01-41a1-a2f6-a3ad74d197f2	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-02-12 20:53:15.05+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-12", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
de6a834a-a54b-4a57-a1d6-c936543527d3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-02-13 14:29:23.646+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-12", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
b383a4f5-f752-4179-b59d-a1c4d927b1a8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	21	grams	2025-02-14 02:08:34.166+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-12", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
1d6c187d-dd4f-48bf-845b-4a0a8f9e4205	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-02-15 17:08:12.505+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-12", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
4db87557-b7fe-43f8-99b7-bbcd9fdb0a41	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-02-16 09:18:05.46+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-16", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
f667b8fa-56de-44d4-9aa5-649b273a82e6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-02-17 22:38:04.27+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-16", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
3cab3dc3-7fdb-483b-bb33-1fbdeec1e547	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-02-18 12:01:05.669+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-18", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
66575b98-f7dc-43f6-aff8-3c7519bafb48	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-02-19 06:04:12.508+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-18", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
d4836907-eb54-4779-a78b-41575c8dc695	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-02-20 14:51:42.168+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-20", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
8fe875d8-2277-4c41-bc47-a06d02c73c3c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-02-21 03:08:51.364+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-20", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
c6e69dc7-0ad0-40ae-8c8a-0dac4973ccf3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-02-22 15:38:35.348+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-20", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
3089aa02-a7b4-4991-bbe5-efb11fab4c8d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	20	grams	2025-02-23 23:05:13.709+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-20", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
c08a7455-97a9-4d8d-948b-e3adea524d89	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	35	grams	2025-02-24 06:32:25.389+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-20", "days_since_injection": 4}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
e866a4b0-a3db-40ad-a231-55560b69e8b5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	24	grams	2025-02-25 23:42:42.283+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-20", "days_since_injection": 5}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
70c02e4d-6500-410a-a392-30da435b0991	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	56	grams	2025-02-26 07:26:36.696+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-20", "days_since_injection": 6}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
aa2a3bc4-e40e-4e6b-aec2-b5f07e0afccd	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	52	grams	2025-02-27 11:39:45.556+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-20", "days_since_injection": 7}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
6aeff362-9a92-4d9c-bedb-0cdef36dbb64	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-02-28 01:13:08.091+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-28", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
9f6fb240-0fc0-4d06-8596-aaadb8c5a6d8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	20	grams	2025-03-01 00:47:35.416+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-02-28", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
61f1c570-6ad7-48fb-801b-171c2db00939	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	21	grams	2025-03-02 23:00:16.608+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-02", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
345282d3-25d6-4906-8dac-6ddc4eaf836a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	21	grams	2025-03-03 16:03:21.971+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-02", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
3817b010-10c1-4a63-a4b3-07557d3e6289	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-03-04 22:31:38.906+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-04", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
a3702de3-c687-4c35-8d7a-6936ebe8357e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-03-05 22:36:28.909+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-04", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
69a17958-32aa-4848-a625-1d374b9dbbcc	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	20	grams	2025-03-06 13:39:33.918+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-06", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
657ba7e1-1ced-4be8-ba9f-f48faf47fc44	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	25	grams	2025-03-07 12:19:32.568+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-06", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
763103cb-0b01-4f1c-a06f-2dc2dbb86f82	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	14	grams	2025-03-08 19:25:20.479+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-08", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
72231b63-98f0-4b09-831f-3173a4ee668e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	31	grams	2025-03-09 12:50:52.528+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-09", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
e7cd3c5e-2c9e-4d5e-b31a-6017d824f175	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	23	grams	2025-03-10 16:07:29.887+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-09", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
ea80e233-7bd0-4e04-9ed7-616d874e487e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-03-11 09:35:50.77+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-09", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
2628013d-178d-4b57-9e84-93a4a0401b23	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-03-12 05:22:49.455+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-11", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
9cfda18e-21e6-4025-8566-f11f49f397f6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	26	grams	2025-03-13 20:37:38.251+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-11", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
df12222b-f5e2-4e55-8b91-a32e05bfb0b6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	11	grams	2025-03-14 06:31:15.153+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-13", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
249d3013-0154-468b-b2d4-f6e64e63cc84	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-03-15 13:52:20.995+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-13", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
83e86ad0-30a4-4f50-93ab-81815a01c508	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-03-16 14:46:29.965+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-15", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
4fed287b-b53e-437a-9dfd-d345b378d11e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	24	grams	2025-03-17 02:52:58.695+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-15", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
8ba89ddd-3b31-4b59-8db2-3222d2aeb295	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	14	grams	2025-03-17 23:25:29.605+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-17", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
da745e44-9be4-428c-b4d8-2475af130108	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	14	grams	2025-03-19 13:58:01.593+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-17", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
8a4fa7df-578f-4232-a462-24e9d1e625ae	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-03-20 10:47:44.106+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-19", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
786d2ac7-54dc-48d9-99b1-9ca8d660d557	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-03-21 02:53:46.572+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-19", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
45525010-9e01-42ad-8b7d-7f5bbd184be7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-03-22 00:54:26.205+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-21", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
6fa612b2-68a0-434a-919c-f91722aa8d40	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	21	grams	2025-03-23 03:52:22.099+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-21", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
4078bc17-20e5-4c64-ba3f-d6d3a088d4c4	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-03-24 00:22:56.097+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-23", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
1030935d-b32c-4a30-acdb-0173560f360a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-03-25 11:22:12.855+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-23", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
676d68d7-a91c-4839-ab4f-8548093b3d22	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-03-26 01:40:28.438+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-25", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
ee047c78-c8da-4d1f-84f3-de21529aaa2c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	10	grams	2025-03-27 02:37:05.162+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-25", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
bd06ab2d-e69b-418f-a924-c69fa59a0c69	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	23	grams	2025-03-28 05:38:40.69+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-25", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
3109ec86-1ba2-4ea9-b2e3-a5bdd50fa57e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	21	grams	2025-03-29 01:22:46.736+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-25", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
d22233ab-faa9-47d1-9a86-959fe0fd851e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	44	grams	2025-03-30 11:45:50.289+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-25", "days_since_injection": 4}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
dee10059-0962-4128-8bf6-28eaab9484ff	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	37	grams	2025-03-31 02:21:08.367+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-25", "days_since_injection": 5}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
adc43554-0b49-4f7f-8c6c-279436cefa07	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	11	grams	2025-04-01 09:19:26.493+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-31", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
d7f051c9-0d01-462c-8af6-60a5c055e5b1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	14	grams	2025-04-02 13:16:52.569+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-03-31", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
0834a9a6-f015-434b-b144-26233a041ecc	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-04-03 08:38:34.745+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-02", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
be6a895e-9e48-4735-9547-f8dc6d778e85	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	12	grams	2025-04-04 19:59:56.91+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-02", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
769307bb-4978-42d9-a591-dac9aad007bb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	12	grams	2025-04-05 17:21:27.148+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-04", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
88782e73-ac93-4730-b463-2cf738ca199f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	25	grams	2025-04-06 09:10:53.717+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-04", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
7d4f868f-3a5c-46d2-bd28-a2b0630c7249	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-04-07 19:43:59.144+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-06", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
871829d4-2b9c-411b-a178-6e9ee49af3e5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-04-08 06:57:00.151+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-06", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
970c653d-5201-4554-9d35-683ed1c3911e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	29	grams	2025-04-09 08:54:36.48+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-08", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
3ea1502b-1bc6-4a6c-8e89-b1aa0596dd9b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-04-10 18:52:22.08+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-08", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
b14a7213-d40a-46da-af9e-048b6e3a2c52	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	199.4	lbs	2025-09-08 03:56:59.524+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 35.6, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 242}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
78788c70-7212-44af-bb6d-e253aa6622ff	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	198.7	lbs	2025-09-10 03:10:31.282+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 36.3, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 244}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
dacf2b1b-5753-4cea-8dc0-fb9157e57400	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	199.4	lbs	2025-09-11 06:22:21.027+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 35.6, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 245}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
1b2f3912-eec7-41fb-b3ff-568fb1387065	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	199.9	lbs	2025-09-12 17:03:12.135+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 35.1, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 246}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
96c61d18-1d27-4798-8948-3371ee41d421	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	199.5	lbs	2025-09-13 17:41:37.547+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 35.5, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 247}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
30c721de-c386-4a4e-b9be-446c41abd98a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	199.9	lbs	2025-09-15 07:43:28.214+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 35.1, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 249}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
cc97e84f-9e40-4c63-8a4e-bd0d32de8272	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-04-11 15:09:36.661+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-10", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
15ffa386-e50b-4ea8-abf8-56c0df767137	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	12	grams	2025-04-12 03:27:35.785+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-10", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
0931e32d-0f68-4ea7-bd6a-fb240b19e031	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	22	grams	2025-04-13 21:48:56.907+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-10", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
934dc04a-ba6a-4d19-8947-5609221fa965	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	28	grams	2025-04-14 18:31:53.825+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-10", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
67dc5dad-36e3-4f1b-9de0-cc2f5d15a538	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-04-15 07:11:17.571+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-14", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
353a63f7-ee95-47f8-aa47-5e0468c88b7b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-04-16 15:31:36.616+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-14", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
2017c40c-aad3-464c-bd01-4dfe1c0be0ba	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-04-17 07:07:05.836+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-14", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
8fede7e9-62f2-441c-bc42-a8c5bbeeeffd	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-04-18 14:44:52.152+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-14", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
c4f58392-324d-4d34-90f0-6beaa5e1a042	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-04-19 04:46:35.248+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-18", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
2fcebcc6-9b0b-4f29-967d-39228de6950c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	24	grams	2025-04-20 11:41:17.801+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-18", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
9fdbd1b9-8fd7-4bbb-845c-66252142b763	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	21	grams	2025-04-21 14:16:55.415+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-18", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
f7a9d852-b5f9-4f8e-8801-919ea6ff6894	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	24	grams	2025-04-22 02:21:04.488+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-18", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
74172a4e-ce74-4d29-9f1f-60a63ba2b8b6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	26	grams	2025-04-23 06:36:47.64+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-18", "days_since_injection": 4}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
07d2dbc2-cf9b-4d6d-9b84-98cc79d99e77	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	24	grams	2025-04-24 18:31:55.888+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-18", "days_since_injection": 5}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
37db3071-0771-49bb-a20e-6522e7000179	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-04-25 15:22:49.61+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-24", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
b55f4301-b71b-43a9-a6aa-e00c89357542	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	11	grams	2025-04-26 17:24:06.408+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-24", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
e3bf2794-3ba9-43f0-b421-db55843b4e1a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-04-27 17:39:16.845+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-26", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
46077a64-ae17-4687-90f4-b6fff893983c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-04-28 18:06:35.049+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-26", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
dd9f0423-8c63-4225-a195-81fc5fa552ef	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-04-29 17:16:02.253+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-28", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
af3965aa-9461-4588-a98c-49440713c8f0	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	27	grams	2025-04-30 08:35:41.394+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-28", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
7da2833f-6905-49a6-8b8a-be382b7a3580	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-05-01 04:30:44.489+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-28", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
e8ba4a07-8053-423e-a248-d601ebf67d3b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	37	grams	2025-05-02 16:13:25.451+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-04-28", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
d80c8805-2656-49e1-8be1-5b3ac281de5c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-05-03 07:50:04.147+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-02", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
dc91b5dc-c769-4e5d-aa2e-3610ea26b4f3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-05-04 07:18:45.891+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-02", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
41111477-1ddc-49a0-b800-b30af7ef0efc	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	21	grams	2025-05-05 00:00:53.209+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-04", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
8474fabd-56c7-4275-b3c7-22822e413429	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-05-06 00:01:52.331+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-04", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
c6f86f99-1e57-4b49-a2a9-dcc5066b8a85	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	23	grams	2025-05-07 09:35:19.168+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-06", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
48010186-5ec3-42e7-a038-3b898359bd9f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	25	grams	2025-05-08 12:35:49.118+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-06", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
16a5e5fc-b983-457d-ad63-deb2f23f9e91	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	27	grams	2025-05-09 14:22:45.912+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-06", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
744e9b4c-36f6-4ca3-ba5f-5eb41c799dfa	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-05-10 18:33:59.973+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-06", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
d0485af1-7414-4507-a36d-46b99cd64acb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	21	grams	2025-05-11 08:32:38.31+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-10", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
b97ce4ea-1e3a-45c4-ba10-e897c0d28fe6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	24	grams	2025-05-12 07:57:03.88+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-10", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
57e1812e-a9e5-4257-b1c0-bf0e34dd329f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	14	grams	2025-05-13 02:16:02.974+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-12", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
1387cceb-ec61-431f-9397-9978f3cc1008	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	21	grams	2025-05-14 20:35:54.342+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-12", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
d9ed4edd-46c0-4fc8-a804-6cd33d4a9bb7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	14	grams	2025-05-15 13:18:20.658+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-12", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
fb939542-f33e-41ab-921d-e557621325d5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	27	grams	2025-05-16 00:56:59.444+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-12", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
f763c31b-6644-4f34-becd-5fcb6d06ff73	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-05-17 16:59:36.496+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-16", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
734d5ca0-4f78-4f00-8109-45791cd04b10	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-05-18 07:20:48.61+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-16", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
4587dfe8-4f4f-4b4f-96b4-83c5480372f4	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	20	grams	2025-05-19 12:26:20.61+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-16", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
dd017926-6380-455f-a182-0427d2e643d9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	23	grams	2025-05-20 19:43:29.168+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-16", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
10f174de-57bf-42af-b279-81575b57f6ab	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-05-21 01:01:38.012+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-20", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
061fdcc8-a374-4a0e-b16c-797ac0907142	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	14	grams	2025-05-22 15:31:53.662+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-20", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
6e64b3f9-5366-4f22-8b8a-dc6fd5b6db1b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-05-23 16:13:08.903+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-20", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
eed502bd-2fe3-4374-97ae-d27d6523d988	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-05-24 21:46:49.951+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-20", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
662206cf-cdc2-47f3-84ce-44a19a43953e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-05-25 04:54:30.508+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-24", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
0645160f-f1ce-4434-9dec-d779e4b2213c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-05-26 15:55:29.258+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-24", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
8e643163-4d06-4a88-a925-daa3bc58f956	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-05-27 16:43:43.16+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-26", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
8c314c00-cedc-47b2-a1ac-125e2d79bc1c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-05-28 05:15:20.192+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-26", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
7dd1f738-4b6e-449d-a479-17651db45d81	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	11	grams	2025-05-29 05:17:28.754+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-28", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
45c20778-0109-42c3-bb81-69076c4c36fc	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	12	grams	2025-05-30 02:14:05.482+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-28", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
18400e2e-af4b-4a03-9713-e9643911bb3e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-05-31 05:59:42.891+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-30", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
842b2642-3964-45f1-97b6-6a615e14e7ed	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	23	grams	2025-06-01 03:57:29.041+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-05-30", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
9fcf67b1-39c5-4e66-b514-60606f78136f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	24	grams	2025-06-02 06:53:56.097+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-01", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
19732cec-64f7-459e-bdbe-b59b9f0f2d4d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-06-03 14:56:27.374+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-01", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
7a455dbe-097c-4aeb-ad53-d8415d546a2c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-06-04 18:38:17.913+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-01", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
96e0e14c-bbd8-4da3-b35c-37029dcbe30d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	20	grams	2025-06-05 16:16:24.79+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-01", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
ac218dd4-bc61-4e38-84d5-7f3a165e549c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-06-06 07:08:08.241+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-05", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
c13605fa-124c-4257-a0e0-4decf3c7fa12	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	14	grams	2025-06-07 03:07:39.587+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-05", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
2ecdab4a-cace-4752-9603-a67a60c774b5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	21	grams	2025-06-08 21:37:05.203+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-07", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
1d9db308-f711-497b-8211-9f9dcef78253	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	23	grams	2025-06-09 06:23:12.177+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-07", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
6100e186-3f29-4324-92fc-3469747578ad	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-06-10 16:15:19.626+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-07", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
cb364b8c-9b6a-4a7e-a7af-453555f12339	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	25	grams	2025-06-11 03:27:00.087+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-07", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
f4a8ef3d-2ae6-4e30-bcee-0fa9617e9dff	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-06-12 21:06:45.175+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-11", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
e4380759-6231-4037-9ad9-620a6ef452dd	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-06-13 12:17:47.876+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-11", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
3769d07e-912c-485c-8ca3-d2d2f0bc60e6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-06-14 11:52:58.14+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-13", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
93d8aeea-d73c-43f1-b6e6-c0f9d60a16ce	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	23	grams	2025-06-15 13:15:33.73+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-13", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
87a5bbc1-7933-4aa9-bc76-d1db55a9332b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-06-16 18:40:47.8+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-15", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
9d95fa8c-e43d-42eb-b39e-258c948ab577	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-06-17 07:12:13.99+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-15", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
9b06735d-0bda-497e-8254-49b8a0bef0b0	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	11	grams	2025-06-18 02:19:46.033+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-17", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
b2f10364-83fe-43de-93b1-29450fe956e3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	14	grams	2025-06-19 16:27:31.565+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-17", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
5c63c3b8-02a0-4737-b3ee-2090413d33a3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	27	grams	2025-06-20 05:04:01.147+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-17", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
6ef9bd8b-1e9a-4c98-8125-2ea832745718	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-06-21 06:47:21.733+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-17", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
22dca3d8-2af5-4ef2-aad7-748b26f3bbc2	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-06-22 01:00:18.259+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-21", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
1c79aa39-f00a-42c1-8d03-55cdbc2625a9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	25	grams	2025-06-23 22:18:34.462+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-21", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
d1febc55-266a-4152-8c4b-70d22e07e748	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-06-24 19:54:33.898+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-23", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
ea27f02a-a88d-4148-9580-dfd5c8065bbe	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-06-25 03:07:21.873+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-23", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
76af881c-d24e-47ba-80e9-82abb0738caa	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	21	grams	2025-06-26 10:31:40.411+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-25", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
8ed61b78-0de8-45e5-9dce-149a57add622	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-06-27 06:24:24.108+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-25", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
c1a03b20-072a-462d-8453-e531713a4585	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	20	grams	2025-06-28 12:05:33.934+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-27", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
51e99d31-3ba3-4d0b-b222-c8a7cbd74284	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-06-29 06:59:08.139+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-27", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
d564df7b-99c0-4915-b53b-9df8ca2060e5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-06-30 05:59:54.026+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-29", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
441ad9f0-66e3-482e-900b-614270d9caa7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-06-30 23:05:36.311+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-06-29", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
b2b15a90-8a17-4172-a120-811fe975cb9c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-07-02 02:06:26.31+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-01", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
0b7614e6-d9b2-4062-83e4-9b6032c5d8b2	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-07-03 10:33:10.347+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-01", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
094cdc9f-d0a3-49a4-8440-94ec1bcec1d1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	12	grams	2025-07-04 08:58:15.451+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-03", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
5a815e87-7d02-49b0-b794-078b9ebc7f36	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-07-05 21:32:41.121+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-03", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
d3cc660b-6341-4553-8120-959cd90f05bb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	25	grams	2025-07-06 18:05:42.344+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-03", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
41fbb5bc-7605-4618-8141-609fa0ada72b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	41	grams	2025-07-07 03:55:52.211+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-03", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
affd68fd-31c4-4267-8979-9d75ad9cdc77	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-07-08 11:18:41.988+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-07", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
f9d9e547-43a1-4ad1-849a-7b52ecadd3ad	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-07-09 05:10:34.698+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-07", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
a7085699-9bd3-4bb7-aad9-48d64c13da05	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-07-10 04:06:18.129+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-09", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
2050f99d-d61a-49ef-9f7a-a2e98cf7ee8b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	11	grams	2025-07-11 15:57:59.437+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-09", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
33baa8d2-b054-4ca4-ba5b-b24377d8bd9b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	12	grams	2025-07-12 01:31:38.222+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-11", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
7f18791c-74cd-4a69-99e2-3506d05d4059	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	22	grams	2025-07-13 20:07:06.695+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-11", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
c4930bf5-e6e0-43e9-896d-88b59b4d3afa	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	24	grams	2025-07-14 10:46:57.283+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-13", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
5316ddbe-a951-4f06-aa98-6c13cee71554	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	12	grams	2025-07-15 13:31:53.04+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-13", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
756add46-e717-4cd0-acd2-7ca29a40656d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-07-16 14:42:42.574+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-13", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
b1a88576-eef5-4167-a0b9-91c67617685a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	35	grams	2025-07-17 02:39:58.402+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-13", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
cbaf46f3-2301-4e56-85c2-0bda71f19821	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-07-18 11:47:19.442+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-17", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
119b037b-0165-42db-b7f3-57873c8e8d9c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-07-19 14:54:32.74+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-17", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
d46d5a59-3155-4f4d-acf2-06ba8da890db	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	198.7	lbs	2025-09-19 04:27:22.884+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 36.3, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 253}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
25590b67-a298-4248-9353-62fcf113aeec	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	198.3	lbs	2025-09-20 17:52:34.13+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 36.7, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 254}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
4fbc864f-f119-47ba-99dd-18aabcf17a07	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	200	lbs	2025-09-22 14:01:47.133+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 35, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 256}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
f022376c-b04f-48be-ba9c-3734825c056f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	199.6	lbs	2025-09-23 10:05:02.286+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 35.4, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 257}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
0ccd18bb-761f-4e2a-a0b1-2c63ecb2b97b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	199	lbs	2025-09-26 03:15:30.535+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 36, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 260}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
81630d7e-2ce4-4821-9145-ead27f717a82	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	20	grams	2025-07-20 19:19:29.718+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-17", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
9a55a1c2-40c5-47a2-9820-20d892db36de	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	30	grams	2025-07-21 04:23:33.698+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-17", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
f2c0bcd8-ea40-4120-839a-b9e19b3fbcdf	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-07-22 03:22:58.991+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-21", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
36889877-a8e9-4b0b-ab76-843c89114cf7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	20	grams	2025-07-23 19:54:38.832+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-21", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
e9c06ec1-b1d6-4ad8-9fd0-043a6c90899b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	11	grams	2025-07-24 16:07:04.722+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-23", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
977b08af-d9f0-4e27-ab6c-e764a100ace1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	11	grams	2025-07-25 13:35:36.63+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-23", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
0af391a2-3e0d-4bfd-9d17-ff5793644593	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-07-26 08:16:35.993+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-25", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
6e0b0e42-6288-4e13-bb6b-7f05e0a94bfd	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	20	grams	2025-07-27 22:56:29.205+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-25", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
e586d9f5-0a3b-4491-aa73-999974806283	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	22	grams	2025-07-28 09:12:20.31+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-27", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
17f7f837-4a70-4ab7-9562-78b30eb248ba	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	14	grams	2025-07-29 17:37:12.637+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-27", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
e2705e73-7ee9-447e-b80b-c44b4a76dea9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	22	grams	2025-07-30 01:06:03.522+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-29", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
d0a079e0-d565-42e5-8c09-73c4a051246f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	11	grams	2025-07-31 16:22:00.455+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-29", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
93d78a67-3fc6-4efb-a2a6-5c7a5b092976	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-08-01 03:04:01.484+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-31", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
925aa3f3-ef04-4d8f-bc26-2b63466f723a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	17	grams	2025-08-02 21:46:00.097+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-07-31", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
2b0c3c0d-10ff-41d5-9c84-d658ca9bee50	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-08-03 06:07:17.152+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-02", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
15a38ab2-4b17-4c31-8ec6-b760e3432d70	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-08-04 14:17:09.183+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-02", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
0c52cd1c-1958-4e13-818d-aaefdf638b91	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-08-05 14:30:13.399+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-02", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
1d6e7e23-a5ff-4dd8-a372-ad6d2fce430f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-08-06 12:42:12.787+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-02", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
0c2a49e9-76b6-48aa-b3dc-bf2946227d27	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	12	grams	2025-08-06 23:02:55.934+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-06", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
8a1b7383-f2f3-4a54-a481-6f94188f9b11	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-08-08 08:23:05.889+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-06", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
e917a6a5-feda-4d99-9b2c-f363b84f87b7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	12	grams	2025-08-09 19:22:13.449+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-08", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
77d0aab3-e81a-4184-9e96-8e9e5aa7dd72	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-08-10 03:40:28.974+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-08", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
76f7b903-f648-4705-a688-7b02674dd9d5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-08-11 08:43:02.639+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-10", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
73f1ab8f-22f3-48d0-8c64-0842879b1f96	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	20	grams	2025-08-12 07:04:55.515+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-10", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
71943a5a-2252-4f7a-bb0e-fad89d175a42	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	20	grams	2025-08-13 16:50:40.785+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-12", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
742a4ba7-37fb-4117-be64-486928e87f2f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	11	grams	2025-08-14 19:32:22.83+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-12", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
39dc0809-8b3b-4fa3-aa46-53c24d1471f5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-08-15 12:37:06.187+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-14", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
adbaf742-5c94-4d8e-89b8-0c3b50352b7d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	10	grams	2025-08-15 23:39:55.124+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-14", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
27ae1c40-d053-4924-904d-d3dfd08619da	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	27	grams	2025-08-17 06:56:01.755+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-16", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
ca65b241-9998-475a-88dc-d993fc10c66f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-08-18 22:11:22.159+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-16", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
b13cdc3f-2c64-4376-b58a-81314ca50fac	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	12	grams	2025-08-19 08:21:09.147+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-18", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
f2049247-bad4-4972-8089-66a6b3a44bbc	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	21	grams	2025-08-20 00:48:51.287+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-18", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
4cf385e7-9eec-4bcc-b378-ac66d750bff6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	32	grams	2025-08-21 22:08:17.533+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-18", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
89cf5d2c-172a-4ae2-b81c-08ff6668fe34	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	37	grams	2025-08-22 03:11:33.977+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-18", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
18e3fd81-b2d1-415d-8658-efa7ce0f4093	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-08-23 21:16:08.244+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-22", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
93dad7d7-f03e-4f09-937b-256f7513ce3e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	25	grams	2025-08-24 03:54:20.032+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-22", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
7fde666f-5a39-478c-ac88-7dfa44c9069a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-08-25 04:56:19.669+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-24", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
04466017-6772-45c8-a20b-ec1986a766d1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	11	grams	2025-08-26 20:27:27.821+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-24", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
0ef6cd72-47c5-4f30-bfd6-0b0c8eea8d2c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	20	grams	2025-08-27 04:19:06.27+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-26", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
612499c3-b8c9-4fba-86b4-9d859b0697a1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-08-28 09:12:29.198+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-26", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
29f2ee6e-9002-4849-b468-d0880e1e6604	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-08-29 10:27:06.337+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-28", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
0adb46d1-a5f9-4416-b15d-c3ce58bf17ea	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	20	grams	2025-08-30 11:21:54.969+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-28", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
61fc0ddb-b7d5-4dea-98f7-d72993ea2071	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	32	grams	2025-08-31 12:42:24.922+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-28", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
a31dc3c6-c992-4e8a-aed4-70e794b4c6d3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	22	grams	2025-09-01 11:12:15.334+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-08-28", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
07d4f4fb-ddad-4da6-b948-7c0ed99a6258	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-09-02 09:02:55.524+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-01", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
f23918ed-c242-42d3-84db-e9ca2c6453c9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-09-03 06:28:21.318+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-01", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
8e63af04-58f8-400a-8aa8-8bd8f9cd3c3c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-09-04 03:23:40.064+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-03", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
fb8cb9ff-76c9-4559-99d2-88fad038665a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-09-05 09:28:02.307+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-03", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
d4784a84-c209-43d0-8cc7-e0b5c62ed47d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	22	grams	2025-09-06 04:02:27.213+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-03", "days_since_injection": 2}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
786f4b5f-5f3e-48ab-a58b-b9557ddbfa41	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	29	grams	2025-09-07 01:27:17.24+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-03", "days_since_injection": 3}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
52a415b5-cae9-41ff-a34a-bf938f12fe33	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	34	grams	2025-09-08 08:46:39.169+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-03", "days_since_injection": 4}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
346296cb-b265-4031-9db6-4ea26f76b97c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	23	grams	2025-09-09 11:52:21.681+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-03", "days_since_injection": 5}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
cb29b00a-1696-43fa-99d4-452153e59070	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-09-10 15:00:35.987+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-09", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
8ce31309-ab83-43a9-9ad2-89efdcdf3f8c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-09-11 10:59:33.366+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-09", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
157c54c4-3ddf-48bd-9edb-d4e8580862fa	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	10	grams	2025-09-12 21:38:10.864+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-11", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
c852a9e8-9832-4c56-9ab3-cba298397f54	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-09-13 13:06:57.999+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-11", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
c204efd6-e8f5-4609-839b-97f17bb8793e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	21	grams	2025-09-14 21:08:46.624+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-13", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
cc7b54f8-531e-4bb1-9c70-f2e458cc25ab	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-09-15 18:50:08.998+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-13", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
fec99703-3825-411d-a52e-714dfc6b971f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-09-16 00:17:41.114+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-15", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
361e33ed-b21d-4468-8ad5-53ddc1aca55c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-09-17 02:54:02.162+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-15", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
8c228a04-29de-4fba-beac-c392cf610fd9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-09-18 02:04:33.388+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-17", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
a2b29227-8bc8-4182-976d-9fd6ccfc61a8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-09-19 04:22:03.925+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-18", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
135bdc6b-caed-4b78-adc9-188b2e9a5bb4	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-09-20 16:04:08.493+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-19", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
65478605-d223-4abf-963f-d8271e63f47a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	16	grams	2025-09-21 18:19:57.418+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-19", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
d05780b6-f992-468c-a3a2-b31501df743e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	20	grams	2025-09-22 18:08:42.658+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-21", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
6a5de49b-bddc-45ef-b6bc-ce96644bac10	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-09-23 16:36:02.841+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-21", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
3c10b73b-dbf0-4141-827b-2f7f35416956	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	27	grams	2025-09-24 14:24:40.013+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-23", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
c7246000-b364-461c-be5d-64c00841f41f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	19	grams	2025-09-25 07:43:50.908+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-23", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
f95ac5af-3933-4156-bd47-97e34f7eee72	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-09-26 01:08:14.902+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-25", "days_since_injection": 0}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.735+00
f9367bac-6c2d-4d64-b54b-13aaa917f5fc	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	18	grams	2025-09-27 17:54:14.331+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-25", "days_since_injection": 1}	2025-10-08 00:05:43.735+00	2025-10-08 00:05:43.736+00
e3e70379-c3fc-462f-a89d-cccb621b0e55	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	25	grams	2025-09-28 14:11:03.551+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-25", "days_since_injection": 2}	2025-10-08 00:05:43.736+00	2025-10-08 00:05:43.736+00
6ed3c11e-7b0d-4b71-b471-5469efa09647	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	28	grams	2025-09-29 01:08:24.881+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-25", "days_since_injection": 3}	2025-10-08 00:05:43.736+00	2025-10-08 00:05:43.736+00
037aec9b-6626-4f80-a210-df646aa873a8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-09-30 13:31:42.052+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-29", "days_since_injection": 0}	2025-10-08 00:05:43.736+00	2025-10-08 00:05:43.736+00
d758d114-1729-40bf-b84b-89d4ead66abc	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	12	grams	2025-10-01 02:19:49.951+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-09-29", "days_since_injection": 1}	2025-10-08 00:05:43.736+00	2025-10-08 00:05:43.736+00
be72382c-2caa-4606-8bbf-5d65a17d6588	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	13	grams	2025-10-02 13:50:54.834+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-10-01", "days_since_injection": 0}	2025-10-08 00:05:43.736+00	2025-10-08 00:05:43.736+00
f08da2b1-4cf8-4b6b-92cf-7dcb55edbff7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	10	grams	2025-10-03 22:48:40.483+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-10-01", "days_since_injection": 1}	2025-10-08 00:05:43.736+00	2025-10-08 00:05:43.736+00
641cdcfa-4c91-431c-acc2-9fbb037a4064	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	12	grams	2025-10-04 19:41:33.192+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-10-03", "days_since_injection": 0}	2025-10-08 00:05:43.736+00	2025-10-08 00:05:43.736+00
1ed7a0cb-287d-488a-a960-935f822432f6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	20	grams	2025-10-05 18:29:45.22+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-10-03", "days_since_injection": 1}	2025-10-08 00:05:43.736+00	2025-10-08 00:05:43.736+00
27404b28-1fb9-4e37-a903-7b1e163b578b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	23	grams	2025-10-06 20:43:16.017+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-10-05", "days_since_injection": 0}	2025-10-08 00:05:43.736+00	2025-10-08 00:05:43.736+00
b4fd9c98-bccb-4f17-9604-f4e7f05f0b01	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-10-07 09:51:16.394+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-10-05", "days_since_injection": 1}	2025-10-08 00:05:43.736+00	2025-10-08 00:05:43.736+00
4ac10843-894f-4fd8-90a7-0085ef5d7630	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sugar	15	grams	2025-10-08 08:58:03.648+00	manual	{"correlation_note": "Sugar intake increases as next GLP-1 dose approaches", "last_injection_date": "2025-10-07", "days_since_injection": 0}	2025-10-08 00:05:43.736+00	2025-10-08 00:05:43.736+00
75cc6015-dab3-4201-8e01-4341bc885db7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	198.4	lbs	2025-10-02 13:59:45.798+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 36.6, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 266}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
45b4acc7-8f87-4e6f-9340-d51bdf16d66c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	197.1	lbs	2025-10-08 14:32:42.707+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 37.9, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 272}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
6d4df8d0-a7b6-4acb-86fb-84c196fd1174	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	234.2	lbs	2025-01-09 13:38:19.454+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 0.8, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 0}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
f1d94391-40e8-4fe2-938e-6d6a290cf019	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	234.1	lbs	2025-01-10 04:50:13.836+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 0.9, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 1}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
35d06832-643f-48b5-88ee-2cd5dffcf8d2	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	232.9	lbs	2025-01-15 07:10:05.859+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 2.1, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 6}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
2e38b862-1f83-4acf-9211-6e2a20a3d5b4	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	230.5	lbs	2025-01-23 20:28:13.179+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 4.5, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 14}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
622a6881-763d-4693-adcf-364e69f64c8a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	232.4	lbs	2025-01-24 06:06:41.75+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 2.6, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 15}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
c53d3799-4795-4da6-aa0f-112d88d95702	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	231.7	lbs	2025-01-26 23:33:51.932+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 3.3, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 17}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
94d301d4-aab4-44af-adf8-6cc74bcfc234	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	229.6	lbs	2025-01-28 22:46:04.144+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 5.4, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 19}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
abd4533e-4e9d-42d3-8bd1-f6bbf414c414	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	227.9	lbs	2025-01-29 22:58:56.716+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 7.1, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 20}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
3938f738-0665-4063-9419-ff63139604bd	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	229.4	lbs	2025-01-31 08:52:28.893+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 5.6, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 22}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
a37b5f62-8305-4a64-a31c-ddfedfcba0bb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	229.1	lbs	2025-02-03 14:36:06.247+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 5.9, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 25}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
4eb51bc3-5d41-466d-911a-5415894ca7bb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	227.2	lbs	2025-02-06 04:29:30.615+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 7.8, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 28}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
58086098-6b3a-4413-b52d-1cc795c317b1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2556	kcal	2025-04-01 23:04:00+00	manual	{"season": "spring", "dayIndex": 90, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
58b19d7f-9681-4b79-9de4-7d501bc4ec1d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	101	grams	2025-04-03 01:16:00+00	manual	{"season": "spring", "dayIndex": 91, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
090cbfa4-7289-4357-a055-a5ba424aca51	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	10508	steps	2025-04-03 21:44:00+00	manual	{"season": "spring", "dayIndex": 92, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
d0efac4c-5eac-4e8f-8e68-d42634564cc1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	6236	steps	2025-04-04 20:40:00+00	manual	{"season": "spring", "dayIndex": 93, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
27f231a6-0de9-4002-afc2-4c92c9beb1d1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	63	bpm	2025-04-04 23:46:00+00	manual	{"season": "spring", "dayIndex": 93, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
388ff506-4507-4cf9-981b-fb082284fd59	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	1965	kcal	2025-04-04 16:18:00+00	manual	{"season": "spring", "dayIndex": 93, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
52754569-001b-4e96-b479-77fc2a30836c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	59	bpm	2025-04-06 23:08:00+00	manual	{"season": "spring", "dayIndex": 95, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
aa141985-4855-40d0-ba83-aa2f74ef105d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	48	fl oz	2025-04-07 16:55:00+00	manual	{"season": "spring", "dayIndex": 96, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
f1a6796a-4646-4852-9f0c-d023c433db13	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	10325	steps	2025-04-07 15:08:00+00	manual	{"season": "spring", "dayIndex": 96, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
80621ad5-e858-480a-aeea-76e73de93f5e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	5857	steps	2025-04-09 20:14:00+00	manual	{"season": "spring", "dayIndex": 98, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
c642e93f-bb7d-4de5-8d23-fcaf7aaec70c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2090	kcal	2025-04-09 20:18:00+00	manual	{"season": "spring", "dayIndex": 98, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
4d284daf-3bf6-4385-b6c2-8bb2f6bb4b0b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.3	hours	2025-04-10 01:39:00+00	manual	{"season": "spring", "dayIndex": 98, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
4cabe74a-5c69-4666-9c80-759d43a89044	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	171	grams	2025-04-10 23:15:00+00	manual	{"season": "spring", "dayIndex": 99, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
e5a72637-d883-4a64-80dd-73c8ef47a18f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	229.3	lbs	2025-02-07 18:28:09.415+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 5.7, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 29}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
c45f8894-e4cb-4c18-aa73-516977346cf9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	227.9	lbs	2025-02-10 23:33:38.696+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 7.1, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 32}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
7925e49e-2dd4-4cc1-bd09-57814a2a313c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	227	lbs	2025-02-12 14:45:38.899+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 8, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 34}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
3028a50e-5188-4904-9032-5c5d5c58e477	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	226.6	lbs	2025-02-18 23:52:31.18+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 8.4, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 40}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
83836904-e70a-40fa-972d-4d6c78115771	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	225.7	lbs	2025-02-23 16:53:24.218+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 9.3, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 45}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
a06b0f3a-3b22-45a2-abe8-e61dfeb01974	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	222.2	lbs	2025-02-26 19:46:09.529+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 12.8, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 48}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
296f5ed9-7f01-4623-b3e7-1fa548184eac	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	221.3	lbs	2025-02-27 01:22:25.605+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 13.7, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 49}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
5c7819fd-c06b-43bc-9615-6d1d65b091fe	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	221.7	lbs	2025-03-01 18:14:47.231+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 13.3, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 51}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
c37c8739-e42c-4a18-9c2c-a9e75987c2f1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	220.8	lbs	2025-03-04 22:46:52.483+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 14.2, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 54}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
42c10a9c-ee2d-48fe-8cc5-1b8ca69028b9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	222.2	lbs	2025-03-05 15:41:29.844+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 12.8, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 55}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
af72259e-a165-47d6-8816-43e5f5b4718a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	223.6	lbs	2025-03-09 04:46:24.622+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 11.4, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 59}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
bf8ade40-63da-4906-95be-8ff23d4c7240	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	222.5	lbs	2025-03-11 21:26:07.694+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 12.5, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 61}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
56a1ecae-653b-4a5b-8ad6-35c8d18c6495	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	220.6	lbs	2025-03-14 17:06:51.99+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 14.4, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 64}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
05fdf25e-f770-4192-8170-b9a515bfa5ae	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	221	lbs	2025-03-21 20:19:49.882+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 14, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 71}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
5edbac72-3689-47ba-8bbb-cbd07c719805	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	219.2	lbs	2025-03-22 15:15:07.277+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 15.8, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 72}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
42bf4478-bb63-4c65-8440-3a2592117ed9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	219.1	lbs	2025-03-29 21:43:02.391+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 15.9, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 79}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
3cbcd3ae-7265-4645-85d1-dd278c3fbc2f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	216.7	lbs	2025-04-01 10:02:55.341+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 18.3, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 82}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
40f0c068-6f1e-4e26-a29c-968c07fc3b0c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	216.9	lbs	2025-04-02 10:51:41.58+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 18.1, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 83}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
b71d9021-e3f8-4a55-add5-0d82b5bc260e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	218.4	lbs	2025-04-03 12:43:08.377+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 16.6, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 84}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
485303b0-76f1-4ab5-8a97-da862d55cc19	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	218.6	lbs	2025-04-06 05:48:26.565+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 16.4, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 87}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
c763ca40-dcc7-4ce0-96c6-d422d2d9fa0b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	218.7	lbs	2025-04-06 23:14:50.982+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 16.3, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 88}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
79506d40-7ddf-4825-a5dc-d769a22a3b6d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	217.8	lbs	2025-04-11 23:35:27.029+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 17.2, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 93}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
a6b8d442-79a7-49ee-bf3d-5afe5cf061d1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	216.8	lbs	2025-04-19 11:22:53.914+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 18.2, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 100}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
18f2a012-5e95-4311-a585-1168198e9f4c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	214.3	lbs	2025-04-20 13:39:45.942+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 20.7, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 101}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
81bb53cf-2676-4a34-aa71-8516634161f8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	216.3	lbs	2025-04-21 02:23:35.914+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 18.7, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 102}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
40c93615-2750-47c1-baf6-d1225b46d7e0	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	213.3	lbs	2025-04-29 23:39:37.332+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 21.7, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 111}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
ec3fb374-cc31-4b4d-9853-c28ed682439a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	215.3	lbs	2025-05-02 02:51:44.692+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 19.7, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 113}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
50b8d3aa-c713-414e-856d-7a71dbfb8436	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	215.1	lbs	2025-05-03 07:43:42.521+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 19.9, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 114}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
dae39292-2b3b-425f-b3f5-f960b8c21c14	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	214.8	lbs	2025-05-05 04:21:23.15+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 20.2, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 116}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
65b5f86d-e84d-4eab-b23d-b3a7067dcae7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	215.7	lbs	2025-05-06 12:02:44.032+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 19.3, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 117}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
aff8a935-571e-47ce-98e7-3901c90d32ff	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	214.3	lbs	2025-05-08 14:55:56.013+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 20.7, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 119}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
f58373a0-94f5-4d6c-924b-bfb409874015	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	215.5	lbs	2025-05-09 15:03:45.209+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 19.5, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 120}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
5cdbd006-cd48-4fcd-8fb3-ce960d6e7b38	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	213.8	lbs	2025-05-10 00:32:59.974+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 21.2, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 121}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
d1233e01-fa97-45ec-9726-fdc8ab691ec8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	211.9	lbs	2025-05-14 07:20:31.63+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 23.1, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 125}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
4ea9e8e3-8a37-47b3-aa87-975e44c45dcf	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	211.4	lbs	2025-05-16 05:05:14.482+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 23.6, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 127}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
1108cbbc-b53a-46ff-83dc-be631d173b27	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	212.5	lbs	2025-05-20 23:04:37.631+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 22.5, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 132}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
a0b80b06-9fa5-411f-8f5e-39638b1874c7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	210.9	lbs	2025-05-22 16:35:32.102+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 24.1, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 133}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
6cc5bb7d-13a6-4310-93fa-cb68f22a6e70	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	210.5	lbs	2025-05-23 14:15:31.113+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 24.5, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 134}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
b9dd60b2-85d0-4638-af10-f0307a705c25	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	211.5	lbs	2025-05-25 15:46:50.31+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 23.5, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 136}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
8e31230f-4b27-41ec-a086-5bc5171d8232	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	211.3	lbs	2025-06-03 13:15:24.132+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 23.7, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 145}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
0176e52b-4ace-4153-9732-79b64e6eb046	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	211.3	lbs	2025-06-07 01:32:19.077+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 23.7, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 149}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
15d25673-a6da-4b6f-ab5f-d025774b7a62	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	209.6	lbs	2025-06-08 20:36:30.903+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 25.4, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 150}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
7b71e938-e23e-4013-88d6-d4820473d08a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	209.9	lbs	2025-06-14 00:43:36.961+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 25.1, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 156}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
a6e74b48-7087-4e11-9361-32d046a0d6e8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	208.3	lbs	2025-06-16 17:31:28.547+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 26.7, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 158}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
c4be9546-4d93-4560-8a11-0b286816bba5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	207.7	lbs	2025-06-20 17:14:17.71+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 27.3, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 162}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
8cec5f32-ab03-4798-9b72-7f316cf97974	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	149	grams	2025-04-12 22:18:00+00	manual	{"season": "spring", "dayIndex": 101, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
5222cf6e-b9d3-4309-84c8-9ad3463c2042	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	127	grams	2025-04-14 19:07:00+00	manual	{"season": "spring", "dayIndex": 103, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
5b488853-eb45-4e77-9822-6c0d144aeb79	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	10158	steps	2025-04-14 17:48:00+00	manual	{"season": "spring", "dayIndex": 103, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
1e667889-b1e0-42d5-8f02-2935575a1315	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.5	hours	2025-04-16 02:39:00+00	manual	{"season": "spring", "dayIndex": 104, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
2e84096a-9ddb-4d99-823b-41d7b28f06b7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	8102	steps	2025-04-15 23:21:00+00	manual	{"season": "spring", "dayIndex": 104, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
60a177da-a5a9-4faa-b135-c5528f8ca2db	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	6.8	hours	2025-04-17 21:02:00+00	manual	{"season": "spring", "dayIndex": 106, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
c0cb38c3-0e25-46f1-a5c4-ba78065876c2	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	8840	steps	2025-04-19 00:25:00+00	manual	{"season": "spring", "dayIndex": 107, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
d6d097e0-d2f8-49ac-a9b5-764a9b39abe5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	6.8	hours	2025-04-18 22:56:00+00	manual	{"season": "spring", "dayIndex": 107, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
634aad6d-1cf9-4699-b5de-e9c8e4d507ad	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	4308	steps	2025-04-26 19:33:00+00	manual	{"season": "spring", "dayIndex": 115, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
d23fb0cb-0439-4f15-a01b-7e55d64a49fa	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	10	hours	2025-04-28 02:03:00+00	manual	{"season": "spring", "dayIndex": 116, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
36fa3f55-1247-4c34-91c0-6df09b1fe6c1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	7448	steps	2025-04-27 17:42:00+00	manual	{"season": "spring", "dayIndex": 116, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
7dae10c4-6b5e-4b00-862b-ac4e0bef3db1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	75	fl oz	2025-04-29 18:14:00+00	manual	{"season": "spring", "dayIndex": 118, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
0a2dd50e-dd81-48ca-a9ce-3b0cc99b6ca5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2041	kcal	2025-04-29 18:49:00+00	manual	{"season": "spring", "dayIndex": 118, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
ac4ae6b1-5736-42e1-b901-606ae52f3773	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	6.3	hours	2025-04-30 20:41:00+00	manual	{"season": "spring", "dayIndex": 119, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.592696+00	2025-10-07 04:47:32.592696+00
0b7b54df-f855-4342-9a35-5d875a22014a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	173	grams	2025-05-03 02:04:00+00	manual	{"season": "spring", "dayIndex": 121, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
38a5fcdc-2780-4add-881f-76ba4a1181fd	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7	hours	2025-05-02 16:25:00+00	manual	{"season": "spring", "dayIndex": 121, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
450c6a24-ba6b-438b-a6e7-df30bb743f4b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	142	grams	2025-05-03 19:57:00+00	manual	{"season": "spring", "dayIndex": 122, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
15230d03-8c32-45ac-8e5b-90a2f4f681b1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	60	bpm	2025-05-03 20:11:00+00	manual	{"season": "spring", "dayIndex": 122, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
e8bbf777-812c-48cc-8956-b4ab2dca803f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	127	grams	2025-05-04 21:15:00+00	manual	{"season": "spring", "dayIndex": 123, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
fbb63145-9726-4110-a1ce-966e7f582182	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2192	kcal	2025-05-04 19:45:00+00	manual	{"season": "spring", "dayIndex": 123, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
d23ae0c7-f2f4-4f78-b598-0638dda32be6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	52	bpm	2025-05-04 17:55:00+00	manual	{"season": "spring", "dayIndex": 123, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
ff6127fa-1751-4db5-a59b-f97ac51a37a5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.5	hours	2025-05-04 19:02:00+00	manual	{"season": "spring", "dayIndex": 123, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
912e374f-f530-4d6e-9463-d70f50687e89	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	7459	steps	2025-05-05 16:35:00+00	manual	{"season": "spring", "dayIndex": 124, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
6a48d84c-18a7-426b-b7f6-c9e7dcc7b742	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	160	grams	2025-05-05 21:29:00+00	manual	{"season": "spring", "dayIndex": 124, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
75705cc6-dd91-4b57-8f8f-97b092246541	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	5506	steps	2025-05-06 19:01:00+00	manual	{"season": "spring", "dayIndex": 125, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
cf997eee-865b-46e2-9f54-c2023cbdbf38	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7.6	hours	2025-05-07 22:41:00+00	manual	{"season": "spring", "dayIndex": 126, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
889d2114-7206-423e-aefa-42e2ededf29b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	80	fl oz	2025-05-09 22:33:00+00	manual	{"season": "spring", "dayIndex": 128, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
af0d0cfb-b4b0-4d2b-b511-5f3d0aedc101	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	183	grams	2025-05-09 15:56:00+00	manual	{"season": "spring", "dayIndex": 128, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
1837e358-aecb-4184-9ea3-d82962098549	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	58	fl oz	2025-05-10 23:40:00+00	manual	{"season": "spring", "dayIndex": 129, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
93659824-6919-44f9-8ed6-83fab877cee9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	5166	steps	2025-05-10 19:48:00+00	manual	{"season": "spring", "dayIndex": 129, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
ebfe1017-6168-419d-b71e-adc6a6f10aab	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	54	bpm	2025-05-13 18:56:00+00	manual	{"season": "spring", "dayIndex": 132, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
c6e9ff30-6a24-4e07-b352-33e8a627b93f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	9	hours	2025-05-14 00:02:00+00	manual	{"season": "spring", "dayIndex": 132, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
606270d3-9df2-473f-a35e-e48fa8328599	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	58	fl oz	2025-05-13 23:43:00+00	manual	{"season": "spring", "dayIndex": 132, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
5e8aba08-8575-4037-bee8-c97098de4f49	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	8410	steps	2025-05-15 02:55:00+00	manual	{"season": "spring", "dayIndex": 133, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
da26abba-fef5-42d8-b881-1a7a6bf8c826	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	52	bpm	2025-05-15 18:42:00+00	manual	{"season": "spring", "dayIndex": 134, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
ecdcb170-a0aa-4c8e-b018-7145120e2698	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	159	grams	2025-05-16 01:17:00+00	manual	{"season": "spring", "dayIndex": 134, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
e7f84bd9-559e-4f45-8b29-304fb2dc44bf	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	77	fl oz	2025-05-17 00:42:00+00	manual	{"season": "spring", "dayIndex": 135, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
4d2cc982-68d1-4192-953d-e06c2dba4621	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	9.2	hours	2025-05-18 00:33:00+00	manual	{"season": "spring", "dayIndex": 136, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
a2075ace-55c2-4747-8751-bf2cf1c1d0fe	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2399	kcal	2025-05-17 20:06:00+00	manual	{"season": "spring", "dayIndex": 136, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
3f6a07d4-6c45-44db-9225-ab233317cdb2	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	63	bpm	2025-05-18 22:35:00+00	manual	{"season": "spring", "dayIndex": 137, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
dfa7a557-51a8-4b46-98bd-5649027a1987	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	58	fl oz	2025-05-18 23:41:00+00	manual	{"season": "spring", "dayIndex": 137, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
76b41c39-c05b-4993-b1fe-c74bac0168d0	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	64	bpm	2025-05-21 16:52:00+00	manual	{"season": "spring", "dayIndex": 140, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
070fb7b5-4e54-4a96-b8c8-35030551f7f4	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	11247	steps	2025-05-28 02:25:00+00	manual	{"season": "spring", "dayIndex": 146, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
e6896323-73b8-418c-ae2f-81938e79c934	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7.2	hours	2025-05-28 00:33:00+00	manual	{"season": "spring", "dayIndex": 146, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
0239882f-0e57-4efb-83aa-4e45eb8a4d84	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	53	bpm	2025-05-28 00:49:00+00	manual	{"season": "spring", "dayIndex": 146, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
c7b142b2-ed65-4e6d-8358-49d5f6cc2f6d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2023	kcal	2025-05-28 19:59:00+00	manual	{"season": "spring", "dayIndex": 147, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
5abc75a0-50e0-42d0-a345-86a3d2ea75a6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	56	bpm	2025-05-28 15:43:00+00	manual	{"season": "spring", "dayIndex": 147, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
b16a074d-8f96-4fbd-96f4-f10afea91a43	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	5870	steps	2025-05-30 17:17:00+00	manual	{"season": "spring", "dayIndex": 149, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
52ac47c6-eed1-4bdd-9bd4-38c55e55f742	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	99	grams	2025-05-31 15:48:00+00	manual	{"season": "spring", "dayIndex": 150, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
372f4142-6b0f-468c-8d31-39e174ed2341	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	6071	steps	2025-05-31 23:50:00+00	manual	{"season": "spring", "dayIndex": 150, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
cf3402e2-5408-4f30-859e-29f4376d8902	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	50	bpm	2025-06-03 02:16:00+00	manual	{"season": "summer", "dayIndex": 152, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
81d834e8-e2f0-489c-8aba-bc72cdaaf68b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.9	hours	2025-06-03 02:18:00+00	manual	{"season": "summer", "dayIndex": 152, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
f82da955-56db-4cd2-b24c-79d671bdfa61	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	7049	steps	2025-06-02 19:48:00+00	manual	{"season": "summer", "dayIndex": 152, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
f8997624-9072-4d96-be4e-b0b5dccf6841	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	88	fl oz	2025-06-04 00:27:00+00	manual	{"season": "summer", "dayIndex": 153, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
fd6de1a5-20a3-4fc3-808c-7feb9ab9879e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2349	kcal	2025-06-04 02:12:00+00	manual	{"season": "summer", "dayIndex": 153, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
d421f3a9-4e2b-4bed-8cf8-fc9bf488b28d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	78	fl oz	2025-06-04 19:52:00+00	manual	{"season": "summer", "dayIndex": 154, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
11504488-23fd-491f-82a8-76f58f4a37eb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	138	grams	2025-06-05 15:48:00+00	manual	{"season": "summer", "dayIndex": 155, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
45913ff4-bc0c-4011-9fab-e792b7974243	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	10316	steps	2025-06-06 01:09:00+00	manual	{"season": "summer", "dayIndex": 155, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
e5d857a3-628a-4d28-9f2f-64961b494680	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2525	kcal	2025-06-05 17:34:00+00	manual	{"season": "summer", "dayIndex": 155, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
e8ad4ea3-55e4-46a4-a34f-fb0a99eca849	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	62	bpm	2025-06-07 17:24:00+00	manual	{"season": "summer", "dayIndex": 157, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
8a2b9257-6a16-4a76-81c6-161115c6372f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	4677	steps	2025-06-07 18:12:00+00	manual	{"season": "summer", "dayIndex": 157, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
2ebc5c0b-b79e-4da1-a770-adb887bb06ce	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	83	fl oz	2025-06-07 16:15:00+00	manual	{"season": "summer", "dayIndex": 157, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
18c3b8dc-f3e0-4306-b8b4-c32d887990b0	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	9.5	hours	2025-06-07 20:53:00+00	manual	{"season": "summer", "dayIndex": 157, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
b9989e85-ab4e-4542-839b-767b8cc7afd5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	120	grams	2025-06-08 23:21:00+00	manual	{"season": "summer", "dayIndex": 158, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
e54d2602-c4ac-4e76-87a8-109bfb4524c5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7.4	hours	2025-06-08 17:43:00+00	manual	{"season": "summer", "dayIndex": 158, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
1c13d271-3aef-4c31-9894-dae82c43df26	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	4790	steps	2025-06-09 01:21:00+00	manual	{"season": "summer", "dayIndex": 158, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
7b43ea4b-f6f1-4f1c-97db-212fee99a563	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	5640	steps	2025-06-13 23:45:00+00	manual	{"season": "summer", "dayIndex": 163, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
07575c3d-6ba9-4263-af39-62b68751ffb5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.2	hours	2025-06-13 16:49:00+00	manual	{"season": "summer", "dayIndex": 163, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
e7e7e27b-1161-4464-9593-b2b61789141f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.6	hours	2025-06-14 17:00:00+00	manual	{"season": "summer", "dayIndex": 164, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
7297f361-5ca7-4648-ae5e-c176659eefd8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	50	bpm	2025-06-16 00:31:00+00	manual	{"season": "summer", "dayIndex": 165, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
3ea18fb6-af27-4579-9c72-1e62db36d01a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.2	hours	2025-06-15 23:02:00+00	manual	{"season": "summer", "dayIndex": 165, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
9c20979e-f3df-4c03-bfd6-0200b16a5da6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2709	kcal	2025-06-15 18:29:00+00	manual	{"season": "summer", "dayIndex": 165, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
5dfca3fc-cce0-435a-9889-88fe20ce9821	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	81	fl oz	2025-06-16 18:41:00+00	manual	{"season": "summer", "dayIndex": 166, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
7444c18a-ee66-406f-8a4a-1e10a96647ac	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	9079	steps	2025-06-17 00:37:00+00	manual	{"season": "summer", "dayIndex": 166, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
c8c8055c-e222-43cf-a340-32a1d14bce86	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	187	grams	2025-06-17 02:02:00+00	manual	{"season": "summer", "dayIndex": 166, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
0d953d59-662b-4a80-92d7-088aba2a3550	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7.6	hours	2025-06-17 21:50:00+00	manual	{"season": "summer", "dayIndex": 167, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
7e117c19-a71d-4a0f-b0b1-851ef693dda5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	56	bpm	2025-06-17 22:32:00+00	manual	{"season": "summer", "dayIndex": 167, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
4a47b6b8-08f7-4713-8459-c5e81e381a6d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	63	fl oz	2025-06-18 17:08:00+00	manual	{"season": "summer", "dayIndex": 168, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
d361ecaf-2fba-4184-8991-e44982f791af	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	6680	steps	2025-06-18 18:33:00+00	manual	{"season": "summer", "dayIndex": 168, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
354453ee-9d80-4bd8-9493-b800e6134bfb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	50	bpm	2025-06-18 20:41:00+00	manual	{"season": "summer", "dayIndex": 168, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
e4853795-d677-4417-a90b-f073235440e2	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	141	grams	2025-06-18 23:23:00+00	manual	{"season": "summer", "dayIndex": 168, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
74004e27-200f-4b05-831f-a39d52c1514e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	6.1	hours	2025-06-19 23:15:00+00	manual	{"season": "summer", "dayIndex": 169, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
3d71ce56-fcfe-4e86-81f9-7ee3f59f0fbf	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	4761	steps	2025-06-22 21:26:00+00	manual	{"season": "summer", "dayIndex": 172, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
d77795fa-5790-4068-a171-4f24832f6c00	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	145	grams	2025-06-24 01:05:00+00	manual	{"season": "summer", "dayIndex": 173, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
d8aab9e9-8df7-45be-998b-7589ef29b09d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	126	grams	2025-06-25 00:37:00+00	manual	{"season": "summer", "dayIndex": 174, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
905f4d02-361b-4524-89ed-0d3515e0c870	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	93	fl oz	2025-06-24 17:34:00+00	manual	{"season": "summer", "dayIndex": 174, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.596944+00	2025-10-07 04:47:32.596944+00
9faba14b-27a7-4f58-997c-8f7aadeb89e7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	208.9	lbs	2025-06-21 14:49:12.07+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 26.1, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 163}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
243d4d2e-d660-4eb2-a1bc-a8cb9ea0b390	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	209.5	lbs	2025-06-23 04:33:53.514+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 25.5, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 165}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
7aa2b7ab-8d20-46a8-a4f5-9e7fdf09928f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	206.9	lbs	2025-06-28 00:41:30.881+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 28.1, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 170}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
d555f80d-4c77-4eb2-92b6-7a74462ef825	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2073	kcal	2025-06-26 16:46:00+00	manual	{"season": "summer", "dayIndex": 176, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
13eb2460-7925-4c9f-a944-3b1cd1ed905f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.1	hours	2025-06-26 21:43:00+00	manual	{"season": "summer", "dayIndex": 176, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
9a085fff-6f7b-4634-88e2-1f6cb5c189fb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	50	bpm	2025-06-29 22:21:00+00	manual	{"season": "summer", "dayIndex": 179, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
90d842cf-d96c-474d-8ac6-0b6c9ecb7aef	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.9	hours	2025-06-29 17:34:00+00	manual	{"season": "summer", "dayIndex": 179, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
0a5b0eed-4f0b-4e40-ba19-881721a5ff62	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	60	fl oz	2025-06-30 02:14:00+00	manual	{"season": "summer", "dayIndex": 179, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
5c751f30-6826-42af-8453-8a13f8ba4c8e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7.2	hours	2025-07-02 02:22:00+00	manual	{"season": "summer", "dayIndex": 181, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
39e14dae-13b1-4be8-9960-b39cc502235b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	7358	steps	2025-07-01 23:44:00+00	manual	{"season": "summer", "dayIndex": 181, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
e8fe8055-0d6d-4ecd-ac08-7409dda044ee	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	78	fl oz	2025-07-01 16:58:00+00	manual	{"season": "summer", "dayIndex": 181, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
71592025-3121-4300-83d9-5e24231627f5	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	5737	steps	2025-07-03 17:46:00+00	manual	{"season": "summer", "dayIndex": 183, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
3a40afb8-9db7-4044-8143-cd26332b1bf7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	6.5	hours	2025-07-04 02:35:00+00	manual	{"season": "summer", "dayIndex": 183, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
aecb9b2b-0d25-4967-941c-999efeb580c8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.8	hours	2025-07-04 18:54:00+00	manual	{"season": "summer", "dayIndex": 184, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
8706836b-8073-4b3b-918c-8e7f63d201a7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	63	fl oz	2025-07-05 19:56:00+00	manual	{"season": "summer", "dayIndex": 185, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
d2b02de9-85dc-45d5-a23c-93ed7aa9e396	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	116	grams	2025-07-06 15:54:00+00	manual	{"season": "summer", "dayIndex": 186, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
0479bd56-f130-4ad3-b1b9-53aa56e6a17b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	50	bpm	2025-07-06 23:08:00+00	manual	{"season": "summer", "dayIndex": 186, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
57550b0a-d245-4766-9ecc-3b40e4049a61	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2202	kcal	2025-07-07 00:50:00+00	manual	{"season": "summer", "dayIndex": 186, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
a31a1704-5531-4220-9e67-ea85f23a91f7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	1970	kcal	2025-07-08 17:04:00+00	manual	{"season": "summer", "dayIndex": 188, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
249a9809-b67d-4be4-bcc6-5d872d411993	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	175	grams	2025-07-08 16:00:00+00	manual	{"season": "summer", "dayIndex": 188, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
10091ec2-cb86-49e6-bb0f-c239a144ad13	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.4	hours	2025-07-08 15:19:00+00	manual	{"season": "summer", "dayIndex": 188, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
672f30c4-f348-498b-932d-b3a879400611	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	78	fl oz	2025-07-10 02:30:00+00	manual	{"season": "summer", "dayIndex": 189, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
aae82517-679f-42cf-9ef7-3cad46cb942a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	136	grams	2025-07-09 16:03:00+00	manual	{"season": "summer", "dayIndex": 189, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
ca6536a4-903b-46f9-a6f9-6f48142bef93	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2531	kcal	2025-07-09 20:33:00+00	manual	{"season": "summer", "dayIndex": 189, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
ac52c46b-8a60-4054-90fd-202ef7851170	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	1974	kcal	2025-07-11 02:28:00+00	manual	{"season": "summer", "dayIndex": 190, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
68698caf-1bcc-456e-8f37-c94ab0b12089	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7.1	hours	2025-07-15 20:52:00+00	manual	{"season": "summer", "dayIndex": 195, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
8291ad8b-ce24-434b-968d-f1bf618e0f98	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2045	kcal	2025-07-15 23:26:00+00	manual	{"season": "summer", "dayIndex": 195, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
7a1480f8-6a42-4e33-b683-834c62f09c5e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	162	grams	2025-07-15 20:29:00+00	manual	{"season": "summer", "dayIndex": 195, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
fef0d3ea-9e7f-45a9-96f5-3136628085b4	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	68	fl oz	2025-07-16 16:55:00+00	manual	{"season": "summer", "dayIndex": 196, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
3fa68b89-ec7b-40ef-b120-d80b7dfe1f06	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.9	hours	2025-07-17 22:50:00+00	manual	{"season": "summer", "dayIndex": 197, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
6684515b-45ab-4e8c-9bad-5eb1c91a0768	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	55	bpm	2025-07-18 01:15:00+00	manual	{"season": "summer", "dayIndex": 197, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
c3f6faa8-349f-462d-a6e0-485d8616d5ca	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	1912	kcal	2025-07-17 23:10:00+00	manual	{"season": "summer", "dayIndex": 197, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
db04e5e5-a25f-4ca4-a54e-3cce33e22045	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	5876	steps	2025-07-17 20:34:00+00	manual	{"season": "summer", "dayIndex": 197, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
8590e682-d1d8-4a8c-83e7-deeeb6bfe22e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	5822	steps	2025-07-21 19:21:00+00	manual	{"season": "summer", "dayIndex": 201, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
c22a7e46-f5bc-40a5-a158-518088c01dd7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	54	bpm	2025-07-22 00:35:00+00	manual	{"season": "summer", "dayIndex": 201, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
3c096fea-d6a0-4e0d-8cab-46d873b2c8f3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	70	fl oz	2025-07-23 18:17:00+00	manual	{"season": "summer", "dayIndex": 203, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
0439b96e-6084-480d-be24-8fd82283b1c6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	146	grams	2025-07-23 17:03:00+00	manual	{"season": "summer", "dayIndex": 203, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
0d7716d5-d60d-472a-b2d8-b573f0874485	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	59	bpm	2025-07-24 22:25:00+00	manual	{"season": "summer", "dayIndex": 204, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
7439f7fe-bce2-48be-b88d-7d543656428c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.8	hours	2025-07-24 15:21:00+00	manual	{"season": "summer", "dayIndex": 204, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
9fb5a446-2a2f-4137-ba07-c342131e308f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	70	fl oz	2025-07-24 19:37:00+00	manual	{"season": "summer", "dayIndex": 204, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
5521f0da-2b98-47cd-a205-14d995c20a69	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	5840	steps	2025-07-27 23:47:00+00	manual	{"season": "summer", "dayIndex": 207, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
9e6a9df5-4059-43a3-a70d-9e3844ac896f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	10.5	hours	2025-07-27 18:24:00+00	manual	{"season": "summer", "dayIndex": 207, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
f55c0bb8-a6ac-4739-9015-a877c8e1a7b2	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2137	kcal	2025-07-28 16:08:00+00	manual	{"season": "summer", "dayIndex": 208, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
cf8886e3-2f42-4656-b545-724a800334d7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	93	fl oz	2025-07-29 19:25:00+00	manual	{"season": "summer", "dayIndex": 209, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
b377e523-7f5e-4ed7-9d6a-a89c3be27f4d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	52	bpm	2025-07-30 16:04:00+00	manual	{"season": "summer", "dayIndex": 210, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
6e9f8665-8655-4945-b54a-6238262dad96	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2426	kcal	2025-07-30 16:07:00+00	manual	{"season": "summer", "dayIndex": 210, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
f6fde08b-2c36-4891-b6d6-f6f11b0eeeb2	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	163	grams	2025-07-31 18:24:00+00	manual	{"season": "summer", "dayIndex": 211, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
938be484-f8e3-4ab3-a830-b98a5fd96329	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2026	kcal	2025-08-01 00:41:00+00	manual	{"season": "summer", "dayIndex": 211, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
a298ad13-04c9-4d96-85e5-51f8b8f2204b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	5683	steps	2025-08-03 21:02:00+00	manual	{"season": "summer", "dayIndex": 214, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
d6ffc348-e633-4f0c-880a-fb75e9a2e1e8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	74	fl oz	2025-08-03 19:07:00+00	manual	{"season": "summer", "dayIndex": 214, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
271ae883-4a75-4206-b4d9-d473f84f6b6b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	6168	steps	2025-08-06 23:41:00+00	manual	{"season": "summer", "dayIndex": 217, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
f23efe16-8e01-4a6f-be6d-9ad3a39b2275	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	6.5	hours	2025-08-06 15:46:00+00	manual	{"season": "summer", "dayIndex": 217, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
24f7f74c-fa39-447a-a3de-4e09c939ab8c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	67	fl oz	2025-08-08 02:26:00+00	manual	{"season": "summer", "dayIndex": 218, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
b825fb23-312c-42eb-aca3-7ce5513632c0	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	6188	steps	2025-08-07 15:50:00+00	manual	{"season": "summer", "dayIndex": 218, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
83fa0123-1876-4fa9-a262-072bc9d70bed	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	115	grams	2025-08-11 01:30:00+00	manual	{"season": "summer", "dayIndex": 221, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
5949a087-12b6-494e-ba1f-306942d49887	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2820	kcal	2025-08-10 17:51:00+00	manual	{"season": "summer", "dayIndex": 221, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
bb22b543-d0ad-40bd-84a6-9e0daacee2d1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	50	bpm	2025-08-12 16:59:00+00	manual	{"season": "summer", "dayIndex": 223, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
bc8ec992-c038-46f1-82cf-ddaa8af1a604	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	6.1	hours	2025-08-12 16:28:00+00	manual	{"season": "summer", "dayIndex": 223, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
cb06d33a-bccf-48d9-b5af-2ecc2e44ebe8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	10341	steps	2025-08-13 01:48:00+00	manual	{"season": "summer", "dayIndex": 223, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
a47c41fc-9b4d-4cb0-ad62-425e57269a4c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2443	kcal	2025-08-12 17:41:00+00	manual	{"season": "summer", "dayIndex": 223, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
992501de-feb4-4a22-834b-79967b542f6e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	50	bpm	2025-08-13 20:31:00+00	manual	{"season": "summer", "dayIndex": 224, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
bb29e793-efcc-4579-ba69-4d7c9abefc6f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2080	kcal	2025-08-16 00:58:00+00	manual	{"season": "summer", "dayIndex": 226, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
72c465f3-023a-403f-91e8-e4d511e34678	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	127	grams	2025-08-16 02:10:00+00	manual	{"season": "summer", "dayIndex": 226, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
5529efae-e05a-4b1e-bfcf-3f263dfa657d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	52	bpm	2025-08-16 00:42:00+00	manual	{"season": "summer", "dayIndex": 226, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
62a29d16-7d67-4571-afde-a9bd045637da	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	6.9	hours	2025-08-15 17:31:00+00	manual	{"season": "summer", "dayIndex": 226, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
010fa68a-833c-4548-8aa2-680745b6ee54	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	50	bpm	2025-08-17 01:48:00+00	manual	{"season": "summer", "dayIndex": 227, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
1e0a70ac-3819-4cf4-a9ec-07119033d0a2	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.6	hours	2025-08-16 23:21:00+00	manual	{"season": "summer", "dayIndex": 227, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
c55b26a2-315d-4c67-8c0f-ee784d7025ac	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	69	fl oz	2025-08-19 01:15:00+00	manual	{"season": "summer", "dayIndex": 229, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
2ab09df8-86b6-41a9-beab-df23494f6d1f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2359	kcal	2025-08-18 19:02:00+00	manual	{"season": "summer", "dayIndex": 229, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
6c66c03c-4a43-4846-9b2e-15e8ba3582a8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7.8	hours	2025-08-19 02:19:00+00	manual	{"season": "summer", "dayIndex": 229, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
ae8f8b70-004c-4616-a50b-75f57f1ce9b9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	191	grams	2025-08-19 19:46:00+00	manual	{"season": "summer", "dayIndex": 230, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
d98d4714-2ea5-4f0a-ac12-28e80bce586e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2052	kcal	2025-08-19 19:13:00+00	manual	{"season": "summer", "dayIndex": 230, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
78298215-9bed-403a-baf9-94950d200fcd	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	51	bpm	2025-08-19 22:29:00+00	manual	{"season": "summer", "dayIndex": 230, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.600961+00	2025-10-07 04:47:32.600961+00
5fe929be-1f70-4ae9-9660-89ca1a3d178b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	207.6	lbs	2025-06-29 17:45:18.585+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 27.4, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 171}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
e9f8e290-7364-4664-91a2-8638d1ed68e7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	210.1	lbs	2025-06-30 06:50:40.173+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 24.9, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 172}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
55d433ff-b8ad-4df0-bbf1-1861186d61a1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	207.7	lbs	2025-07-01 18:52:54.556+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 27.3, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 173}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
9ac80989-e7b9-41a6-864e-e609e3b33dc2	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	209.2	lbs	2025-07-06 15:32:39.392+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 25.8, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 178}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
d4c12b32-d4bd-4c74-8d4f-470d1e619009	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	206.7	lbs	2025-07-07 00:34:28.634+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 28.3, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 179}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
6528355d-6943-4421-9335-70fc196285df	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	207.6	lbs	2025-07-07 23:15:56.697+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 27.4, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 180}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
943bf87d-eec8-4f94-a87f-60147e35199b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	207.5	lbs	2025-07-09 19:06:59.537+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 27.5, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 181}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
40190b69-d0e0-4bf2-8143-23f86fb1e394	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	207.2	lbs	2025-07-10 12:55:59.776+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 27.8, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 182}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
9c91d40d-1aaa-4ed9-b071-59107b890564	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	57	bpm	2025-08-22 01:03:00+00	manual	{"season": "summer", "dayIndex": 232, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
5f2ebc62-c26b-4e24-ade0-67375f4fed54	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	77	fl oz	2025-08-21 16:12:00+00	manual	{"season": "summer", "dayIndex": 232, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
bef9cdac-686b-412c-9f74-a5b6d8e7d767	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	8485	steps	2025-08-21 19:48:00+00	manual	{"season": "summer", "dayIndex": 232, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
6e0d1e01-f864-4002-8147-850b16bd73c3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	188	grams	2025-08-21 15:44:00+00	manual	{"season": "summer", "dayIndex": 232, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
6357dde9-cd4c-4e7a-b3b8-94b73b3d9e97	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	6749	steps	2025-08-25 00:38:00+00	manual	{"season": "summer", "dayIndex": 235, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
1f1d0a01-d340-45bb-9212-6090f073919a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.2	hours	2025-08-24 21:23:00+00	manual	{"season": "summer", "dayIndex": 235, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
a1288af4-2d57-4adb-bd70-5aed88a477cc	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	6536	steps	2025-08-26 21:47:00+00	manual	{"season": "summer", "dayIndex": 237, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
e74b69d3-8ddc-45eb-bd3d-91e81b75e648	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	89	fl oz	2025-08-26 19:55:00+00	manual	{"season": "summer", "dayIndex": 237, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
efb485ff-5c59-44df-b3cb-980c25530272	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	6.5	hours	2025-08-27 17:30:00+00	manual	{"season": "summer", "dayIndex": 238, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
668eacee-6c3d-4950-956d-da765a81283b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2257	kcal	2025-08-27 20:02:00+00	manual	{"season": "summer", "dayIndex": 238, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
527fe484-2068-4319-87b5-b10cac7bad79	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	1938	kcal	2025-08-28 19:40:00+00	manual	{"season": "summer", "dayIndex": 239, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
d9312f98-84f3-44fd-8317-5ac1ec0db0f4	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2346	kcal	2025-08-30 02:29:00+00	manual	{"season": "summer", "dayIndex": 240, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
4e724112-394a-4daa-86fc-8e498c0c4890	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	54	bpm	2025-08-31 22:19:00+00	manual	{"season": "summer", "dayIndex": 242, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
d72d8afc-e601-4c81-909e-f38fe25c3dbb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	58	fl oz	2025-09-01 01:58:00+00	manual	{"season": "summer", "dayIndex": 242, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
0b23e957-9c37-4cdb-b246-268e50f8f6ca	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	68	fl oz	2025-09-02 16:01:00+00	manual	{"season": "fall", "dayIndex": 244, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
bd073e12-b4ad-44d9-814b-b1af7a6716c7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	10210	steps	2025-09-02 22:15:00+00	manual	{"season": "fall", "dayIndex": 244, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
8936618f-ea82-4243-b39e-352a24a000af	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	59	fl oz	2025-09-04 02:55:00+00	manual	{"season": "fall", "dayIndex": 245, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
aac7edf9-0983-4440-b1a5-4ab70d273edd	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2024	kcal	2025-09-05 02:00:00+00	manual	{"season": "fall", "dayIndex": 246, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
ae758914-e0aa-4521-ba1a-35d602197ff3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	160	grams	2025-09-05 20:37:00+00	manual	{"season": "fall", "dayIndex": 247, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
73bfa4c9-ca4c-43a5-a230-807ab0bd7c78	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2194	kcal	2025-09-05 20:07:00+00	manual	{"season": "fall", "dayIndex": 247, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
e716f501-aea7-4d9d-8621-ab54ca7293ea	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	50	bpm	2025-09-05 23:20:00+00	manual	{"season": "fall", "dayIndex": 247, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
624f4180-2056-415e-a2da-d3fb49ccc21d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2404	kcal	2025-09-09 17:05:00+00	manual	{"season": "fall", "dayIndex": 251, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
6393ea3f-c99b-47f3-8aa0-38de30749d13	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	55	fl oz	2025-09-10 18:34:00+00	manual	{"season": "fall", "dayIndex": 252, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
c1fb9582-5c9f-439b-bce3-89289f156225	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	110	grams	2025-09-10 20:56:00+00	manual	{"season": "fall", "dayIndex": 252, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
e4f061b6-e430-45d0-aa09-0d23ed14ce6e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	129	grams	2025-09-12 01:21:00+00	manual	{"season": "fall", "dayIndex": 253, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
c1487a84-fe4b-4137-8bff-a59b9a19a34a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	8627	steps	2025-09-11 22:41:00+00	manual	{"season": "fall", "dayIndex": 253, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
d0de86b9-7f41-4bfd-8b8e-f103cf7ca8ef	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	148	grams	2025-09-12 19:16:00+00	manual	{"season": "fall", "dayIndex": 254, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
3a9baf05-bcae-4160-b26d-ad349d457af8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	50	bpm	2025-09-13 00:59:00+00	manual	{"season": "fall", "dayIndex": 254, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
0216db27-5f78-4426-94d5-9c2201a72ec2	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	50	bpm	2025-09-13 21:36:00+00	manual	{"season": "fall", "dayIndex": 255, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
92f414ac-22fe-4603-9238-be341e2a5b0b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	3938	steps	2025-09-13 16:10:00+00	manual	{"season": "fall", "dayIndex": 255, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
f115657c-33eb-4638-b603-1106cc5faad8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	76	fl oz	2025-09-13 21:18:00+00	manual	{"season": "fall", "dayIndex": 255, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
17c040a5-769b-4a52-b1ee-62320b5de698	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	96	grams	2025-09-13 22:56:00+00	manual	{"season": "fall", "dayIndex": 255, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
24707286-cbe5-467a-a9ff-db67b44d8128	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2232	kcal	2025-09-14 23:19:00+00	manual	{"season": "fall", "dayIndex": 256, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
7d6bb6e0-f518-4c96-b71b-db81cdb32c0a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	7518	steps	2025-09-15 15:40:00+00	manual	{"season": "fall", "dayIndex": 257, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
32015477-1825-407d-94a3-f17539fc9f1a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	60	fl oz	2025-09-15 16:12:00+00	manual	{"season": "fall", "dayIndex": 257, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
62cc7c95-ac19-464f-81da-f33586c2083c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	112	grams	2025-09-17 19:45:00+00	manual	{"season": "fall", "dayIndex": 259, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
99127b77-0d1a-43d2-a6d8-ec3f01552ff6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.9	hours	2025-09-17 17:00:00+00	manual	{"season": "fall", "dayIndex": 259, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
ef2957c6-718b-448e-8a43-1841b4e541b1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	10772	steps	2025-09-17 18:13:00+00	manual	{"season": "fall", "dayIndex": 259, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
e9061026-35ed-4ead-a0a7-2f49dcef7f8f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	93	grams	2025-09-20 15:08:00+00	manual	{"season": "fall", "dayIndex": 262, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
74ec9839-236c-4959-826a-e8cd9b717036	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	8.2	hours	2025-09-20 20:04:00+00	manual	{"season": "fall", "dayIndex": 262, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
9ee910d3-c854-4ed0-b244-aedb30729d94	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	50	bpm	2025-09-20 22:47:00+00	manual	{"season": "fall", "dayIndex": 262, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
4e60deff-2336-4e47-9834-9c7fc3e35768	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2533	kcal	2025-09-21 19:46:00+00	manual	{"season": "fall", "dayIndex": 263, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
1b3d5a87-482f-43a6-90f6-6b74b85f0822	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	50	bpm	2025-09-23 17:41:00+00	manual	{"season": "fall", "dayIndex": 265, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
ea2d8ce8-28cd-4540-b4f4-d04b476fe00e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	protein	130	grams	2025-09-26 01:09:00+00	manual	{"season": "fall", "dayIndex": 267, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
593d1843-beb4-4e2d-90d2-0bba3c57966d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	5676	steps	2025-09-26 00:27:00+00	manual	{"season": "fall", "dayIndex": 267, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
31f19597-91b5-49df-8435-db136ab3a7e7	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	1949	kcal	2025-09-25 17:13:00+00	manual	{"season": "fall", "dayIndex": 267, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
c92fd7d1-e648-44e1-be9f-429b8ba8e67d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	6967	steps	2025-09-27 23:16:00+00	manual	{"season": "fall", "dayIndex": 269, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
98f4ccc1-71bb-4b95-a1ad-ffdc4977c8ed	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	7073	steps	2025-09-29 02:14:00+00	manual	{"season": "fall", "dayIndex": 270, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
5e300be5-3a7a-43da-8ce9-b05a9ea4762f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	50	bpm	2025-09-28 18:21:00+00	manual	{"season": "fall", "dayIndex": 270, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
fb383a16-6079-4ea7-932e-2f11ddcf75ea	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	10087	steps	2025-09-30 01:55:00+00	manual	{"season": "fall", "dayIndex": 271, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
4f25ee37-44c7-48d3-8d9e-5bb01e08abb9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7.8	hours	2025-09-29 21:22:00+00	manual	{"season": "fall", "dayIndex": 271, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
47fd8245-3114-43de-a971-b34ad3adf884	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	49	fl oz	2025-10-01 23:04:00+00	manual	{"season": "fall", "dayIndex": 273, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
36203e10-99d7-45b2-999c-4dafdd91c9a4	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	7.1	hours	2025-10-01 17:36:00+00	manual	{"season": "fall", "dayIndex": 273, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
76e6bce7-8659-4526-b71b-47460fbeb9b3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	6735	steps	2025-10-01 19:23:00+00	manual	{"season": "fall", "dayIndex": 273, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
3d007c5e-cd37-46d7-82c9-48a2c927ce50	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2026	kcal	2025-10-01 15:49:00+00	manual	{"season": "fall", "dayIndex": 273, "generated": true, "isWeekend": false, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
0425c225-f6a6-44ef-a73d-b9f0ea9ed98c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	50	bpm	2025-10-03 20:51:00+00	manual	{"season": "fall", "dayIndex": 275, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
9fe516bf-205d-4794-add1-abb5757b13aa	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	50	bpm	2025-10-05 00:55:00+00	manual	{"season": "fall", "dayIndex": 276, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
992aa31e-4927-404d-aab1-d1cd96eae192	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	sleep	10.5	hours	2025-10-04 23:54:00+00	manual	{"season": "fall", "dayIndex": 276, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
8f1c190d-16f2-4b66-8dc1-f70db50a121e	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	steps	4729	steps	2025-10-04 16:51:00+00	manual	{"season": "fall", "dayIndex": 276, "generated": true, "isWeekend": true, "isWorkoutDay": false}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
9e61876c-1c2c-4078-8e76-845bd72687c3	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	calories	2201	kcal	2025-10-07 02:42:00+00	manual	{"season": "fall", "dayIndex": 278, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
23d3849a-b513-4109-8ae8-470cd4fb713b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	heart_rate	50	bpm	2025-10-07 00:14:00+00	manual	{"season": "fall", "dayIndex": 278, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
897652f7-a7a0-441d-aec2-1022ffc95be1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	water	80	fl oz	2025-10-06 22:42:00+00	manual	{"season": "fall", "dayIndex": 278, "generated": true, "isWeekend": false, "isWorkoutDay": true}	2025-10-07 04:47:32.604334+00	2025-10-07 04:47:32.604334+00
805eba0f-b50c-4198-8464-06d1ccac19f1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	205.3	lbs	2025-07-15 08:54:02.199+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 29.7, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 187}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
10b58f55-7195-453d-84b8-e4044b58c8e8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	203.9	lbs	2025-07-16 17:34:08.112+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 31.1, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 188}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
d547f0b9-67b0-4fc3-8390-bdb28a2dec21	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	205.5	lbs	2025-07-18 14:26:24.515+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 29.5, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 190}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
d5310b21-fc2d-425f-9949-befa8faffb97	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	206.2	lbs	2025-07-19 11:34:50.354+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 28.8, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 191}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
2408c7b1-c0f5-4da7-b24b-6ace0ee34108	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	204.2	lbs	2025-07-25 18:43:03.736+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 30.8, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 197}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
dedb8ad7-3ff1-4639-b1ba-883a862ae35b	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	204.9	lbs	2025-07-26 17:07:37.59+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 30.1, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 198}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
4c16dc93-dd03-41f0-85ac-70c6b29017ac	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	204.7	lbs	2025-07-28 12:55:41.886+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 30.3, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 200}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
0e5ee4d9-eedf-4308-af86-4bcd541bc9b8	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	205.6	lbs	2025-08-01 13:46:03.068+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 29.4, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 204}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
7825213b-6cef-40d1-b47b-59a77a0ca2bb	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	206.4	lbs	2025-08-03 06:16:30.728+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 28.6, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 206}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
4983026c-1623-45fa-8379-8b5a6c07d324	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	203.9	lbs	2025-08-06 12:30:58.349+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 31.1, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 209}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
0f88193c-6279-40e4-b212-8d2887852415	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	203.7	lbs	2025-08-07 21:28:15.307+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 31.3, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 210}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
0e248e9c-75b7-4252-a910-7dd36c2b50c9	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	205.3	lbs	2025-08-10 18:17:06.038+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 29.7, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 213}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
47a91789-9865-4419-9790-b7306813b2d1	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	200.7	lbs	2025-08-14 16:56:11.186+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 34.3, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 217}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
d227957b-619b-440c-8b9c-9225f21a13f6	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	202.2	lbs	2025-08-15 05:23:58.771+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 32.8, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 218}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
59a69fc9-2d2e-455d-a602-72ce2356212f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	202	lbs	2025-08-21 19:18:24.258+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 33, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 224}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
a631e718-4b75-431f-97bd-1fa9b78d541f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	203.6	lbs	2025-08-23 00:31:24.17+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 31.4, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 226}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
4e221909-ae41-43ca-9127-6b7ef9b3a23a	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	202.6	lbs	2025-08-24 19:24:55.861+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 32.4, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 227}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
9ce3848d-d5ba-40eb-88f2-31b6d772c73f	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	201.1	lbs	2025-08-26 13:54:11.032+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 33.9, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 229}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
e98297c2-239d-4bc2-8a3a-f53888081d44	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	202.1	lbs	2025-08-27 20:18:51.592+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 32.9, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 230}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
67d6a83a-72f8-4055-a55e-13f186bd2885	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	201.6	lbs	2025-08-29 23:00:21.913+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 33.4, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 233}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
68e3badd-677d-4c56-8793-1554bcedb053	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	202.9	lbs	2025-09-01 18:28:07.649+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 32.1, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 235}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
ba849646-1e36-41c8-85f8-15fafa493e50	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	weight	203.1	lbs	2025-09-02 14:57:04.917+00	manual	{"note": "Weight loss progression on GLP-1 medication", "total_weight_loss": 31.9, "treatment_start_date": "2025-01-09", "days_since_treatment_start": 236}	2025-10-08 02:36:37.756+00	2025-10-08 02:36:37.756+00
\.


--
-- TOC entry 4752 (class 0 OID 18449)
-- Dependencies: 325
-- Data for Name: patient_medication_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patient_medication_preferences (id, patient_id, medication_id, preferred_dosage, frequency, notes, status, requested_date, created_at, updated_at, medication_dosage_id, faxed, next_prescription_due, supply_days, refill_requested) FROM stdin;
7bcb49fe-fe0b-4aa1-ac48-2eaab22b689d	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	77c41b69-f3b6-4194-98f0-118f1c7aecef	2.5mg	2	\N	approved	2025-10-06 06:11:43.582176+00	2025-10-06 06:11:43.582176+00	2025-10-06 06:12:18.834833+00	\N	2025-10-06 06:12:18.834+00	2025-10-16	10	f
43aa9695-2c22-4df0-bd7a-c019a5d51a4c	4c3c0e97-7074-4bc0-97b6-654bcfa584a5	72ea2dc1-23e0-458b-a556-5dd6cd3041ea	0.25mg	\N	\N	pending	2025-10-07 04:04:40.139685+00	2025-10-07 04:04:40.139685+00	2025-10-11 21:49:10.062239+00	\N	\N	\N	\N	f
\.


--
-- TOC entry 4745 (class 0 OID 18302)
-- Dependencies: 318
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patients (id, profile_id, date_of_birth, phone, has_completed_intake, created_at, updated_at) FROM stdin;
0615f0c9-6711-4d10-ae4d-4176fc22a0a8	aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa	\N	\N	f	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00
4227aec1-5e9b-45e4-8d40-bcd9f1a9ab7e	bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb	\N	\N	f	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00
3f80d6e9-fc78-4511-b7e7-c3d0eca5b543	cccccccc-cccc-cccc-cccc-cccccccccccc	\N	\N	f	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00
240dfa68-c2e2-4128-a15d-0d44fe641621	11111111-1111-1111-1111-111111111111	\N	555-0101	t	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00
7c81144f-8e56-49a1-8ea8-dfd8f4d201dd	22222222-2222-2222-2222-222222222222	\N	555-0102	t	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00
fc783f29-4531-4c45-9b7a-785279b88cff	33333333-3333-3333-3333-333333333333	\N	555-0103	t	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00
70aac36f-7956-4397-a846-bd89f7ff7abc	44444444-4444-4444-4444-444444444444	\N	555-0104	t	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00
4c3c0e97-7074-4bc0-97b6-654bcfa584a5	b095ab96-69c1-4bbd-bf63-8098b530ab69	\N	\N	f	2025-10-06 03:35:13.02509+00	2025-10-06 03:35:13.02509+00
\.


--
-- TOC entry 4744 (class 0 OID 18285)
-- Dependencies: 317
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (id, email, first_name, last_name, role, created_at, updated_at) FROM stdin;
11111111-1111-1111-1111-111111111111	sarah.j@test.com	Sarah	Johnson	patient	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00
22222222-2222-2222-2222-222222222222	michael.r@test.com	Michael	Roberts	patient	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00
33333333-3333-3333-3333-333333333333	jennifer.m@test.com	Jennifer	Martinez	patient	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00
44444444-4444-4444-4444-444444444444	david.a@test.com	David	Anderson	patient	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00
aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa	admin@test.com	Admin	User	admin	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00
bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb	dr.watson@test.com	Dr. Emily	Watson	provider	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00
cccccccc-cccc-cccc-cccc-cccccccccccc	dr.wilson@test.com	Dr. James	Wilson	provider	2025-10-06 03:29:33.16878+00	2025-10-06 03:29:33.16878+00
b095ab96-69c1-4bbd-bf63-8098b530ab69	patientexample@test.com	patient	example	patient	2025-10-06 03:35:13.02509+00	2025-10-06 03:35:13.02509+00
94700da3-b8bf-43a6-8e00-866059953329	adminexample@test.com	admin	example	admin	2025-10-06 03:36:00.511221+00	2025-10-06 03:36:00.511221+00
305d1547-37d4-4852-8ff0-f63199270616	providerexample@test.com	provider	example	provider	2025-10-06 03:36:28.412535+00	2025-10-06 03:36:28.412535+00
\.


--
-- TOC entry 4756 (class 0 OID 18588)
-- Dependencies: 329
-- Data for Name: provider_availability_overrides; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.provider_availability_overrides (id, provider_id, date, start_time, end_time, available, reason, created_at) FROM stdin;
\.


--
-- TOC entry 4755 (class 0 OID 18565)
-- Dependencies: 328
-- Data for Name: provider_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.provider_schedules (id, provider_id, day_of_week, start_time, end_time, slot_duration_minutes, treatment_types, active, created_at, updated_at) FROM stdin;
363bd0df-4daf-44bb-8eb2-2d7144f91814	e7fcaca9-bde3-4cb9-8e57-2d1813fe1551	1	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-10-06 03:36:28.412535+00	2025-10-06 03:36:28.412535+00
8982a29f-35e9-4141-8145-f766b4c1453a	e7fcaca9-bde3-4cb9-8e57-2d1813fe1551	2	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-10-06 03:36:28.412535+00	2025-10-06 03:36:28.412535+00
f97acc66-2c1f-46bd-97d8-c29770773de5	e7fcaca9-bde3-4cb9-8e57-2d1813fe1551	3	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-10-06 03:36:28.412535+00	2025-10-06 03:36:28.412535+00
3b8573fb-8352-4cbf-b5b8-685766ceb881	e7fcaca9-bde3-4cb9-8e57-2d1813fe1551	4	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-10-06 03:36:28.412535+00	2025-10-06 03:36:28.412535+00
52da3cc6-73bd-4474-b621-2f7a5959e6c6	e7fcaca9-bde3-4cb9-8e57-2d1813fe1551	5	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-10-06 03:36:28.412535+00	2025-10-06 03:36:28.412535+00
\.


--
-- TOC entry 4746 (class 0 OID 18320)
-- Dependencies: 319
-- Data for Name: providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.providers (id, profile_id, specialty, license_number, phone, active, created_at, updated_at) FROM stdin;
e7fcaca9-bde3-4cb9-8e57-2d1813fe1551	305d1547-37d4-4852-8ff0-f63199270616	weight loss	12345678		t	2025-10-06 03:36:28.412535+00	2025-10-06 03:36:28.412535+00
\.


--
-- TOC entry 4764 (class 0 OID 18920)
-- Dependencies: 339
-- Data for Name: visit_addendums; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visit_addendums (id, visit_id, provider_id, content, created_at) FROM stdin;
\.


--
-- TOC entry 4761 (class 0 OID 18778)
-- Dependencies: 336
-- Data for Name: visit_interactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visit_interactions (id, clinical_note_id, appointment_id, interaction_type, details, provider_notes, created_at, performed_by, medication_id, medication_name, previous_dosage, new_dosage, previous_frequency, new_frequency, previous_status, new_status) FROM stdin;
\.


--
-- TOC entry 4760 (class 0 OID 18753)
-- Dependencies: 335
-- Data for Name: visit_medication_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visit_medication_adjustments (id, clinical_note_id, appointment_id, preference_id, previous_dosage, previous_frequency, previous_status, previous_provider_notes, new_dosage, new_frequency, new_status, new_provider_notes, adjustment_reason, provider_notes, created_at, performed_by, new_supply_days) FROM stdin;
\.


--
-- TOC entry 4721 (class 0 OID 17024)
-- Dependencies: 293
-- Data for Name: messages_2025_10_05; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_10_05 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4722 (class 0 OID 17036)
-- Dependencies: 294
-- Data for Name: messages_2025_10_06; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_10_06 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4723 (class 0 OID 17048)
-- Dependencies: 295
-- Data for Name: messages_2025_10_07; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_10_07 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4724 (class 0 OID 17060)
-- Dependencies: 296
-- Data for Name: messages_2025_10_08; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_10_08 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4725 (class 0 OID 17072)
-- Dependencies: 297
-- Data for Name: messages_2025_10_09; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_10_09 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4718 (class 0 OID 16844)
-- Dependencies: 286
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2025-10-06 03:29:24
20211116045059	2025-10-06 03:29:24
20211116050929	2025-10-06 03:29:24
20211116051442	2025-10-06 03:29:24
20211116212300	2025-10-06 03:29:24
20211116213355	2025-10-06 03:29:24
20211116213934	2025-10-06 03:29:24
20211116214523	2025-10-06 03:29:24
20211122062447	2025-10-06 03:29:24
20211124070109	2025-10-06 03:29:24
20211202204204	2025-10-06 03:29:24
20211202204605	2025-10-06 03:29:24
20211210212804	2025-10-06 03:29:24
20211228014915	2025-10-06 03:29:24
20220107221237	2025-10-06 03:29:24
20220228202821	2025-10-06 03:29:24
20220312004840	2025-10-06 03:29:24
20220603231003	2025-10-06 03:29:24
20220603232444	2025-10-06 03:29:24
20220615214548	2025-10-06 03:29:24
20220712093339	2025-10-06 03:29:24
20220908172859	2025-10-06 03:29:24
20220916233421	2025-10-06 03:29:24
20230119133233	2025-10-06 03:29:24
20230128025114	2025-10-06 03:29:24
20230128025212	2025-10-06 03:29:24
20230227211149	2025-10-06 03:29:24
20230228184745	2025-10-06 03:29:24
20230308225145	2025-10-06 03:29:24
20230328144023	2025-10-06 03:29:24
20231018144023	2025-10-06 03:29:24
20231204144023	2025-10-06 03:29:24
20231204144024	2025-10-06 03:29:24
20231204144025	2025-10-06 03:29:24
20240108234812	2025-10-06 03:29:24
20240109165339	2025-10-06 03:29:24
20240227174441	2025-10-06 03:29:24
20240311171622	2025-10-06 03:29:24
20240321100241	2025-10-06 03:29:24
20240401105812	2025-10-06 03:29:24
20240418121054	2025-10-06 03:29:24
20240523004032	2025-10-06 03:29:24
20240618124746	2025-10-06 03:29:24
20240801235015	2025-10-06 03:29:24
20240805133720	2025-10-06 03:29:24
20240827160934	2025-10-06 03:29:24
20240919163303	2025-10-06 03:29:24
20240919163305	2025-10-06 03:29:24
20241019105805	2025-10-06 03:29:24
20241030150047	2025-10-06 03:29:24
20241108114728	2025-10-06 03:29:24
20241121104152	2025-10-06 03:29:24
20241130184212	2025-10-06 03:29:24
20241220035512	2025-10-06 03:29:24
20241220123912	2025-10-06 03:29:24
20241224161212	2025-10-06 03:29:24
20250107150512	2025-10-06 03:29:24
20250110162412	2025-10-06 03:29:24
20250123174212	2025-10-06 03:29:24
20250128220012	2025-10-06 03:29:24
20250506224012	2025-10-06 03:29:24
20250523164012	2025-10-06 03:29:24
20250714121412	2025-10-06 03:29:24
20250905041441	2025-10-06 03:29:24
\.


--
-- TOC entry 4720 (class 0 OID 16867)
-- Dependencies: 289
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at) FROM stdin;
\.


--
-- TOC entry 4712 (class 0 OID 16509)
-- Dependencies: 267
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
\.


--
-- TOC entry 4729 (class 0 OID 17892)
-- Dependencies: 301
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_analytics (id, type, format, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4730 (class 0 OID 17903)
-- Dependencies: 302
-- Data for Name: iceberg_namespaces; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.iceberg_namespaces (id, bucket_id, name, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4731 (class 0 OID 17919)
-- Dependencies: 303
-- Data for Name: iceberg_tables; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.iceberg_tables (id, namespace_id, bucket_id, name, location, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4714 (class 0 OID 16551)
-- Dependencies: 269
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2025-10-06 03:29:32.642259
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2025-10-06 03:29:32.643648
2	storage-schema	5c7968fd083fcea04050c1b7f6253c9771b99011	2025-10-06 03:29:32.644309
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2025-10-06 03:29:32.647237
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2025-10-06 03:29:32.64935
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2025-10-06 03:29:32.649981
6	change-column-name-in-get-size	f93f62afdf6613ee5e7e815b30d02dc990201044	2025-10-06 03:29:32.650978
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2025-10-06 03:29:32.651911
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2025-10-06 03:29:32.652519
9	fix-search-function	3a0af29f42e35a4d101c259ed955b67e1bee6825	2025-10-06 03:29:32.653224
10	search-files-search-function	68dc14822daad0ffac3746a502234f486182ef6e	2025-10-06 03:29:32.654445
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2025-10-06 03:29:32.65531
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2025-10-06 03:29:32.656191
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2025-10-06 03:29:32.656814
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2025-10-06 03:29:32.657584
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2025-10-06 03:29:32.661776
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2025-10-06 03:29:32.662478
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2025-10-06 03:29:32.663066
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2025-10-06 03:29:32.66374
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2025-10-06 03:29:32.664805
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2025-10-06 03:29:32.665695
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2025-10-06 03:29:32.666559
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2025-10-06 03:29:32.66903
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2025-10-06 03:29:32.671017
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2025-10-06 03:29:32.671801
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2025-10-06 03:29:32.672579
26	objects-prefixes	ef3f7871121cdc47a65308e6702519e853422ae2	2025-10-06 03:29:32.673117
27	search-v2	33b8f2a7ae53105f028e13e9fcda9dc4f356b4a2	2025-10-06 03:29:32.675852
28	object-bucket-name-sorting	ba85ec41b62c6a30a3f136788227ee47f311c436	2025-10-06 03:29:32.689045
29	create-prefixes	a7b1a22c0dc3ab630e3055bfec7ce7d2045c5b7b	2025-10-06 03:29:32.690005
30	update-object-levels	6c6f6cc9430d570f26284a24cf7b210599032db7	2025-10-06 03:29:32.690834
31	objects-level-index	33f1fef7ec7fea08bb892222f4f0f5d79bab5eb8	2025-10-06 03:29:32.691603
32	backward-compatible-index-on-objects	2d51eeb437a96868b36fcdfb1ddefdf13bef1647	2025-10-06 03:29:32.692306
33	backward-compatible-index-on-prefixes	fe473390e1b8c407434c0e470655945b110507bf	2025-10-06 03:29:32.693085
34	optimize-search-function-v1	82b0e469a00e8ebce495e29bfa70a0797f7ebd2c	2025-10-06 03:29:32.693228
35	add-insert-trigger-prefixes	63bb9fd05deb3dc5e9fa66c83e82b152f0caf589	2025-10-06 03:29:32.694429
36	optimise-existing-functions	81cf92eb0c36612865a18016a38496c530443899	2025-10-06 03:29:32.694978
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2025-10-06 03:29:32.696628
38	iceberg-catalog-flag-on-buckets	19a8bd89d5dfa69af7f222a46c726b7c41e462c5	2025-10-06 03:29:32.697392
\.


--
-- TOC entry 4713 (class 0 OID 16524)
-- Dependencies: 268
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata, level) FROM stdin;
\.


--
-- TOC entry 4728 (class 0 OID 17848)
-- Dependencies: 300
-- Data for Name: prefixes; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.prefixes (bucket_id, name, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4726 (class 0 OID 17795)
-- Dependencies: 298
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata) FROM stdin;
\.


--
-- TOC entry 4727 (class 0 OID 17809)
-- Dependencies: 299
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- TOC entry 4717 (class 0 OID 16763)
-- Dependencies: 282
-- Data for Name: hooks; Type: TABLE DATA; Schema: supabase_functions; Owner: -
--

COPY supabase_functions.hooks (id, hook_table_id, hook_name, created_at, request_id) FROM stdin;
\.


--
-- TOC entry 4715 (class 0 OID 16754)
-- Dependencies: 280
-- Data for Name: migrations; Type: TABLE DATA; Schema: supabase_functions; Owner: -
--

COPY supabase_functions.migrations (version, inserted_at) FROM stdin;
initial	2025-10-06 03:29:20.735852+00
20210809183423_update_grants	2025-10-06 03:29:20.735852+00
\.


--
-- TOC entry 4886 (class 0 OID 0)
-- Dependencies: 262
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 157, true);


--
-- TOC entry 4887 (class 0 OID 0)
-- Dependencies: 322
-- Name: assignment_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assignment_log_id_seq', 2, true);


--
-- TOC entry 4888 (class 0 OID 0)
-- Dependencies: 288
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: -
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- TOC entry 4889 (class 0 OID 0)
-- Dependencies: 281
-- Name: hooks_id_seq; Type: SEQUENCE SET; Schema: supabase_functions; Owner: -
--

SELECT pg_catalog.setval('supabase_functions.hooks_id_seq', 1, false);


--
-- TOC entry 4114 (class 2606 OID 18079)
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- TOC entry 4026 (class 2606 OID 16494)
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 4137 (class 2606 OID 18185)
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- TOC entry 4093 (class 2606 OID 18203)
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- TOC entry 4095 (class 2606 OID 18213)
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- TOC entry 4024 (class 2606 OID 16487)
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- TOC entry 4116 (class 2606 OID 18072)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- TOC entry 4112 (class 2606 OID 18060)
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- TOC entry 4104 (class 2606 OID 18253)
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- TOC entry 4106 (class 2606 OID 18047)
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- TOC entry 4147 (class 2606 OID 18274)
-- Name: oauth_clients oauth_clients_client_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_client_id_key UNIQUE (client_id);


--
-- TOC entry 4150 (class 2606 OID 18272)
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- TOC entry 4141 (class 2606 OID 18238)
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 4018 (class 2606 OID 16477)
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 4021 (class 2606 OID 17990)
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- TOC entry 4126 (class 2606 OID 18119)
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- TOC entry 4128 (class 2606 OID 18117)
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4133 (class 2606 OID 18133)
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- TOC entry 4029 (class 2606 OID 16500)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4099 (class 2606 OID 18011)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 4123 (class 2606 OID 18100)
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- TOC entry 4118 (class 2606 OID 18091)
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4011 (class 2606 OID 18173)
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- TOC entry 4013 (class 2606 OID 16464)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4168 (class 2606 OID 18349)
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- TOC entry 4170 (class 2606 OID 18351)
-- Name: admins admins_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_profile_id_key UNIQUE (profile_id);


--
-- TOC entry 4237 (class 2606 OID 18653)
-- Name: appointment_history appointment_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment_history
    ADD CONSTRAINT appointment_history_pkey PRIMARY KEY (id);


--
-- TOC entry 4224 (class 2606 OID 18625)
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- TOC entry 4180 (class 2606 OID 18435)
-- Name: assignment_log assignment_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assignment_log
    ADD CONSTRAINT assignment_log_pkey PRIMARY KEY (id);


--
-- TOC entry 4285 (class 2606 OID 18975)
-- Name: auth_trigger_debug_log auth_trigger_debug_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_trigger_debug_log
    ADD CONSTRAINT auth_trigger_debug_log_pkey PRIMARY KEY (id);


--
-- TOC entry 4271 (class 2606 OID 18865)
-- Name: auth_trigger_logs auth_trigger_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_trigger_logs
    ADD CONSTRAINT auth_trigger_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 4241 (class 2606 OID 18735)
-- Name: clinical_notes clinical_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_pkey PRIMARY KEY (id);


--
-- TOC entry 4287 (class 2606 OID 19036)
-- Name: faxes faxes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_pkey PRIMARY KEY (id);


--
-- TOC entry 4201 (class 2606 OID 18483)
-- Name: medication_approvals medication_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_pkey PRIMARY KEY (id);


--
-- TOC entry 4276 (class 2606 OID 18904)
-- Name: medication_dosages medication_dosages_medication_id_strength_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_dosages
    ADD CONSTRAINT medication_dosages_medication_id_strength_key UNIQUE (medication_id, strength);


--
-- TOC entry 4278 (class 2606 OID 18902)
-- Name: medication_dosages medication_dosages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_dosages
    ADD CONSTRAINT medication_dosages_pkey PRIMARY KEY (id);


--
-- TOC entry 4210 (class 2606 OID 18506)
-- Name: medication_orders medication_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_pkey PRIMARY KEY (id);


--
-- TOC entry 4300 (class 2606 OID 19172)
-- Name: medication_tracking_entries medication_tracking_entries_patient_id_medication_preferenc_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_tracking_entries
    ADD CONSTRAINT medication_tracking_entries_patient_id_medication_preferenc_key UNIQUE (patient_id, medication_preference_id, taken_date);


--
-- TOC entry 4302 (class 2606 OID 19170)
-- Name: medication_tracking_entries medication_tracking_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_tracking_entries
    ADD CONSTRAINT medication_tracking_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 4184 (class 2606 OID 18448)
-- Name: medications medications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medications
    ADD CONSTRAINT medications_pkey PRIMARY KEY (id);


--
-- TOC entry 4176 (class 2606 OID 18370)
-- Name: patient_assignments patient_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT patient_assignments_pkey PRIMARY KEY (id);


--
-- TOC entry 4308 (class 2606 OID 19207)
-- Name: patient_health_metrics patient_health_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_health_metrics
    ADD CONSTRAINT patient_health_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 4193 (class 2606 OID 18462)
-- Name: patient_medication_preferences patient_medication_preferences_patient_id_medication_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_patient_id_medication_id_key UNIQUE (patient_id, medication_id);


--
-- TOC entry 4195 (class 2606 OID 18460)
-- Name: patient_medication_preferences patient_medication_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_pkey PRIMARY KEY (id);


--
-- TOC entry 4159 (class 2606 OID 18312)
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- TOC entry 4161 (class 2606 OID 18314)
-- Name: patients patients_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_profile_id_key UNIQUE (profile_id);


--
-- TOC entry 4154 (class 2606 OID 18296)
-- Name: profiles profiles_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_email_key UNIQUE (email);


--
-- TOC entry 4156 (class 2606 OID 18294)
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- TOC entry 4220 (class 2606 OID 18597)
-- Name: provider_availability_overrides provider_availability_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_availability_overrides
    ADD CONSTRAINT provider_availability_overrides_pkey PRIMARY KEY (id);


--
-- TOC entry 4214 (class 2606 OID 18580)
-- Name: provider_schedules provider_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_schedules
    ADD CONSTRAINT provider_schedules_pkey PRIMARY KEY (id);


--
-- TOC entry 4164 (class 2606 OID 18330)
-- Name: providers providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4166 (class 2606 OID 18332)
-- Name: providers providers_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_profile_id_key UNIQUE (profile_id);


--
-- TOC entry 4251 (class 2606 OID 18737)
-- Name: clinical_notes unique_appointment_clinical_note; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT unique_appointment_clinical_note UNIQUE (appointment_id);


--
-- TOC entry 4253 (class 2606 OID 18834)
-- Name: clinical_notes unique_clinical_note_per_appointment; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT unique_clinical_note_per_appointment UNIQUE (appointment_id);


--
-- TOC entry 4178 (class 2606 OID 18372)
-- Name: patient_assignments unique_primary_assignment; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT unique_primary_assignment EXCLUDE USING btree (patient_id WITH =) WHERE (((is_primary = true) AND (active = true)));


--
-- TOC entry 4222 (class 2606 OID 18599)
-- Name: provider_availability_overrides unique_provider_override; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_availability_overrides
    ADD CONSTRAINT unique_provider_override UNIQUE (provider_id, date, start_time, end_time);


--
-- TOC entry 4216 (class 2606 OID 18582)
-- Name: provider_schedules unique_provider_schedule; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_schedules
    ADD CONSTRAINT unique_provider_schedule UNIQUE (provider_id, day_of_week, start_time, end_time);


--
-- TOC entry 4235 (class 2606 OID 18627)
-- Name: appointments unique_provider_slot; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT unique_provider_slot UNIQUE (provider_id, appointment_date, start_time);


--
-- TOC entry 4283 (class 2606 OID 18929)
-- Name: visit_addendums visit_addendums_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_addendums
    ADD CONSTRAINT visit_addendums_pkey PRIMARY KEY (id);


--
-- TOC entry 4269 (class 2606 OID 18787)
-- Name: visit_interactions visit_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_interactions
    ADD CONSTRAINT visit_interactions_pkey PRIMARY KEY (id);


--
-- TOC entry 4260 (class 2606 OID 18762)
-- Name: visit_medication_adjustments visit_medication_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_pkey PRIMARY KEY (id);


--
-- TOC entry 4059 (class 2606 OID 17021)
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4062 (class 2606 OID 17032)
-- Name: messages_2025_10_05 messages_2025_10_05_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_10_05
    ADD CONSTRAINT messages_2025_10_05_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4065 (class 2606 OID 17044)
-- Name: messages_2025_10_06 messages_2025_10_06_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_10_06
    ADD CONSTRAINT messages_2025_10_06_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4068 (class 2606 OID 17056)
-- Name: messages_2025_10_07 messages_2025_10_07_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_10_07
    ADD CONSTRAINT messages_2025_10_07_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4071 (class 2606 OID 17068)
-- Name: messages_2025_10_08 messages_2025_10_08_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_10_08
    ADD CONSTRAINT messages_2025_10_08_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4074 (class 2606 OID 17080)
-- Name: messages_2025_10_09 messages_2025_10_09_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_10_09
    ADD CONSTRAINT messages_2025_10_09_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4055 (class 2606 OID 16875)
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- TOC entry 4052 (class 2606 OID 16848)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4084 (class 2606 OID 17902)
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- TOC entry 4032 (class 2606 OID 16517)
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- TOC entry 4086 (class 2606 OID 17912)
-- Name: iceberg_namespaces iceberg_namespaces_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_namespaces
    ADD CONSTRAINT iceberg_namespaces_pkey PRIMARY KEY (id);


--
-- TOC entry 4089 (class 2606 OID 17928)
-- Name: iceberg_tables iceberg_tables_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_pkey PRIMARY KEY (id);


--
-- TOC entry 4042 (class 2606 OID 16558)
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- TOC entry 4044 (class 2606 OID 16556)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 4040 (class 2606 OID 16534)
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- TOC entry 4082 (class 2606 OID 17857)
-- Name: prefixes prefixes_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT prefixes_pkey PRIMARY KEY (bucket_id, level, name);


--
-- TOC entry 4079 (class 2606 OID 17818)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- TOC entry 4077 (class 2606 OID 17803)
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- TOC entry 4048 (class 2606 OID 16771)
-- Name: hooks hooks_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: -
--

ALTER TABLE ONLY supabase_functions.hooks
    ADD CONSTRAINT hooks_pkey PRIMARY KEY (id);


--
-- TOC entry 4046 (class 2606 OID 16761)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: -
--

ALTER TABLE ONLY supabase_functions.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4027 (class 1259 OID 16495)
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- TOC entry 4001 (class 1259 OID 18000)
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4002 (class 1259 OID 18002)
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4003 (class 1259 OID 18003)
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4102 (class 1259 OID 18081)
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- TOC entry 4135 (class 1259 OID 18189)
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- TOC entry 4091 (class 1259 OID 18169)
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- TOC entry 4890 (class 0 OID 0)
-- Dependencies: 4091
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- TOC entry 4096 (class 1259 OID 17997)
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- TOC entry 4138 (class 1259 OID 18186)
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- TOC entry 4139 (class 1259 OID 18187)
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- TOC entry 4110 (class 1259 OID 18192)
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- TOC entry 4107 (class 1259 OID 18053)
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- TOC entry 4108 (class 1259 OID 18198)
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- TOC entry 4145 (class 1259 OID 18275)
-- Name: oauth_clients_client_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_client_id_idx ON auth.oauth_clients USING btree (client_id);


--
-- TOC entry 4148 (class 1259 OID 18276)
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- TOC entry 4142 (class 1259 OID 18245)
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- TOC entry 4143 (class 1259 OID 18244)
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- TOC entry 4144 (class 1259 OID 18246)
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- TOC entry 4004 (class 1259 OID 18004)
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4005 (class 1259 OID 18001)
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4014 (class 1259 OID 16478)
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- TOC entry 4015 (class 1259 OID 16479)
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- TOC entry 4016 (class 1259 OID 17996)
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- TOC entry 4019 (class 1259 OID 18083)
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- TOC entry 4022 (class 1259 OID 18188)
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- TOC entry 4129 (class 1259 OID 18125)
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- TOC entry 4130 (class 1259 OID 18190)
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- TOC entry 4131 (class 1259 OID 18140)
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- TOC entry 4134 (class 1259 OID 18139)
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- TOC entry 4097 (class 1259 OID 18191)
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- TOC entry 4100 (class 1259 OID 18082)
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- TOC entry 4121 (class 1259 OID 18107)
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- TOC entry 4124 (class 1259 OID 18106)
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- TOC entry 4119 (class 1259 OID 18092)
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- TOC entry 4120 (class 1259 OID 18254)
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- TOC entry 4109 (class 1259 OID 18251)
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- TOC entry 4101 (class 1259 OID 18080)
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- TOC entry 4006 (class 1259 OID 18160)
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- TOC entry 4891 (class 0 OID 0)
-- Dependencies: 4006
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- TOC entry 4007 (class 1259 OID 17998)
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- TOC entry 4008 (class 1259 OID 16468)
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- TOC entry 4009 (class 1259 OID 18215)
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- TOC entry 4171 (class 1259 OID 18387)
-- Name: idx_admins_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admins_profile_id ON public.admins USING btree (profile_id);


--
-- TOC entry 4238 (class 1259 OID 18669)
-- Name: idx_appointment_history_appointment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointment_history_appointment ON public.appointment_history USING btree (appointment_id);


--
-- TOC entry 4239 (class 1259 OID 18670)
-- Name: idx_appointment_history_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointment_history_created ON public.appointment_history USING btree (created_at);


--
-- TOC entry 4225 (class 1259 OID 18668)
-- Name: idx_appointments_assignment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_assignment ON public.appointments USING btree (assignment_id);


--
-- TOC entry 4226 (class 1259 OID 18665)
-- Name: idx_appointments_date_range; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_date_range ON public.appointments USING btree (appointment_date);


--
-- TOC entry 4227 (class 1259 OID 18663)
-- Name: idx_appointments_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_patient_id ON public.appointments USING btree (patient_id);


--
-- TOC entry 4228 (class 1259 OID 18666)
-- Name: idx_appointments_provider_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_provider_date ON public.appointments USING btree (provider_id, appointment_date);


--
-- TOC entry 4229 (class 1259 OID 18664)
-- Name: idx_appointments_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_provider_id ON public.appointments USING btree (provider_id);


--
-- TOC entry 4230 (class 1259 OID 18961)
-- Name: idx_appointments_reschedule_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_reschedule_source ON public.appointments USING btree (is_reschedule_source);


--
-- TOC entry 4231 (class 1259 OID 18959)
-- Name: idx_appointments_rescheduled_from; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_rescheduled_from ON public.appointments USING btree (rescheduled_from_id);


--
-- TOC entry 4232 (class 1259 OID 18960)
-- Name: idx_appointments_rescheduled_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_rescheduled_to ON public.appointments USING btree (rescheduled_to_id);


--
-- TOC entry 4233 (class 1259 OID 18667)
-- Name: idx_appointments_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_status ON public.appointments USING btree (status);


--
-- TOC entry 4242 (class 1259 OID 18798)
-- Name: idx_clinical_notes_appointment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_appointment ON public.clinical_notes USING btree (appointment_id);


--
-- TOC entry 4243 (class 1259 OID 18827)
-- Name: idx_clinical_notes_appointment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_appointment_id ON public.clinical_notes USING btree (appointment_id);


--
-- TOC entry 4244 (class 1259 OID 18801)
-- Name: idx_clinical_notes_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_created_at ON public.clinical_notes USING btree (created_at);


--
-- TOC entry 4245 (class 1259 OID 18799)
-- Name: idx_clinical_notes_patient; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_patient ON public.clinical_notes USING btree (patient_id);


--
-- TOC entry 4246 (class 1259 OID 18828)
-- Name: idx_clinical_notes_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_patient_id ON public.clinical_notes USING btree (patient_id);


--
-- TOC entry 4247 (class 1259 OID 18800)
-- Name: idx_clinical_notes_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_provider ON public.clinical_notes USING btree (provider_id);


--
-- TOC entry 4248 (class 1259 OID 18829)
-- Name: idx_clinical_notes_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_provider_id ON public.clinical_notes USING btree (provider_id);


--
-- TOC entry 4249 (class 1259 OID 18802)
-- Name: idx_clinical_notes_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_updated_at ON public.clinical_notes USING btree (updated_at);


--
-- TOC entry 4288 (class 1259 OID 19057)
-- Name: idx_faxes_approval_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_approval_id ON public.faxes USING btree (approval_id);


--
-- TOC entry 4289 (class 1259 OID 19061)
-- Name: idx_faxes_faxed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_faxed_at ON public.faxes USING btree (faxed_at);


--
-- TOC entry 4290 (class 1259 OID 19059)
-- Name: idx_faxes_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_patient_id ON public.faxes USING btree (patient_id);


--
-- TOC entry 4291 (class 1259 OID 19113)
-- Name: idx_faxes_patient_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_patient_profile_id ON public.faxes USING btree (patient_profile_id);


--
-- TOC entry 4292 (class 1259 OID 19058)
-- Name: idx_faxes_preference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_preference_id ON public.faxes USING btree (preference_id);


--
-- TOC entry 4293 (class 1259 OID 19060)
-- Name: idx_faxes_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_provider_id ON public.faxes USING btree (provider_id);


--
-- TOC entry 4294 (class 1259 OID 19112)
-- Name: idx_faxes_provider_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_provider_profile_id ON public.faxes USING btree (provider_profile_id);


--
-- TOC entry 4295 (class 1259 OID 19062)
-- Name: idx_faxes_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_faxes_status ON public.faxes USING btree (fax_status);


--
-- TOC entry 4196 (class 1259 OID 18526)
-- Name: idx_medication_approvals_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_approvals_provider_id ON public.medication_approvals USING btree (provider_id);


--
-- TOC entry 4197 (class 1259 OID 19111)
-- Name: idx_medication_approvals_provider_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_approvals_provider_profile_id ON public.medication_approvals USING btree (provider_profile_id);


--
-- TOC entry 4198 (class 1259 OID 18527)
-- Name: idx_medication_approvals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_approvals_status ON public.medication_approvals USING btree (status);


--
-- TOC entry 4199 (class 1259 OID 19116)
-- Name: idx_medication_approvals_supply_days; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_approvals_supply_days ON public.medication_approvals USING btree (supply_days);


--
-- TOC entry 4272 (class 1259 OID 18911)
-- Name: idx_medication_dosages_available; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_dosages_available ON public.medication_dosages USING btree (available);


--
-- TOC entry 4273 (class 1259 OID 18910)
-- Name: idx_medication_dosages_medication_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_dosages_medication_id ON public.medication_dosages USING btree (medication_id);


--
-- TOC entry 4274 (class 1259 OID 18912)
-- Name: idx_medication_dosages_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_dosages_sort_order ON public.medication_dosages USING btree (sort_order);


--
-- TOC entry 4202 (class 1259 OID 18530)
-- Name: idx_medication_orders_fulfillment_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_fulfillment_status ON public.medication_orders USING btree (fulfillment_status);


--
-- TOC entry 4203 (class 1259 OID 18559)
-- Name: idx_medication_orders_patient_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_patient_created ON public.medication_orders USING btree (patient_id, created_at DESC);


--
-- TOC entry 4204 (class 1259 OID 18528)
-- Name: idx_medication_orders_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_patient_id ON public.medication_orders USING btree (patient_id);


--
-- TOC entry 4205 (class 1259 OID 19115)
-- Name: idx_medication_orders_patient_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_patient_profile_id ON public.medication_orders USING btree (patient_profile_id);


--
-- TOC entry 4206 (class 1259 OID 18529)
-- Name: idx_medication_orders_payment_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_payment_status ON public.medication_orders USING btree (payment_status);


--
-- TOC entry 4207 (class 1259 OID 19114)
-- Name: idx_medication_orders_provider_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_provider_profile_id ON public.medication_orders USING btree (provider_profile_id);


--
-- TOC entry 4208 (class 1259 OID 18557)
-- Name: idx_medication_orders_sent_to_pharmacy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_sent_to_pharmacy ON public.medication_orders USING btree (sent_to_pharmacy);


--
-- TOC entry 4296 (class 1259 OID 19183)
-- Name: idx_medication_tracking_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_tracking_patient_id ON public.medication_tracking_entries USING btree (patient_id);


--
-- TOC entry 4297 (class 1259 OID 19184)
-- Name: idx_medication_tracking_preference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_tracking_preference_id ON public.medication_tracking_entries USING btree (medication_preference_id);


--
-- TOC entry 4298 (class 1259 OID 19185)
-- Name: idx_medication_tracking_taken_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_tracking_taken_date ON public.medication_tracking_entries USING btree (taken_date);


--
-- TOC entry 4181 (class 1259 OID 18523)
-- Name: idx_medications_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medications_active ON public.medications USING btree (active);


--
-- TOC entry 4182 (class 1259 OID 18522)
-- Name: idx_medications_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medications_category ON public.medications USING btree (category);


--
-- TOC entry 4172 (class 1259 OID 18390)
-- Name: idx_patient_assignments_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_assignments_active ON public.patient_assignments USING btree (active);


--
-- TOC entry 4173 (class 1259 OID 18388)
-- Name: idx_patient_assignments_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_assignments_patient_id ON public.patient_assignments USING btree (patient_id);


--
-- TOC entry 4174 (class 1259 OID 18389)
-- Name: idx_patient_assignments_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_assignments_provider_id ON public.patient_assignments USING btree (provider_id);


--
-- TOC entry 4303 (class 1259 OID 19214)
-- Name: idx_patient_health_metrics_metric_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_health_metrics_metric_type ON public.patient_health_metrics USING btree (metric_type);


--
-- TOC entry 4304 (class 1259 OID 19213)
-- Name: idx_patient_health_metrics_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_health_metrics_patient_id ON public.patient_health_metrics USING btree (patient_id);


--
-- TOC entry 4305 (class 1259 OID 19216)
-- Name: idx_patient_health_metrics_patient_metric_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_health_metrics_patient_metric_date ON public.patient_health_metrics USING btree (patient_id, metric_type, recorded_at);


--
-- TOC entry 4306 (class 1259 OID 19215)
-- Name: idx_patient_health_metrics_recorded_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_health_metrics_recorded_at ON public.patient_health_metrics USING btree (recorded_at);


--
-- TOC entry 4185 (class 1259 OID 19063)
-- Name: idx_patient_medication_preferences_faxed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_faxed ON public.patient_medication_preferences USING btree (faxed);


--
-- TOC entry 4186 (class 1259 OID 19064)
-- Name: idx_patient_medication_preferences_next_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_next_due ON public.patient_medication_preferences USING btree (next_prescription_due);


--
-- TOC entry 4187 (class 1259 OID 18524)
-- Name: idx_patient_medication_preferences_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_patient_id ON public.patient_medication_preferences USING btree (patient_id);


--
-- TOC entry 4188 (class 1259 OID 19141)
-- Name: idx_patient_medication_preferences_refill_requested; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_refill_requested ON public.patient_medication_preferences USING btree (refill_requested);


--
-- TOC entry 4189 (class 1259 OID 18525)
-- Name: idx_patient_medication_preferences_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_status ON public.patient_medication_preferences USING btree (status);


--
-- TOC entry 4190 (class 1259 OID 19130)
-- Name: idx_patient_medication_preferences_supply_days; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_supply_days ON public.patient_medication_preferences USING btree (supply_days);


--
-- TOC entry 4157 (class 1259 OID 18385)
-- Name: idx_patients_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patients_profile_id ON public.patients USING btree (profile_id);


--
-- TOC entry 4191 (class 1259 OID 19142)
-- Name: idx_preferences_provider_approval; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_preferences_provider_approval ON public.patient_medication_preferences USING btree (status, refill_requested) WHERE ((status = 'pending'::text) AND (refill_requested = true));


--
-- TOC entry 4151 (class 1259 OID 18384)
-- Name: idx_profiles_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_email ON public.profiles USING btree (email);


--
-- TOC entry 4152 (class 1259 OID 18383)
-- Name: idx_profiles_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_role ON public.profiles USING btree (role);


--
-- TOC entry 4217 (class 1259 OID 18662)
-- Name: idx_provider_overrides_date_range; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provider_overrides_date_range ON public.provider_availability_overrides USING btree (date);


--
-- TOC entry 4218 (class 1259 OID 18661)
-- Name: idx_provider_overrides_provider_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provider_overrides_provider_date ON public.provider_availability_overrides USING btree (provider_id, date);


--
-- TOC entry 4211 (class 1259 OID 18660)
-- Name: idx_provider_schedules_day_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provider_schedules_day_active ON public.provider_schedules USING btree (day_of_week, active);


--
-- TOC entry 4212 (class 1259 OID 18659)
-- Name: idx_provider_schedules_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provider_schedules_provider_id ON public.provider_schedules USING btree (provider_id);


--
-- TOC entry 4162 (class 1259 OID 18386)
-- Name: idx_providers_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_providers_profile_id ON public.providers USING btree (profile_id);


--
-- TOC entry 4279 (class 1259 OID 18942)
-- Name: idx_visit_addendums_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_addendums_created_at ON public.visit_addendums USING btree (created_at);


--
-- TOC entry 4280 (class 1259 OID 18941)
-- Name: idx_visit_addendums_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_addendums_provider_id ON public.visit_addendums USING btree (provider_id);


--
-- TOC entry 4281 (class 1259 OID 18940)
-- Name: idx_visit_addendums_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_addendums_visit_id ON public.visit_addendums USING btree (visit_id);


--
-- TOC entry 4261 (class 1259 OID 18808)
-- Name: idx_visit_interactions_appointment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_appointment ON public.visit_interactions USING btree (appointment_id);


--
-- TOC entry 4262 (class 1259 OID 18831)
-- Name: idx_visit_interactions_appointment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_appointment_id ON public.visit_interactions USING btree (appointment_id);


--
-- TOC entry 4263 (class 1259 OID 18807)
-- Name: idx_visit_interactions_clinical_note; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_clinical_note ON public.visit_interactions USING btree (clinical_note_id);


--
-- TOC entry 4264 (class 1259 OID 18830)
-- Name: idx_visit_interactions_clinical_note_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_clinical_note_id ON public.visit_interactions USING btree (clinical_note_id);


--
-- TOC entry 4265 (class 1259 OID 18810)
-- Name: idx_visit_interactions_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_created_at ON public.visit_interactions USING btree (created_at);


--
-- TOC entry 4266 (class 1259 OID 18832)
-- Name: idx_visit_interactions_medication_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_medication_id ON public.visit_interactions USING btree (medication_id);


--
-- TOC entry 4267 (class 1259 OID 18809)
-- Name: idx_visit_interactions_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_type ON public.visit_interactions USING btree (interaction_type);


--
-- TOC entry 4254 (class 1259 OID 18804)
-- Name: idx_visit_medication_adjustments_appointment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_appointment ON public.visit_medication_adjustments USING btree (appointment_id);


--
-- TOC entry 4255 (class 1259 OID 18803)
-- Name: idx_visit_medication_adjustments_clinical_note; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_clinical_note ON public.visit_medication_adjustments USING btree (clinical_note_id);


--
-- TOC entry 4256 (class 1259 OID 18806)
-- Name: idx_visit_medication_adjustments_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_created_at ON public.visit_medication_adjustments USING btree (created_at);


--
-- TOC entry 4257 (class 1259 OID 18805)
-- Name: idx_visit_medication_adjustments_preference; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_preference ON public.visit_medication_adjustments USING btree (preference_id);


--
-- TOC entry 4258 (class 1259 OID 19131)
-- Name: idx_visit_medication_adjustments_supply_days; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_supply_days ON public.visit_medication_adjustments USING btree (new_supply_days);


--
-- TOC entry 4053 (class 1259 OID 17022)
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- TOC entry 4057 (class 1259 OID 17023)
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4060 (class 1259 OID 17033)
-- Name: messages_2025_10_05_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_10_05_inserted_at_topic_idx ON realtime.messages_2025_10_05 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4063 (class 1259 OID 17045)
-- Name: messages_2025_10_06_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_10_06_inserted_at_topic_idx ON realtime.messages_2025_10_06 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4066 (class 1259 OID 17057)
-- Name: messages_2025_10_07_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_10_07_inserted_at_topic_idx ON realtime.messages_2025_10_07 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4069 (class 1259 OID 17069)
-- Name: messages_2025_10_08_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_10_08_inserted_at_topic_idx ON realtime.messages_2025_10_08 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4072 (class 1259 OID 17081)
-- Name: messages_2025_10_09_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_10_09_inserted_at_topic_idx ON realtime.messages_2025_10_09 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4056 (class 1259 OID 16924)
-- Name: subscription_subscription_id_entity_filters_key; Type: INDEX; Schema: realtime; Owner: -
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_key ON realtime.subscription USING btree (subscription_id, entity, filters);


--
-- TOC entry 4030 (class 1259 OID 16523)
-- Name: bname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- TOC entry 4033 (class 1259 OID 16545)
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- TOC entry 4087 (class 1259 OID 17918)
-- Name: idx_iceberg_namespaces_bucket_id; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX idx_iceberg_namespaces_bucket_id ON storage.iceberg_namespaces USING btree (bucket_id, name);


--
-- TOC entry 4090 (class 1259 OID 17939)
-- Name: idx_iceberg_tables_namespace_id; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX idx_iceberg_tables_namespace_id ON storage.iceberg_tables USING btree (namespace_id, name);


--
-- TOC entry 4075 (class 1259 OID 17829)
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- TOC entry 4034 (class 1259 OID 17875)
-- Name: idx_name_bucket_level_unique; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX idx_name_bucket_level_unique ON storage.objects USING btree (name COLLATE "C", bucket_id, level);


--
-- TOC entry 4035 (class 1259 OID 17794)
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- TOC entry 4036 (class 1259 OID 17877)
-- Name: idx_objects_lower_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_lower_name ON storage.objects USING btree ((path_tokens[level]), lower(name) text_pattern_ops, bucket_id, level);


--
-- TOC entry 4080 (class 1259 OID 17878)
-- Name: idx_prefixes_lower_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_prefixes_lower_name ON storage.prefixes USING btree (bucket_id, level, ((string_to_array(name, '/'::text))[level]), lower(name) text_pattern_ops);


--
-- TOC entry 4037 (class 1259 OID 16546)
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- TOC entry 4038 (class 1259 OID 17876)
-- Name: objects_bucket_id_level_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX objects_bucket_id_level_idx ON storage.objects USING btree (bucket_id, level, name COLLATE "C");


--
-- TOC entry 4049 (class 1259 OID 16773)
-- Name: supabase_functions_hooks_h_table_id_h_name_idx; Type: INDEX; Schema: supabase_functions; Owner: -
--

CREATE INDEX supabase_functions_hooks_h_table_id_h_name_idx ON supabase_functions.hooks USING btree (hook_table_id, hook_name);


--
-- TOC entry 4050 (class 1259 OID 16772)
-- Name: supabase_functions_hooks_request_id_idx; Type: INDEX; Schema: supabase_functions; Owner: -
--

CREATE INDEX supabase_functions_hooks_request_id_idx ON supabase_functions.hooks USING btree (request_id);


--
-- TOC entry 4309 (class 0 OID 0)
-- Name: messages_2025_10_05_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_05_inserted_at_topic_idx;


--
-- TOC entry 4310 (class 0 OID 0)
-- Name: messages_2025_10_05_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_05_pkey;


--
-- TOC entry 4311 (class 0 OID 0)
-- Name: messages_2025_10_06_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_06_inserted_at_topic_idx;


--
-- TOC entry 4312 (class 0 OID 0)
-- Name: messages_2025_10_06_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_06_pkey;


--
-- TOC entry 4313 (class 0 OID 0)
-- Name: messages_2025_10_07_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_07_inserted_at_topic_idx;


--
-- TOC entry 4314 (class 0 OID 0)
-- Name: messages_2025_10_07_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_07_pkey;


--
-- TOC entry 4315 (class 0 OID 0)
-- Name: messages_2025_10_08_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_08_inserted_at_topic_idx;


--
-- TOC entry 4316 (class 0 OID 0)
-- Name: messages_2025_10_08_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_08_pkey;


--
-- TOC entry 4317 (class 0 OID 0)
-- Name: messages_2025_10_09_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_09_inserted_at_topic_idx;


--
-- TOC entry 4318 (class 0 OID 0)
-- Name: messages_2025_10_09_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_09_pkey;


--
-- TOC entry 4384 (class 2620 OID 19023)
-- Name: users on_auth_user_created; Type: TRIGGER; Schema: auth; Owner: -
--

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();


--
-- TOC entry 4406 (class 2620 OID 18674)
-- Name: appointments appointment_audit_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER appointment_audit_trigger AFTER INSERT OR DELETE OR UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.log_appointment_changes();


--
-- TOC entry 4407 (class 2620 OID 18707)
-- Name: appointments appointment_business_rules_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER appointment_business_rules_trigger BEFORE INSERT OR UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.validate_appointment_business_rules();


--
-- TOC entry 4399 (class 2620 OID 19139)
-- Name: patient_medication_preferences calculate_next_due_on_supply_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER calculate_next_due_on_supply_update BEFORE UPDATE ON public.patient_medication_preferences FOR EACH ROW EXECUTE FUNCTION public.calculate_next_prescription_due();


--
-- TOC entry 4892 (class 0 OID 0)
-- Dependencies: 4399
-- Name: TRIGGER calculate_next_due_on_supply_update ON patient_medication_preferences; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TRIGGER calculate_next_due_on_supply_update ON public.patient_medication_preferences IS 'Calculates next_prescription_due when supply_days is updated with approved status';


--
-- TOC entry 4402 (class 2620 OID 19127)
-- Name: medication_orders check_approval_expiry_on_delivery_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER check_approval_expiry_on_delivery_trigger AFTER UPDATE ON public.medication_orders FOR EACH ROW EXECUTE FUNCTION public.check_approval_expiry_on_delivery();


--
-- TOC entry 4413 (class 2620 OID 19072)
-- Name: faxes create_order_on_fax_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER create_order_on_fax_trigger AFTER INSERT ON public.faxes FOR EACH ROW EXECUTE FUNCTION public.create_order_on_fax();


--
-- TOC entry 4893 (class 0 OID 0)
-- Dependencies: 4413
-- Name: TRIGGER create_order_on_fax_trigger ON faxes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TRIGGER create_order_on_fax_trigger ON public.faxes IS 'Trigger to create medication order when fax is sent';


--
-- TOC entry 4396 (class 2620 OID 18395)
-- Name: admins update_admins_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_admins_updated_at BEFORE UPDATE ON public.admins FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4408 (class 2620 OID 18672)
-- Name: appointments update_appointments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_appointments_updated_at BEFORE UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4409 (class 2620 OID 18813)
-- Name: clinical_notes update_clinical_note_editor_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_clinical_note_editor_trigger BEFORE UPDATE ON public.clinical_notes FOR EACH ROW EXECUTE FUNCTION public.update_clinical_note_editor();


--
-- TOC entry 4410 (class 2620 OID 18825)
-- Name: clinical_notes update_clinical_notes_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_clinical_notes_updated_at BEFORE UPDATE ON public.clinical_notes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4414 (class 2620 OID 19065)
-- Name: faxes update_faxes_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_faxes_updated_at BEFORE UPDATE ON public.faxes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4401 (class 2620 OID 18533)
-- Name: medication_approvals update_medication_approvals_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medication_approvals_updated_at BEFORE UPDATE ON public.medication_approvals FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4412 (class 2620 OID 18913)
-- Name: medication_dosages update_medication_dosages_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medication_dosages_updated_at BEFORE UPDATE ON public.medication_dosages FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4403 (class 2620 OID 18534)
-- Name: medication_orders update_medication_orders_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medication_orders_updated_at BEFORE UPDATE ON public.medication_orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4398 (class 2620 OID 18531)
-- Name: medications update_medications_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medications_updated_at BEFORE UPDATE ON public.medications FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4397 (class 2620 OID 18396)
-- Name: patient_assignments update_patient_assignments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patient_assignments_updated_at BEFORE UPDATE ON public.patient_assignments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4415 (class 2620 OID 19217)
-- Name: patient_health_metrics update_patient_health_metrics_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patient_health_metrics_updated_at BEFORE UPDATE ON public.patient_health_metrics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4400 (class 2620 OID 18532)
-- Name: patient_medication_preferences update_patient_medication_preferences_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patient_medication_preferences_updated_at BEFORE UPDATE ON public.patient_medication_preferences FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4394 (class 2620 OID 18393)
-- Name: patients update_patients_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patients_updated_at BEFORE UPDATE ON public.patients FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4411 (class 2620 OID 19133)
-- Name: visit_medication_adjustments update_preference_on_adjustment_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_preference_on_adjustment_trigger AFTER INSERT ON public.visit_medication_adjustments FOR EACH ROW EXECUTE FUNCTION public.update_preference_on_medication_adjustment();


--
-- TOC entry 4894 (class 0 OID 0)
-- Dependencies: 4411
-- Name: TRIGGER update_preference_on_adjustment_trigger ON visit_medication_adjustments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TRIGGER update_preference_on_adjustment_trigger ON public.visit_medication_adjustments IS 'Updates patient_medication_preferences when medication adjustments are approved, including supply_days and next_prescription_due calculation';


--
-- TOC entry 4404 (class 2620 OID 19068)
-- Name: medication_orders update_prescription_due_date_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_prescription_due_date_trigger AFTER UPDATE ON public.medication_orders FOR EACH ROW EXECUTE FUNCTION public.update_prescription_due_date();


--
-- TOC entry 4393 (class 2620 OID 18392)
-- Name: profiles update_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4405 (class 2620 OID 18671)
-- Name: provider_schedules update_provider_schedules_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_provider_schedules_updated_at BEFORE UPDATE ON public.provider_schedules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4395 (class 2620 OID 18394)
-- Name: providers update_providers_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_providers_updated_at BEFORE UPDATE ON public.providers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4390 (class 2620 OID 16880)
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: -
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- TOC entry 4385 (class 2620 OID 17885)
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- TOC entry 4386 (class 2620 OID 17873)
-- Name: objects objects_delete_delete_prefix; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER objects_delete_delete_prefix AFTER DELETE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- TOC entry 4387 (class 2620 OID 17871)
-- Name: objects objects_insert_create_prefix; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER objects_insert_create_prefix BEFORE INSERT ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.objects_insert_prefix_trigger();


--
-- TOC entry 4388 (class 2620 OID 17872)
-- Name: objects objects_update_create_prefix; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER objects_update_create_prefix BEFORE UPDATE ON storage.objects FOR EACH ROW WHEN (((new.name <> old.name) OR (new.bucket_id <> old.bucket_id))) EXECUTE FUNCTION storage.objects_update_prefix_trigger();


--
-- TOC entry 4391 (class 2620 OID 17881)
-- Name: prefixes prefixes_create_hierarchy; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER prefixes_create_hierarchy BEFORE INSERT ON storage.prefixes FOR EACH ROW WHEN ((pg_trigger_depth() < 1)) EXECUTE FUNCTION storage.prefixes_insert_trigger();


--
-- TOC entry 4392 (class 2620 OID 17870)
-- Name: prefixes prefixes_delete_hierarchy; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER prefixes_delete_hierarchy AFTER DELETE ON storage.prefixes FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- TOC entry 4389 (class 2620 OID 17782)
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- TOC entry 4328 (class 2606 OID 17984)
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4332 (class 2606 OID 18073)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4331 (class 2606 OID 18061)
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- TOC entry 4330 (class 2606 OID 18048)
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4337 (class 2606 OID 18239)
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4319 (class 2606 OID 18017)
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4334 (class 2606 OID 18120)
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4335 (class 2606 OID 18193)
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- TOC entry 4336 (class 2606 OID 18134)
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4329 (class 2606 OID 18012)
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4333 (class 2606 OID 18101)
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4341 (class 2606 OID 18352)
-- Name: admins admins_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4362 (class 2606 OID 18654)
-- Name: appointment_history appointment_history_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment_history
    ADD CONSTRAINT appointment_history_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4357 (class 2606 OID 18638)
-- Name: appointments appointments_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.patient_assignments(id);


--
-- TOC entry 4358 (class 2606 OID 18628)
-- Name: appointments appointments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4359 (class 2606 OID 18633)
-- Name: appointments appointments_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4360 (class 2606 OID 18949)
-- Name: appointments appointments_rescheduled_from_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_rescheduled_from_id_fkey FOREIGN KEY (rescheduled_from_id) REFERENCES public.appointments(id);


--
-- TOC entry 4361 (class 2606 OID 18954)
-- Name: appointments appointments_rescheduled_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_rescheduled_to_id_fkey FOREIGN KEY (rescheduled_to_id) REFERENCES public.appointments(id);


--
-- TOC entry 4371 (class 2606 OID 18866)
-- Name: auth_trigger_logs auth_trigger_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_trigger_logs
    ADD CONSTRAINT auth_trigger_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- TOC entry 4363 (class 2606 OID 18738)
-- Name: clinical_notes clinical_notes_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4364 (class 2606 OID 18743)
-- Name: clinical_notes clinical_notes_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4365 (class 2606 OID 18748)
-- Name: clinical_notes clinical_notes_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4375 (class 2606 OID 19037)
-- Name: faxes faxes_approval_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_approval_id_fkey FOREIGN KEY (approval_id) REFERENCES public.medication_approvals(id) ON DELETE CASCADE;


--
-- TOC entry 4376 (class 2606 OID 19047)
-- Name: faxes faxes_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4377 (class 2606 OID 19096)
-- Name: faxes faxes_patient_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_patient_profile_id_fkey FOREIGN KEY (patient_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4378 (class 2606 OID 19042)
-- Name: faxes faxes_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_preference_id_fkey FOREIGN KEY (preference_id) REFERENCES public.patient_medication_preferences(id) ON DELETE CASCADE;


--
-- TOC entry 4379 (class 2606 OID 19052)
-- Name: faxes faxes_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4380 (class 2606 OID 19091)
-- Name: faxes faxes_provider_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faxes
    ADD CONSTRAINT faxes_provider_profile_id_fkey FOREIGN KEY (provider_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4347 (class 2606 OID 18484)
-- Name: medication_approvals medication_approvals_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_preference_id_fkey FOREIGN KEY (preference_id) REFERENCES public.patient_medication_preferences(id) ON DELETE CASCADE;


--
-- TOC entry 4348 (class 2606 OID 18489)
-- Name: medication_approvals medication_approvals_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4349 (class 2606 OID 19086)
-- Name: medication_approvals medication_approvals_provider_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_provider_profile_id_fkey FOREIGN KEY (provider_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4372 (class 2606 OID 18905)
-- Name: medication_dosages medication_dosages_medication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_dosages
    ADD CONSTRAINT medication_dosages_medication_id_fkey FOREIGN KEY (medication_id) REFERENCES public.medications(id) ON DELETE CASCADE;


--
-- TOC entry 4350 (class 2606 OID 18507)
-- Name: medication_orders medication_orders_approval_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_approval_id_fkey FOREIGN KEY (approval_id) REFERENCES public.medication_approvals(id) ON DELETE CASCADE;


--
-- TOC entry 4351 (class 2606 OID 18517)
-- Name: medication_orders medication_orders_medication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_medication_id_fkey FOREIGN KEY (medication_id) REFERENCES public.medications(id) ON DELETE CASCADE;


--
-- TOC entry 4352 (class 2606 OID 18512)
-- Name: medication_orders medication_orders_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4353 (class 2606 OID 19106)
-- Name: medication_orders medication_orders_patient_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_patient_profile_id_fkey FOREIGN KEY (patient_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4354 (class 2606 OID 19101)
-- Name: medication_orders medication_orders_provider_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_provider_profile_id_fkey FOREIGN KEY (provider_profile_id) REFERENCES auth.users(id);


--
-- TOC entry 4381 (class 2606 OID 19178)
-- Name: medication_tracking_entries medication_tracking_entries_medication_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_tracking_entries
    ADD CONSTRAINT medication_tracking_entries_medication_preference_id_fkey FOREIGN KEY (medication_preference_id) REFERENCES public.patient_medication_preferences(id) ON DELETE CASCADE;


--
-- TOC entry 4382 (class 2606 OID 19173)
-- Name: medication_tracking_entries medication_tracking_entries_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_tracking_entries
    ADD CONSTRAINT medication_tracking_entries_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4342 (class 2606 OID 18373)
-- Name: patient_assignments patient_assignments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT patient_assignments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4343 (class 2606 OID 18378)
-- Name: patient_assignments patient_assignments_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT patient_assignments_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4383 (class 2606 OID 19208)
-- Name: patient_health_metrics patient_health_metrics_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_health_metrics
    ADD CONSTRAINT patient_health_metrics_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4344 (class 2606 OID 18914)
-- Name: patient_medication_preferences patient_medication_preferences_medication_dosage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_medication_dosage_id_fkey FOREIGN KEY (medication_dosage_id) REFERENCES public.medication_dosages(id) ON DELETE SET NULL;


--
-- TOC entry 4345 (class 2606 OID 18468)
-- Name: patient_medication_preferences patient_medication_preferences_medication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_medication_id_fkey FOREIGN KEY (medication_id) REFERENCES public.medications(id) ON DELETE CASCADE;


--
-- TOC entry 4346 (class 2606 OID 18463)
-- Name: patient_medication_preferences patient_medication_preferences_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4339 (class 2606 OID 18315)
-- Name: patients patients_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4338 (class 2606 OID 18297)
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4356 (class 2606 OID 18600)
-- Name: provider_availability_overrides provider_availability_overrides_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_availability_overrides
    ADD CONSTRAINT provider_availability_overrides_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4355 (class 2606 OID 18583)
-- Name: provider_schedules provider_schedules_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_schedules
    ADD CONSTRAINT provider_schedules_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4340 (class 2606 OID 18333)
-- Name: providers providers_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4373 (class 2606 OID 18935)
-- Name: visit_addendums visit_addendums_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_addendums
    ADD CONSTRAINT visit_addendums_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4374 (class 2606 OID 18930)
-- Name: visit_addendums visit_addendums_visit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_addendums
    ADD CONSTRAINT visit_addendums_visit_id_fkey FOREIGN KEY (visit_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4369 (class 2606 OID 18793)
-- Name: visit_interactions visit_interactions_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_interactions
    ADD CONSTRAINT visit_interactions_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4370 (class 2606 OID 18788)
-- Name: visit_interactions visit_interactions_clinical_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_interactions
    ADD CONSTRAINT visit_interactions_clinical_note_id_fkey FOREIGN KEY (clinical_note_id) REFERENCES public.clinical_notes(id) ON DELETE CASCADE;


--
-- TOC entry 4366 (class 2606 OID 18768)
-- Name: visit_medication_adjustments visit_medication_adjustments_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4367 (class 2606 OID 18763)
-- Name: visit_medication_adjustments visit_medication_adjustments_clinical_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_clinical_note_id_fkey FOREIGN KEY (clinical_note_id) REFERENCES public.clinical_notes(id) ON DELETE CASCADE;


--
-- TOC entry 4368 (class 2606 OID 18773)
-- Name: visit_medication_adjustments visit_medication_adjustments_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_preference_id_fkey FOREIGN KEY (preference_id) REFERENCES public.patient_medication_preferences(id) ON DELETE CASCADE;


--
-- TOC entry 4325 (class 2606 OID 17913)
-- Name: iceberg_namespaces iceberg_namespaces_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_namespaces
    ADD CONSTRAINT iceberg_namespaces_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_analytics(id) ON DELETE CASCADE;


--
-- TOC entry 4326 (class 2606 OID 17934)
-- Name: iceberg_tables iceberg_tables_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_analytics(id) ON DELETE CASCADE;


--
-- TOC entry 4327 (class 2606 OID 17929)
-- Name: iceberg_tables iceberg_tables_namespace_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES storage.iceberg_namespaces(id) ON DELETE CASCADE;


--
-- TOC entry 4320 (class 2606 OID 16535)
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4324 (class 2606 OID 17858)
-- Name: prefixes prefixes_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT "prefixes_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4321 (class 2606 OID 17804)
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4322 (class 2606 OID 17824)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4323 (class 2606 OID 17819)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- TOC entry 4570 (class 0 OID 16488)
-- Dependencies: 265
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4591 (class 0 OID 18179)
-- Dependencies: 313
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4582 (class 0 OID 17977)
-- Dependencies: 304
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4569 (class 0 OID 16481)
-- Dependencies: 264
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4586 (class 0 OID 18066)
-- Dependencies: 308
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4585 (class 0 OID 18054)
-- Dependencies: 307
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4584 (class 0 OID 18041)
-- Dependencies: 306
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4592 (class 0 OID 18229)
-- Dependencies: 314
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4568 (class 0 OID 16470)
-- Dependencies: 263
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4589 (class 0 OID 18108)
-- Dependencies: 311
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4590 (class 0 OID 18126)
-- Dependencies: 312
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4571 (class 0 OID 16496)
-- Dependencies: 266
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4583 (class 0 OID 18007)
-- Dependencies: 305
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4588 (class 0 OID 18093)
-- Dependencies: 310
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4587 (class 0 OID 18084)
-- Dependencies: 309
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4567 (class 0 OID 16458)
-- Dependencies: 261
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4689 (class 3256 OID 19079)
-- Name: medication_approvals Admins can manage all approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all approvals" ON public.medication_approvals USING ((auth.uid() IN ( SELECT a.profile_id
   FROM public.admins a
  WHERE (a.active = true))));


--
-- TOC entry 4622 (class 3256 OID 18413)
-- Name: patient_assignments Admins can manage all assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all assignments" ON public.patient_assignments USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4694 (class 3256 OID 19084)
-- Name: faxes Admins can manage all faxes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all faxes" ON public.faxes USING ((auth.uid() IN ( SELECT a.profile_id
   FROM public.admins a
  WHERE (a.active = true))));


--
-- TOC entry 4633 (class 3256 OID 18551)
-- Name: medication_orders Admins can manage all medication orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all medication orders" ON public.medication_orders USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4624 (class 3256 OID 18542)
-- Name: medications Admins can manage all medications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all medications" ON public.medications USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4614 (class 3256 OID 18405)
-- Name: patients Admins can manage all patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all patients" ON public.patients USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4617 (class 3256 OID 18408)
-- Name: providers Admins can manage all providers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all providers" ON public.providers USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4619 (class 3256 OID 18410)
-- Name: admins Admins can update own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can update own data" ON public.admins FOR UPDATE USING ((profile_id = auth.uid()));


--
-- TOC entry 4655 (class 3256 OID 18816)
-- Name: clinical_notes Admins can view all clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all clinical notes" ON public.clinical_notes FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))));


--
-- TOC entry 4631 (class 3256 OID 18549)
-- Name: medication_approvals Admins can view all medication approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all medication approvals" ON public.medication_approvals FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4627 (class 3256 OID 18545)
-- Name: patient_medication_preferences Admins can view all medication preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all medication preferences" ON public.patient_medication_preferences FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4610 (class 3256 OID 18401)
-- Name: profiles Admins can view all profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all profiles" ON public.profiles USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4673 (class 3256 OID 18946)
-- Name: visit_addendums Admins can view all visit addendums; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all visit addendums" ON public.visit_addendums FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))));


--
-- TOC entry 4658 (class 3256 OID 18821)
-- Name: visit_interactions Admins can view all visit interactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all visit interactions" ON public.visit_interactions FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))));


--
-- TOC entry 4618 (class 3256 OID 18409)
-- Name: admins Admins can view own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view own data" ON public.admins FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4670 (class 3256 OID 18872)
-- Name: auth_trigger_logs Allow admins to read logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow admins to read logs" ON public.auth_trigger_logs FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.profiles p
  WHERE ((p.id = auth.uid()) AND (p.role = 'admin'::text)))));


--
-- TOC entry 4666 (class 3256 OID 18853)
-- Name: profiles Allow auth trigger and service role; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow auth trigger and service role" ON public.profiles USING (true);


--
-- TOC entry 4668 (class 3256 OID 18855)
-- Name: provider_schedules Allow auth trigger and service role; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow auth trigger and service role" ON public.provider_schedules USING (true);


--
-- TOC entry 4667 (class 3256 OID 18854)
-- Name: providers Allow auth trigger and service role; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow auth trigger and service role" ON public.providers USING (true);


--
-- TOC entry 4669 (class 3256 OID 18871)
-- Name: auth_trigger_logs Allow trigger function to write logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow trigger function to write logs" ON public.auth_trigger_logs FOR INSERT WITH CHECK (true);


--
-- TOC entry 4623 (class 3256 OID 18541)
-- Name: medications Anyone can view active medications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can view active medications" ON public.medications FOR SELECT USING ((active = true));


--
-- TOC entry 4625 (class 3256 OID 18543)
-- Name: patient_medication_preferences Patients can manage own medication preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can manage own medication preferences" ON public.patient_medication_preferences USING ((EXISTS ( SELECT 1
   FROM public.patients
  WHERE ((patients.profile_id = auth.uid()) AND (patients.id = patient_medication_preferences.patient_id)))));


--
-- TOC entry 4612 (class 3256 OID 18403)
-- Name: patients Patients can update own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can update own data" ON public.patients FOR UPDATE USING ((profile_id = auth.uid()));


--
-- TOC entry 4620 (class 3256 OID 18411)
-- Name: patient_assignments Patients can view own assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view own assignments" ON public.patient_assignments FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.patients
  WHERE ((patients.id = patient_assignments.patient_id) AND (patients.profile_id = auth.uid())))));


--
-- TOC entry 4611 (class 3256 OID 18402)
-- Name: patients Patients can view own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view own data" ON public.patients FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4630 (class 3256 OID 18548)
-- Name: medication_approvals Patients can view own medication approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view own medication approvals" ON public.medication_approvals FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patients pt
     JOIN public.patient_medication_preferences pmp ON ((pt.id = pmp.patient_id)))
  WHERE ((pt.profile_id = auth.uid()) AND (pmp.id = medication_approvals.preference_id)))));


--
-- TOC entry 4632 (class 3256 OID 18550)
-- Name: medication_orders Patients can view own medication orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view own medication orders" ON public.medication_orders FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.patients
  WHERE ((patients.profile_id = auth.uid()) AND (patients.id = medication_orders.patient_id)))));


--
-- TOC entry 4654 (class 3256 OID 18815)
-- Name: clinical_notes Patients can view their clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their clinical notes" ON public.clinical_notes FOR SELECT TO authenticated USING ((patient_id IN ( SELECT p.id
   FROM (public.patients p
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4688 (class 3256 OID 19077)
-- Name: medication_approvals Patients can view their own approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their own approvals" ON public.medication_approvals FOR SELECT USING ((preference_id IN ( SELECT pmp.id
   FROM (public.patient_medication_preferences pmp
     JOIN public.patients pat ON ((pmp.patient_id = pat.id)))
  WHERE (pat.profile_id = auth.uid()))));


--
-- TOC entry 4895 (class 0 OID 0)
-- Dependencies: 4688
-- Name: POLICY "Patients can view their own approvals" ON medication_approvals; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Patients can view their own approvals" ON public.medication_approvals IS 'Allows patients to view approvals for their medication preferences';


--
-- TOC entry 4662 (class 3256 OID 18838)
-- Name: clinical_notes Patients can view their own clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their own clinical notes" ON public.clinical_notes FOR SELECT USING ((patient_id IN ( SELECT p.id
   FROM public.patients p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4693 (class 3256 OID 19083)
-- Name: faxes Patients can view their own faxes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their own faxes" ON public.faxes FOR SELECT USING ((patient_id IN ( SELECT pat.id
   FROM public.patients pat
  WHERE (pat.profile_id = auth.uid()))));


--
-- TOC entry 4896 (class 0 OID 0)
-- Dependencies: 4693
-- Name: POLICY "Patients can view their own faxes" ON faxes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Patients can view their own faxes" ON public.faxes IS 'Allows patients to view faxes related to their medications';


--
-- TOC entry 4665 (class 3256 OID 18843)
-- Name: visit_interactions Patients can view their own visit interactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their own visit interactions" ON public.visit_interactions FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4672 (class 3256 OID 18944)
-- Name: visit_addendums Patients can view their visit addendums; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their visit addendums" ON public.visit_addendums FOR SELECT TO authenticated USING ((visit_id IN ( SELECT a.id
   FROM ((public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4657 (class 3256 OID 18819)
-- Name: visit_interactions Patients can view their visit interactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their visit interactions" ON public.visit_interactions FOR SELECT TO authenticated USING ((appointment_id IN ( SELECT a.id
   FROM ((public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4686 (class 3256 OID 19074)
-- Name: medication_approvals Providers can create approvals for assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create approvals for assigned patients" ON public.medication_approvals FOR INSERT WITH CHECK (((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))) AND (preference_id IN ( SELECT pmp.id
   FROM ((public.patient_medication_preferences pmp
     JOIN public.patients pat ON ((pmp.patient_id = pat.id)))
     JOIN public.patient_assignments pa ON ((pat.id = pa.patient_id)))
  WHERE ((pa.provider_id IN ( SELECT p.id
           FROM public.providers p
          WHERE (p.profile_id = auth.uid()))) AND (pa.active = true))))));


--
-- TOC entry 4897 (class 0 OID 0)
-- Dependencies: 4686
-- Name: POLICY "Providers can create approvals for assigned patients" ON medication_approvals; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Providers can create approvals for assigned patients" ON public.medication_approvals IS 'Allows providers to create approvals only for patients assigned to them';


--
-- TOC entry 4660 (class 3256 OID 18836)
-- Name: clinical_notes Providers can create clinical notes for their patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create clinical notes for their patients" ON public.clinical_notes FOR INSERT WITH CHECK ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4691 (class 3256 OID 19081)
-- Name: faxes Providers can create faxes for assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create faxes for assigned patients" ON public.faxes FOR INSERT WITH CHECK (((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))) AND (patient_id IN ( SELECT pa.patient_id
   FROM public.patient_assignments pa
  WHERE ((pa.provider_id IN ( SELECT p.id
           FROM public.providers p
          WHERE (p.profile_id = auth.uid()))) AND (pa.active = true))))));


--
-- TOC entry 4898 (class 0 OID 0)
-- Dependencies: 4691
-- Name: POLICY "Providers can create faxes for assigned patients" ON faxes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Providers can create faxes for assigned patients" ON public.faxes IS 'Allows providers to create faxes only for patients assigned to them';


--
-- TOC entry 4635 (class 3256 OID 18562)
-- Name: medication_orders Providers can create orders for assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create orders for assigned patients" ON public.medication_orders FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = medication_orders.patient_id)))));


--
-- TOC entry 4664 (class 3256 OID 18841)
-- Name: visit_interactions Providers can create visit interactions for their appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create visit interactions for their appointments" ON public.visit_interactions FOR INSERT WITH CHECK ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.providers p ON ((a.provider_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4671 (class 3256 OID 18943)
-- Name: visit_addendums Providers can manage addendums for their patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can manage addendums for their patients" ON public.visit_addendums TO authenticated USING ((provider_id IN ( SELECT p.id
   FROM (public.providers p
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4628 (class 3256 OID 18546)
-- Name: medication_approvals Providers can manage approvals for assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can manage approvals for assigned patients" ON public.medication_approvals USING ((EXISTS ( SELECT 1
   FROM ((public.providers p
     JOIN public.patient_assignments pa ON ((p.id = pa.provider_id)))
     JOIN public.patient_medication_preferences pmp ON ((pa.patient_id = pmp.patient_id)))
  WHERE ((p.profile_id = auth.uid()) AND (pmp.id = medication_approvals.preference_id)))));


--
-- TOC entry 4653 (class 3256 OID 18814)
-- Name: clinical_notes Providers can manage clinical notes for their patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can manage clinical notes for their patients" ON public.clinical_notes TO authenticated USING ((provider_id IN ( SELECT p.id
   FROM (public.providers p
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4656 (class 3256 OID 18817)
-- Name: visit_interactions Providers can manage visit interactions for their patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can manage visit interactions for their patients" ON public.visit_interactions TO authenticated USING ((appointment_id IN ( SELECT a.id
   FROM ((public.appointments a
     JOIN public.providers p ON ((a.provider_id = p.id)))
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4636 (class 3256 OID 18563)
-- Name: medication_orders Providers can update assigned patient orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update assigned patient orders" ON public.medication_orders FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = medication_orders.patient_id)))));


--
-- TOC entry 4637 (class 3256 OID 18564)
-- Name: patient_medication_preferences Providers can update assigned patient preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update assigned patient preferences" ON public.patient_medication_preferences FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = patient_medication_preferences.patient_id)))));


--
-- TOC entry 4616 (class 3256 OID 18407)
-- Name: providers Providers can update own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update own data" ON public.providers FOR UPDATE USING ((profile_id = auth.uid()));


--
-- TOC entry 4687 (class 3256 OID 19076)
-- Name: medication_approvals Providers can update their own approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update their own approvals" ON public.medication_approvals FOR UPDATE USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4661 (class 3256 OID 18837)
-- Name: clinical_notes Providers can update their own clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update their own clinical notes" ON public.clinical_notes FOR UPDATE USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4692 (class 3256 OID 19082)
-- Name: faxes Providers can update their own faxes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update their own faxes" ON public.faxes FOR UPDATE USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4634 (class 3256 OID 18552)
-- Name: medication_orders Providers can view assigned patient orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view assigned patient orders" ON public.medication_orders FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = medication_orders.patient_id)))));


--
-- TOC entry 4626 (class 3256 OID 18544)
-- Name: patient_medication_preferences Providers can view assigned patient preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view assigned patient preferences" ON public.patient_medication_preferences FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = patient_medication_preferences.patient_id)))));


--
-- TOC entry 4700 (class 3256 OID 19190)
-- Name: medication_tracking_entries Providers can view assigned patient tracking entries; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view assigned patient tracking entries" ON public.medication_tracking_entries FOR SELECT USING ((patient_id IN ( SELECT pa.patient_id
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.active = true)))));


--
-- TOC entry 4613 (class 3256 OID 18404)
-- Name: patients Providers can view assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view assigned patients" ON public.patients FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((p.id = pa.provider_id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = patients.id) AND (pa.active = true)))));


--
-- TOC entry 4615 (class 3256 OID 18406)
-- Name: providers Providers can view own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view own data" ON public.providers FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4621 (class 3256 OID 18412)
-- Name: patient_assignments Providers can view their assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their assignments" ON public.patient_assignments FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.providers
  WHERE ((providers.id = patient_assignments.provider_id) AND (providers.profile_id = auth.uid())))));


--
-- TOC entry 4685 (class 3256 OID 19073)
-- Name: medication_approvals Providers can view their own approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their own approvals" ON public.medication_approvals FOR SELECT USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4899 (class 0 OID 0)
-- Dependencies: 4685
-- Name: POLICY "Providers can view their own approvals" ON medication_approvals; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Providers can view their own approvals" ON public.medication_approvals IS 'Allows providers to view medication approvals they created';


--
-- TOC entry 4659 (class 3256 OID 18835)
-- Name: clinical_notes Providers can view their own clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their own clinical notes" ON public.clinical_notes FOR SELECT USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4690 (class 3256 OID 19080)
-- Name: faxes Providers can view their own faxes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their own faxes" ON public.faxes FOR SELECT USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4900 (class 0 OID 0)
-- Dependencies: 4690
-- Name: POLICY "Providers can view their own faxes" ON faxes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Providers can view their own faxes" ON public.faxes IS 'Allows providers to view faxes they sent';


--
-- TOC entry 4695 (class 3256 OID 19085)
-- Name: providers Providers can view their own record; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their own record" ON public.providers FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4901 (class 0 OID 0)
-- Dependencies: 4695
-- Name: POLICY "Providers can view their own record" ON providers; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY "Providers can view their own record" ON public.providers IS 'Allows providers to view their own provider record when authenticated';


--
-- TOC entry 4663 (class 3256 OID 18839)
-- Name: visit_interactions Providers can view their own visit interactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their own visit interactions" ON public.visit_interactions FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.providers p ON ((a.provider_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4679 (class 3256 OID 19008)
-- Name: admins Service role can manage admins; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage admins" ON public.admins USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = profile_id)));


--
-- TOC entry 4684 (class 3256 OID 19021)
-- Name: admins Service role can manage all admins; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage all admins" ON public.admins USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4682 (class 3256 OID 19019)
-- Name: patients Service role can manage all patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage all patients" ON public.patients USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4681 (class 3256 OID 19018)
-- Name: profiles Service role can manage all profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage all profiles" ON public.profiles USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4683 (class 3256 OID 19020)
-- Name: providers Service role can manage all providers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage all providers" ON public.providers USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4677 (class 3256 OID 19006)
-- Name: patients Service role can manage patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage patients" ON public.patients USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = profile_id)));


--
-- TOC entry 4675 (class 3256 OID 19004)
-- Name: profiles Service role can manage profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage profiles" ON public.profiles USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = id)));


--
-- TOC entry 4678 (class 3256 OID 19007)
-- Name: providers Service role can manage providers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage providers" ON public.providers USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = profile_id)));


--
-- TOC entry 4680 (class 3256 OID 19009)
-- Name: provider_schedules Service role can manage schedules; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage schedules" ON public.provider_schedules USING ((current_setting('role'::text) = 'service_role'::text));


--
-- TOC entry 4704 (class 3256 OID 19221)
-- Name: patient_health_metrics Users can delete their own health metrics; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can delete their own health metrics" ON public.patient_health_metrics FOR DELETE USING ((patient_id IN ( SELECT patients.id
   FROM public.patients
  WHERE (patients.profile_id = auth.uid()))));


--
-- TOC entry 4699 (class 3256 OID 19189)
-- Name: medication_tracking_entries Users can delete their own tracking entries; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can delete their own tracking entries" ON public.medication_tracking_entries FOR DELETE USING ((patient_id IN ( SELECT patients.id
   FROM public.patients
  WHERE (patients.profile_id = auth.uid()))));


--
-- TOC entry 4702 (class 3256 OID 19219)
-- Name: patient_health_metrics Users can insert their own health metrics; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can insert their own health metrics" ON public.patient_health_metrics FOR INSERT WITH CHECK ((patient_id IN ( SELECT patients.id
   FROM public.patients
  WHERE (patients.profile_id = auth.uid()))));


--
-- TOC entry 4697 (class 3256 OID 19187)
-- Name: medication_tracking_entries Users can insert their own tracking entries; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can insert their own tracking entries" ON public.medication_tracking_entries FOR INSERT WITH CHECK ((patient_id IN ( SELECT patients.id
   FROM public.patients
  WHERE (patients.profile_id = auth.uid()))));


--
-- TOC entry 4674 (class 3256 OID 18998)
-- Name: profiles Users can update own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING ((auth.uid() = id));


--
-- TOC entry 4703 (class 3256 OID 19220)
-- Name: patient_health_metrics Users can update their own health metrics; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own health metrics" ON public.patient_health_metrics FOR UPDATE USING ((patient_id IN ( SELECT patients.id
   FROM public.patients
  WHERE (patients.profile_id = auth.uid()))));


--
-- TOC entry 4698 (class 3256 OID 19188)
-- Name: medication_tracking_entries Users can update their own tracking entries; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own tracking entries" ON public.medication_tracking_entries FOR UPDATE USING ((patient_id IN ( SELECT patients.id
   FROM public.patients
  WHERE (patients.profile_id = auth.uid()))));


--
-- TOC entry 4676 (class 3256 OID 19005)
-- Name: profiles Users can view own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING ((auth.uid() = id));


--
-- TOC entry 4701 (class 3256 OID 19218)
-- Name: patient_health_metrics Users can view their own health metrics; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own health metrics" ON public.patient_health_metrics FOR SELECT USING ((patient_id IN ( SELECT patients.id
   FROM public.patients
  WHERE (patients.profile_id = auth.uid()))));


--
-- TOC entry 4696 (class 3256 OID 19186)
-- Name: medication_tracking_entries Users can view their own tracking entries; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own tracking entries" ON public.medication_tracking_entries FOR SELECT USING ((patient_id IN ( SELECT patients.id
   FROM public.patients
  WHERE (patients.profile_id = auth.uid()))));


--
-- TOC entry 4649 (class 3256 OID 18699)
-- Name: appointments admin_full_appointments_access; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_full_appointments_access ON public.appointments USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4902 (class 0 OID 0)
-- Dependencies: 4649
-- Name: POLICY admin_full_appointments_access ON appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY admin_full_appointments_access ON public.appointments IS 'Admins have full access to all appointment data';


--
-- TOC entry 4651 (class 3256 OID 18704)
-- Name: appointment_history admin_view_all_appointment_history; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_view_all_appointment_history ON public.appointment_history USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4643 (class 3256 OID 18692)
-- Name: provider_availability_overrides admin_view_all_overrides; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_view_all_overrides ON public.provider_availability_overrides USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4629 (class 3256 OID 18688)
-- Name: provider_schedules admin_view_all_schedules; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_view_all_schedules ON public.provider_schedules USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4596 (class 0 OID 18338)
-- Dependencies: 320
-- Name: admins; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.admins ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4652 (class 3256 OID 18705)
-- Name: appointment_history appointment_history_readonly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY appointment_history_readonly ON public.appointment_history FOR INSERT WITH CHECK (false);


--
-- TOC entry 4903 (class 0 OID 0)
-- Dependencies: 4652
-- Name: POLICY appointment_history_readonly ON appointment_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY appointment_history_readonly ON public.appointment_history IS 'History is maintained by system triggers only';


--
-- TOC entry 4605 (class 0 OID 18857)
-- Dependencies: 337
-- Name: auth_trigger_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.auth_trigger_logs ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4603 (class 0 OID 18720)
-- Dependencies: 334
-- Name: clinical_notes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.clinical_notes ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4607 (class 0 OID 19024)
-- Dependencies: 341
-- Name: faxes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.faxes ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4599 (class 0 OID 18473)
-- Dependencies: 326
-- Name: medication_approvals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medication_approvals ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4600 (class 0 OID 18494)
-- Dependencies: 327
-- Name: medication_orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medication_orders ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4608 (class 0 OID 19161)
-- Dependencies: 343
-- Name: medication_tracking_entries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medication_tracking_entries ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4597 (class 0 OID 18436)
-- Dependencies: 324
-- Name: medications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medications ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4645 (class 3256 OID 18694)
-- Name: appointments patient_booking_restrictions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_booking_restrictions ON public.appointments FOR INSERT WITH CHECK (((patient_id IN ( SELECT p.id
   FROM public.patients p
  WHERE (p.profile_id = auth.uid()))) AND (provider_id IN ( SELECT pa.provider_id
   FROM (public.patient_assignments pa
     JOIN public.patients p ON ((pa.patient_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.active = true)))) AND ((appointment_date > CURRENT_DATE) OR ((appointment_date = CURRENT_DATE) AND (start_time > LOCALTIME))) AND (appointment_date <= (CURRENT_DATE + '90 days'::interval)) AND (booked_by = 'patient'::text)));


--
-- TOC entry 4904 (class 0 OID 0)
-- Dependencies: 4645
-- Name: POLICY patient_booking_restrictions ON appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY patient_booking_restrictions ON public.appointments IS 'Enforces business rules for patient appointment booking';


--
-- TOC entry 4609 (class 0 OID 19192)
-- Dependencies: 344
-- Name: patient_health_metrics; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.patient_health_metrics ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4598 (class 0 OID 18449)
-- Dependencies: 325
-- Name: patient_medication_preferences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.patient_medication_preferences ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4646 (class 3256 OID 18696)
-- Name: appointments patient_no_delete_appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_no_delete_appointments ON public.appointments FOR DELETE USING (false);


--
-- TOC entry 4644 (class 3256 OID 18693)
-- Name: appointments patient_own_appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_own_appointments ON public.appointments USING ((patient_id IN ( SELECT p.id
   FROM public.patients p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4905 (class 0 OID 0)
-- Dependencies: 4644
-- Name: POLICY patient_own_appointments ON appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY patient_own_appointments ON public.appointments IS 'Patients can only access their own appointments';


--
-- TOC entry 4650 (class 3256 OID 18700)
-- Name: appointment_history patient_view_own_appointment_history; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_view_own_appointment_history ON public.appointment_history FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4642 (class 3256 OID 18690)
-- Name: provider_availability_overrides patient_view_provider_overrides; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_view_provider_overrides ON public.provider_availability_overrides FOR SELECT USING ((provider_id IN ( SELECT pa.provider_id
   FROM (public.patient_assignments pa
     JOIN public.patients p ON ((pa.patient_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.active = true)))));


--
-- TOC entry 4639 (class 3256 OID 18686)
-- Name: provider_schedules patient_view_provider_schedules; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_view_provider_schedules ON public.provider_schedules FOR SELECT USING ((provider_id IN ( SELECT pa.provider_id
   FROM (public.patient_assignments pa
     JOIN public.patients p ON ((pa.patient_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.active = true)))));


--
-- TOC entry 4594 (class 0 OID 18302)
-- Dependencies: 318
-- Name: patients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4593 (class 0 OID 18285)
-- Dependencies: 317
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4602 (class 0 OID 18588)
-- Dependencies: 329
-- Name: provider_availability_overrides; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.provider_availability_overrides ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4648 (class 3256 OID 18698)
-- Name: appointments provider_no_delete_appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_no_delete_appointments ON public.appointments FOR DELETE USING (false);


--
-- TOC entry 4647 (class 3256 OID 18697)
-- Name: appointments provider_own_appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_own_appointments ON public.appointments USING ((provider_id IN ( SELECT pr.id
   FROM public.providers pr
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4906 (class 0 OID 0)
-- Dependencies: 4647
-- Name: POLICY provider_own_appointments ON appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY provider_own_appointments ON public.appointments IS 'Providers can manage appointments with their patients';


--
-- TOC entry 4641 (class 3256 OID 18689)
-- Name: provider_availability_overrides provider_own_overrides_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_own_overrides_policy ON public.provider_availability_overrides USING ((provider_id IN ( SELECT pr.id
   FROM public.providers pr
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4638 (class 3256 OID 18685)
-- Name: provider_schedules provider_own_schedule_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_own_schedule_policy ON public.provider_schedules USING ((provider_id IN ( SELECT pr.id
   FROM public.providers pr
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4601 (class 0 OID 18565)
-- Dependencies: 328
-- Name: provider_schedules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.provider_schedules ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4640 (class 3256 OID 18702)
-- Name: appointment_history provider_view_appointment_history; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_view_appointment_history ON public.appointment_history FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.providers pr ON ((a.provider_id = pr.id)))
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4595 (class 0 OID 18320)
-- Dependencies: 319
-- Name: providers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4606 (class 0 OID 18920)
-- Dependencies: 339
-- Name: visit_addendums; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.visit_addendums ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4604 (class 0 OID 18778)
-- Dependencies: 336
-- Name: visit_interactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.visit_interactions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4575 (class 0 OID 17007)
-- Dependencies: 292
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4572 (class 0 OID 16509)
-- Dependencies: 267
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4579 (class 0 OID 17892)
-- Dependencies: 301
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4580 (class 0 OID 17903)
-- Dependencies: 302
-- Name: iceberg_namespaces; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.iceberg_namespaces ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4581 (class 0 OID 17919)
-- Dependencies: 303
-- Name: iceberg_tables; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.iceberg_tables ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4574 (class 0 OID 16551)
-- Dependencies: 269
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4573 (class 0 OID 16524)
-- Dependencies: 268
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4578 (class 0 OID 17848)
-- Dependencies: 300
-- Name: prefixes; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.prefixes ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4576 (class 0 OID 17795)
-- Dependencies: 298
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4577 (class 0 OID 17809)
-- Dependencies: 299
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

-- Completed on 2025-10-13 08:41:55 UTC

--
-- PostgreSQL database dump complete
--

