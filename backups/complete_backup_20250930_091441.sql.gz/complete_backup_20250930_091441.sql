--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-09-30 16:14:41 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS postgres;
--
-- TOC entry 4653 (class 1262 OID 5)
-- Name: postgres; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = icu LOCALE = 'en_US.UTF-8' ICU_LOCALE = 'en-US';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4654 (class 0 OID 0)
-- Dependencies: 4653
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- TOC entry 4655 (class 0 OID 0)
-- Name: postgres; Type: DATABASE PROPERTIES; Schema: -; Owner: -
--

ALTER DATABASE postgres SET "app.settings.jwt_secret" TO 'super-secret-jwt-token-with-at-least-32-characters-long';
ALTER DATABASE postgres SET "app.settings.jwt_exp" TO '3600';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 34 (class 2615 OID 16457)
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- TOC entry 25 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- TOC entry 4656 (class 0 OID 0)
-- Dependencies: 25
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- TOC entry 22 (class 2615 OID 16605)
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA realtime;


--
-- TOC entry 35 (class 2615 OID 16505)
-- Name: storage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA storage;


--
-- TOC entry 16 (class 2615 OID 16750)
-- Name: supabase_functions; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA supabase_functions;


--
-- TOC entry 1247 (class 1247 OID 18016)
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


--
-- TOC entry 1271 (class 1247 OID 18157)
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


--
-- TOC entry 1244 (class 1247 OID 18010)
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


--
-- TOC entry 1241 (class 1247 OID 18005)
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


--
-- TOC entry 1283 (class 1247 OID 18238)
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


--
-- TOC entry 1277 (class 1247 OID 18199)
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


--
-- TOC entry 1187 (class 1247 OID 17496)
-- Name: action; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


--
-- TOC entry 1178 (class 1247 OID 17457)
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


--
-- TOC entry 1181 (class 1247 OID 17471)
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


--
-- TOC entry 1193 (class 1247 OID 17538)
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


--
-- TOC entry 1190 (class 1247 OID 17509)
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


--
-- TOC entry 1226 (class 1247 OID 17886)
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: -
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS'
);


--
-- TOC entry 500 (class 1255 OID 16503)
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


--
-- TOC entry 4657 (class 0 OID 0)
-- Dependencies: 500
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- TOC entry 387 (class 1255 OID 17987)
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


--
-- TOC entry 431 (class 1255 OID 16502)
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


--
-- TOC entry 4658 (class 0 OID 0)
-- Dependencies: 431
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- TOC entry 429 (class 1255 OID 16501)
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


--
-- TOC entry 4659 (class 0 OID 0)
-- Dependencies: 429
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- TOC entry 398 (class 1255 OID 18407)
-- Name: assign_patient_to_provider(uuid, uuid, text, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.assign_patient_to_provider(patient_profile_id uuid, provider_profile_id uuid, treatment_type_param text DEFAULT 'general_care'::text, is_primary_param boolean DEFAULT false) RETURNS TABLE(success boolean, message text, assignment_id uuid)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  patient_id_var UUID;
  provider_id_var UUID;
  assignment_id_var UUID;
BEGIN
  -- Get the patient ID from profile ID
  SELECT id INTO patient_id_var
  FROM patients
  WHERE profile_id = patient_profile_id;
  
  IF patient_id_var IS NULL THEN
    RETURN QUERY SELECT false, 'Patient not found', NULL::UUID;
    RETURN;
  END IF;
  
  -- Get the provider ID from profile ID
  SELECT id INTO provider_id_var
  FROM providers
  WHERE profile_id = provider_profile_id AND active = true;
  
  IF provider_id_var IS NULL THEN
    RETURN QUERY SELECT false, 'Provider not found or inactive', NULL::UUID;
    RETURN;
  END IF;
  
  -- Check if assignment already exists
  IF EXISTS (
    SELECT 1 FROM patient_assignments 
    WHERE patient_id = patient_id_var 
    AND provider_id = provider_id_var
    AND treatment_type = treatment_type_param
  ) THEN
    RETURN QUERY SELECT false, 'Patient is already assigned to this provider for this treatment type', NULL::UUID;
    RETURN;
  END IF;
  
  -- Create the assignment
  INSERT INTO patient_assignments (
    patient_id,
    provider_id,
    treatment_type,
    is_primary,
    assigned_date
  ) VALUES (
    patient_id_var,
    provider_id_var,
    treatment_type_param,
    is_primary_param,
    CURRENT_DATE
  ) RETURNING id INTO assignment_id_var;
  
  RETURN QUERY SELECT true, 'Patient successfully assigned to provider', assignment_id_var;
END;
$$;


--
-- TOC entry 374 (class 1255 OID 18660)
-- Name: book_appointment(uuid, uuid, date, time without time zone, text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text DEFAULT 'consultation'::text, p_booked_by text DEFAULT 'patient'::text, p_patient_notes text DEFAULT NULL::text) RETURNS TABLE(success boolean, appointment_id uuid, message text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  v_patient_id UUID;
  v_assignment_id UUID;
  v_duration_minutes INTEGER;
  v_end_time TIME;
  v_new_appointment_id UUID;
BEGIN
  -- Get patient ID from profile ID
  SELECT p.id INTO v_patient_id
  FROM patients p
  WHERE p.profile_id = p_patient_profile_id;
  
  IF v_patient_id IS NULL THEN
    success := false;
    appointment_id := NULL;
    message := 'Patient not found';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Verify patient-provider relationship exists
  SELECT pa.id INTO v_assignment_id
  FROM patient_assignments pa
  WHERE pa.patient_id = v_patient_id
    AND pa.provider_id = p_provider_id
    AND pa.active = true
  LIMIT 1;
  
  IF v_assignment_id IS NULL THEN
    success := false;
    appointment_id := NULL;
    message := 'No active assignment between patient and provider';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Check if the requested slot is available
  SELECT ps.slot_duration_minutes INTO v_duration_minutes
  FROM provider_schedules ps
  WHERE ps.provider_id = p_provider_id
    AND ps.day_of_week = EXTRACT(DOW FROM p_appointment_date)
    AND ps.start_time <= p_start_time
    AND ps.end_time >= p_start_time + INTERVAL '30 minutes' -- minimum slot
    AND ps.active = true
    AND (p_treatment_type = ANY(ps.treatment_types) OR array_length(ps.treatment_types, 1) IS NULL)
  LIMIT 1;
  
  IF v_duration_minutes IS NULL THEN
    success := false;
    appointment_id := NULL;
    message := 'Provider not available at requested time';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Calculate end time
  v_end_time := p_start_time + INTERVAL '1 minute' * v_duration_minutes;
  
  -- Check for scheduling conflicts
  IF EXISTS (
    SELECT 1 FROM appointments a
    WHERE a.provider_id = p_provider_id
      AND a.appointment_date = p_appointment_date
      AND a.start_time = p_start_time
      AND a.status NOT IN ('cancelled', 'no_show')
  ) THEN
    success := false;
    appointment_id := NULL;
    message := 'Time slot already booked';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Check for availability overrides
  IF EXISTS (
    SELECT 1 FROM provider_availability_overrides pao
    WHERE pao.provider_id = p_provider_id
      AND pao.date = p_appointment_date
      AND pao.available = false
      AND (pao.start_time IS NULL OR p_start_time >= pao.start_time)
      AND (pao.end_time IS NULL OR v_end_time <= pao.end_time)
  ) THEN
    success := false;
    appointment_id := NULL;
    message := 'Provider not available on requested date';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Create the appointment
  INSERT INTO appointments (
    patient_id,
    provider_id,
    assignment_id,
    appointment_date,
    start_time,
    end_time,
    duration_minutes,
    treatment_type,
    appointment_type,
    status,
    patient_notes,
    booked_by,
    booked_by_user_id
  ) VALUES (
    v_patient_id,
    p_provider_id,
    v_assignment_id,
    p_appointment_date,
    p_start_time,
    v_end_time,
    v_duration_minutes,
    p_treatment_type,
    p_appointment_type,
    'scheduled',
    p_patient_notes,
    p_booked_by,
    p_patient_profile_id
  ) RETURNING id INTO v_new_appointment_id;
  
  -- Return success
  success := true;
  appointment_id := v_new_appointment_id;
  message := 'Appointment booked successfully';
  RETURN NEXT;
  RETURN;
  
EXCEPTION
  WHEN OTHERS THEN
    success := false;
    appointment_id := NULL;
    message := 'Error booking appointment: ' || SQLERRM;
    RETURN NEXT;
    RETURN;
END;
$$;


--
-- TOC entry 4660 (class 0 OID 0)
-- Dependencies: 374
-- Name: FUNCTION book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text, p_booked_by text, p_patient_notes text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.book_appointment(p_patient_profile_id uuid, p_provider_id uuid, p_appointment_date date, p_start_time time without time zone, p_treatment_type text, p_appointment_type text, p_booked_by text, p_patient_notes text) IS 'Books a new appointment with full validation';


--
-- TOC entry 452 (class 1255 OID 18662)
-- Name: cancel_appointment(uuid, text, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text) RETURNS TABLE(success boolean, message text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  v_appointment RECORD;
BEGIN
  -- Get appointment details
  SELECT * INTO v_appointment
  FROM appointments
  WHERE id = p_appointment_id;
  
  IF NOT FOUND THEN
    success := false;
    message := 'Appointment not found';
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Check if appointment can be cancelled
  IF v_appointment.status NOT IN ('scheduled', 'confirmed') THEN
    success := false;
    message := 'Appointment cannot be cancelled in current status: ' || v_appointment.status;
    RETURN NEXT;
    RETURN;
  END IF;
  
  -- Update appointment status
  UPDATE appointments
  SET 
    status = 'cancelled',
    cancelled_at = NOW(),
    cancelled_by = p_cancelled_by,
    cancelled_by_user_id = p_cancelled_by_user_id,
    cancellation_reason = p_cancellation_reason
  WHERE id = p_appointment_id;
  
  success := true;
  message := 'Appointment cancelled successfully';
  RETURN NEXT;
  RETURN;
  
EXCEPTION
  WHEN OTHERS THEN
    success := false;
    message := 'Error cancelling appointment: ' || SQLERRM;
    RETURN NEXT;
    RETURN;
END;
$$;


--
-- TOC entry 4661 (class 0 OID 0)
-- Dependencies: 452
-- Name: FUNCTION cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.cancel_appointment(p_appointment_id uuid, p_cancelled_by text, p_cancelled_by_user_id uuid, p_cancellation_reason text) IS 'Cancels an existing appointment with audit trail';


--
-- TOC entry 455 (class 1255 OID 18859)
-- Name: check_auth_trigger_health(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_auth_trigger_health() RETURNS TABLE(metric text, value integer, status text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    auth_users_count INTEGER;
    profiles_count INTEGER;
    providers_count INTEGER;
    schedules_count INTEGER;
    recent_failures INTEGER;
    missing_profiles INTEGER;
BEGIN
    -- Get counts
    SELECT COUNT(*) INTO auth_users_count FROM auth.users;
    SELECT COUNT(*) INTO profiles_count FROM public.profiles;
    SELECT COUNT(*) INTO providers_count FROM public.providers;
    SELECT COUNT(*) INTO schedules_count FROM public.provider_schedules;
    
    -- Check for missing profiles
    SELECT COUNT(*) INTO missing_profiles 
    FROM auth.users u 
    LEFT JOIN public.profiles p ON u.id = p.id 
    WHERE p.id IS NULL;
    
    -- Check recent failures
    SELECT COUNT(*) INTO recent_failures 
    FROM public.auth_trigger_logs 
    WHERE success = false 
    AND created_at > NOW() - INTERVAL '1 hour';
    
    -- Return metrics
    RETURN QUERY VALUES 
        ('auth_users', auth_users_count, CASE WHEN auth_users_count > 0 THEN 'OK' ELSE 'EMPTY' END),
        ('profiles', profiles_count, CASE WHEN profiles_count >= auth_users_count THEN 'OK' ELSE 'MISSING' END),
        ('providers', providers_count, 'INFO'),
        ('schedules', schedules_count, 'INFO'),
        ('missing_profiles', missing_profiles, CASE WHEN missing_profiles = 0 THEN 'OK' ELSE 'NEEDS_REPAIR' END),
        ('recent_failures', recent_failures, CASE WHEN recent_failures = 0 THEN 'OK' ELSE 'ATTENTION' END);
END;
$$;


--
-- TOC entry 454 (class 1255 OID 18830)
-- Name: create_default_provider_schedule(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_default_provider_schedule() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RAISE LOG 'Provider schedule trigger fired for provider ID: %', NEW.id;
    RAISE NOTICE 'Provider schedule trigger fired for provider ID: %', NEW.id;
    
    -- Add Monday-Friday 9 AM to 5 PM schedule for new provider
    INSERT INTO provider_schedules (provider_id, day_of_week, start_time, end_time, active, created_at) VALUES
    (NEW.id, 1, '09:00:00', '17:00:00', true, now()), -- Monday
    (NEW.id, 2, '09:00:00', '17:00:00', true, now()), -- Tuesday
    (NEW.id, 3, '09:00:00', '17:00:00', true, now()), -- Wednesday
    (NEW.id, 4, '09:00:00', '17:00:00', true, now()), -- Thursday
    (NEW.id, 5, '09:00:00', '17:00:00', true, now()); -- Friday
    
    RAISE LOG 'Created default schedule for provider %', NEW.id;
    RAISE NOTICE 'Created default schedule for provider %', NEW.id;
    
    RETURN NEW;
EXCEPTION
    WHEN OTHERS THEN
        -- Log error but don't fail the provider creation
        RAISE LOG 'Error creating default schedule for provider %: %', NEW.id, SQLERRM;
        RAISE NOTICE 'Error creating default schedule for provider %: %', NEW.id, SQLERRM;
        RETURN NEW;
END;
$$;


--
-- TOC entry 351 (class 1255 OID 18663)
-- Name: get_admin_appointment_overview(date, date, uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_admin_appointment_overview(p_date_range_start date DEFAULT CURRENT_DATE, p_date_range_end date DEFAULT (CURRENT_DATE + '7 days'::interval), p_provider_id uuid DEFAULT NULL::uuid, p_patient_id uuid DEFAULT NULL::uuid) RETURNS TABLE(appointment_id uuid, patient_name text, provider_name text, appointment_date date, start_time time without time zone, end_time time without time zone, treatment_type text, appointment_type text, status text, last_updated timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    a.id as appointment_id,
    (patient_prof.first_name || ' ' || patient_prof.last_name) as patient_name,
    (provider_prof.first_name || ' ' || provider_prof.last_name) as provider_name,
    a.appointment_date,
    a.start_time,
    a.end_time,
    a.treatment_type,
    a.appointment_type,
    a.status,
    a.updated_at as last_updated
  FROM appointments a
  INNER JOIN patients p ON a.patient_id = p.id
  INNER JOIN profiles patient_prof ON p.profile_id = patient_prof.id
  INNER JOIN providers prov ON a.provider_id = prov.id
  INNER JOIN profiles provider_prof ON prov.profile_id = provider_prof.id
  WHERE a.appointment_date >= p_date_range_start
    AND a.appointment_date <= p_date_range_end
    AND (p_provider_id IS NULL OR a.provider_id = p_provider_id)
    AND (p_patient_id IS NULL OR a.patient_id = p_patient_id)
  ORDER BY a.appointment_date ASC, a.start_time ASC;
END;
$$;


--
-- TOC entry 4662 (class 0 OID 0)
-- Dependencies: 351
-- Name: FUNCTION get_admin_appointment_overview(p_date_range_start date, p_date_range_end date, p_provider_id uuid, p_patient_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_admin_appointment_overview(p_date_range_start date, p_date_range_end date, p_provider_id uuid, p_patient_id uuid) IS 'Admin dashboard view of appointments with filtering';


--
-- TOC entry 469 (class 1255 OID 18537)
-- Name: get_admin_fulfillment_queue(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_admin_fulfillment_queue() RETURNS TABLE(order_id uuid, patient_name text, medication_name text, quantity integer, total_amount numeric, payment_status text, fulfillment_status text, order_date timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    mo.id,
    CONCAT(pr.first_name, ' ', pr.last_name),
    m.name,
    mo.quantity,
    mo.total_amount,
    mo.payment_status,
    mo.fulfillment_status,
    mo.created_at
  FROM medication_orders mo
  JOIN medications m ON mo.medication_id = m.id
  JOIN patients pt ON mo.patient_id = pt.id
  JOIN profiles pr ON pt.profile_id = pr.id
  WHERE mo.fulfillment_status IN ('pending', 'processing')
  ORDER BY 
    CASE mo.payment_status 
      WHEN 'paid' THEN 1 
      ELSE 2 
    END,
    mo.created_at ASC;
END;
$$;


--
-- TOC entry 473 (class 1255 OID 18542)
-- Name: get_all_patients_for_admin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_all_patients_for_admin() RETURNS TABLE(patient_id uuid, profile_id uuid, first_name text, last_name text, email text, phone text, date_of_birth date, has_completed_intake boolean, assigned_providers text[], treatment_types text[], medications text[], created_at timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id as patient_id,
    p.profile_id,
    prof.first_name,
    prof.last_name,
    prof.email,
    p.phone,
    p.date_of_birth,
    p.has_completed_intake,
    COALESCE(
      ARRAY_AGG(
        DISTINCT CONCAT(prov_prof.first_name, ' ', prov_prof.last_name)
      ) FILTER (WHERE pa.id IS NOT NULL),
      '{}'::TEXT[]
    ) as assigned_providers,
    COALESCE(
      ARRAY_AGG(DISTINCT pa.treatment_type) FILTER (WHERE pa.treatment_type IS NOT NULL),
      '{}'::TEXT[]
    ) as treatment_types,
    COALESCE(
      ARRAY_AGG(DISTINCT m.name) FILTER (WHERE m.name IS NOT NULL),
      '{}'::TEXT[]
    ) as medications,
    p.created_at
  FROM patients p
  INNER JOIN profiles prof ON p.profile_id = prof.id
  LEFT JOIN patient_assignments pa ON p.profile_id = pa.patient_id
  LEFT JOIN providers prov ON pa.provider_id = prov.id
  LEFT JOIN profiles prov_prof ON prov.profile_id = prov_prof.id
  LEFT JOIN patient_medication_preferences pmp ON p.id = pmp.patient_id
  LEFT JOIN medications m ON pmp.medication_id = m.id
  WHERE prof.role = 'patient'  -- Only include users with patient role
  GROUP BY p.id, p.profile_id, prof.first_name, prof.last_name, prof.email, p.phone, p.date_of_birth, p.has_completed_intake, p.created_at
  ORDER BY prof.first_name, prof.last_name;
END;
$$;


--
-- TOC entry 419 (class 1255 OID 18543)
-- Name: get_assigned_patients_for_provider(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_assigned_patients_for_provider(provider_profile_id uuid) RETURNS TABLE(patient_id uuid, profile_id uuid, first_name text, last_name text, email text, phone text, date_of_birth date, treatment_type text, assigned_date date, is_primary boolean, has_completed_intake boolean, created_at timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id as patient_id,
    p.profile_id,
    prof.first_name,
    prof.last_name,
    prof.email,
    p.phone,
    p.date_of_birth,
    pa.treatment_type,
    pa.assigned_date::DATE,
    pa.is_primary,
    p.has_completed_intake,
    p.created_at
  FROM patients p
  INNER JOIN profiles prof ON p.profile_id = prof.id
  INNER JOIN patient_assignments pa ON p.id = pa.patient_id  -- Fixed: was p.profile_id = pa.patient_id
  INNER JOIN providers prov ON pa.provider_id = prov.id
  WHERE prov.profile_id = provider_profile_id
  ORDER BY pa.assigned_date DESC, prof.first_name, prof.last_name;
END;
$$;


--
-- TOC entry 436 (class 1255 OID 18988)
-- Name: get_available_slots_for_provider(uuid, date, date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text DEFAULT NULL::text) RETURNS TABLE(slot_date date, slot_start_time time without time zone, slot_end_time time without time zone, duration_minutes integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY
  WITH RECURSIVE date_series AS (
    SELECT p_start_date AS date
    UNION ALL
    SELECT date + 1
    FROM date_series
    WHERE date < p_end_date
  ),
  provider_daily_schedule AS (
    SELECT 
      ds.date,
      ps.start_time,
      ps.end_time,
      ps.slot_duration_minutes,
      ps.treatment_types
    FROM date_series ds
    CROSS JOIN provider_schedules ps
    WHERE ps.provider_id = p_provider_id
      AND ps.active = true
      AND ps.day_of_week = EXTRACT(DOW FROM ds.date)
      AND (
        p_treatment_type IS NULL 
        OR array_length(ps.treatment_types, 1) IS NULL 
        OR p_treatment_type = ANY(ps.treatment_types)
      )
  ),
  time_slots AS (
    SELECT 
      pds.date,
      slot_time::TIME AS start_time,
      (slot_time + (pds.slot_duration_minutes || ' minutes')::INTERVAL)::TIME AS end_time,
      pds.slot_duration_minutes
    FROM provider_daily_schedule pds
    CROSS JOIN LATERAL generate_series(
      pds.date + pds.start_time,
      pds.date + pds.end_time - (pds.slot_duration_minutes || ' minutes')::INTERVAL,
      (pds.slot_duration_minutes || ' minutes')::INTERVAL
    ) AS slot_time
  )
  SELECT 
    ts.date AS slot_date,
    ts.start_time AS slot_start_time,
    ts.end_time AS slot_end_time,
    ts.slot_duration_minutes AS duration_minutes
  FROM time_slots ts
  LEFT JOIN appointments a ON (
    a.provider_id = p_provider_id
    AND a.appointment_date = ts.date
    AND a.start_time = ts.start_time
    AND a.status IN ('scheduled', 'confirmed')
    AND (a.is_reschedule_source IS NULL OR a.is_reschedule_source = false)
  )
  WHERE a.id IS NULL  -- Only return slots that don't have existing appointments
  ORDER BY ts.date, ts.start_time;
END;
$$;


--
-- TOC entry 4663 (class 0 OID 0)
-- Dependencies: 436
-- Name: FUNCTION get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_available_slots_for_provider(p_provider_id uuid, p_start_date date, p_end_date date, p_treatment_type text) IS 'Returns available appointment slots for a provider excluding rescheduled appointments';


--
-- TOC entry 353 (class 1255 OID 18659)
-- Name: get_patient_appointments(uuid, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean DEFAULT false) RETURNS TABLE(appointment_id uuid, provider_name text, provider_specialty text, appointment_date date, start_time time without time zone, end_time time without time zone, treatment_type text, appointment_type text, status text, patient_notes text, provider_notes text, can_cancel boolean, can_reschedule boolean, created_at timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    a.id as appointment_id,
    (prof.first_name || ' ' || prof.last_name) as provider_name,
    prov.specialty as provider_specialty,
    a.appointment_date,
    a.start_time,
    a.end_time,
    a.treatment_type,
    a.appointment_type,
    a.status,
    a.patient_notes,
    a.provider_notes,
    -- Can cancel if appointment is scheduled/confirmed and at least 24 hours away
    CASE 
      WHEN a.status IN ('scheduled', 'confirmed') 
        AND (a.appointment_date > CURRENT_DATE + INTERVAL '1 day' 
             OR (a.appointment_date = CURRENT_DATE + INTERVAL '1 day' AND a.start_time > LOCALTIME))
      THEN true
      ELSE false
    END as can_cancel,
    -- Can reschedule if appointment is scheduled/confirmed and at least 48 hours away
    CASE 
      WHEN a.status IN ('scheduled', 'confirmed') 
        AND (a.appointment_date > CURRENT_DATE + INTERVAL '2 days'
             OR (a.appointment_date = CURRENT_DATE + INTERVAL '2 days' AND a.start_time > LOCALTIME))
      THEN true
      ELSE false
    END as can_reschedule,
    a.created_at
  FROM appointments a
  INNER JOIN patients p ON a.patient_id = p.id
  INNER JOIN providers prov ON a.provider_id = prov.id
  INNER JOIN profiles prof ON prov.profile_id = prof.id
  WHERE p.profile_id = p_patient_profile_id
    AND (p_include_past = true OR a.appointment_date >= CURRENT_DATE)
  ORDER BY a.appointment_date ASC, a.start_time ASC;
END;
$$;


--
-- TOC entry 4664 (class 0 OID 0)
-- Dependencies: 353
-- Name: FUNCTION get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_patient_appointments(p_patient_profile_id uuid, p_include_past boolean) IS 'Gets all appointments for a patient with cancellation/reschedule permissions';


--
-- TOC entry 483 (class 1255 OID 18535)
-- Name: get_patient_medication_overview(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_patient_medication_overview(patient_uuid uuid) RETURNS TABLE(medication_name text, category text, preference_status text, approval_status text, order_status text, payment_status text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    m.name,
    m.category,
    pmp.status as preference_status,
    COALESCE(ma.status, 'no_review') as approval_status,
    COALESCE(mo.fulfillment_status, 'no_order') as order_status,
    COALESCE(mo.payment_status, 'no_payment') as payment_status
  FROM patient_medication_preferences pmp
  JOIN medications m ON pmp.medication_id = m.id
  LEFT JOIN medication_approvals ma ON pmp.id = ma.preference_id
  LEFT JOIN medication_orders mo ON ma.id = mo.approval_id
  WHERE pmp.patient_id = patient_uuid
  ORDER BY pmp.created_at DESC;
END;
$$;


--
-- TOC entry 439 (class 1255 OID 18540)
-- Name: get_patient_medications_detailed(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_patient_medications_detailed(patient_uuid uuid) RETURNS TABLE(medication_id uuid, medication_name text, dosage text, supply text, status text, last_payment_date timestamp with time zone, sent_to_pharmacy_date timestamp with time zone, shipped_date timestamp with time zone, tracking_number text, order_id uuid)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        m.id as medication_id,
        m.name as medication_name,
        CONCAT(m.strength, ' ', m.dosage_form) as dosage,
        CASE 
            WHEN mo.quantity > 1 THEN CONCAT(mo.quantity::TEXT, ' units')
            ELSE '30 day supply'
        END as supply,
        mo.fulfillment_status as status,
        mo.payment_date as last_payment_date,
        mo.sent_to_pharmacy as sent_to_pharmacy_date,
        mo.shipped_date as shipped_date,
        mo.tracking_number as tracking_number,
        mo.id as order_id
    FROM medication_orders mo
    JOIN medications m ON mo.medication_id = m.id
    JOIN medication_approvals ma ON mo.approval_id = ma.id
    JOIN patient_medication_preferences pmp ON ma.preference_id = pmp.id
    WHERE mo.patient_id = patient_uuid
    AND pmp.status = 'approved'
    AND ma.status = 'approved'
    ORDER BY mo.created_at DESC;
END;
$$;


--
-- TOC entry 355 (class 1255 OID 18403)
-- Name: get_provider_by_profile_id(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_provider_by_profile_id(provider_profile_id uuid) RETURNS TABLE(provider_id uuid, profile_id uuid, first_name text, last_name text, email text, specialty text, license_number text, phone text, active boolean)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    prov.id as provider_id,
    prov.profile_id,
    prof.first_name,
    prof.last_name,
    prof.email,
    prov.specialty,
    prov.license_number,
    prov.phone,
    prov.active
  FROM providers prov
  INNER JOIN profiles prof ON prov.profile_id = prof.id
  WHERE prov.profile_id = provider_profile_id
  AND prov.active = true;
END;
$$;


--
-- TOC entry 352 (class 1255 OID 18536)
-- Name: get_provider_pending_approvals(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_provider_pending_approvals(provider_uuid uuid) RETURNS TABLE(preference_id uuid, patient_name text, medication_name text, preferred_dosage text, frequency text, patient_notes text, requested_date timestamp with time zone)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    pmp.id,
    CONCAT(pr.first_name, ' ', pr.last_name),
    m.name,
    pmp.preferred_dosage,
    pmp.frequency,
    pmp.notes,
    pmp.requested_date
  FROM patient_medication_preferences pmp
  JOIN medications m ON pmp.medication_id = m.id
  JOIN patients pt ON pmp.patient_id = pt.id
  JOIN profiles pr ON pt.profile_id = pr.id
  JOIN patient_assignments pa ON pt.id = pa.patient_id
  JOIN providers prov ON pa.provider_id = prov.id
  LEFT JOIN medication_approvals ma ON pmp.id = ma.preference_id
  WHERE prov.profile_id = provider_uuid
  AND pmp.status = 'pending'
  AND ma.id IS NULL -- No approval exists yet
  ORDER BY pmp.requested_date ASC;
END;
$$;


--
-- TOC entry 491 (class 1255 OID 18396)
-- Name: get_user_role(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_user_role(user_id uuid DEFAULT auth.uid()) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN (
    SELECT role 
    FROM profiles 
    WHERE id = user_id
  );
END;
$$;


--
-- TOC entry 444 (class 1255 OID 19022)
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    user_role TEXT;
    first_name TEXT;
    last_name TEXT;
    phone_val TEXT;
    specialty_val TEXT;
    license_number_val TEXT;
    new_provider_id UUID;
BEGIN
    -- Extract data from raw_user_meta_data only
    user_role := COALESCE(NEW.raw_user_meta_data->>'role', 'patient');
    first_name := COALESCE(
        NEW.raw_user_meta_data->>'first_name',
        NEW.raw_user_meta_data->>'firstName', 
        'User'
    );
    last_name := COALESCE(
        NEW.raw_user_meta_data->>'last_name',
        NEW.raw_user_meta_data->>'lastName', 
        'Unknown'
    );
    phone_val := NEW.raw_user_meta_data->>'phone';
    specialty_val := NEW.raw_user_meta_data->>'specialty';
    license_number_val := COALESCE(
        NEW.raw_user_meta_data->>'license_number',
        NEW.raw_user_meta_data->>'licenseNumber'
    );

    -- Create profile first with explicit schema reference
    INSERT INTO public.profiles (id, email, first_name, last_name, role, created_at, updated_at)
    VALUES (NEW.id, NEW.email, first_name, last_name, user_role, NOW(), NOW());

    -- Create role-specific records with explicit schema references
    IF user_role = 'patient' THEN
        INSERT INTO public.patients (profile_id, phone, has_completed_intake, created_at, updated_at)
        VALUES (NEW.id, phone_val, false, NOW(), NOW());

    ELSIF user_role = 'provider' THEN
        -- Create provider record and capture the ID for schedule creation
        INSERT INTO public.providers (profile_id, specialty, license_number, phone, active, created_at, updated_at)
        VALUES (NEW.id, specialty_val, license_number_val, phone_val, true, NOW(), NOW())
        RETURNING id INTO new_provider_id;

        -- Create default provider schedule (Monday-Friday, 9 AM - 5 PM)
        INSERT INTO public.provider_schedules (provider_id, day_of_week, start_time, end_time, treatment_types, active, created_at, updated_at)
        VALUES
            (new_provider_id, 1, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 2, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 3, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 4, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW()),
            (new_provider_id, 5, '09:00:00', '17:00:00', ARRAY['weight_loss', 'mens_health'], true, NOW(), NOW());

    ELSIF user_role = 'admin' THEN
        INSERT INTO public.admins (profile_id, permissions, active, created_at, updated_at)
        VALUES (NEW.id, ARRAY['dashboard', 'patients', 'providers', 'assignments'], true, NOW(), NOW());
    END IF;

    RETURN NEW;
EXCEPTION
    WHEN OTHERS THEN
        RAISE LOG 'Error in handle_new_user trigger for user %: % - %', NEW.id, SQLSTATE, SQLERRM;
        RAISE;
END;
$$;


--
-- TOC entry 486 (class 1255 OID 18655)
-- Name: log_appointment_changes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.log_appointment_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Insert into appointment_history
  INSERT INTO appointment_history (
    appointment_id,
    action,
    performed_by,
    performed_by_user_id,
    old_values,
    new_values,
    reason
  ) VALUES (
    COALESCE(NEW.id, OLD.id),
    CASE 
      WHEN TG_OP = 'INSERT' THEN 'created'
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'cancelled' AND OLD.status != 'cancelled' THEN 'cancelled'
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'completed' AND OLD.status != 'completed' THEN 'completed'  
      WHEN TG_OP = 'UPDATE' AND (NEW.appointment_date != OLD.appointment_date OR NEW.start_time != OLD.start_time) THEN 'rescheduled'
      WHEN TG_OP = 'UPDATE' THEN 'updated'
      WHEN TG_OP = 'DELETE' THEN 'deleted'
    END,
    COALESCE(
      current_setting('app.current_user_role', true),
      'system'
    ),
    CASE 
      WHEN current_setting('app.current_user_id', true) != '' 
      THEN current_setting('app.current_user_id', true)::UUID
      ELSE NULL
    END,
    CASE WHEN TG_OP != 'INSERT' THEN to_jsonb(OLD) ELSE NULL END,
    CASE WHEN TG_OP != 'DELETE' THEN to_jsonb(NEW) ELSE NULL END,
    CASE 
      WHEN TG_OP = 'UPDATE' AND NEW.status = 'cancelled' THEN NEW.cancellation_reason
      ELSE NULL
    END
  );
  
  RETURN COALESCE(NEW, OLD);
END;
$$;


--
-- TOC entry 359 (class 1255 OID 18858)
-- Name: repair_missing_profiles(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.repair_missing_profiles() RETURNS TABLE(user_id uuid, action_taken text, success boolean, error_message text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    user_rec RECORD;
    new_provider_id UUID;
    schedule_count INTEGER;
BEGIN
    -- Find users without profiles
    FOR user_rec IN (
        SELECT u.id, u.email, u.created_at, u.raw_user_meta_data
        FROM auth.users u
        LEFT JOIN public.profiles p ON u.id = p.id
        WHERE p.id IS NULL
        ORDER BY u.created_at DESC
    ) LOOP
        BEGIN
            -- Extract role and create profile
            DECLARE
                user_role TEXT := COALESCE(user_rec.raw_user_meta_data->>'role', 'patient');
                first_name_val TEXT := COALESCE(
                    user_rec.raw_user_meta_data->>'firstName',
                    user_rec.raw_user_meta_data->>'first_name',
                    split_part(user_rec.email, '@', 1)
                );
                last_name_val TEXT := COALESCE(
                    user_rec.raw_user_meta_data->>'lastName',
                    user_rec.raw_user_meta_data->>'last_name',
                    'User'
                );
            BEGIN
                -- Create profile
                INSERT INTO public.profiles (id, email, role, first_name, last_name, created_at)
                VALUES (user_rec.id, user_rec.email, user_role, first_name_val, last_name_val, user_rec.created_at);
                
                -- Create role-specific records
                IF user_role = 'provider' THEN
                    INSERT INTO public.providers (profile_id, specialty, license_number, active, created_at)
                    VALUES (user_rec.id, 'General Practice', 'REPAIRED', true, user_rec.created_at)
                    RETURNING id INTO new_provider_id;
                    
                    -- Create schedules
                    INSERT INTO public.provider_schedules (provider_id, day_of_week, start_time, end_time, active, created_at)
                    SELECT new_provider_id, day_num, '09:00:00'::TIME, '17:00:00'::TIME, true, user_rec.created_at
                    FROM generate_series(1, 5) AS day_num;
                    
                    GET DIAGNOSTICS schedule_count = ROW_COUNT;
                    
                    RETURN QUERY SELECT 
                        user_rec.id,
                        format('Created profile, provider, and %s schedules', schedule_count),
                        true,
                        NULL::TEXT;
                        
                ELSIF user_role = 'patient' THEN
                    INSERT INTO public.patients (profile_id, has_completed_intake, created_at)
                    VALUES (user_rec.id, false, user_rec.created_at);
                    
                    RETURN QUERY SELECT 
                        user_rec.id,
                        'Created profile and patient record',
                        true,
                        NULL::TEXT;
                        
                ELSIF user_role = 'admin' THEN
                    INSERT INTO public.admins (profile_id, permissions, active, created_at)
                    VALUES (user_rec.id, ARRAY['dashboard', 'patients', 'providers'], true, user_rec.created_at);
                    
                    RETURN QUERY SELECT 
                        user_rec.id,
                        'Created profile and admin record',
                        true,
                        NULL::TEXT;
                ELSE
                    RETURN QUERY SELECT 
                        user_rec.id,
                        'Created profile only',
                        true,
                        NULL::TEXT;
                END IF;
                
            EXCEPTION WHEN OTHERS THEN
                RETURN QUERY SELECT 
                    user_rec.id,
                    'Failed to repair',
                    false,
                    SQLERRM;
            END;
        END;
    END LOOP;
END;
$$;


--
-- TOC entry 378 (class 1255 OID 18962)
-- Name: reschedule_appointment(uuid, date, time without time zone, text, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text DEFAULT 'patient'::text, p_rescheduled_by_user_id uuid DEFAULT NULL::uuid, p_reason text DEFAULT NULL::text) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_old_appointment appointments%ROWTYPE;
  v_new_appointment_id UUID;
  v_new_end_time TIME;
  v_duration_minutes INTEGER;
BEGIN
  -- Get the original appointment
  SELECT * INTO v_old_appointment 
  FROM appointments 
  WHERE id = p_appointment_id AND status NOT IN ('cancelled', 'completed');
  
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Appointment not found or cannot be rescheduled'
    );
  END IF;
  
  -- Check if the new slot is available
  IF EXISTS (
    SELECT 1 FROM appointments a
    WHERE a.provider_id = v_old_appointment.provider_id
      AND a.appointment_date = p_new_date
      AND a.start_time = p_new_time
      AND a.status NOT IN ('cancelled', 'no_show')
      AND a.id != p_appointment_id
  ) THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Selected time slot is already booked'
    );
  END IF;
  
  -- Calculate new end time (preserve original duration)
  v_duration_minutes := COALESCE(v_old_appointment.duration_minutes, 30);
  v_new_end_time := p_new_time + (v_duration_minutes || ' minutes')::INTERVAL;
  
  -- Start transaction
  BEGIN
    -- Mark the original appointment as rescheduled
    UPDATE appointments 
    SET 
      status = 'rescheduled',
      updated_at = NOW()
    WHERE id = p_appointment_id;
    
    -- Create new appointment
    INSERT INTO appointments (
      patient_id,
      provider_id,
      assignment_id,
      appointment_date,
      start_time,
      end_time,
      duration_minutes,
      treatment_type,
      appointment_type,
      status,
      patient_notes,
      provider_notes,
      admin_notes,
      booked_by,
      booked_by_user_id
    ) VALUES (
      v_old_appointment.patient_id,
      v_old_appointment.provider_id,
      v_old_appointment.assignment_id,
      p_new_date,
      p_new_time,
      v_new_end_time,
      v_duration_minutes,
      v_old_appointment.treatment_type,
      v_old_appointment.appointment_type,
      'scheduled',
      v_old_appointment.patient_notes,
      v_old_appointment.provider_notes,
      'Rescheduled from ' || v_old_appointment.appointment_date || ' ' || v_old_appointment.start_time,
      p_rescheduled_by,
      p_rescheduled_by_user_id
    ) RETURNING id INTO v_new_appointment_id;
    
    -- Return success
    RETURN json_build_object(
      'success', true,
      'old_appointment_id', p_appointment_id,
      'new_appointment_id', v_new_appointment_id,
      'message', 'Appointment successfully rescheduled'
    );
    
  EXCEPTION WHEN OTHERS THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Failed to reschedule appointment: ' || SQLERRM
    );
  END;
END;
$$;


--
-- TOC entry 4665 (class 0 OID 0)
-- Dependencies: 378
-- Name: FUNCTION reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text, p_rescheduled_by_user_id uuid, p_reason text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.reschedule_appointment(p_appointment_id uuid, p_new_date date, p_new_time time without time zone, p_rescheduled_by text, p_rescheduled_by_user_id uuid, p_reason text) IS 'Reschedule an appointment to a new date and time';


--
-- TOC entry 382 (class 1255 OID 18664)
-- Name: set_appointment_context(text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_appointment_context(p_user_role text, p_user_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  PERFORM set_config('app.current_user_role', p_user_role, true);
  PERFORM set_config('app.current_user_id', p_user_id::TEXT, true);
END;
$$;


--
-- TOC entry 4666 (class 0 OID 0)
-- Dependencies: 382
-- Name: FUNCTION set_appointment_context(p_user_role text, p_user_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.set_appointment_context(p_user_role text, p_user_id uuid) IS 'Sets security context for appointment operations';


--
-- TOC entry 407 (class 1255 OID 18794)
-- Name: update_clinical_note_editor(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_clinical_note_editor() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Set last_updated_by to current user if available
  IF current_setting('app.current_user_id', true) != '' THEN
    NEW.last_updated_by = current_setting('app.current_user_id', true)::UUID;
  END IF;
  
  RETURN NEW;
END;
$$;


--
-- TOC entry 421 (class 1255 OID 18373)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only update if the table actually has an updated_at column
    IF TG_TABLE_NAME = 'clinical_notes' THEN
        NEW.updated_at = NOW();
    END IF;
    RETURN NEW;
EXCEPTION
    WHEN OTHERS THEN
        -- Don't fail the operation if there's an issue
        RETURN NEW;
END;
$$;


--
-- TOC entry 420 (class 1255 OID 18688)
-- Name: validate_appointment_business_rules(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_appointment_business_rules() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Prevent booking conflicts
  IF EXISTS (
    SELECT 1 FROM appointments a
    WHERE a.provider_id = NEW.provider_id
      AND a.appointment_date = NEW.appointment_date
      AND a.start_time = NEW.start_time
      AND a.id != COALESCE(NEW.id, '00000000-0000-0000-0000-000000000000'::UUID)
      AND a.status NOT IN ('cancelled', 'no_show')
  ) THEN
    RAISE EXCEPTION 'Appointment slot already booked';
  END IF;
  
  -- Validate appointment is within provider's schedule
  IF NOT EXISTS (
    SELECT 1 FROM provider_schedules ps
    WHERE ps.provider_id = NEW.provider_id
      AND ps.day_of_week = EXTRACT(DOW FROM NEW.appointment_date)
      AND ps.start_time <= NEW.start_time
      AND ps.end_time >= NEW.end_time
      AND ps.active = true
  ) THEN
    RAISE EXCEPTION 'Appointment outside provider schedule';
  END IF;
  
  -- Check for availability overrides that block this time
  IF EXISTS (
    SELECT 1 FROM provider_availability_overrides pao
    WHERE pao.provider_id = NEW.provider_id
      AND pao.date = NEW.appointment_date
      AND pao.available = false
      AND (pao.start_time IS NULL OR NEW.start_time >= pao.start_time)
      AND (pao.end_time IS NULL OR NEW.end_time <= pao.end_time)
  ) THEN
    RAISE EXCEPTION 'Provider not available at requested time';
  END IF;
  
  RETURN NEW;
END;
$$;


--
-- TOC entry 395 (class 1255 OID 17531)
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_;

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


--
-- TOC entry 479 (class 1255 OID 17610)
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


--
-- TOC entry 376 (class 1255 OID 17543)
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


--
-- TOC entry 495 (class 1255 OID 17493)
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
    declare
      res jsonb;
    begin
      execute format('select to_jsonb(%L::'|| type_::text || ')', val)  into res;
      return res;
    end
    $$;


--
-- TOC entry 446 (class 1255 OID 17488)
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


--
-- TOC entry 418 (class 1255 OID 17539)
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


--
-- TOC entry 383 (class 1255 OID 17550)
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS SETOF realtime.wal_rls
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
      with pub as (
        select
          concat_ws(
            ',',
            case when bool_or(pubinsert) then 'insert' else null end,
            case when bool_or(pubupdate) then 'update' else null end,
            case when bool_or(pubdelete) then 'delete' else null end
          ) as w2j_actions,
          coalesce(
            string_agg(
              realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
              ','
            ) filter (where ppt.tablename is not null and ppt.tablename not like '% %'),
            ''
          ) w2j_add_tables
        from
          pg_publication pp
          left join pg_publication_tables ppt
            on pp.pubname = ppt.pubname
        where
          pp.pubname = publication
        group by
          pp.pubname
        limit 1
      ),
      w2j as (
        select
          x.*, pub.w2j_add_tables
        from
          pub,
          pg_logical_slot_get_changes(
            slot_name, null, max_changes,
            'include-pk', 'true',
            'include-transaction', 'false',
            'include-timestamp', 'true',
            'include-type-oids', 'true',
            'format-version', '2',
            'actions', pub.w2j_actions,
            'add-tables', pub.w2j_add_tables
          ) x
      )
      select
        xyz.wal,
        xyz.is_rls_enabled,
        xyz.subscription_ids,
        xyz.errors
      from
        w2j,
        realtime.apply_rls(
          wal := w2j.data::jsonb,
          max_record_bytes := max_record_bytes
        ) xyz(wal, is_rls_enabled, subscription_ids, errors)
      where
        w2j.w2j_add_tables <> ''
        and xyz.subscription_ids[1] is not null
    $$;


--
-- TOC entry 415 (class 1255 OID 17487)
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


--
-- TOC entry 453 (class 1255 OID 17609)
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  BEGIN
    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (payload, event, topic, private, extension)
    VALUES (payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      RAISE WARNING 'ErrorSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- TOC entry 501 (class 1255 OID 17485)
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


--
-- TOC entry 381 (class 1255 OID 17520)
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


--
-- TOC entry 470 (class 1255 OID 17603)
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


--
-- TOC entry 441 (class 1255 OID 17864)
-- Name: add_prefixes(text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.add_prefixes(_bucket_id text, _name text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    prefixes text[];
BEGIN
    prefixes := "storage"."get_prefixes"("_name");

    IF array_length(prefixes, 1) > 0 THEN
        INSERT INTO storage.prefixes (name, bucket_id)
        SELECT UNNEST(prefixes) as name, "_bucket_id" ON CONFLICT DO NOTHING;
    END IF;
END;
$$;


--
-- TOC entry 450 (class 1255 OID 17790)
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


--
-- TOC entry 368 (class 1255 OID 17865)
-- Name: delete_prefix(text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.delete_prefix(_bucket_id text, _name text) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    -- Check if we can delete the prefix
    IF EXISTS(
        SELECT FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name") + 1
          AND "prefixes"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    )
    OR EXISTS(
        SELECT FROM "storage"."objects"
        WHERE "objects"."bucket_id" = "_bucket_id"
          AND "storage"."get_level"("objects"."name") = "storage"."get_level"("_name") + 1
          AND "objects"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    ) THEN
    -- There are sub-objects, skip deletion
    RETURN false;
    ELSE
        DELETE FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name")
          AND "prefixes"."name" = "_name";
        RETURN true;
    END IF;
END;
$$;


--
-- TOC entry 487 (class 1255 OID 17868)
-- Name: delete_prefix_hierarchy_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.delete_prefix_hierarchy_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    prefix text;
BEGIN
    prefix := "storage"."get_prefix"(OLD."name");

    IF coalesce(prefix, '') != '' THEN
        PERFORM "storage"."delete_prefix"(OLD."bucket_id", prefix);
    END IF;

    RETURN OLD;
END;
$$;


--
-- TOC entry 379 (class 1255 OID 17883)
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


--
-- TOC entry 494 (class 1255 OID 17764)
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    SELECT _parts[array_length(_parts,1)] INTO _filename;
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


--
-- TOC entry 386 (class 1255 OID 17763)
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


--
-- TOC entry 466 (class 1255 OID 17762)
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


--
-- TOC entry 482 (class 1255 OID 17846)
-- Name: get_level(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_level(name text) RETURNS integer
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
SELECT array_length(string_to_array("name", '/'), 1);
$$;


--
-- TOC entry 456 (class 1255 OID 17862)
-- Name: get_prefix(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_prefix(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
SELECT
    CASE WHEN strpos("name", '/') > 0 THEN
             regexp_replace("name", '[\/]{1}[^\/]+\/?$', '')
         ELSE
             ''
        END;
$_$;


--
-- TOC entry 396 (class 1255 OID 17863)
-- Name: get_prefixes(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_prefixes(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $$
DECLARE
    parts text[];
    prefixes text[];
    prefix text;
BEGIN
    -- Split the name into parts by '/'
    parts := string_to_array("name", '/');
    prefixes := '{}';

    -- Construct the prefixes, stopping one level below the last part
    FOR i IN 1..array_length(parts, 1) - 1 LOOP
            prefix := array_to_string(parts[1:i], '/');
            prefixes := array_append(prefixes, prefix);
    END LOOP;

    RETURN prefixes;
END;
$$;


--
-- TOC entry 388 (class 1255 OID 17881)
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


--
-- TOC entry 490 (class 1255 OID 17829)
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


--
-- TOC entry 384 (class 1255 OID 17792)
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(name COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                        substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1)))
                    ELSE
                        name
                END AS name, id, metadata, updated_at
            FROM
                storage.objects
            WHERE
                bucket_id = $5 AND
                name ILIKE $1 || ''%'' AND
                CASE
                    WHEN $6 != '''' THEN
                    name COLLATE "C" > $6
                ELSE true END
                AND CASE
                    WHEN $4 != '''' THEN
                        CASE
                            WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                                substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                name COLLATE "C" > $4
                            END
                    ELSE
                        true
                END
            ORDER BY
                name COLLATE "C" ASC) as e order by name COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_token, bucket_id, start_after;
END;
$_$;


--
-- TOC entry 449 (class 1255 OID 17867)
-- Name: objects_insert_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.objects_insert_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    NEW.level := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


--
-- TOC entry 400 (class 1255 OID 17882)
-- Name: objects_update_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.objects_update_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    old_prefixes TEXT[];
BEGIN
    -- Ensure this is an update operation and the name has changed
    IF TG_OP = 'UPDATE' AND (NEW."name" <> OLD."name" OR NEW."bucket_id" <> OLD."bucket_id") THEN
        -- Retrieve old prefixes
        old_prefixes := "storage"."get_prefixes"(OLD."name");

        -- Remove old prefixes that are only used by this object
        WITH all_prefixes as (
            SELECT unnest(old_prefixes) as prefix
        ),
        can_delete_prefixes as (
             SELECT prefix
             FROM all_prefixes
             WHERE NOT EXISTS (
                 SELECT 1 FROM "storage"."objects"
                 WHERE "bucket_id" = OLD."bucket_id"
                   AND "name" <> OLD."name"
                   AND "name" LIKE (prefix || '%')
             )
         )
        DELETE FROM "storage"."prefixes" WHERE name IN (SELECT prefix FROM can_delete_prefixes);

        -- Add new prefixes
        PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    END IF;
    -- Set the new level
    NEW."level" := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


--
-- TOC entry 406 (class 1255 OID 17845)
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


--
-- TOC entry 463 (class 1255 OID 17866)
-- Name: prefixes_insert_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.prefixes_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    RETURN NEW;
END;
$$;


--
-- TOC entry 394 (class 1255 OID 17779)
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql
    AS $$
declare
    can_bypass_rls BOOLEAN;
begin
    SELECT rolbypassrls
    INTO can_bypass_rls
    FROM pg_roles
    WHERE rolname = coalesce(nullif(current_setting('role', true), 'none'), current_user);

    IF can_bypass_rls THEN
        RETURN QUERY SELECT * FROM storage.search_v1_optimised(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    ELSE
        RETURN QUERY SELECT * FROM storage.search_legacy_v1(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    END IF;
end;
$$;


--
-- TOC entry 409 (class 1255 OID 17879)
-- Name: search_legacy_v1(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_legacy_v1(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select path_tokens[$1] as folder
           from storage.objects
             where objects.name ilike $2 || $3 || ''%''
               and bucket_id = $4
               and array_length(objects.path_tokens, 1) <> $1
           group by folder
           order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(objects.path_tokens, 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


--
-- TOC entry 476 (class 1255 OID 17878)
-- Name: search_v1_optimised(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v1_optimised(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select (string_to_array(name, ''/''))[level] as name
           from storage.prefixes
             where lower(prefixes.name) like lower($2 || $3) || ''%''
               and bucket_id = $4
               and level = $1
           order by name ' || v_sort_order || '
     )
     (select name,
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[level] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where lower(objects.name) like lower($2 || $3) || ''%''
       and bucket_id = $4
       and level = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


--
-- TOC entry 393 (class 1255 OID 17873)
-- Name: search_v2(text, text, integer, integer, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
BEGIN
    RETURN query EXECUTE
        $sql$
        SELECT * FROM (
            (
                SELECT
                    split_part(name, '/', $4) AS key,
                    name || '/' AS name,
                    NULL::uuid AS id,
                    NULL::timestamptz AS updated_at,
                    NULL::timestamptz AS created_at,
                    NULL::jsonb AS metadata
                FROM storage.prefixes
                WHERE name COLLATE "C" LIKE $1 || '%'
                AND bucket_id = $2
                AND level = $4
                AND name COLLATE "C" > $5
                ORDER BY prefixes.name COLLATE "C" LIMIT $3
            )
            UNION ALL
            (SELECT split_part(name, '/', $4) AS key,
                name,
                id,
                updated_at,
                created_at,
                metadata
            FROM storage.objects
            WHERE name COLLATE "C" LIKE $1 || '%'
                AND bucket_id = $2
                AND level = $4
                AND name COLLATE "C" > $5
            ORDER BY name COLLATE "C" LIMIT $3)
        ) obj
        ORDER BY name COLLATE "C" LIMIT $3;
        $sql$
        USING prefix, bucket_name, limits, levels, start_after;
END;
$_$;


--
-- TOC entry 443 (class 1255 OID 17780)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


--
-- TOC entry 459 (class 1255 OID 16774)
-- Name: http_request(); Type: FUNCTION; Schema: supabase_functions; Owner: -
--

CREATE FUNCTION supabase_functions.http_request() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'supabase_functions'
    AS $$
  DECLARE
    request_id bigint;
    payload jsonb;
    url text := TG_ARGV[0]::text;
    method text := TG_ARGV[1]::text;
    headers jsonb DEFAULT '{}'::jsonb;
    params jsonb DEFAULT '{}'::jsonb;
    timeout_ms integer DEFAULT 1000;
  BEGIN
    IF url IS NULL OR url = 'null' THEN
      RAISE EXCEPTION 'url argument is missing';
    END IF;

    IF method IS NULL OR method = 'null' THEN
      RAISE EXCEPTION 'method argument is missing';
    END IF;

    IF TG_ARGV[2] IS NULL OR TG_ARGV[2] = 'null' THEN
      headers = '{"Content-Type": "application/json"}'::jsonb;
    ELSE
      headers = TG_ARGV[2]::jsonb;
    END IF;

    IF TG_ARGV[3] IS NULL OR TG_ARGV[3] = 'null' THEN
      params = '{}'::jsonb;
    ELSE
      params = TG_ARGV[3]::jsonb;
    END IF;

    IF TG_ARGV[4] IS NULL OR TG_ARGV[4] = 'null' THEN
      timeout_ms = 1000;
    ELSE
      timeout_ms = TG_ARGV[4]::integer;
    END IF;

    CASE
      WHEN method = 'GET' THEN
        SELECT http_get INTO request_id FROM net.http_get(
          url,
          params,
          headers,
          timeout_ms
        );
      WHEN method = 'POST' THEN
        payload = jsonb_build_object(
          'old_record', OLD,
          'record', NEW,
          'type', TG_OP,
          'table', TG_TABLE_NAME,
          'schema', TG_TABLE_SCHEMA
        );

        SELECT http_post INTO request_id FROM net.http_post(
          url,
          payload,
          params,
          headers,
          timeout_ms
        );
      ELSE
        RAISE EXCEPTION 'method argument % is invalid', method;
    END CASE;

    INSERT INTO supabase_functions.hooks
      (hook_table_id, hook_name, request_id)
    VALUES
      (TG_RELID, TG_NAME, request_id);

    RETURN NEW;
  END
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 273 (class 1259 OID 16488)
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


--
-- TOC entry 4667 (class 0 OID 0)
-- Dependencies: 273
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- TOC entry 321 (class 1259 OID 18161)
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text NOT NULL,
    code_challenge_method auth.code_challenge_method NOT NULL,
    code_challenge text NOT NULL,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone
);


--
-- TOC entry 4668 (class 0 OID 0)
-- Dependencies: 321
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.flow_state IS 'stores metadata for pkce logins';


--
-- TOC entry 312 (class 1259 OID 17959)
-- Name: identities; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 4669 (class 0 OID 0)
-- Dependencies: 312
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- TOC entry 4670 (class 0 OID 0)
-- Dependencies: 312
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- TOC entry 272 (class 1259 OID 16481)
-- Name: instances; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- TOC entry 4671 (class 0 OID 0)
-- Dependencies: 272
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- TOC entry 316 (class 1259 OID 18048)
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


--
-- TOC entry 4672 (class 0 OID 0)
-- Dependencies: 316
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- TOC entry 315 (class 1259 OID 18036)
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


--
-- TOC entry 4673 (class 0 OID 0)
-- Dependencies: 315
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- TOC entry 314 (class 1259 OID 18023)
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid
);


--
-- TOC entry 4674 (class 0 OID 0)
-- Dependencies: 314
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- TOC entry 323 (class 1259 OID 18243)
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_id text NOT NULL,
    client_secret_hash text NOT NULL,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048))
);


--
-- TOC entry 322 (class 1259 OID 18211)
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


--
-- TOC entry 271 (class 1259 OID 16470)
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


--
-- TOC entry 4675 (class 0 OID 0)
-- Dependencies: 271
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- TOC entry 270 (class 1259 OID 16469)
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: -
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4676 (class 0 OID 0)
-- Dependencies: 270
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: -
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- TOC entry 319 (class 1259 OID 18090)
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


--
-- TOC entry 4677 (class 0 OID 0)
-- Dependencies: 319
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- TOC entry 320 (class 1259 OID 18108)
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


--
-- TOC entry 4678 (class 0 OID 0)
-- Dependencies: 320
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- TOC entry 274 (class 1259 OID 16496)
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


--
-- TOC entry 4679 (class 0 OID 0)
-- Dependencies: 274
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- TOC entry 313 (class 1259 OID 17989)
-- Name: sessions; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text
);


--
-- TOC entry 4680 (class 0 OID 0)
-- Dependencies: 313
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- TOC entry 4681 (class 0 OID 0)
-- Dependencies: 313
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- TOC entry 318 (class 1259 OID 18075)
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


--
-- TOC entry 4682 (class 0 OID 0)
-- Dependencies: 318
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- TOC entry 317 (class 1259 OID 18066)
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


--
-- TOC entry 4683 (class 0 OID 0)
-- Dependencies: 317
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- TOC entry 4684 (class 0 OID 0)
-- Dependencies: 317
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- TOC entry 269 (class 1259 OID 16458)
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


--
-- TOC entry 4685 (class 0 OID 0)
-- Dependencies: 269
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- TOC entry 4686 (class 0 OID 0)
-- Dependencies: 269
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- TOC entry 328 (class 1259 OID 18320)
-- Name: admins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admins (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    permissions text[] DEFAULT ARRAY['dashboard'::text],
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 339 (class 1259 OID 18625)
-- Name: appointment_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointment_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    appointment_id uuid NOT NULL,
    action text NOT NULL,
    performed_by text NOT NULL,
    performed_by_user_id uuid,
    old_values jsonb,
    new_values jsonb,
    reason text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT appointment_history_action_check CHECK ((action = ANY (ARRAY['created'::text, 'updated'::text, 'cancelled'::text, 'completed'::text, 'no_show'::text, 'reschedule'::text, 'rescheduled'::text]))),
    CONSTRAINT appointment_history_performed_by_check CHECK ((performed_by = ANY (ARRAY['patient'::text, 'provider'::text, 'admin'::text, 'system'::text])))
);


--
-- TOC entry 4687 (class 0 OID 0)
-- Dependencies: 339
-- Name: TABLE appointment_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.appointment_history IS 'Complete audit trail of all appointment changes';


--
-- TOC entry 338 (class 1259 OID 18587)
-- Name: appointments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    assignment_id uuid,
    appointment_date date NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    duration_minutes integer NOT NULL,
    treatment_type text NOT NULL,
    appointment_type text DEFAULT 'consultation'::text NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    patient_notes text,
    provider_notes text,
    admin_notes text,
    booked_by text NOT NULL,
    booked_by_user_id uuid,
    booking_timestamp timestamp with time zone DEFAULT now(),
    cancelled_at timestamp with time zone,
    cancelled_by text,
    cancelled_by_user_id uuid,
    cancellation_reason text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    rescheduled_from_id uuid,
    rescheduled_to_id uuid,
    is_reschedule_source boolean DEFAULT false,
    reschedule_count integer DEFAULT 0,
    CONSTRAINT appointment_in_future CHECK (((appointment_date > CURRENT_DATE) OR ((appointment_date = CURRENT_DATE) AND (start_time >= LOCALTIME)))),
    CONSTRAINT appointments_appointment_type_check CHECK ((appointment_type = ANY (ARRAY['consultation'::text, 'follow_up'::text, 'treatment'::text, 'evaluation'::text, 'review'::text]))),
    CONSTRAINT appointments_booked_by_check CHECK ((booked_by = ANY (ARRAY['patient'::text, 'provider'::text, 'admin'::text]))),
    CONSTRAINT appointments_cancelled_by_check CHECK ((cancelled_by = ANY (ARRAY['patient'::text, 'provider'::text, 'admin'::text]))),
    CONSTRAINT appointments_duration_minutes_check CHECK ((duration_minutes > 0)),
    CONSTRAINT appointments_status_check CHECK ((status = ANY (ARRAY['scheduled'::text, 'confirmed'::text, 'completed'::text, 'cancelled'::text, 'no_show'::text, 'rescheduled'::text]))),
    CONSTRAINT valid_appointment_time CHECK ((end_time > start_time)),
    CONSTRAINT valid_cancellation CHECK (((status <> 'cancelled'::text) OR ((status = 'cancelled'::text) AND (cancelled_at IS NOT NULL) AND (cancelled_by IS NOT NULL))))
);


--
-- TOC entry 4688 (class 0 OID 0)
-- Dependencies: 338
-- Name: TABLE appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.appointments IS 'Core appointments between patients and providers';


--
-- TOC entry 4689 (class 0 OID 0)
-- Dependencies: 338
-- Name: COLUMN appointments.assignment_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.assignment_id IS 'Links appointment to specific patient-provider treatment assignment';


--
-- TOC entry 4690 (class 0 OID 0)
-- Dependencies: 338
-- Name: COLUMN appointments.booked_by_user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.booked_by_user_id IS 'Profile ID of the person who booked the appointment';


--
-- TOC entry 4691 (class 0 OID 0)
-- Dependencies: 338
-- Name: COLUMN appointments.rescheduled_from_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.rescheduled_from_id IS 'Points to original appointment if this is a rescheduled appointment';


--
-- TOC entry 4692 (class 0 OID 0)
-- Dependencies: 338
-- Name: COLUMN appointments.rescheduled_to_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.rescheduled_to_id IS 'Points to new appointment if this was rescheduled';


--
-- TOC entry 4693 (class 0 OID 0)
-- Dependencies: 338
-- Name: COLUMN appointments.is_reschedule_source; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.is_reschedule_source IS 'True if this appointment was rescheduled (original slot now available)';


--
-- TOC entry 4694 (class 0 OID 0)
-- Dependencies: 338
-- Name: COLUMN appointments.reschedule_count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.appointments.reschedule_count IS 'Number of times this appointment chain has been rescheduled';


--
-- TOC entry 331 (class 1259 OID 18409)
-- Name: assignment_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assignment_log (
    id integer NOT NULL,
    message text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- TOC entry 330 (class 1259 OID 18408)
-- Name: assignment_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assignment_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4695 (class 0 OID 0)
-- Dependencies: 330
-- Name: assignment_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assignment_log_id_seq OWNED BY public.assignment_log.id;


--
-- TOC entry 348 (class 1259 OID 18967)
-- Name: auth_trigger_debug_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_trigger_debug_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    step text,
    status text,
    error_message text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 345 (class 1259 OID 18839)
-- Name: auth_trigger_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_trigger_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    trigger_stage text NOT NULL,
    success boolean NOT NULL,
    error_message text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 342 (class 1259 OID 18702)
-- Name: clinical_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clinical_notes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    appointment_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    allergies text[] DEFAULT '{}'::text[],
    previous_medications text[] DEFAULT '{}'::text[],
    current_medications text[] DEFAULT '{}'::text[],
    clinical_note text DEFAULT ''::text,
    internal_note text DEFAULT ''::text,
    visit_summary text DEFAULT ''::text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    created_by uuid,
    last_updated_by uuid
);


--
-- TOC entry 4696 (class 0 OID 0)
-- Dependencies: 342
-- Name: TABLE clinical_notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.clinical_notes IS 'Clinical notes and medical information recorded during patient visits';


--
-- TOC entry 4697 (class 0 OID 0)
-- Dependencies: 342
-- Name: COLUMN clinical_notes.appointment_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.appointment_id IS 'Links clinical note to specific appointment';


--
-- TOC entry 4698 (class 0 OID 0)
-- Dependencies: 342
-- Name: COLUMN clinical_notes.allergies; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.allergies IS 'Array of patient allergies recorded during visit';


--
-- TOC entry 4699 (class 0 OID 0)
-- Dependencies: 342
-- Name: COLUMN clinical_notes.previous_medications; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.previous_medications IS 'Array of previous medications mentioned during visit';


--
-- TOC entry 4700 (class 0 OID 0)
-- Dependencies: 342
-- Name: COLUMN clinical_notes.current_medications; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.current_medications IS 'Array of current medications mentioned during visit';


--
-- TOC entry 4701 (class 0 OID 0)
-- Dependencies: 342
-- Name: COLUMN clinical_notes.clinical_note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.clinical_note IS 'Main clinical observations and notes';


--
-- TOC entry 4702 (class 0 OID 0)
-- Dependencies: 342
-- Name: COLUMN clinical_notes.internal_note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.internal_note IS 'Internal provider notes, not visible to patients';


--
-- TOC entry 4703 (class 0 OID 0)
-- Dependencies: 342
-- Name: COLUMN clinical_notes.visit_summary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clinical_notes.visit_summary IS 'Auto-generated or custom summary of the visit';


--
-- TOC entry 334 (class 1259 OID 18455)
-- Name: medication_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medication_approvals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    preference_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    status text DEFAULT 'needs_review'::text NOT NULL,
    approved_dosage text,
    approved_frequency text,
    provider_notes text,
    contraindications text,
    approval_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT check_approval_status CHECK ((status = ANY (ARRAY['approved'::text, 'denied'::text, 'needs_review'::text])))
);


--
-- TOC entry 346 (class 1259 OID 18890)
-- Name: medication_dosages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medication_dosages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    medication_id uuid NOT NULL,
    strength text NOT NULL,
    unit_price numeric(10,2) DEFAULT 0 NOT NULL,
    available boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 4704 (class 0 OID 0)
-- Dependencies: 346
-- Name: TABLE medication_dosages; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.medication_dosages IS 'Stores multiple dosage options for each medication. Replaces the single strength field in medications table.';


--
-- TOC entry 335 (class 1259 OID 18476)
-- Name: medication_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medication_orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    approval_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    medication_id uuid NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    payment_status text DEFAULT 'pending'::text NOT NULL,
    payment_method text,
    payment_date timestamp with time zone,
    fulfillment_status text DEFAULT 'pending'::text NOT NULL,
    tracking_number text,
    shipped_date timestamp with time zone,
    estimated_delivery timestamp with time zone,
    admin_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    sent_to_pharmacy timestamp with time zone,
    CONSTRAINT check_fulfillment_status CHECK ((fulfillment_status = ANY (ARRAY['pending'::text, 'processing'::text, 'shipped'::text, 'delivered'::text]))),
    CONSTRAINT check_payment_status CHECK ((payment_status = ANY (ARRAY['pending'::text, 'paid'::text, 'failed'::text, 'refunded'::text]))),
    CONSTRAINT check_positive_amounts CHECK (((unit_price >= (0)::numeric) AND (total_amount >= (0)::numeric) AND (quantity > 0)))
);


--
-- TOC entry 4705 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN medication_orders.shipped_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_orders.shipped_date IS 'Date when medication was physically shipped to patient';


--
-- TOC entry 4706 (class 0 OID 0)
-- Dependencies: 335
-- Name: COLUMN medication_orders.sent_to_pharmacy; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.medication_orders.sent_to_pharmacy IS 'Date when prescription was sent to pharmacy for processing';


--
-- TOC entry 332 (class 1259 OID 18418)
-- Name: medications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    generic_name text,
    brand_name text,
    dosage_form text NOT NULL,
    strength text NOT NULL,
    description text,
    category text NOT NULL,
    unit_price numeric(10,2) DEFAULT 0 NOT NULL,
    requires_prescription boolean DEFAULT true,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 329 (class 1259 OID 18339)
-- Name: patient_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patient_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    treatment_type text DEFAULT 'general_care'::text,
    is_primary boolean DEFAULT false,
    assigned_date timestamp with time zone DEFAULT now(),
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 333 (class 1259 OID 18431)
-- Name: patient_medication_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patient_medication_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    patient_id uuid NOT NULL,
    medication_id uuid NOT NULL,
    preferred_dosage text,
    frequency text,
    notes text,
    status text DEFAULT 'pending'::text NOT NULL,
    requested_date timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    medication_dosage_id uuid,
    CONSTRAINT check_preference_status CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'denied'::text, 'discontinued'::text])))
);


--
-- TOC entry 4707 (class 0 OID 0)
-- Dependencies: 333
-- Name: COLUMN patient_medication_preferences.medication_dosage_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.patient_medication_preferences.medication_dosage_id IS 'References the specific dosage selected by the patient. New preferred method over preferred_dosage text field.';


--
-- TOC entry 326 (class 1259 OID 18284)
-- Name: patients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    date_of_birth date,
    phone text,
    has_completed_intake boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 325 (class 1259 OID 18267)
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL,
    email text NOT NULL,
    first_name text,
    last_name text,
    role text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT profiles_role_check CHECK ((role = ANY (ARRAY['patient'::text, 'admin'::text, 'provider'::text])))
);


--
-- TOC entry 337 (class 1259 OID 18570)
-- Name: provider_availability_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provider_availability_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid NOT NULL,
    date date NOT NULL,
    start_time time without time zone,
    end_time time without time zone,
    available boolean NOT NULL,
    reason text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_override_time CHECK (((available = false) OR ((available = true) AND (start_time IS NOT NULL) AND (end_time IS NOT NULL) AND (end_time > start_time))))
);


--
-- TOC entry 4708 (class 0 OID 0)
-- Dependencies: 337
-- Name: TABLE provider_availability_overrides; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.provider_availability_overrides IS 'Date-specific availability changes (vacations, special hours, etc.)';


--
-- TOC entry 4709 (class 0 OID 0)
-- Dependencies: 337
-- Name: COLUMN provider_availability_overrides.available; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provider_availability_overrides.available IS 'false=unavailable, true=special availability override';


--
-- TOC entry 336 (class 1259 OID 18547)
-- Name: provider_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provider_schedules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid NOT NULL,
    day_of_week integer NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    slot_duration_minutes integer DEFAULT 30 NOT NULL,
    treatment_types text[] DEFAULT '{}'::text[],
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT provider_schedules_day_of_week_check CHECK (((day_of_week >= 0) AND (day_of_week <= 6))),
    CONSTRAINT provider_schedules_slot_duration_minutes_check CHECK ((slot_duration_minutes > 0)),
    CONSTRAINT valid_time_range CHECK ((end_time > start_time))
);


--
-- TOC entry 4710 (class 0 OID 0)
-- Dependencies: 336
-- Name: TABLE provider_schedules; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.provider_schedules IS 'Recurring weekly availability schedules for providers';


--
-- TOC entry 4711 (class 0 OID 0)
-- Dependencies: 336
-- Name: COLUMN provider_schedules.day_of_week; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provider_schedules.day_of_week IS '0=Sunday, 1=Monday, ..., 6=Saturday';


--
-- TOC entry 4712 (class 0 OID 0)
-- Dependencies: 336
-- Name: COLUMN provider_schedules.treatment_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.provider_schedules.treatment_types IS 'Empty array means available for all treatment types';


--
-- TOC entry 327 (class 1259 OID 18302)
-- Name: providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    profile_id uuid NOT NULL,
    specialty text,
    license_number text,
    phone text,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 340 (class 1259 OID 18691)
-- Name: provider_availability_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.provider_availability_summary AS
 SELECT p.id AS provider_id,
    ((prof.first_name || ' '::text) || prof.last_name) AS provider_name,
    ps.day_of_week,
        CASE ps.day_of_week
            WHEN 0 THEN 'Sunday'::text
            WHEN 1 THEN 'Monday'::text
            WHEN 2 THEN 'Tuesday'::text
            WHEN 3 THEN 'Wednesday'::text
            WHEN 4 THEN 'Thursday'::text
            WHEN 5 THEN 'Friday'::text
            WHEN 6 THEN 'Saturday'::text
            ELSE NULL::text
        END AS day_name,
    ps.start_time,
    ps.end_time,
    ps.slot_duration_minutes,
    ps.treatment_types,
    ps.active
   FROM ((public.providers p
     JOIN public.profiles prof ON ((p.profile_id = prof.id)))
     JOIN public.provider_schedules ps ON ((p.id = ps.provider_id)))
  ORDER BY p.id, ps.day_of_week, ps.start_time;


--
-- TOC entry 4713 (class 0 OID 0)
-- Dependencies: 340
-- Name: VIEW provider_availability_summary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.provider_availability_summary IS 'Easy view of all provider schedules with readable day names';


--
-- TOC entry 341 (class 1259 OID 18696)
-- Name: upcoming_appointments_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.upcoming_appointments_summary AS
 SELECT a.id AS appointment_id,
    ((patient_prof.first_name || ' '::text) || patient_prof.last_name) AS patient_name,
    ((provider_prof.first_name || ' '::text) || provider_prof.last_name) AS provider_name,
    a.appointment_date,
    a.start_time,
    a.end_time,
    a.treatment_type,
    a.appointment_type,
    a.status,
    a.created_at
   FROM ((((public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
     JOIN public.profiles patient_prof ON ((p.profile_id = patient_prof.id)))
     JOIN public.providers prov ON ((a.provider_id = prov.id)))
     JOIN public.profiles provider_prof ON ((prov.profile_id = provider_prof.id)))
  WHERE (a.appointment_date >= CURRENT_DATE)
  ORDER BY a.appointment_date, a.start_time;


--
-- TOC entry 4714 (class 0 OID 0)
-- Dependencies: 341
-- Name: VIEW upcoming_appointments_summary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.upcoming_appointments_summary IS 'Overview of all upcoming appointments with patient and provider names';


--
-- TOC entry 347 (class 1259 OID 18920)
-- Name: visit_addendums; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visit_addendums (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    visit_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT visit_addendums_content_not_empty CHECK ((length(TRIM(BOTH FROM content)) > 0))
);


--
-- TOC entry 4715 (class 0 OID 0)
-- Dependencies: 347
-- Name: TABLE visit_addendums; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.visit_addendums IS 'Addendums to previous visits for additional notes or corrections';


--
-- TOC entry 4716 (class 0 OID 0)
-- Dependencies: 347
-- Name: COLUMN visit_addendums.visit_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_addendums.visit_id IS 'Links addendum to specific appointment/visit';


--
-- TOC entry 4717 (class 0 OID 0)
-- Dependencies: 347
-- Name: COLUMN visit_addendums.provider_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_addendums.provider_id IS 'Provider who created the addendum';


--
-- TOC entry 4718 (class 0 OID 0)
-- Dependencies: 347
-- Name: COLUMN visit_addendums.content; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_addendums.content IS 'Content of the addendum';


--
-- TOC entry 4719 (class 0 OID 0)
-- Dependencies: 347
-- Name: COLUMN visit_addendums.created_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_addendums.created_at IS 'When the addendum was created';


--
-- TOC entry 344 (class 1259 OID 18760)
-- Name: visit_interactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visit_interactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinical_note_id uuid NOT NULL,
    appointment_id uuid NOT NULL,
    interaction_type text NOT NULL,
    details text,
    provider_notes text,
    created_at timestamp with time zone DEFAULT now(),
    performed_by uuid NOT NULL,
    medication_id uuid,
    medication_name text,
    previous_dosage text,
    new_dosage text,
    previous_frequency text,
    new_frequency text,
    previous_status text,
    new_status text,
    CONSTRAINT visit_interactions_interaction_type_check CHECK ((interaction_type = ANY (ARRAY['treatment_plan_update'::text, 'follow_up_scheduled'::text, 'referral_made'::text, 'lab_ordered'::text, 'allergy_noted'::text, 'vital_signs_recorded'::text]))),
    CONSTRAINT visit_interactions_new_status_check CHECK (((new_status IS NULL) OR (new_status = ANY (ARRAY['pending'::text, 'approved'::text, 'denied'::text, 'discontinued'::text]))))
);


--
-- TOC entry 4720 (class 0 OID 0)
-- Dependencies: 344
-- Name: TABLE visit_interactions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.visit_interactions IS 'General interactions and activities during visits (non-medication)';


--
-- TOC entry 4721 (class 0 OID 0)
-- Dependencies: 344
-- Name: COLUMN visit_interactions.interaction_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_interactions.interaction_type IS 'Type of interaction: treatment_plan_update, follow_up_scheduled, etc.';


--
-- TOC entry 4722 (class 0 OID 0)
-- Dependencies: 344
-- Name: COLUMN visit_interactions.details; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_interactions.details IS 'General details about the interaction';


--
-- TOC entry 343 (class 1259 OID 18735)
-- Name: visit_medication_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visit_medication_adjustments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinical_note_id uuid NOT NULL,
    appointment_id uuid NOT NULL,
    preference_id uuid NOT NULL,
    previous_dosage text,
    previous_frequency text,
    previous_status text,
    previous_provider_notes text,
    new_dosage text,
    new_frequency text,
    new_status text,
    new_provider_notes text,
    adjustment_reason text,
    provider_notes text,
    created_at timestamp with time zone DEFAULT now(),
    performed_by uuid NOT NULL,
    CONSTRAINT visit_medication_adjustments_new_status_check CHECK ((new_status = ANY (ARRAY['pending'::text, 'approved'::text, 'denied'::text, 'discontinued'::text])))
);


--
-- TOC entry 4723 (class 0 OID 0)
-- Dependencies: 343
-- Name: TABLE visit_medication_adjustments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.visit_medication_adjustments IS 'Medication adjustments made during visits, links to patient_medication_preferences';


--
-- TOC entry 4724 (class 0 OID 0)
-- Dependencies: 343
-- Name: COLUMN visit_medication_adjustments.preference_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_medication_adjustments.preference_id IS 'Links to existing patient_medication_preferences table';


--
-- TOC entry 4725 (class 0 OID 0)
-- Dependencies: 343
-- Name: COLUMN visit_medication_adjustments.adjustment_reason; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.visit_medication_adjustments.adjustment_reason IS 'Reason for the medication adjustment';


--
-- TOC entry 300 (class 1259 OID 17613)
-- Name: messages; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
)
PARTITION BY RANGE (inserted_at);


--
-- TOC entry 301 (class 1259 OID 17630)
-- Name: messages_2025_09_28; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_09_28 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 302 (class 1259 OID 17642)
-- Name: messages_2025_09_29; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_09_29 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 303 (class 1259 OID 17654)
-- Name: messages_2025_09_30; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_09_30 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 304 (class 1259 OID 17666)
-- Name: messages_2025_10_01; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_10_01 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 305 (class 1259 OID 17678)
-- Name: messages_2025_10_02; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2025_10_02 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 294 (class 1259 OID 17451)
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


--
-- TOC entry 297 (class 1259 OID 17473)
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);


--
-- TOC entry 296 (class 1259 OID 17472)
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: -
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 275 (class 1259 OID 16509)
-- Name: buckets; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


--
-- TOC entry 4726 (class 0 OID 0)
-- Dependencies: 275
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 309 (class 1259 OID 17892)
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_analytics (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 310 (class 1259 OID 17903)
-- Name: iceberg_namespaces; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.iceberg_namespaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 311 (class 1259 OID 17919)
-- Name: iceberg_tables; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.iceberg_tables (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    namespace_id uuid NOT NULL,
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    location text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 277 (class 1259 OID 16551)
-- Name: migrations; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 276 (class 1259 OID 16524)
-- Name: objects; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb,
    level integer
);


--
-- TOC entry 4727 (class 0 OID 0)
-- Dependencies: 276
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 308 (class 1259 OID 17847)
-- Name: prefixes; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.prefixes (
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    level integer GENERATED ALWAYS AS (storage.get_level(name)) STORED NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 306 (class 1259 OID 17794)
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb
);


--
-- TOC entry 307 (class 1259 OID 17808)
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 290 (class 1259 OID 16763)
-- Name: hooks; Type: TABLE; Schema: supabase_functions; Owner: -
--

CREATE TABLE supabase_functions.hooks (
    id bigint NOT NULL,
    hook_table_id integer NOT NULL,
    hook_name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    request_id bigint
);


--
-- TOC entry 4728 (class 0 OID 0)
-- Dependencies: 290
-- Name: TABLE hooks; Type: COMMENT; Schema: supabase_functions; Owner: -
--

COMMENT ON TABLE supabase_functions.hooks IS 'Supabase Functions Hooks: Audit trail for triggered hooks.';


--
-- TOC entry 289 (class 1259 OID 16762)
-- Name: hooks_id_seq; Type: SEQUENCE; Schema: supabase_functions; Owner: -
--

CREATE SEQUENCE supabase_functions.hooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4729 (class 0 OID 0)
-- Dependencies: 289
-- Name: hooks_id_seq; Type: SEQUENCE OWNED BY; Schema: supabase_functions; Owner: -
--

ALTER SEQUENCE supabase_functions.hooks_id_seq OWNED BY supabase_functions.hooks.id;


--
-- TOC entry 288 (class 1259 OID 16754)
-- Name: migrations; Type: TABLE; Schema: supabase_functions; Owner: -
--

CREATE TABLE supabase_functions.migrations (
    version text NOT NULL,
    inserted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 3755 (class 0 OID 0)
-- Name: messages_2025_09_28; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_09_28 FOR VALUES FROM ('2025-09-28 00:00:00') TO ('2025-09-29 00:00:00');


--
-- TOC entry 3756 (class 0 OID 0)
-- Name: messages_2025_09_29; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_09_29 FOR VALUES FROM ('2025-09-29 00:00:00') TO ('2025-09-30 00:00:00');


--
-- TOC entry 3757 (class 0 OID 0)
-- Name: messages_2025_09_30; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_09_30 FOR VALUES FROM ('2025-09-30 00:00:00') TO ('2025-10-01 00:00:00');


--
-- TOC entry 3758 (class 0 OID 0)
-- Name: messages_2025_10_01; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_01 FOR VALUES FROM ('2025-10-01 00:00:00') TO ('2025-10-02 00:00:00');


--
-- TOC entry 3759 (class 0 OID 0)
-- Name: messages_2025_10_02; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2025_10_02 FOR VALUES FROM ('2025-10-02 00:00:00') TO ('2025-10-03 00:00:00');


--
-- TOC entry 3769 (class 2604 OID 16473)
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- TOC entry 3858 (class 2604 OID 18412)
-- Name: assignment_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assignment_log ALTER COLUMN id SET DEFAULT nextval('public.assignment_log_id_seq'::regclass);


--
-- TOC entry 3783 (class 2604 OID 16766)
-- Name: hooks id; Type: DEFAULT; Schema: supabase_functions; Owner: -
--

ALTER TABLE ONLY supabase_functions.hooks ALTER COLUMN id SET DEFAULT nextval('supabase_functions.hooks_id_seq'::regclass);


--
-- TOC entry 4592 (class 0 OID 16488)
-- Dependencies: 273
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
00000000-0000-0000-0000-000000000000	d9610feb-66f0-4a13-834b-5842fd8d2310	{"action":"user_signedup","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"team","traits":{"provider":"email"}}	2025-09-29 19:13:41.560472+00	
00000000-0000-0000-0000-000000000000	cbcc188c-c5aa-4241-9643-56796d987eb7	{"action":"login","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 19:13:41.563309+00	
00000000-0000-0000-0000-000000000000	44559e76-6e05-41d0-86bf-a0e6a91376e4	{"action":"logout","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"account"}	2025-09-29 19:13:51.311+00	
00000000-0000-0000-0000-000000000000	98fda0e6-40ca-456a-9b72-6e6e9632133d	{"action":"user_signedup","actor_id":"e6e0a334-66bc-4e11-9447-c6ac75c295e4","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"team","traits":{"provider":"email"}}	2025-09-29 19:14:13.338499+00	
00000000-0000-0000-0000-000000000000	aa576cdf-8fef-41c1-8699-57b869971664	{"action":"login","actor_id":"e6e0a334-66bc-4e11-9447-c6ac75c295e4","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 19:14:13.340256+00	
00000000-0000-0000-0000-000000000000	31173c9e-754d-40e7-8a63-3dde13bd1b20	{"action":"logout","actor_id":"e6e0a334-66bc-4e11-9447-c6ac75c295e4","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-09-29 19:14:20.680277+00	
00000000-0000-0000-0000-000000000000	91b824e4-2e84-4c49-932a-ded351950700	{"action":"user_signedup","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"team","traits":{"provider":"email"}}	2025-09-29 19:14:56.423436+00	
00000000-0000-0000-0000-000000000000	1de3b724-c5b1-4b85-b298-f5e0a669b30b	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 19:14:56.425093+00	
00000000-0000-0000-0000-000000000000	aed3ad52-ac52-4d44-b59d-dc082115c403	{"action":"login","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 19:24:04.688466+00	
00000000-0000-0000-0000-000000000000	f323db9e-e644-48d8-8665-09d04c947f5e	{"action":"logout","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"account"}	2025-09-29 19:24:04.705281+00	
00000000-0000-0000-0000-000000000000	bb0e9e19-3994-4665-9089-829717a652f3	{"action":"login","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 19:24:15.841266+00	
00000000-0000-0000-0000-000000000000	bc2eef86-e692-47df-abb7-da5ddf902a9f	{"action":"logout","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"account"}	2025-09-29 19:24:30.174607+00	
00000000-0000-0000-0000-000000000000	b1e8090e-180f-4bb8-8774-f35299392f17	{"action":"login","actor_id":"e6e0a334-66bc-4e11-9447-c6ac75c295e4","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 19:24:38.87086+00	
00000000-0000-0000-0000-000000000000	9bc328f4-ab22-4d3f-acab-f04f0255ea3f	{"action":"logout","actor_id":"e6e0a334-66bc-4e11-9447-c6ac75c295e4","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-09-29 19:24:48.76404+00	
00000000-0000-0000-0000-000000000000	67e7bede-c6b0-4c99-be3f-0ec993e1add5	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 19:25:07.977825+00	
00000000-0000-0000-0000-000000000000	c45bca4a-f92e-4618-b4eb-cf60f7fb0faf	{"action":"logout","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-09-29 19:25:29.978114+00	
00000000-0000-0000-0000-000000000000	bce2d172-ead6-4da0-a560-a1b0e4606a58	{"action":"login","actor_id":"e6e0a334-66bc-4e11-9447-c6ac75c295e4","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 19:25:40.357671+00	
00000000-0000-0000-0000-000000000000	0b430ec1-d057-4e56-acee-82970d539746	{"action":"login","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 19:32:57.362903+00	
00000000-0000-0000-0000-000000000000	0a428fe6-e8d8-45be-b4da-39c61a46fe60	{"action":"logout","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"account"}	2025-09-29 19:33:06.345084+00	
00000000-0000-0000-0000-000000000000	9e08ad0c-cb2d-41d2-84ad-54102b7ab211	{"action":"login","actor_id":"e6e0a334-66bc-4e11-9447-c6ac75c295e4","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 19:33:21.125635+00	
00000000-0000-0000-0000-000000000000	025be669-0a27-4c85-9b36-82bde98ce7a9	{"action":"logout","actor_id":"e6e0a334-66bc-4e11-9447-c6ac75c295e4","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-09-29 19:33:45.243741+00	
00000000-0000-0000-0000-000000000000	de850d0d-943b-4adc-8d2d-504d54021e67	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 19:33:58.925554+00	
00000000-0000-0000-0000-000000000000	ade86207-69a4-4f14-b8e7-0890d7bc7771	{"action":"logout","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-09-29 19:34:09.364588+00	
00000000-0000-0000-0000-000000000000	47de46ec-ff84-40fd-8a46-05d0915bef52	{"action":"login","actor_id":"e6e0a334-66bc-4e11-9447-c6ac75c295e4","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 20:35:26.621352+00	
00000000-0000-0000-0000-000000000000	580ad288-f336-45dd-8249-2897b21816d4	{"action":"login","actor_id":"e6e0a334-66bc-4e11-9447-c6ac75c295e4","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 20:53:53.729387+00	
00000000-0000-0000-0000-000000000000	5a37a2f9-9b4d-45e9-9a27-f0006c40e06e	{"action":"login","actor_id":"e6e0a334-66bc-4e11-9447-c6ac75c295e4","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 21:02:15.944843+00	
00000000-0000-0000-0000-000000000000	9125cca6-c6be-4d3d-aead-982c78a1afb3	{"action":"login","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 21:08:30.222214+00	
00000000-0000-0000-0000-000000000000	d56efed7-1cea-49e5-aa24-275e3defb8e2	{"action":"login","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 22:06:16.072851+00	
00000000-0000-0000-0000-000000000000	eeaa3917-ec32-483a-a509-f29222ffa168	{"action":"login","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 22:25:35.573457+00	
00000000-0000-0000-0000-000000000000	207e5c00-8810-4ce7-b2ae-16dc37df2bf5	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 22:31:24.871995+00	
00000000-0000-0000-0000-000000000000	1edee69f-b257-4a1f-8323-207987bfedb4	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 22:45:24.93866+00	
00000000-0000-0000-0000-000000000000	cb6832cb-f0d1-422b-b812-3e9a99da3780	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-29 22:47:50.883291+00	
00000000-0000-0000-0000-000000000000	44f209bd-d2b1-41bb-8ef6-f7d56047443f	{"action":"login","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 00:40:34.174071+00	
00000000-0000-0000-0000-000000000000	2e01a27e-4fcc-4f0b-bd2e-98214e51eeee	{"action":"logout","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"account"}	2025-09-30 00:40:50.947076+00	
00000000-0000-0000-0000-000000000000	c77ab8de-6567-4623-89bc-4e58c9cf5c7b	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 00:41:03.877182+00	
00000000-0000-0000-0000-000000000000	ce0a6e2d-13e6-4f8d-906e-5403481e49a5	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 00:50:20.022557+00	
00000000-0000-0000-0000-000000000000	97b08cc4-4205-4677-90dd-3cd9bf9f68e7	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 01:11:21.122265+00	
00000000-0000-0000-0000-000000000000	480f31b3-a91c-4bd9-b4f8-80a4108a144b	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 01:14:43.16619+00	
00000000-0000-0000-0000-000000000000	b3447313-ca38-438b-bf07-9a6d50dc77d4	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 01:19:51.056029+00	
00000000-0000-0000-0000-000000000000	f4eb50a7-dbb9-4f71-a49e-59ddbab9b6bd	{"action":"logout","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account"}	2025-09-30 01:22:37.901868+00	
00000000-0000-0000-0000-000000000000	90e4a519-5090-42b7-975d-8836ab58cbec	{"action":"login","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 01:23:01.937554+00	
00000000-0000-0000-0000-000000000000	fa8225b2-3cee-43b2-b909-2c7d713bfb43	{"action":"logout","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"account"}	2025-09-30 01:23:22.094094+00	
00000000-0000-0000-0000-000000000000	c888c474-eb3e-41a5-9b61-84d486498533	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 01:23:45.654098+00	
00000000-0000-0000-0000-000000000000	dac66337-1b2d-4bd3-ad75-a6ea07fe63e3	{"action":"login","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 01:25:13.786655+00	
00000000-0000-0000-0000-000000000000	c9915e41-e008-4c01-b87d-9c6a85d2eb90	{"action":"logout","actor_id":"63f32a86-6e57-4728-a254-df0f14987d68","actor_username":"patient@test.com","actor_via_sso":false,"log_type":"account"}	2025-09-30 01:25:42.611608+00	
00000000-0000-0000-0000-000000000000	edda13d2-dd7e-40c8-b163-184be26c7a6e	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 01:25:54.325141+00	
00000000-0000-0000-0000-000000000000	dcc41f03-4ae8-4b5d-adef-48ad5c17bc28	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 01:30:13.272597+00	
00000000-0000-0000-0000-000000000000	0bd18c03-a006-4ff5-aaa0-a5a2ad55f158	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 01:32:46.63178+00	
00000000-0000-0000-0000-000000000000	c753fd69-bfe7-4c41-8eaa-09ed04e190a4	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 02:12:26.839407+00	
00000000-0000-0000-0000-000000000000	12a7e4e3-f9e6-4709-baa4-84f017abe502	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 02:17:39.791586+00	
00000000-0000-0000-0000-000000000000	919be8ef-c1a0-4128-b501-479249a8d002	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 02:23:16.990314+00	
00000000-0000-0000-0000-000000000000	5fa03bd8-2fbe-4487-927f-8da0a8ae3aca	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 02:50:47.853562+00	
00000000-0000-0000-0000-000000000000	9ada062d-1b69-4f88-8ccc-184df692cae1	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 02:53:10.660154+00	
00000000-0000-0000-0000-000000000000	556cd731-b416-4d2f-9353-7b465ee8b6f5	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 02:56:05.902894+00	
00000000-0000-0000-0000-000000000000	0c6276e5-8eff-40e6-8d39-648c1a40bb3b	{"action":"token_refreshed","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-09-30 14:38:51.702213+00	
00000000-0000-0000-0000-000000000000	35ccadc1-48bf-4a83-aa39-c1b4a79a9f2d	{"action":"token_revoked","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"token"}	2025-09-30 14:38:51.702803+00	
00000000-0000-0000-0000-000000000000	dbfafa51-f95e-4f95-8096-808e61f98b08	{"action":"login","actor_id":"e6e0a334-66bc-4e11-9447-c6ac75c295e4","actor_username":"adminexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 14:39:16.206811+00	
00000000-0000-0000-0000-000000000000	ad179f34-a632-4f9b-9bb6-0be6a5055ac2	{"action":"login","actor_id":"f071d913-6faa-4d8a-baee-9215992408b5","actor_username":"providerexample@test.com","actor_via_sso":false,"log_type":"account","traits":{"provider":"email"}}	2025-09-30 15:52:44.212071+00	
\.


--
-- TOC entry 4623 (class 0 OID 18161)
-- Dependencies: 321
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at) FROM stdin;
\.


--
-- TOC entry 4614 (class 0 OID 17959)
-- Dependencies: 312
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
63f32a86-6e57-4728-a254-df0f14987d68	63f32a86-6e57-4728-a254-df0f14987d68	{"sub": "63f32a86-6e57-4728-a254-df0f14987d68", "role": "patient", "email": "patient@test.com", "last_name": "example", "first_name": "patient", "email_verified": false, "phone_verified": false}	email	2025-09-29 19:13:41.559434+00	2025-09-29 19:13:41.55945+00	2025-09-29 19:13:41.55945+00	1506b368-8c27-4635-bc81-93fe9f767f9b
e6e0a334-66bc-4e11-9447-c6ac75c295e4	e6e0a334-66bc-4e11-9447-c6ac75c295e4	{"sub": "e6e0a334-66bc-4e11-9447-c6ac75c295e4", "role": "admin", "email": "adminexample@test.com", "last_name": "example", "first_name": "admin", "email_verified": false, "phone_verified": false}	email	2025-09-29 19:14:13.337689+00	2025-09-29 19:14:13.337734+00	2025-09-29 19:14:13.337734+00	efee8f53-7762-498e-9ae3-4174fb36a4e6
f071d913-6faa-4d8a-baee-9215992408b5	f071d913-6faa-4d8a-baee-9215992408b5	{"sub": "f071d913-6faa-4d8a-baee-9215992408b5", "role": "provider", "email": "providerexample@test.com", "phone": "", "last_name": "example", "specialty": "weight loss", "first_name": "provider", "email_verified": false, "license_number": "1234567890", "phone_verified": false}	email	2025-09-29 19:14:56.422635+00	2025-09-29 19:14:56.42265+00	2025-09-29 19:14:56.42265+00	9793f1a6-407e-4bb2-8a61-570bb278ba29
\.


--
-- TOC entry 4591 (class 0 OID 16481)
-- Dependencies: 272
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4618 (class 0 OID 18048)
-- Dependencies: 316
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
2f7ed4b2-3d69-4e05-a728-e8a592ed3dc7	2025-09-29 20:35:26.623465+00	2025-09-29 20:35:26.623465+00	password	b06e99ba-b2b6-466f-aac6-e150a6fe9a39
f0071449-5194-4ee4-a36c-5dd1bf402bb1	2025-09-29 20:53:53.730711+00	2025-09-29 20:53:53.730711+00	password	0d8452cd-df98-443a-82b3-06e324923d8c
6de37132-33eb-4ab9-9da5-70e709513b2d	2025-09-29 21:02:15.946634+00	2025-09-29 21:02:15.946634+00	password	a4dfd22d-ae16-46bb-8b10-51a9d057817e
8c347cd3-dc96-4499-b00b-ec82fc6bbbab	2025-09-30 01:23:45.655449+00	2025-09-30 01:23:45.655449+00	password	2950a619-e666-4c2c-a3a8-f83e06c0fa28
36574895-9742-41e8-8d51-1149b40448c6	2025-09-30 01:25:54.326597+00	2025-09-30 01:25:54.326597+00	password	d86dfc07-cc1c-4b95-a76b-b7670e8f2c3e
74b294ab-28df-467a-9b09-b6d31ea903a1	2025-09-30 01:30:13.273825+00	2025-09-30 01:30:13.273825+00	password	3c320e80-e3a1-43bc-9c42-a68dd46aae02
27a5d20d-3c05-4d77-a12b-2a4ec25999dc	2025-09-30 01:32:46.633248+00	2025-09-30 01:32:46.633248+00	password	6579e458-7cbd-4f57-ad1f-3ecf4a6c4937
4016f8f1-b939-4ed7-add8-65ef74dc4658	2025-09-30 02:12:26.84139+00	2025-09-30 02:12:26.84139+00	password	17c9e985-7ad8-4ac6-8e64-eb50ec6f7b7c
f8c39fce-b2bb-4d69-8829-7a2caceec148	2025-09-30 02:17:39.793535+00	2025-09-30 02:17:39.793535+00	password	b4706812-d85c-49a9-a68e-82293e8378ff
42926caa-b291-41e0-ab62-a9f7bae6e222	2025-09-30 02:23:16.991823+00	2025-09-30 02:23:16.991823+00	password	1b2a8282-d00d-42b9-9fe1-01586b87a3a3
75249d00-e680-4605-9bd8-80dc5be014d9	2025-09-30 02:50:47.855374+00	2025-09-30 02:50:47.855374+00	password	58a85d73-d631-4263-ae47-020fdc303cd6
0ef480f2-4fc4-42c3-b396-cc647d998b81	2025-09-30 02:53:10.661484+00	2025-09-30 02:53:10.661484+00	password	0e55ec32-3d4a-4c1c-8856-ca6125c8174d
5baf245e-6ff0-46b9-80d1-1b3feb07951f	2025-09-30 02:56:05.904855+00	2025-09-30 02:56:05.904855+00	password	92cab1fd-3a81-42d5-b64e-844d12d2d8e9
7ce27bcb-2376-47d4-b5f9-f1ecec756710	2025-09-30 14:39:16.20799+00	2025-09-30 14:39:16.20799+00	password	059a11eb-7fba-4d8e-83af-28e44281e6f7
aa8a04a9-dd91-42a0-a63b-aea03a98daaf	2025-09-30 15:52:44.214269+00	2025-09-30 15:52:44.214269+00	password	b7f7efc1-2145-4f7e-96cc-97aff2981825
\.


--
-- TOC entry 4617 (class 0 OID 18036)
-- Dependencies: 315
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- TOC entry 4616 (class 0 OID 18023)
-- Dependencies: 314
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid) FROM stdin;
\.


--
-- TOC entry 4625 (class 0 OID 18243)
-- Dependencies: 323
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_clients (id, client_id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- TOC entry 4624 (class 0 OID 18211)
-- Dependencies: 322
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4590 (class 0 OID 16470)
-- Dependencies: 271
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
00000000-0000-0000-0000-000000000000	12	ycipuc3x7kdn	e6e0a334-66bc-4e11-9447-c6ac75c295e4	f	2025-09-29 20:35:26.622661+00	2025-09-29 20:35:26.622661+00	\N	2f7ed4b2-3d69-4e05-a728-e8a592ed3dc7
00000000-0000-0000-0000-000000000000	13	pgkfu3c4obcw	e6e0a334-66bc-4e11-9447-c6ac75c295e4	f	2025-09-29 20:53:53.730253+00	2025-09-29 20:53:53.730253+00	\N	f0071449-5194-4ee4-a36c-5dd1bf402bb1
00000000-0000-0000-0000-000000000000	14	wgpou6m6vij7	e6e0a334-66bc-4e11-9447-c6ac75c295e4	f	2025-09-29 21:02:15.946058+00	2025-09-29 21:02:15.946058+00	\N	6de37132-33eb-4ab9-9da5-70e709513b2d
00000000-0000-0000-0000-000000000000	28	c5dnyzublqoj	f071d913-6faa-4d8a-baee-9215992408b5	f	2025-09-30 01:23:45.654937+00	2025-09-30 01:23:45.654937+00	\N	8c347cd3-dc96-4499-b00b-ec82fc6bbbab
00000000-0000-0000-0000-000000000000	30	2hmz5jztfrkt	f071d913-6faa-4d8a-baee-9215992408b5	f	2025-09-30 01:25:54.326028+00	2025-09-30 01:25:54.326028+00	\N	36574895-9742-41e8-8d51-1149b40448c6
00000000-0000-0000-0000-000000000000	31	5l4b53gluee4	f071d913-6faa-4d8a-baee-9215992408b5	f	2025-09-30 01:30:13.273381+00	2025-09-30 01:30:13.273381+00	\N	74b294ab-28df-467a-9b09-b6d31ea903a1
00000000-0000-0000-0000-000000000000	32	3gk2alx2kjjr	f071d913-6faa-4d8a-baee-9215992408b5	f	2025-09-30 01:32:46.632627+00	2025-09-30 01:32:46.632627+00	\N	27a5d20d-3c05-4d77-a12b-2a4ec25999dc
00000000-0000-0000-0000-000000000000	33	ks6zafappsyu	f071d913-6faa-4d8a-baee-9215992408b5	f	2025-09-30 02:12:26.840714+00	2025-09-30 02:12:26.840714+00	\N	4016f8f1-b939-4ed7-add8-65ef74dc4658
00000000-0000-0000-0000-000000000000	34	5a72ce2zm6cq	f071d913-6faa-4d8a-baee-9215992408b5	f	2025-09-30 02:17:39.792903+00	2025-09-30 02:17:39.792903+00	\N	f8c39fce-b2bb-4d69-8829-7a2caceec148
00000000-0000-0000-0000-000000000000	35	4q7evlhnwdrn	f071d913-6faa-4d8a-baee-9215992408b5	f	2025-09-30 02:23:16.991196+00	2025-09-30 02:23:16.991196+00	\N	42926caa-b291-41e0-ab62-a9f7bae6e222
00000000-0000-0000-0000-000000000000	36	unmljjgkqkqb	f071d913-6faa-4d8a-baee-9215992408b5	f	2025-09-30 02:50:47.854739+00	2025-09-30 02:50:47.854739+00	\N	75249d00-e680-4605-9bd8-80dc5be014d9
00000000-0000-0000-0000-000000000000	37	sz7ct4mmmrrq	f071d913-6faa-4d8a-baee-9215992408b5	f	2025-09-30 02:53:10.660949+00	2025-09-30 02:53:10.660949+00	\N	0ef480f2-4fc4-42c3-b396-cc647d998b81
00000000-0000-0000-0000-000000000000	38	aa62y5wxzlc5	f071d913-6faa-4d8a-baee-9215992408b5	t	2025-09-30 02:56:05.904231+00	2025-09-30 14:38:51.703091+00	\N	5baf245e-6ff0-46b9-80d1-1b3feb07951f
00000000-0000-0000-0000-000000000000	39	vp5blp2xjruh	f071d913-6faa-4d8a-baee-9215992408b5	f	2025-09-30 14:38:51.703652+00	2025-09-30 14:38:51.703652+00	aa62y5wxzlc5	5baf245e-6ff0-46b9-80d1-1b3feb07951f
00000000-0000-0000-0000-000000000000	40	nykqwky3fpu2	e6e0a334-66bc-4e11-9447-c6ac75c295e4	f	2025-09-30 14:39:16.207551+00	2025-09-30 14:39:16.207551+00	\N	7ce27bcb-2376-47d4-b5f9-f1ecec756710
00000000-0000-0000-0000-000000000000	41	qcfhzrrsbycq	f071d913-6faa-4d8a-baee-9215992408b5	f	2025-09-30 15:52:44.213461+00	2025-09-30 15:52:44.213461+00	\N	aa8a04a9-dd91-42a0-a63b-aea03a98daaf
\.


--
-- TOC entry 4621 (class 0 OID 18090)
-- Dependencies: 319
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- TOC entry 4622 (class 0 OID 18108)
-- Dependencies: 320
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- TOC entry 4593 (class 0 OID 16496)
-- Dependencies: 274
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
\.


--
-- TOC entry 4615 (class 0 OID 17989)
-- Dependencies: 313
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag) FROM stdin;
2f7ed4b2-3d69-4e05-a728-e8a592ed3dc7	e6e0a334-66bc-4e11-9447-c6ac75c295e4	2025-09-29 20:35:26.622039+00	2025-09-29 20:35:26.622039+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	172.217.12.106	\N
f0071449-5194-4ee4-a36c-5dd1bf402bb1	e6e0a334-66bc-4e11-9447-c6ac75c295e4	2025-09-29 20:53:53.729784+00	2025-09-29 20:53:53.729784+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	172.217.12.106	\N
6de37132-33eb-4ab9-9da5-70e709513b2d	e6e0a334-66bc-4e11-9447-c6ac75c295e4	2025-09-29 21:02:15.945418+00	2025-09-29 21:02:15.945418+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	172.217.12.106	\N
8c347cd3-dc96-4499-b00b-ec82fc6bbbab	f071d913-6faa-4d8a-baee-9215992408b5	2025-09-30 01:23:45.654599+00	2025-09-30 01:23:45.654599+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	172.217.12.106	\N
36574895-9742-41e8-8d51-1149b40448c6	f071d913-6faa-4d8a-baee-9215992408b5	2025-09-30 01:25:54.325591+00	2025-09-30 01:25:54.325591+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	172.217.12.106	\N
74b294ab-28df-467a-9b09-b6d31ea903a1	f071d913-6faa-4d8a-baee-9215992408b5	2025-09-30 01:30:13.272995+00	2025-09-30 01:30:13.272995+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	172.217.12.106	\N
27a5d20d-3c05-4d77-a12b-2a4ec25999dc	f071d913-6faa-4d8a-baee-9215992408b5	2025-09-30 01:32:46.632207+00	2025-09-30 01:32:46.632207+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	172.217.12.106	\N
4016f8f1-b939-4ed7-add8-65ef74dc4658	f071d913-6faa-4d8a-baee-9215992408b5	2025-09-30 02:12:26.840049+00	2025-09-30 02:12:26.840049+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	172.217.12.106	\N
f8c39fce-b2bb-4d69-8829-7a2caceec148	f071d913-6faa-4d8a-baee-9215992408b5	2025-09-30 02:17:39.792178+00	2025-09-30 02:17:39.792178+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	172.217.12.106	\N
42926caa-b291-41e0-ab62-a9f7bae6e222	f071d913-6faa-4d8a-baee-9215992408b5	2025-09-30 02:23:16.990824+00	2025-09-30 02:23:16.990824+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	172.217.12.106	\N
75249d00-e680-4605-9bd8-80dc5be014d9	f071d913-6faa-4d8a-baee-9215992408b5	2025-09-30 02:50:47.854343+00	2025-09-30 02:50:47.854343+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	172.217.12.106	\N
0ef480f2-4fc4-42c3-b396-cc647d998b81	f071d913-6faa-4d8a-baee-9215992408b5	2025-09-30 02:53:10.660608+00	2025-09-30 02:53:10.660608+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	172.217.12.106	\N
5baf245e-6ff0-46b9-80d1-1b3feb07951f	f071d913-6faa-4d8a-baee-9215992408b5	2025-09-30 02:56:05.903642+00	2025-09-30 14:38:51.70465+00	\N	aal1	\N	2025-09-30 14:38:51.704631	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	172.217.12.106	\N
7ce27bcb-2376-47d4-b5f9-f1ecec756710	e6e0a334-66bc-4e11-9447-c6ac75c295e4	2025-09-30 14:39:16.207194+00	2025-09-30 14:39:16.207194+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	172.217.12.106	\N
aa8a04a9-dd91-42a0-a63b-aea03a98daaf	f071d913-6faa-4d8a-baee-9215992408b5	2025-09-30 15:52:44.212908+00	2025-09-30 15:52:44.212908+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	172.217.12.106	\N
\.


--
-- TOC entry 4620 (class 0 OID 18075)
-- Dependencies: 318
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4619 (class 0 OID 18066)
-- Dependencies: 317
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- TOC entry 4588 (class 0 OID 16458)
-- Dependencies: 269
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\N	22222222-2222-2222-2222-222222222222	\N	\N	michael.r@test.com	$2a$10$dummyhashformichaelroberts	2025-09-29 18:50:37.391785+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	33333333-3333-3333-3333-333333333333	\N	\N	jennifer.m@test.com	$2a$10$dummyhashforjennifermartinez	2025-09-29 18:50:37.391785+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	44444444-4444-4444-4444-444444444444	\N	\N	david.a@test.com	$2a$10$dummyhashfordavidanderson	2025-09-29 18:50:37.391785+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb	\N	\N	dr.watson@test.com	$2a$10$dummyhashfordrwatson	2025-09-29 18:50:37.391785+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	cccccccc-cccc-cccc-cccc-cccccccccccc	\N	\N	dr.wilson@test.com	$2a$10$dummyhashfordrwilson	2025-09-29 18:50:37.391785+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa	\N	\N	admin@test.com	admin123	2025-09-29 18:50:37.39972+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"role": "admin", "last_name": "User", "first_name": "Admin"}	\N	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.39972+00	\N	\N			\N		0	\N		\N	f	\N	f
\N	11111111-1111-1111-1111-111111111111	\N	\N	sarah.j@test.com	patient123	2025-09-29 18:50:37.39972+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"role": "patient", "last_name": "Johnson", "first_name": "Sarah"}	\N	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.39972+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f071d913-6faa-4d8a-baee-9215992408b5	authenticated	authenticated	providerexample@test.com	$2a$10$ofG2KjDlXvPPNJx2VoGgxuKYDjCv5w0Fwx65rGI0KdhUyud/cv6nC	2025-09-29 19:14:56.42368+00	\N		\N		\N			\N	2025-09-30 15:52:44.21285+00	{"provider": "email", "providers": ["email"]}	{"sub": "f071d913-6faa-4d8a-baee-9215992408b5", "role": "provider", "email": "providerexample@test.com", "phone": "", "last_name": "example", "specialty": "weight loss", "first_name": "provider", "email_verified": true, "license_number": "1234567890", "phone_verified": false}	\N	2025-09-29 19:14:56.42059+00	2025-09-30 15:52:44.21408+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	63f32a86-6e57-4728-a254-df0f14987d68	authenticated	authenticated	patient@test.com	$2a$10$MYbunnOyIsyWBpRMBayJ6eBfdjsUpsfzRnr7/6tIV8a10jryf9mZq	2025-09-29 19:13:41.560862+00	\N		\N		\N			\N	2025-09-30 01:25:13.787004+00	{"provider": "email", "providers": ["email"]}	{"sub": "63f32a86-6e57-4728-a254-df0f14987d68", "role": "patient", "email": "patient@test.com", "last_name": "example", "first_name": "patient", "email_verified": true, "phone_verified": false}	\N	2025-09-29 19:13:41.556514+00	2025-09-30 01:25:13.78791+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	e6e0a334-66bc-4e11-9447-c6ac75c295e4	authenticated	authenticated	adminexample@test.com	$2a$10$JFw1yklFU27EZwVndm/hkOX6oq8tK9IJNKuV.Ev4bK7alIVD58ijO	2025-09-29 19:14:13.338712+00	\N		\N		\N			\N	2025-09-30 14:39:16.207169+00	{"provider": "email", "providers": ["email"]}	{"sub": "e6e0a334-66bc-4e11-9447-c6ac75c295e4", "role": "admin", "email": "adminexample@test.com", "last_name": "example", "first_name": "admin", "email_verified": true, "phone_verified": false}	\N	2025-09-29 19:14:13.336077+00	2025-09-30 14:39:16.207889+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- TOC entry 4629 (class 0 OID 18320)
-- Dependencies: 328
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admins (id, profile_id, permissions, active, created_at, updated_at) FROM stdin;
8352d4f6-cad2-45e1-9e9e-28e3a915a4f5	e6e0a334-66bc-4e11-9447-c6ac75c295e4	{dashboard,patients,providers,assignments}	t	2025-09-29 19:14:13.335877+00	2025-09-29 19:14:13.335877+00
\.


--
-- TOC entry 4640 (class 0 OID 18625)
-- Dependencies: 339
-- Data for Name: appointment_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appointment_history (id, appointment_id, action, performed_by, performed_by_user_id, old_values, new_values, reason, created_at) FROM stdin;
9966c6f4-d7c9-40d1-a35a-c004921401ec	925c3d7b-e397-4736-bbdc-111bf2cb50c0	created	system	\N	\N	{"id": "925c3d7b-e397-4736-bbdc-111bf2cb50c0", "status": "scheduled", "end_time": "09:30:00", "booked_by": "patient", "created_at": "2025-09-29T19:24:27.271924+00:00", "patient_id": "9cd6eff9-2da4-4bb5-a71a-632906a7729f", "start_time": "09:00:00", "updated_at": "2025-09-29T19:24:27.271924+00:00", "admin_notes": null, "provider_id": "2b66f207-2ae5-442b-8911-ada9c96779cb", "cancelled_at": null, "cancelled_by": null, "assignment_id": "e2914e2d-3fb9-45e3-8a2b-3d35b74fbe66", "patient_notes": "Initial consultation for Semaglutide Visit", "provider_notes": null, "treatment_type": "weight_loss", "appointment_date": "2025-10-06", "appointment_type": "consultation", "duration_minutes": 30, "reschedule_count": 0, "booked_by_user_id": "63f32a86-6e57-4728-a254-df0f14987d68", "booking_timestamp": "2025-09-29T19:24:27.271924+00:00", "rescheduled_to_id": null, "cancellation_reason": null, "rescheduled_from_id": null, "cancelled_by_user_id": null, "is_reschedule_source": false}	\N	2025-09-29 19:24:27.271924+00
f80ecce9-729c-46d8-99b1-9ef853a5fe70	925c3d7b-e397-4736-bbdc-111bf2cb50c0	rescheduled	system	\N	{"id": "925c3d7b-e397-4736-bbdc-111bf2cb50c0", "status": "scheduled", "end_time": "09:30:00", "booked_by": "patient", "created_at": "2025-09-29T19:24:27.271924+00:00", "patient_id": "9cd6eff9-2da4-4bb5-a71a-632906a7729f", "start_time": "09:00:00", "updated_at": "2025-09-29T19:24:27.271924+00:00", "admin_notes": null, "provider_id": "2b66f207-2ae5-442b-8911-ada9c96779cb", "cancelled_at": null, "cancelled_by": null, "assignment_id": "e2914e2d-3fb9-45e3-8a2b-3d35b74fbe66", "patient_notes": "Initial consultation for Semaglutide Visit", "provider_notes": null, "treatment_type": "weight_loss", "appointment_date": "2025-10-06", "appointment_type": "consultation", "duration_minutes": 30, "reschedule_count": 0, "booked_by_user_id": "63f32a86-6e57-4728-a254-df0f14987d68", "booking_timestamp": "2025-09-29T19:24:27.271924+00:00", "rescheduled_to_id": null, "cancellation_reason": null, "rescheduled_from_id": null, "cancelled_by_user_id": null, "is_reschedule_source": false}	{"id": "925c3d7b-e397-4736-bbdc-111bf2cb50c0", "status": "scheduled", "end_time": "10:00:00", "booked_by": "patient", "created_at": "2025-09-29T19:24:27.271924+00:00", "patient_id": "9cd6eff9-2da4-4bb5-a71a-632906a7729f", "start_time": "09:30:00", "updated_at": "2025-09-29T19:33:37.541+00:00", "admin_notes": "Rescheduled by admin", "provider_id": "2b66f207-2ae5-442b-8911-ada9c96779cb", "cancelled_at": null, "cancelled_by": null, "assignment_id": "e2914e2d-3fb9-45e3-8a2b-3d35b74fbe66", "patient_notes": "Initial consultation for Semaglutide Visit", "provider_notes": null, "treatment_type": "weight_loss", "appointment_date": "2025-10-08", "appointment_type": "consultation", "duration_minutes": 30, "reschedule_count": 0, "booked_by_user_id": "63f32a86-6e57-4728-a254-df0f14987d68", "booking_timestamp": "2025-09-29T19:24:27.271924+00:00", "rescheduled_to_id": null, "cancellation_reason": null, "rescheduled_from_id": null, "cancelled_by_user_id": null, "is_reschedule_source": false}	\N	2025-09-29 19:33:37.555505+00
bb209fbe-362e-4559-a291-6c550e135f88	925c3d7b-e397-4736-bbdc-111bf2cb50c0	rescheduled	system	\N	{"id": "925c3d7b-e397-4736-bbdc-111bf2cb50c0", "status": "scheduled", "end_time": "10:00:00", "booked_by": "patient", "created_at": "2025-09-29T19:24:27.271924+00:00", "patient_id": "9cd6eff9-2da4-4bb5-a71a-632906a7729f", "start_time": "09:30:00", "updated_at": "2025-09-29T19:33:37.541+00:00", "admin_notes": "Rescheduled by admin", "provider_id": "2b66f207-2ae5-442b-8911-ada9c96779cb", "cancelled_at": null, "cancelled_by": null, "assignment_id": "e2914e2d-3fb9-45e3-8a2b-3d35b74fbe66", "patient_notes": "Initial consultation for Semaglutide Visit", "provider_notes": null, "treatment_type": "weight_loss", "appointment_date": "2025-10-08", "appointment_type": "consultation", "duration_minutes": 30, "reschedule_count": 0, "booked_by_user_id": "63f32a86-6e57-4728-a254-df0f14987d68", "booking_timestamp": "2025-09-29T19:24:27.271924+00:00", "rescheduled_to_id": null, "cancellation_reason": null, "rescheduled_from_id": null, "cancelled_by_user_id": null, "is_reschedule_source": false}	{"id": "925c3d7b-e397-4736-bbdc-111bf2cb50c0", "status": "scheduled", "end_time": "10:30:00", "booked_by": "patient", "created_at": "2025-09-29T19:24:27.271924+00:00", "patient_id": "9cd6eff9-2da4-4bb5-a71a-632906a7729f", "start_time": "10:00:00", "updated_at": "2025-09-29T21:02:31.797+00:00", "admin_notes": "Rescheduled by admin", "provider_id": "2b66f207-2ae5-442b-8911-ada9c96779cb", "cancelled_at": null, "cancelled_by": null, "assignment_id": "e2914e2d-3fb9-45e3-8a2b-3d35b74fbe66", "patient_notes": "Initial consultation for Semaglutide Visit", "provider_notes": null, "treatment_type": "weight_loss", "appointment_date": "2025-10-09", "appointment_type": "consultation", "duration_minutes": 30, "reschedule_count": 0, "booked_by_user_id": "63f32a86-6e57-4728-a254-df0f14987d68", "booking_timestamp": "2025-09-29T19:24:27.271924+00:00", "rescheduled_to_id": null, "cancellation_reason": null, "rescheduled_from_id": null, "cancelled_by_user_id": null, "is_reschedule_source": false}	\N	2025-09-29 21:02:31.818341+00
49e31309-ae82-4f33-bacd-880f7af68a9c	63fe7478-80d6-4576-bb16-bf0d3e9d75fb	created	system	\N	\N	{"id": "63fe7478-80d6-4576-bb16-bf0d3e9d75fb", "status": "scheduled", "end_time": "09:30:00", "booked_by": "patient", "created_at": "2025-09-29T21:08:41.213474+00:00", "patient_id": "9cd6eff9-2da4-4bb5-a71a-632906a7729f", "start_time": "09:00:00", "updated_at": "2025-09-29T21:08:41.213474+00:00", "admin_notes": null, "provider_id": "2b66f207-2ae5-442b-8911-ada9c96779cb", "cancelled_at": null, "cancelled_by": null, "assignment_id": "e2914e2d-3fb9-45e3-8a2b-3d35b74fbe66", "patient_notes": "Initial consultation for Tirzepatide Visit", "provider_notes": null, "treatment_type": "weight_loss", "appointment_date": "2025-10-02", "appointment_type": "consultation", "duration_minutes": 30, "reschedule_count": 0, "booked_by_user_id": "63f32a86-6e57-4728-a254-df0f14987d68", "booking_timestamp": "2025-09-29T21:08:41.213474+00:00", "rescheduled_to_id": null, "cancellation_reason": null, "rescheduled_from_id": null, "cancelled_by_user_id": null, "is_reschedule_source": false}	\N	2025-09-29 21:08:41.213474+00
f6e2c20a-4da4-4003-9ab0-eef7d93e00b1	ea7b3f15-bcf5-44bb-8178-e4ec5c5431a3	created	system	\N	\N	{"id": "ea7b3f15-bcf5-44bb-8178-e4ec5c5431a3", "status": "scheduled", "end_time": "10:00:00", "booked_by": "patient", "created_at": "2025-09-29T22:06:24.764745+00:00", "patient_id": "9cd6eff9-2da4-4bb5-a71a-632906a7729f", "start_time": "09:30:00", "updated_at": "2025-09-29T22:06:24.764745+00:00", "admin_notes": null, "provider_id": "2b66f207-2ae5-442b-8911-ada9c96779cb", "cancelled_at": null, "cancelled_by": null, "assignment_id": "e2914e2d-3fb9-45e3-8a2b-3d35b74fbe66", "patient_notes": "Initial consultation for Tirzepatide Visit", "provider_notes": null, "treatment_type": "weight_loss", "appointment_date": "2025-10-02", "appointment_type": "consultation", "duration_minutes": 30, "reschedule_count": 0, "booked_by_user_id": "63f32a86-6e57-4728-a254-df0f14987d68", "booking_timestamp": "2025-09-29T22:06:24.764745+00:00", "rescheduled_to_id": null, "cancellation_reason": null, "rescheduled_from_id": null, "cancelled_by_user_id": null, "is_reschedule_source": false}	\N	2025-09-29 22:06:24.764745+00
37568943-acc6-4233-9b6e-afc7c785a308	1a1e0740-8fae-4431-87bf-888101f3eb5e	created	system	\N	\N	{"id": "1a1e0740-8fae-4431-87bf-888101f3eb5e", "status": "scheduled", "end_time": "09:30:00", "booked_by": "patient", "created_at": "2025-09-29T22:25:43.074844+00:00", "patient_id": "9cd6eff9-2da4-4bb5-a71a-632906a7729f", "start_time": "09:00:00", "updated_at": "2025-09-29T22:25:43.074844+00:00", "admin_notes": null, "provider_id": "2b66f207-2ae5-442b-8911-ada9c96779cb", "cancelled_at": null, "cancelled_by": null, "assignment_id": "e2914e2d-3fb9-45e3-8a2b-3d35b74fbe66", "patient_notes": "Initial consultation for Tirzepatide Visit", "provider_notes": null, "treatment_type": "weight_loss", "appointment_date": "2025-10-08", "appointment_type": "consultation", "duration_minutes": 30, "reschedule_count": 0, "booked_by_user_id": "63f32a86-6e57-4728-a254-df0f14987d68", "booking_timestamp": "2025-09-29T22:25:43.074844+00:00", "rescheduled_to_id": null, "cancellation_reason": null, "rescheduled_from_id": null, "cancelled_by_user_id": null, "is_reschedule_source": false}	\N	2025-09-29 22:25:43.074844+00
84f26ea5-4d40-4dbd-b093-e4ae15ebe2bf	6c2be801-d728-42c0-aa1e-ea392a85a7ae	created	system	\N	\N	{"id": "6c2be801-d728-42c0-aa1e-ea392a85a7ae", "status": "scheduled", "end_time": "09:30:00", "booked_by": "patient", "created_at": "2025-09-30T00:40:42.040806+00:00", "patient_id": "9cd6eff9-2da4-4bb5-a71a-632906a7729f", "start_time": "09:00:00", "updated_at": "2025-09-30T00:40:42.040806+00:00", "admin_notes": null, "provider_id": "2b66f207-2ae5-442b-8911-ada9c96779cb", "cancelled_at": null, "cancelled_by": null, "assignment_id": "e2914e2d-3fb9-45e3-8a2b-3d35b74fbe66", "patient_notes": "Initial consultation for Tirzepatide Visit", "provider_notes": null, "treatment_type": "weight_loss", "appointment_date": "2025-10-06", "appointment_type": "consultation", "duration_minutes": 30, "reschedule_count": 0, "booked_by_user_id": "63f32a86-6e57-4728-a254-df0f14987d68", "booking_timestamp": "2025-09-30T00:40:42.040806+00:00", "rescheduled_to_id": null, "cancellation_reason": null, "rescheduled_from_id": null, "cancelled_by_user_id": null, "is_reschedule_source": false}	\N	2025-09-30 00:40:42.040806+00
dbe1eafa-d232-4cf6-aacb-31a068c593cb	8785e6d1-cd74-4c7e-959a-581aff369df0	created	system	\N	\N	{"id": "8785e6d1-cd74-4c7e-959a-581aff369df0", "status": "scheduled", "end_time": "10:00:00", "booked_by": "patient", "created_at": "2025-09-30T01:25:20.855484+00:00", "patient_id": "9cd6eff9-2da4-4bb5-a71a-632906a7729f", "start_time": "09:30:00", "updated_at": "2025-09-30T01:25:20.855484+00:00", "admin_notes": null, "provider_id": "2b66f207-2ae5-442b-8911-ada9c96779cb", "cancelled_at": null, "cancelled_by": null, "assignment_id": "e2914e2d-3fb9-45e3-8a2b-3d35b74fbe66", "patient_notes": "Initial consultation for Tirzepatide Visit", "provider_notes": null, "treatment_type": "weight_loss", "appointment_date": "2025-10-06", "appointment_type": "consultation", "duration_minutes": 30, "reschedule_count": 0, "booked_by_user_id": "63f32a86-6e57-4728-a254-df0f14987d68", "booking_timestamp": "2025-09-30T01:25:20.855484+00:00", "rescheduled_to_id": null, "cancellation_reason": null, "rescheduled_from_id": null, "cancelled_by_user_id": null, "is_reschedule_source": false}	\N	2025-09-30 01:25:20.855484+00
\.


--
-- TOC entry 4639 (class 0 OID 18587)
-- Dependencies: 338
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appointments (id, patient_id, provider_id, assignment_id, appointment_date, start_time, end_time, duration_minutes, treatment_type, appointment_type, status, patient_notes, provider_notes, admin_notes, booked_by, booked_by_user_id, booking_timestamp, cancelled_at, cancelled_by, cancelled_by_user_id, cancellation_reason, created_at, updated_at, rescheduled_from_id, rescheduled_to_id, is_reschedule_source, reschedule_count) FROM stdin;
1dda6efb-6c80-46a8-88a7-1c09deba1fae	ed86babf-e6fc-4fb0-b0ec-3e11ad6be97c	b692a67a-1356-43a8-a753-af4dd00fbf1d	\N	2025-10-08	11:30:00	12:00:00	30	weight_loss	consultation	scheduled	Initial consultation for weight management	\N	\N	patient	11111111-1111-1111-1111-111111111111	2025-09-29 18:50:40.531598+00	\N	\N	\N	\N	2025-09-29 18:50:40.531598+00	2025-09-29 18:50:40.531598+00	\N	\N	f	0
2dda6efb-6c80-46a8-88a7-1c09deba2fae	ed86babf-e6fc-4fb0-b0ec-3e11ad6be97c	b692a67a-1356-43a8-a753-af4dd00fbf1d	\N	2025-10-01	09:00:00	09:30:00	30	weight_loss	consultation	scheduled	Follow-up consultation	\N	\N	patient	11111111-1111-1111-1111-111111111111	2025-09-29 18:50:40.531598+00	\N	\N	\N	\N	2025-09-29 18:50:40.531598+00	2025-09-29 18:50:40.531598+00	\N	\N	f	0
925c3d7b-e397-4736-bbdc-111bf2cb50c0	9cd6eff9-2da4-4bb5-a71a-632906a7729f	2b66f207-2ae5-442b-8911-ada9c96779cb	e2914e2d-3fb9-45e3-8a2b-3d35b74fbe66	2025-10-09	10:00:00	10:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Semaglutide Visit	\N	Rescheduled by admin	patient	63f32a86-6e57-4728-a254-df0f14987d68	2025-09-29 19:24:27.271924+00	\N	\N	\N	\N	2025-09-29 19:24:27.271924+00	2025-09-29 21:02:31.797+00	\N	\N	f	0
63fe7478-80d6-4576-bb16-bf0d3e9d75fb	9cd6eff9-2da4-4bb5-a71a-632906a7729f	2b66f207-2ae5-442b-8911-ada9c96779cb	e2914e2d-3fb9-45e3-8a2b-3d35b74fbe66	2025-10-02	09:00:00	09:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	63f32a86-6e57-4728-a254-df0f14987d68	2025-09-29 21:08:41.213474+00	\N	\N	\N	\N	2025-09-29 21:08:41.213474+00	2025-09-29 21:08:41.213474+00	\N	\N	f	0
ea7b3f15-bcf5-44bb-8178-e4ec5c5431a3	9cd6eff9-2da4-4bb5-a71a-632906a7729f	2b66f207-2ae5-442b-8911-ada9c96779cb	e2914e2d-3fb9-45e3-8a2b-3d35b74fbe66	2025-10-02	09:30:00	10:00:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	63f32a86-6e57-4728-a254-df0f14987d68	2025-09-29 22:06:24.764745+00	\N	\N	\N	\N	2025-09-29 22:06:24.764745+00	2025-09-29 22:06:24.764745+00	\N	\N	f	0
1a1e0740-8fae-4431-87bf-888101f3eb5e	9cd6eff9-2da4-4bb5-a71a-632906a7729f	2b66f207-2ae5-442b-8911-ada9c96779cb	e2914e2d-3fb9-45e3-8a2b-3d35b74fbe66	2025-10-08	09:00:00	09:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	63f32a86-6e57-4728-a254-df0f14987d68	2025-09-29 22:25:43.074844+00	\N	\N	\N	\N	2025-09-29 22:25:43.074844+00	2025-09-29 22:25:43.074844+00	\N	\N	f	0
6c2be801-d728-42c0-aa1e-ea392a85a7ae	9cd6eff9-2da4-4bb5-a71a-632906a7729f	2b66f207-2ae5-442b-8911-ada9c96779cb	e2914e2d-3fb9-45e3-8a2b-3d35b74fbe66	2025-10-06	09:00:00	09:30:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	63f32a86-6e57-4728-a254-df0f14987d68	2025-09-30 00:40:42.040806+00	\N	\N	\N	\N	2025-09-30 00:40:42.040806+00	2025-09-30 00:40:42.040806+00	\N	\N	f	0
8785e6d1-cd74-4c7e-959a-581aff369df0	9cd6eff9-2da4-4bb5-a71a-632906a7729f	2b66f207-2ae5-442b-8911-ada9c96779cb	e2914e2d-3fb9-45e3-8a2b-3d35b74fbe66	2025-10-06	09:30:00	10:00:00	30	weight_loss	consultation	scheduled	Initial consultation for Tirzepatide Visit	\N	\N	patient	63f32a86-6e57-4728-a254-df0f14987d68	2025-09-30 01:25:20.855484+00	\N	\N	\N	\N	2025-09-30 01:25:20.855484+00	2025-09-30 01:25:20.855484+00	\N	\N	f	0
\.


--
-- TOC entry 4632 (class 0 OID 18409)
-- Dependencies: 331
-- Data for Name: assignment_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assignment_log (id, message, created_at) FROM stdin;
1	Starting provider assignment process	2025-09-29 18:50:37.377949
2	Provider assignment process completed	2025-09-29 18:50:37.377949
\.


--
-- TOC entry 4647 (class 0 OID 18967)
-- Dependencies: 348
-- Data for Name: auth_trigger_debug_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_trigger_debug_log (id, user_id, step, status, error_message, metadata, created_at) FROM stdin;
\.


--
-- TOC entry 4644 (class 0 OID 18839)
-- Dependencies: 345
-- Data for Name: auth_trigger_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_trigger_logs (id, user_id, trigger_stage, success, error_message, metadata, created_at) FROM stdin;
\.


--
-- TOC entry 4641 (class 0 OID 18702)
-- Dependencies: 342
-- Data for Name: clinical_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clinical_notes (id, appointment_id, patient_id, provider_id, allergies, previous_medications, current_medications, clinical_note, internal_note, visit_summary, created_at, updated_at, created_by, last_updated_by) FROM stdin;
\.


--
-- TOC entry 4635 (class 0 OID 18455)
-- Dependencies: 334
-- Data for Name: medication_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medication_approvals (id, preference_id, provider_id, status, approved_dosage, approved_frequency, provider_notes, contraindications, approval_date, created_at, updated_at) FROM stdin;
7d78a2d6-3c95-432d-b96e-ca6ef4ec608f	c4bfd509-f560-441b-9b50-49dda56c8cb0	2b66f207-2ae5-442b-8911-ada9c96779cb	approved	2.8mg	\N		\N	2025-09-29 19:25:23.572+00	2025-09-29 19:25:23.574091+00	2025-09-29 19:25:23.574091+00
\.


--
-- TOC entry 4645 (class 0 OID 18890)
-- Dependencies: 346
-- Data for Name: medication_dosages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medication_dosages (id, medication_id, strength, unit_price, available, sort_order, created_at, updated_at) FROM stdin;
a279a7f9-d0fa-44f4-b700-b338654ac534	3041a238-c095-42a5-9f60-2147a0326f6f	2.5mg	1199.99	t	1	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
a8fa78ef-8a37-4127-a786-f5b38643cef7	6c9019b8-55d4-4869-8b51-971fb1e0311d	1.62%	299.99	t	1	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
bad0a7bb-eba7-4eb5-abd8-a7b20e7ac2fd	7a8160fc-3158-4503-85b4-6112a161fb83	0.5mg	899.99	t	1	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
fb438b76-ed43-4069-ae39-569d56825c44	83e70c4b-7fac-47b5-ac07-7e1fb206a482	37.5mg	89.99	t	1	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
4a77605d-3245-40c0-939b-578423242ffb	98ad9848-5870-4c77-86a7-c11338a62352	50mg	89.99	t	1	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
bf5c126b-e271-4f77-8e45-2a45ac7b97c0	9dacc93f-34a4-4068-af56-efdc7115f697	3.0mg	1099.99	t	1	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
03b036e3-72dc-48cf-84a9-028e2cae182d	9e93afa0-b2df-4019-b4e0-b36e23df602d	20mg	99.99	t	1	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
f7828341-fe6d-448c-9e02-1ee3d37c895a	a73b5b89-7a9b-49c3-9246-4de0e7d0a31c	120mg	199.99	t	1	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
47664fb4-0971-4726-9fee-6eb0440c0d92	e7ad8d2c-fc40-4fd5-b533-acc8a1595d8a	5000 IU	149.99	t	1	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
91eb0f92-16a5-4c10-8b33-c2ab63a49ca0	ec85019b-a96d-44ab-92d5-b5062a9f5af5	200mg/ml	199.99	t	1	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
62fd4402-41a9-4fde-b686-996f9025c278	ecf394c8-bfb1-462d-9612-04138d8214e5	1mg	79.99	t	1	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
39916515-07ec-4fb5-8767-272b916dc880	fa253bcf-df6d-4222-82d0-3b08958330a2	250mg/ml	219.99	t	1	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
5960d3ba-e32b-41d4-b87b-a7b5d879e4eb	ffd7b769-3f56-44b1-abb7-1f94e0c6473f	1.0mg	1299.99	t	1	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
c2020cf3-1357-4e43-b5d6-6f70ae35f441	3041a238-c095-42a5-9f60-2147a0326f6f	5.0mg	1399.99	t	10	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
552abd6f-21ce-48af-968c-f6c7802e1db8	3041a238-c095-42a5-9f60-2147a0326f6f	7.5mg	1599.99	t	20	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
0c4143df-6352-4f30-8749-5c15d354bac7	3041a238-c095-42a5-9f60-2147a0326f6f	10mg	1799.99	t	30	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
07379ca8-f331-4a04-8a37-433f643a9b1c	3041a238-c095-42a5-9f60-2147a0326f6f	12.5mg	1999.99	t	40	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
ac10d6df-d5d7-4544-a358-2d5a32011ef6	3041a238-c095-42a5-9f60-2147a0326f6f	15mg	2199.99	t	50	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
5118ce8c-768e-4252-87c3-5d4a0c5ec5fa	7a8160fc-3158-4503-85b4-6112a161fb83	0.25mg	799.99	t	1	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
b6412552-a0ec-4b65-93dc-45a785d0b301	7a8160fc-3158-4503-85b4-6112a161fb83	1.0mg	999.99	t	11	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
c5255bc1-3f50-4c55-ae9b-3373873f8cda	7a8160fc-3158-4503-85b4-6112a161fb83	2.0mg	1199.99	t	21	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
b8c8a960-89cd-4cdd-b49a-5237b8902af9	ec85019b-a96d-44ab-92d5-b5062a9f5af5	100mg/ml	159.99	t	5	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
20afc852-7465-4358-ac84-3c46fae84232	ec85019b-a96d-44ab-92d5-b5062a9f5af5	250mg/ml	239.99	t	15	2025-09-29 18:50:40.514707+00	2025-09-29 18:50:40.514707+00
\.


--
-- TOC entry 4636 (class 0 OID 18476)
-- Dependencies: 335
-- Data for Name: medication_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medication_orders (id, approval_id, patient_id, medication_id, quantity, unit_price, total_amount, payment_status, payment_method, payment_date, fulfillment_status, tracking_number, shipped_date, estimated_delivery, admin_notes, created_at, updated_at, sent_to_pharmacy) FROM stdin;
0623aa41-bce2-4d18-8a8a-5b20bcb12131	7d78a2d6-3c95-432d-b96e-ca6ef4ec608f	9cd6eff9-2da4-4bb5-a71a-632906a7729f	3041a238-c095-42a5-9f60-2147a0326f6f	1	1199.99	1199.99	paid	payment method example	2025-09-29 00:00:00+00	pending	1846981394868139	2025-09-29 00:00:00+00	2025-10-09 00:00:00+00	internal note example	2025-09-29 19:25:23.590299+00	2025-09-29 19:25:23.590299+00	\N
\.


--
-- TOC entry 4633 (class 0 OID 18418)
-- Dependencies: 332
-- Data for Name: medications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medications (id, name, generic_name, brand_name, dosage_form, strength, description, category, unit_price, requires_prescription, active, created_at, updated_at) FROM stdin;
7a8160fc-3158-4503-85b4-6112a161fb83	Semaglutide	Semaglutide	Ozempic	injection	0.5mg	GLP-1 receptor agonist for weight management and diabetes	weight_loss	899.99	t	t	2025-09-29 18:50:37.385361+00	2025-09-29 18:50:37.385361+00
ffd7b769-3f56-44b1-abb7-1f94e0c6473f	Semaglutide	Semaglutide	Wegovy	injection	1.0mg	GLP-1 receptor agonist specifically for chronic weight management	weight_loss	1299.99	t	t	2025-09-29 18:50:37.385361+00	2025-09-29 18:50:37.385361+00
3041a238-c095-42a5-9f60-2147a0326f6f	Tirzepatide	Tirzepatide	Mounjaro	injection	2.5mg	Dual GIP/GLP-1 receptor agonist for weight loss	weight_loss	1199.99	t	t	2025-09-29 18:50:37.385361+00	2025-09-29 18:50:37.385361+00
9dacc93f-34a4-4068-af56-efdc7115f697	Liraglutide	Liraglutide	Saxenda	injection	3.0mg	GLP-1 receptor agonist for weight management	weight_loss	1099.99	t	t	2025-09-29 18:50:37.385361+00	2025-09-29 18:50:37.385361+00
a73b5b89-7a9b-49c3-9246-4de0e7d0a31c	Orlistat	Orlistat	Xenical	capsule	120mg	Lipase inhibitor for weight loss	weight_loss	199.99	t	t	2025-09-29 18:50:37.385361+00	2025-09-29 18:50:37.385361+00
83e70c4b-7fac-47b5-ac07-7e1fb206a482	Phentermine	Phentermine	Adipex-P	tablet	37.5mg	Appetite suppressant for short-term weight loss	weight_loss	89.99	t	t	2025-09-29 18:50:37.385361+00	2025-09-29 18:50:37.385361+00
ec85019b-a96d-44ab-92d5-b5062a9f5af5	Testosterone Cypionate	Testosterone Cypionate	Depo-Testosterone	injection	200mg/ml	Testosterone replacement therapy for hypogonadism	mens_health	199.99	t	t	2025-09-29 18:50:37.385361+00	2025-09-29 18:50:37.385361+00
fa253bcf-df6d-4222-82d0-3b08958330a2	Testosterone Enanthate	Testosterone Enanthate	Delatestryl	injection	250mg/ml	Long-acting testosterone for hormone replacement	mens_health	219.99	t	t	2025-09-29 18:50:37.385361+00	2025-09-29 18:50:37.385361+00
6c9019b8-55d4-4869-8b51-971fb1e0311d	Testosterone Gel	Testosterone	AndroGel	gel	1.62%	Topical testosterone replacement therapy	mens_health	299.99	t	t	2025-09-29 18:50:37.385361+00	2025-09-29 18:50:37.385361+00
98ad9848-5870-4c77-86a7-c11338a62352	Sildenafil	Sildenafil	Viagra	tablet	50mg	PDE5 inhibitor for erectile dysfunction	mens_health	89.99	t	t	2025-09-29 18:50:37.385361+00	2025-09-29 18:50:37.385361+00
9e93afa0-b2df-4019-b4e0-b36e23df602d	Tadalafil	Tadalafil	Cialis	tablet	20mg	Long-acting PDE5 inhibitor for erectile dysfunction	mens_health	99.99	t	t	2025-09-29 18:50:37.385361+00	2025-09-29 18:50:37.385361+00
ecf394c8-bfb1-462d-9612-04138d8214e5	Finasteride	Finasteride	Propecia	tablet	1mg	5-alpha reductase inhibitor for male pattern baldness	mens_health	79.99	t	t	2025-09-29 18:50:37.385361+00	2025-09-29 18:50:37.385361+00
e7ad8d2c-fc40-4fd5-b533-acc8a1595d8a	HCG	Human Chorionic Gonadotropin	Pregnyl	injection	5000 IU	Hormone therapy to support testosterone production	mens_health	149.99	t	t	2025-09-29 18:50:37.385361+00	2025-09-29 18:50:37.385361+00
\.


--
-- TOC entry 4630 (class 0 OID 18339)
-- Dependencies: 329
-- Data for Name: patient_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patient_assignments (id, patient_id, provider_id, treatment_type, is_primary, assigned_date, active, created_at, updated_at) FROM stdin;
e2914e2d-3fb9-45e3-8a2b-3d35b74fbe66	9cd6eff9-2da4-4bb5-a71a-632906a7729f	2b66f207-2ae5-442b-8911-ada9c96779cb	weight_loss	t	2025-09-29 19:22:11.120874+00	t	2025-09-29 19:22:11.120874+00	2025-09-29 19:22:11.120874+00
\.


--
-- TOC entry 4634 (class 0 OID 18431)
-- Dependencies: 333
-- Data for Name: patient_medication_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patient_medication_preferences (id, patient_id, medication_id, preferred_dosage, frequency, notes, status, requested_date, created_at, updated_at, medication_dosage_id) FROM stdin;
5c957171-1105-47e4-a3a2-b93678f1da12	ed86babf-e6fc-4fb0-b0ec-3e11ad6be97c	7a8160fc-3158-4503-85b4-6112a161fb83	0.5mg	weekly	Starting dose for weight management	pending	2025-09-29 18:50:37.403657+00	2025-09-29 18:50:37.403657+00	2025-09-29 18:50:37.403657+00	bad0a7bb-eba7-4eb5-abd8-a7b20e7ac2fd
bd4f7e6e-1405-41a7-86b6-7e7d0c664c9c	27350986-2c3d-4758-b53b-cce67da34565	ffd7b769-3f56-44b1-abb7-1f94e0c6473f	1.0mg	weekly	Higher dose for weight loss	approved	2025-09-29 18:50:37.403657+00	2025-09-29 18:50:37.403657+00	2025-09-29 18:50:37.403657+00	5960d3ba-e32b-41d4-b87b-a7b5d879e4eb
e9f79517-b336-4bf9-b5b5-58a814680335	6bfd9fca-bb43-4276-ad3e-c20ce1237f61	3041a238-c095-42a5-9f60-2147a0326f6f	2.4mg	weekly	Max dose for significant weight loss	approved	2025-09-29 18:50:37.403657+00	2025-09-29 18:50:37.403657+00	2025-09-29 18:50:37.403657+00	a279a7f9-d0fa-44f4-b700-b338654ac534
737b811b-185c-4367-8f0d-f32f4c878a9b	9e9d1801-60ff-42be-b4e7-58cd8d582f14	7a8160fc-3158-4503-85b4-6112a161fb83	0.25mg	weekly	Starting with lowest dose	pending	2025-09-29 18:50:37.403657+00	2025-09-29 18:50:37.403657+00	2025-09-29 18:50:37.403657+00	bad0a7bb-eba7-4eb5-abd8-a7b20e7ac2fd
c4bfd509-f560-441b-9b50-49dda56c8cb0	9cd6eff9-2da4-4bb5-a71a-632906a7729f	3041a238-c095-42a5-9f60-2147a0326f6f	2.8mg	\N	\N	approved	2025-09-29 19:13:48.431777+00	2025-09-29 19:13:48.431777+00	2025-09-29 19:25:23.551+00	\N
f4b264fc-6115-452d-a41e-ac1bcf869ff9	9cd6eff9-2da4-4bb5-a71a-632906a7729f	ffd7b769-3f56-44b1-abb7-1f94e0c6473f	1.0mg	\N	\N	pending	2025-09-30 01:23:19.159945+00	2025-09-30 01:23:19.159945+00	2025-09-30 01:23:19.159945+00	\N
2e0f391b-d377-4a16-a369-f5d31966a02f	9cd6eff9-2da4-4bb5-a71a-632906a7729f	7a8160fc-3158-4503-85b4-6112a161fb83	0.25mg	\N	\N	pending	2025-09-30 01:25:36.690202+00	2025-09-30 01:25:36.690202+00	2025-09-30 01:25:36.690202+00	\N
\.


--
-- TOC entry 4627 (class 0 OID 18284)
-- Dependencies: 326
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patients (id, profile_id, date_of_birth, phone, has_completed_intake, created_at, updated_at) FROM stdin;
c01da351-1365-4574-935a-8f23b5dbe533	aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa	\N	\N	f	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00
d3a767c8-51ef-4b21-92aa-dd35e67a213b	bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb	\N	\N	f	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00
7e79832c-2531-48cf-9f3a-8db7d2eedd45	cccccccc-cccc-cccc-cccc-cccccccccccc	\N	\N	f	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00
ed86babf-e6fc-4fb0-b0ec-3e11ad6be97c	11111111-1111-1111-1111-111111111111	\N	555-0101	t	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00
27350986-2c3d-4758-b53b-cce67da34565	22222222-2222-2222-2222-222222222222	\N	555-0102	t	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00
6bfd9fca-bb43-4276-ad3e-c20ce1237f61	33333333-3333-3333-3333-333333333333	\N	555-0103	t	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00
9e9d1801-60ff-42be-b4e7-58cd8d582f14	44444444-4444-4444-4444-444444444444	\N	555-0104	t	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00
9cd6eff9-2da4-4bb5-a71a-632906a7729f	63f32a86-6e57-4728-a254-df0f14987d68	\N	\N	f	2025-09-29 19:13:41.556328+00	2025-09-29 19:13:41.556328+00
\.


--
-- TOC entry 4626 (class 0 OID 18267)
-- Dependencies: 325
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (id, email, first_name, last_name, role, created_at, updated_at) FROM stdin;
11111111-1111-1111-1111-111111111111	sarah.j@test.com	Sarah	Johnson	patient	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00
22222222-2222-2222-2222-222222222222	michael.r@test.com	Michael	Roberts	patient	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00
33333333-3333-3333-3333-333333333333	jennifer.m@test.com	Jennifer	Martinez	patient	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00
44444444-4444-4444-4444-444444444444	david.a@test.com	David	Anderson	patient	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00
aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa	admin@test.com	Admin	User	admin	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00
bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb	dr.watson@test.com	Dr. Emily	Watson	provider	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00
cccccccc-cccc-cccc-cccc-cccccccccccc	dr.wilson@test.com	Dr. James	Wilson	provider	2025-09-29 18:50:37.391785+00	2025-09-29 18:50:37.391785+00
63f32a86-6e57-4728-a254-df0f14987d68	patient@test.com	patient	example	patient	2025-09-29 19:13:41.556328+00	2025-09-29 19:13:41.556328+00
e6e0a334-66bc-4e11-9447-c6ac75c295e4	adminexample@test.com	admin	example	admin	2025-09-29 19:14:13.335877+00	2025-09-29 19:14:13.335877+00
f071d913-6faa-4d8a-baee-9215992408b5	providerexample@test.com	provider	example	provider	2025-09-29 19:14:56.420396+00	2025-09-29 19:14:56.420396+00
\.


--
-- TOC entry 4638 (class 0 OID 18570)
-- Dependencies: 337
-- Data for Name: provider_availability_overrides; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.provider_availability_overrides (id, provider_id, date, start_time, end_time, available, reason, created_at) FROM stdin;
\.


--
-- TOC entry 4637 (class 0 OID 18547)
-- Dependencies: 336
-- Data for Name: provider_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.provider_schedules (id, provider_id, day_of_week, start_time, end_time, slot_duration_minutes, treatment_types, active, created_at, updated_at) FROM stdin;
85fb64c5-e571-49ad-b518-3617545a4bc8	2b66f207-2ae5-442b-8911-ada9c96779cb	1	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-09-29 19:14:56.420396+00	2025-09-29 19:14:56.420396+00
75ea0978-11a1-4ab0-9b84-4b93eac3308b	2b66f207-2ae5-442b-8911-ada9c96779cb	2	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-09-29 19:14:56.420396+00	2025-09-29 19:14:56.420396+00
4b31e07e-17ca-4c5c-9018-3fa3cd1b9fe0	2b66f207-2ae5-442b-8911-ada9c96779cb	3	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-09-29 19:14:56.420396+00	2025-09-29 19:14:56.420396+00
aac8abdf-54cc-4201-bba9-2f49ee970049	2b66f207-2ae5-442b-8911-ada9c96779cb	4	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-09-29 19:14:56.420396+00	2025-09-29 19:14:56.420396+00
1ca3d654-e5db-4ec3-a58f-085898966c7d	2b66f207-2ae5-442b-8911-ada9c96779cb	5	09:00:00	17:00:00	30	{weight_loss,mens_health}	t	2025-09-29 19:14:56.420396+00	2025-09-29 19:14:56.420396+00
\.


--
-- TOC entry 4628 (class 0 OID 18302)
-- Dependencies: 327
-- Data for Name: providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.providers (id, profile_id, specialty, license_number, phone, active, created_at, updated_at) FROM stdin;
b692a67a-1356-43a8-a753-af4dd00fbf1d	bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb	Weight Loss	TEST123	+1234567890	t	2025-09-29 18:50:40.531598+00	2025-09-29 18:50:40.531598+00
2b66f207-2ae5-442b-8911-ada9c96779cb	f071d913-6faa-4d8a-baee-9215992408b5	weight loss	1234567890		t	2025-09-29 19:14:56.420396+00	2025-09-29 19:14:56.420396+00
\.


--
-- TOC entry 4646 (class 0 OID 18920)
-- Dependencies: 347
-- Data for Name: visit_addendums; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visit_addendums (id, visit_id, provider_id, content, created_at) FROM stdin;
\.


--
-- TOC entry 4643 (class 0 OID 18760)
-- Dependencies: 344
-- Data for Name: visit_interactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visit_interactions (id, clinical_note_id, appointment_id, interaction_type, details, provider_notes, created_at, performed_by, medication_id, medication_name, previous_dosage, new_dosage, previous_frequency, new_frequency, previous_status, new_status) FROM stdin;
\.


--
-- TOC entry 4642 (class 0 OID 18735)
-- Dependencies: 343
-- Data for Name: visit_medication_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visit_medication_adjustments (id, clinical_note_id, appointment_id, preference_id, previous_dosage, previous_frequency, previous_status, previous_provider_notes, new_dosage, new_frequency, new_status, new_provider_notes, adjustment_reason, provider_notes, created_at, performed_by) FROM stdin;
\.


--
-- TOC entry 4603 (class 0 OID 17630)
-- Dependencies: 301
-- Data for Name: messages_2025_09_28; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_09_28 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4604 (class 0 OID 17642)
-- Dependencies: 302
-- Data for Name: messages_2025_09_29; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_09_29 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4605 (class 0 OID 17654)
-- Dependencies: 303
-- Data for Name: messages_2025_09_30; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_09_30 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4606 (class 0 OID 17666)
-- Dependencies: 304
-- Data for Name: messages_2025_10_01; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_10_01 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4607 (class 0 OID 17678)
-- Dependencies: 305
-- Data for Name: messages_2025_10_02; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2025_10_02 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- TOC entry 4600 (class 0 OID 17451)
-- Dependencies: 294
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2025-09-29 18:50:28
20211116045059	2025-09-29 18:50:28
20211116050929	2025-09-29 18:50:28
20211116051442	2025-09-29 18:50:28
20211116212300	2025-09-29 18:50:28
20211116213355	2025-09-29 18:50:28
20211116213934	2025-09-29 18:50:28
20211116214523	2025-09-29 18:50:28
20211122062447	2025-09-29 18:50:28
20211124070109	2025-09-29 18:50:28
20211202204204	2025-09-29 18:50:28
20211202204605	2025-09-29 18:50:28
20211210212804	2025-09-29 18:50:28
20211228014915	2025-09-29 18:50:28
20220107221237	2025-09-29 18:50:28
20220228202821	2025-09-29 18:50:28
20220312004840	2025-09-29 18:50:28
20220603231003	2025-09-29 18:50:28
20220603232444	2025-09-29 18:50:28
20220615214548	2025-09-29 18:50:28
20220712093339	2025-09-29 18:50:28
20220908172859	2025-09-29 18:50:28
20220916233421	2025-09-29 18:50:28
20230119133233	2025-09-29 18:50:28
20230128025114	2025-09-29 18:50:28
20230128025212	2025-09-29 18:50:28
20230227211149	2025-09-29 18:50:28
20230228184745	2025-09-29 18:50:28
20230308225145	2025-09-29 18:50:28
20230328144023	2025-09-29 18:50:28
20231018144023	2025-09-29 18:50:28
20231204144023	2025-09-29 18:50:28
20231204144024	2025-09-29 18:50:28
20231204144025	2025-09-29 18:50:28
20240108234812	2025-09-29 18:50:28
20240109165339	2025-09-29 18:50:28
20240227174441	2025-09-29 18:50:28
20240311171622	2025-09-29 18:50:28
20240321100241	2025-09-29 18:50:28
20240401105812	2025-09-29 18:50:28
20240418121054	2025-09-29 18:50:28
20240523004032	2025-09-29 18:50:28
20240618124746	2025-09-29 18:50:28
20240801235015	2025-09-29 18:50:28
20240805133720	2025-09-29 18:50:28
20240827160934	2025-09-29 18:50:28
20240919163303	2025-09-29 18:50:28
20240919163305	2025-09-29 18:50:28
20241019105805	2025-09-29 18:50:28
20241030150047	2025-09-29 18:50:28
20241108114728	2025-09-29 18:50:28
20241121104152	2025-09-29 18:50:28
20241130184212	2025-09-29 18:50:28
20241220035512	2025-09-29 18:50:28
20241220123912	2025-09-29 18:50:28
20241224161212	2025-09-29 18:50:28
20250107150512	2025-09-29 18:50:28
20250110162412	2025-09-29 18:50:28
20250123174212	2025-09-29 18:50:28
20250128220012	2025-09-29 18:50:28
20250506224012	2025-09-29 18:50:28
20250523164012	2025-09-29 18:50:28
20250714121412	2025-09-29 18:50:28
20250905041441	2025-09-29 18:50:28
\.


--
-- TOC entry 4602 (class 0 OID 17473)
-- Dependencies: 297
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at) FROM stdin;
\.


--
-- TOC entry 4594 (class 0 OID 16509)
-- Dependencies: 275
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
\.


--
-- TOC entry 4611 (class 0 OID 17892)
-- Dependencies: 309
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_analytics (id, type, format, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4612 (class 0 OID 17903)
-- Dependencies: 310
-- Data for Name: iceberg_namespaces; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.iceberg_namespaces (id, bucket_id, name, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4613 (class 0 OID 17919)
-- Dependencies: 311
-- Data for Name: iceberg_tables; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.iceberg_tables (id, namespace_id, bucket_id, name, location, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4596 (class 0 OID 16551)
-- Dependencies: 277
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2025-09-29 18:50:36.860043
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2025-09-29 18:50:36.861832
2	storage-schema	5c7968fd083fcea04050c1b7f6253c9771b99011	2025-09-29 18:50:36.862625
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2025-09-29 18:50:36.86595
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2025-09-29 18:50:36.867849
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2025-09-29 18:50:36.868497
6	change-column-name-in-get-size	f93f62afdf6613ee5e7e815b30d02dc990201044	2025-09-29 18:50:36.869581
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2025-09-29 18:50:36.870461
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2025-09-29 18:50:36.871064
9	fix-search-function	3a0af29f42e35a4d101c259ed955b67e1bee6825	2025-09-29 18:50:36.871645
10	search-files-search-function	68dc14822daad0ffac3746a502234f486182ef6e	2025-09-29 18:50:36.872454
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2025-09-29 18:50:36.873381
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2025-09-29 18:50:36.874295
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2025-09-29 18:50:36.874851
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2025-09-29 18:50:36.875416
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2025-09-29 18:50:36.879555
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2025-09-29 18:50:36.880601
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2025-09-29 18:50:36.881492
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2025-09-29 18:50:36.882506
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2025-09-29 18:50:36.883485
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2025-09-29 18:50:36.884127
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2025-09-29 18:50:36.88512
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2025-09-29 18:50:36.887635
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2025-09-29 18:50:36.889365
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2025-09-29 18:50:36.890233
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2025-09-29 18:50:36.890948
26	objects-prefixes	ef3f7871121cdc47a65308e6702519e853422ae2	2025-09-29 18:50:36.891681
27	search-v2	33b8f2a7ae53105f028e13e9fcda9dc4f356b4a2	2025-09-29 18:50:36.894494
28	object-bucket-name-sorting	ba85ec41b62c6a30a3f136788227ee47f311c436	2025-09-29 18:50:36.911934
29	create-prefixes	a7b1a22c0dc3ab630e3055bfec7ce7d2045c5b7b	2025-09-29 18:50:36.912934
30	update-object-levels	6c6f6cc9430d570f26284a24cf7b210599032db7	2025-09-29 18:50:36.913543
31	objects-level-index	33f1fef7ec7fea08bb892222f4f0f5d79bab5eb8	2025-09-29 18:50:36.914368
32	backward-compatible-index-on-objects	2d51eeb437a96868b36fcdfb1ddefdf13bef1647	2025-09-29 18:50:36.915134
33	backward-compatible-index-on-prefixes	fe473390e1b8c407434c0e470655945b110507bf	2025-09-29 18:50:36.915891
34	optimize-search-function-v1	82b0e469a00e8ebce495e29bfa70a0797f7ebd2c	2025-09-29 18:50:36.916057
35	add-insert-trigger-prefixes	63bb9fd05deb3dc5e9fa66c83e82b152f0caf589	2025-09-29 18:50:36.917202
36	optimise-existing-functions	81cf92eb0c36612865a18016a38496c530443899	2025-09-29 18:50:36.917726
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2025-09-29 18:50:36.919424
38	iceberg-catalog-flag-on-buckets	19a8bd89d5dfa69af7f222a46c726b7c41e462c5	2025-09-29 18:50:36.920179
\.


--
-- TOC entry 4595 (class 0 OID 16524)
-- Dependencies: 276
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata, level) FROM stdin;
\.


--
-- TOC entry 4610 (class 0 OID 17847)
-- Dependencies: 308
-- Data for Name: prefixes; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.prefixes (bucket_id, name, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4608 (class 0 OID 17794)
-- Dependencies: 306
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata) FROM stdin;
\.


--
-- TOC entry 4609 (class 0 OID 17808)
-- Dependencies: 307
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- TOC entry 4599 (class 0 OID 16763)
-- Dependencies: 290
-- Data for Name: hooks; Type: TABLE DATA; Schema: supabase_functions; Owner: -
--

COPY supabase_functions.hooks (id, hook_table_id, hook_name, created_at, request_id) FROM stdin;
\.


--
-- TOC entry 4597 (class 0 OID 16754)
-- Dependencies: 288
-- Data for Name: migrations; Type: TABLE DATA; Schema: supabase_functions; Owner: -
--

COPY supabase_functions.migrations (version, inserted_at) FROM stdin;
initial	2025-09-29 18:50:24.337858+00
20210809183423_update_grants	2025-09-29 18:50:24.337858+00
\.


--
-- TOC entry 4730 (class 0 OID 0)
-- Dependencies: 270
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 41, true);


--
-- TOC entry 4731 (class 0 OID 0)
-- Dependencies: 330
-- Name: assignment_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assignment_log_id_seq', 2, true);


--
-- TOC entry 4732 (class 0 OID 0)
-- Dependencies: 296
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: -
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- TOC entry 4733 (class 0 OID 0)
-- Dependencies: 289
-- Name: hooks_id_seq; Type: SEQUENCE SET; Schema: supabase_functions; Owner: -
--

SELECT pg_catalog.setval('supabase_functions.hooks_id_seq', 1, false);


--
-- TOC entry 4072 (class 2606 OID 18061)
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- TOC entry 3984 (class 2606 OID 16494)
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 4095 (class 2606 OID 18167)
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- TOC entry 4051 (class 2606 OID 18185)
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- TOC entry 4053 (class 2606 OID 18195)
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- TOC entry 3982 (class 2606 OID 16487)
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- TOC entry 4074 (class 2606 OID 18054)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- TOC entry 4070 (class 2606 OID 18042)
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- TOC entry 4062 (class 2606 OID 18235)
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- TOC entry 4064 (class 2606 OID 18029)
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- TOC entry 4105 (class 2606 OID 18256)
-- Name: oauth_clients oauth_clients_client_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_client_id_key UNIQUE (client_id);


--
-- TOC entry 4108 (class 2606 OID 18254)
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- TOC entry 4099 (class 2606 OID 18220)
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 3976 (class 2606 OID 16477)
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 3979 (class 2606 OID 17972)
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- TOC entry 4084 (class 2606 OID 18101)
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- TOC entry 4086 (class 2606 OID 18099)
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4091 (class 2606 OID 18115)
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- TOC entry 3987 (class 2606 OID 16500)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4057 (class 2606 OID 17993)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 4081 (class 2606 OID 18082)
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- TOC entry 4076 (class 2606 OID 18073)
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 3969 (class 2606 OID 18155)
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- TOC entry 3971 (class 2606 OID 16464)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4126 (class 2606 OID 18331)
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- TOC entry 4128 (class 2606 OID 18333)
-- Name: admins admins_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_profile_id_key UNIQUE (profile_id);


--
-- TOC entry 4186 (class 2606 OID 18635)
-- Name: appointment_history appointment_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment_history
    ADD CONSTRAINT appointment_history_pkey PRIMARY KEY (id);


--
-- TOC entry 4173 (class 2606 OID 18607)
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- TOC entry 4138 (class 2606 OID 18417)
-- Name: assignment_log assignment_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assignment_log
    ADD CONSTRAINT assignment_log_pkey PRIMARY KEY (id);


--
-- TOC entry 4233 (class 2606 OID 18975)
-- Name: auth_trigger_debug_log auth_trigger_debug_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_trigger_debug_log
    ADD CONSTRAINT auth_trigger_debug_log_pkey PRIMARY KEY (id);


--
-- TOC entry 4219 (class 2606 OID 18847)
-- Name: auth_trigger_logs auth_trigger_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_trigger_logs
    ADD CONSTRAINT auth_trigger_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 4190 (class 2606 OID 18717)
-- Name: clinical_notes clinical_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_pkey PRIMARY KEY (id);


--
-- TOC entry 4152 (class 2606 OID 18465)
-- Name: medication_approvals medication_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_pkey PRIMARY KEY (id);


--
-- TOC entry 4224 (class 2606 OID 18904)
-- Name: medication_dosages medication_dosages_medication_id_strength_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_dosages
    ADD CONSTRAINT medication_dosages_medication_id_strength_key UNIQUE (medication_id, strength);


--
-- TOC entry 4226 (class 2606 OID 18902)
-- Name: medication_dosages medication_dosages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_dosages
    ADD CONSTRAINT medication_dosages_pkey PRIMARY KEY (id);


--
-- TOC entry 4159 (class 2606 OID 18488)
-- Name: medication_orders medication_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_pkey PRIMARY KEY (id);


--
-- TOC entry 4142 (class 2606 OID 18430)
-- Name: medications medications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medications
    ADD CONSTRAINT medications_pkey PRIMARY KEY (id);


--
-- TOC entry 4134 (class 2606 OID 18352)
-- Name: patient_assignments patient_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT patient_assignments_pkey PRIMARY KEY (id);


--
-- TOC entry 4146 (class 2606 OID 18444)
-- Name: patient_medication_preferences patient_medication_preferences_patient_id_medication_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_patient_id_medication_id_key UNIQUE (patient_id, medication_id);


--
-- TOC entry 4148 (class 2606 OID 18442)
-- Name: patient_medication_preferences patient_medication_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_pkey PRIMARY KEY (id);


--
-- TOC entry 4117 (class 2606 OID 18294)
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- TOC entry 4119 (class 2606 OID 18296)
-- Name: patients patients_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_profile_id_key UNIQUE (profile_id);


--
-- TOC entry 4112 (class 2606 OID 18278)
-- Name: profiles profiles_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_email_key UNIQUE (email);


--
-- TOC entry 4114 (class 2606 OID 18276)
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- TOC entry 4169 (class 2606 OID 18579)
-- Name: provider_availability_overrides provider_availability_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_availability_overrides
    ADD CONSTRAINT provider_availability_overrides_pkey PRIMARY KEY (id);


--
-- TOC entry 4163 (class 2606 OID 18562)
-- Name: provider_schedules provider_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_schedules
    ADD CONSTRAINT provider_schedules_pkey PRIMARY KEY (id);


--
-- TOC entry 4122 (class 2606 OID 18312)
-- Name: providers providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_pkey PRIMARY KEY (id);


--
-- TOC entry 4124 (class 2606 OID 18314)
-- Name: providers providers_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_profile_id_key UNIQUE (profile_id);


--
-- TOC entry 4200 (class 2606 OID 18719)
-- Name: clinical_notes unique_appointment_clinical_note; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT unique_appointment_clinical_note UNIQUE (appointment_id);


--
-- TOC entry 4202 (class 2606 OID 18816)
-- Name: clinical_notes unique_clinical_note_per_appointment; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT unique_clinical_note_per_appointment UNIQUE (appointment_id);


--
-- TOC entry 4136 (class 2606 OID 18354)
-- Name: patient_assignments unique_primary_assignment; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT unique_primary_assignment EXCLUDE USING btree (patient_id WITH =) WHERE (((is_primary = true) AND (active = true)));


--
-- TOC entry 4171 (class 2606 OID 18581)
-- Name: provider_availability_overrides unique_provider_override; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_availability_overrides
    ADD CONSTRAINT unique_provider_override UNIQUE (provider_id, date, start_time, end_time);


--
-- TOC entry 4165 (class 2606 OID 18564)
-- Name: provider_schedules unique_provider_schedule; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_schedules
    ADD CONSTRAINT unique_provider_schedule UNIQUE (provider_id, day_of_week, start_time, end_time);


--
-- TOC entry 4184 (class 2606 OID 18609)
-- Name: appointments unique_provider_slot; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT unique_provider_slot UNIQUE (provider_id, appointment_date, start_time);


--
-- TOC entry 4231 (class 2606 OID 18929)
-- Name: visit_addendums visit_addendums_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_addendums
    ADD CONSTRAINT visit_addendums_pkey PRIMARY KEY (id);


--
-- TOC entry 4217 (class 2606 OID 18769)
-- Name: visit_interactions visit_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_interactions
    ADD CONSTRAINT visit_interactions_pkey PRIMARY KEY (id);


--
-- TOC entry 4208 (class 2606 OID 18744)
-- Name: visit_medication_adjustments visit_medication_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_pkey PRIMARY KEY (id);


--
-- TOC entry 4017 (class 2606 OID 17627)
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4020 (class 2606 OID 17638)
-- Name: messages_2025_09_28 messages_2025_09_28_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_09_28
    ADD CONSTRAINT messages_2025_09_28_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4023 (class 2606 OID 17650)
-- Name: messages_2025_09_29 messages_2025_09_29_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_09_29
    ADD CONSTRAINT messages_2025_09_29_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4026 (class 2606 OID 17662)
-- Name: messages_2025_09_30 messages_2025_09_30_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_09_30
    ADD CONSTRAINT messages_2025_09_30_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4029 (class 2606 OID 17674)
-- Name: messages_2025_10_01 messages_2025_10_01_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_10_01
    ADD CONSTRAINT messages_2025_10_01_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4032 (class 2606 OID 17686)
-- Name: messages_2025_10_02 messages_2025_10_02_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2025_10_02
    ADD CONSTRAINT messages_2025_10_02_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 4013 (class 2606 OID 17481)
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- TOC entry 4010 (class 2606 OID 17455)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 4042 (class 2606 OID 17902)
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- TOC entry 3990 (class 2606 OID 16517)
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- TOC entry 4044 (class 2606 OID 17912)
-- Name: iceberg_namespaces iceberg_namespaces_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_namespaces
    ADD CONSTRAINT iceberg_namespaces_pkey PRIMARY KEY (id);


--
-- TOC entry 4047 (class 2606 OID 17928)
-- Name: iceberg_tables iceberg_tables_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_pkey PRIMARY KEY (id);


--
-- TOC entry 4000 (class 2606 OID 16558)
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- TOC entry 4002 (class 2606 OID 16556)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3998 (class 2606 OID 16534)
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- TOC entry 4040 (class 2606 OID 17856)
-- Name: prefixes prefixes_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT prefixes_pkey PRIMARY KEY (bucket_id, level, name);


--
-- TOC entry 4037 (class 2606 OID 17817)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- TOC entry 4035 (class 2606 OID 17802)
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- TOC entry 4006 (class 2606 OID 16771)
-- Name: hooks hooks_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: -
--

ALTER TABLE ONLY supabase_functions.hooks
    ADD CONSTRAINT hooks_pkey PRIMARY KEY (id);


--
-- TOC entry 4004 (class 2606 OID 16761)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: supabase_functions; Owner: -
--

ALTER TABLE ONLY supabase_functions.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 3985 (class 1259 OID 16495)
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- TOC entry 3959 (class 1259 OID 17982)
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3960 (class 1259 OID 17984)
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3961 (class 1259 OID 17985)
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 4060 (class 1259 OID 18063)
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- TOC entry 4093 (class 1259 OID 18171)
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- TOC entry 4049 (class 1259 OID 18151)
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- TOC entry 4734 (class 0 OID 0)
-- Dependencies: 4049
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- TOC entry 4054 (class 1259 OID 17979)
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- TOC entry 4096 (class 1259 OID 18168)
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- TOC entry 4097 (class 1259 OID 18169)
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- TOC entry 4068 (class 1259 OID 18174)
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- TOC entry 4065 (class 1259 OID 18035)
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- TOC entry 4066 (class 1259 OID 18180)
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- TOC entry 4103 (class 1259 OID 18257)
-- Name: oauth_clients_client_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_client_id_idx ON auth.oauth_clients USING btree (client_id);


--
-- TOC entry 4106 (class 1259 OID 18258)
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- TOC entry 4100 (class 1259 OID 18227)
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- TOC entry 4101 (class 1259 OID 18226)
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- TOC entry 4102 (class 1259 OID 18228)
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- TOC entry 3962 (class 1259 OID 17986)
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3963 (class 1259 OID 17983)
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3972 (class 1259 OID 16478)
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- TOC entry 3973 (class 1259 OID 16479)
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- TOC entry 3974 (class 1259 OID 17978)
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- TOC entry 3977 (class 1259 OID 18065)
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- TOC entry 3980 (class 1259 OID 18170)
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- TOC entry 4087 (class 1259 OID 18107)
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- TOC entry 4088 (class 1259 OID 18172)
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- TOC entry 4089 (class 1259 OID 18122)
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- TOC entry 4092 (class 1259 OID 18121)
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- TOC entry 4055 (class 1259 OID 18173)
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- TOC entry 4058 (class 1259 OID 18064)
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- TOC entry 4079 (class 1259 OID 18089)
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- TOC entry 4082 (class 1259 OID 18088)
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- TOC entry 4077 (class 1259 OID 18074)
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- TOC entry 4078 (class 1259 OID 18236)
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- TOC entry 4067 (class 1259 OID 18233)
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- TOC entry 4059 (class 1259 OID 18062)
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- TOC entry 3964 (class 1259 OID 18142)
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- TOC entry 4735 (class 0 OID 0)
-- Dependencies: 3964
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- TOC entry 3965 (class 1259 OID 17980)
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- TOC entry 3966 (class 1259 OID 16468)
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- TOC entry 3967 (class 1259 OID 18197)
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- TOC entry 4129 (class 1259 OID 18369)
-- Name: idx_admins_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admins_profile_id ON public.admins USING btree (profile_id);


--
-- TOC entry 4187 (class 1259 OID 18651)
-- Name: idx_appointment_history_appointment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointment_history_appointment ON public.appointment_history USING btree (appointment_id);


--
-- TOC entry 4188 (class 1259 OID 18652)
-- Name: idx_appointment_history_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointment_history_created ON public.appointment_history USING btree (created_at);


--
-- TOC entry 4174 (class 1259 OID 18650)
-- Name: idx_appointments_assignment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_assignment ON public.appointments USING btree (assignment_id);


--
-- TOC entry 4175 (class 1259 OID 18647)
-- Name: idx_appointments_date_range; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_date_range ON public.appointments USING btree (appointment_date);


--
-- TOC entry 4176 (class 1259 OID 18645)
-- Name: idx_appointments_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_patient_id ON public.appointments USING btree (patient_id);


--
-- TOC entry 4177 (class 1259 OID 18648)
-- Name: idx_appointments_provider_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_provider_date ON public.appointments USING btree (provider_id, appointment_date);


--
-- TOC entry 4178 (class 1259 OID 18646)
-- Name: idx_appointments_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_provider_id ON public.appointments USING btree (provider_id);


--
-- TOC entry 4179 (class 1259 OID 18961)
-- Name: idx_appointments_reschedule_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_reschedule_source ON public.appointments USING btree (is_reschedule_source);


--
-- TOC entry 4180 (class 1259 OID 18959)
-- Name: idx_appointments_rescheduled_from; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_rescheduled_from ON public.appointments USING btree (rescheduled_from_id);


--
-- TOC entry 4181 (class 1259 OID 18960)
-- Name: idx_appointments_rescheduled_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_rescheduled_to ON public.appointments USING btree (rescheduled_to_id);


--
-- TOC entry 4182 (class 1259 OID 18649)
-- Name: idx_appointments_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_status ON public.appointments USING btree (status);


--
-- TOC entry 4191 (class 1259 OID 18780)
-- Name: idx_clinical_notes_appointment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_appointment ON public.clinical_notes USING btree (appointment_id);


--
-- TOC entry 4192 (class 1259 OID 18809)
-- Name: idx_clinical_notes_appointment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_appointment_id ON public.clinical_notes USING btree (appointment_id);


--
-- TOC entry 4193 (class 1259 OID 18783)
-- Name: idx_clinical_notes_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_created_at ON public.clinical_notes USING btree (created_at);


--
-- TOC entry 4194 (class 1259 OID 18781)
-- Name: idx_clinical_notes_patient; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_patient ON public.clinical_notes USING btree (patient_id);


--
-- TOC entry 4195 (class 1259 OID 18810)
-- Name: idx_clinical_notes_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_patient_id ON public.clinical_notes USING btree (patient_id);


--
-- TOC entry 4196 (class 1259 OID 18782)
-- Name: idx_clinical_notes_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_provider ON public.clinical_notes USING btree (provider_id);


--
-- TOC entry 4197 (class 1259 OID 18811)
-- Name: idx_clinical_notes_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_provider_id ON public.clinical_notes USING btree (provider_id);


--
-- TOC entry 4198 (class 1259 OID 18784)
-- Name: idx_clinical_notes_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clinical_notes_updated_at ON public.clinical_notes USING btree (updated_at);


--
-- TOC entry 4149 (class 1259 OID 18508)
-- Name: idx_medication_approvals_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_approvals_provider_id ON public.medication_approvals USING btree (provider_id);


--
-- TOC entry 4150 (class 1259 OID 18509)
-- Name: idx_medication_approvals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_approvals_status ON public.medication_approvals USING btree (status);


--
-- TOC entry 4220 (class 1259 OID 18911)
-- Name: idx_medication_dosages_available; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_dosages_available ON public.medication_dosages USING btree (available);


--
-- TOC entry 4221 (class 1259 OID 18910)
-- Name: idx_medication_dosages_medication_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_dosages_medication_id ON public.medication_dosages USING btree (medication_id);


--
-- TOC entry 4222 (class 1259 OID 18912)
-- Name: idx_medication_dosages_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_dosages_sort_order ON public.medication_dosages USING btree (sort_order);


--
-- TOC entry 4153 (class 1259 OID 18512)
-- Name: idx_medication_orders_fulfillment_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_fulfillment_status ON public.medication_orders USING btree (fulfillment_status);


--
-- TOC entry 4154 (class 1259 OID 18541)
-- Name: idx_medication_orders_patient_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_patient_created ON public.medication_orders USING btree (patient_id, created_at DESC);


--
-- TOC entry 4155 (class 1259 OID 18510)
-- Name: idx_medication_orders_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_patient_id ON public.medication_orders USING btree (patient_id);


--
-- TOC entry 4156 (class 1259 OID 18511)
-- Name: idx_medication_orders_payment_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_payment_status ON public.medication_orders USING btree (payment_status);


--
-- TOC entry 4157 (class 1259 OID 18539)
-- Name: idx_medication_orders_sent_to_pharmacy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medication_orders_sent_to_pharmacy ON public.medication_orders USING btree (sent_to_pharmacy);


--
-- TOC entry 4139 (class 1259 OID 18505)
-- Name: idx_medications_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medications_active ON public.medications USING btree (active);


--
-- TOC entry 4140 (class 1259 OID 18504)
-- Name: idx_medications_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_medications_category ON public.medications USING btree (category);


--
-- TOC entry 4130 (class 1259 OID 18372)
-- Name: idx_patient_assignments_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_assignments_active ON public.patient_assignments USING btree (active);


--
-- TOC entry 4131 (class 1259 OID 18370)
-- Name: idx_patient_assignments_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_assignments_patient_id ON public.patient_assignments USING btree (patient_id);


--
-- TOC entry 4132 (class 1259 OID 18371)
-- Name: idx_patient_assignments_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_assignments_provider_id ON public.patient_assignments USING btree (provider_id);


--
-- TOC entry 4143 (class 1259 OID 18506)
-- Name: idx_patient_medication_preferences_patient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_patient_id ON public.patient_medication_preferences USING btree (patient_id);


--
-- TOC entry 4144 (class 1259 OID 18507)
-- Name: idx_patient_medication_preferences_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patient_medication_preferences_status ON public.patient_medication_preferences USING btree (status);


--
-- TOC entry 4115 (class 1259 OID 18367)
-- Name: idx_patients_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_patients_profile_id ON public.patients USING btree (profile_id);


--
-- TOC entry 4109 (class 1259 OID 18366)
-- Name: idx_profiles_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_email ON public.profiles USING btree (email);


--
-- TOC entry 4110 (class 1259 OID 18365)
-- Name: idx_profiles_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_role ON public.profiles USING btree (role);


--
-- TOC entry 4166 (class 1259 OID 18644)
-- Name: idx_provider_overrides_date_range; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provider_overrides_date_range ON public.provider_availability_overrides USING btree (date);


--
-- TOC entry 4167 (class 1259 OID 18643)
-- Name: idx_provider_overrides_provider_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provider_overrides_provider_date ON public.provider_availability_overrides USING btree (provider_id, date);


--
-- TOC entry 4160 (class 1259 OID 18642)
-- Name: idx_provider_schedules_day_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provider_schedules_day_active ON public.provider_schedules USING btree (day_of_week, active);


--
-- TOC entry 4161 (class 1259 OID 18641)
-- Name: idx_provider_schedules_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provider_schedules_provider_id ON public.provider_schedules USING btree (provider_id);


--
-- TOC entry 4120 (class 1259 OID 18368)
-- Name: idx_providers_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_providers_profile_id ON public.providers USING btree (profile_id);


--
-- TOC entry 4227 (class 1259 OID 18942)
-- Name: idx_visit_addendums_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_addendums_created_at ON public.visit_addendums USING btree (created_at);


--
-- TOC entry 4228 (class 1259 OID 18941)
-- Name: idx_visit_addendums_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_addendums_provider_id ON public.visit_addendums USING btree (provider_id);


--
-- TOC entry 4229 (class 1259 OID 18940)
-- Name: idx_visit_addendums_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_addendums_visit_id ON public.visit_addendums USING btree (visit_id);


--
-- TOC entry 4209 (class 1259 OID 18790)
-- Name: idx_visit_interactions_appointment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_appointment ON public.visit_interactions USING btree (appointment_id);


--
-- TOC entry 4210 (class 1259 OID 18813)
-- Name: idx_visit_interactions_appointment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_appointment_id ON public.visit_interactions USING btree (appointment_id);


--
-- TOC entry 4211 (class 1259 OID 18789)
-- Name: idx_visit_interactions_clinical_note; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_clinical_note ON public.visit_interactions USING btree (clinical_note_id);


--
-- TOC entry 4212 (class 1259 OID 18812)
-- Name: idx_visit_interactions_clinical_note_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_clinical_note_id ON public.visit_interactions USING btree (clinical_note_id);


--
-- TOC entry 4213 (class 1259 OID 18792)
-- Name: idx_visit_interactions_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_created_at ON public.visit_interactions USING btree (created_at);


--
-- TOC entry 4214 (class 1259 OID 18814)
-- Name: idx_visit_interactions_medication_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_medication_id ON public.visit_interactions USING btree (medication_id);


--
-- TOC entry 4215 (class 1259 OID 18791)
-- Name: idx_visit_interactions_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_interactions_type ON public.visit_interactions USING btree (interaction_type);


--
-- TOC entry 4203 (class 1259 OID 18786)
-- Name: idx_visit_medication_adjustments_appointment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_appointment ON public.visit_medication_adjustments USING btree (appointment_id);


--
-- TOC entry 4204 (class 1259 OID 18785)
-- Name: idx_visit_medication_adjustments_clinical_note; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_clinical_note ON public.visit_medication_adjustments USING btree (clinical_note_id);


--
-- TOC entry 4205 (class 1259 OID 18788)
-- Name: idx_visit_medication_adjustments_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_created_at ON public.visit_medication_adjustments USING btree (created_at);


--
-- TOC entry 4206 (class 1259 OID 18787)
-- Name: idx_visit_medication_adjustments_preference; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_medication_adjustments_preference ON public.visit_medication_adjustments USING btree (preference_id);


--
-- TOC entry 4011 (class 1259 OID 17628)
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- TOC entry 4015 (class 1259 OID 17629)
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4018 (class 1259 OID 17639)
-- Name: messages_2025_09_28_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_09_28_inserted_at_topic_idx ON realtime.messages_2025_09_28 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4021 (class 1259 OID 17651)
-- Name: messages_2025_09_29_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_09_29_inserted_at_topic_idx ON realtime.messages_2025_09_29 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4024 (class 1259 OID 17663)
-- Name: messages_2025_09_30_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_09_30_inserted_at_topic_idx ON realtime.messages_2025_09_30 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4027 (class 1259 OID 17675)
-- Name: messages_2025_10_01_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_10_01_inserted_at_topic_idx ON realtime.messages_2025_10_01 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4030 (class 1259 OID 17687)
-- Name: messages_2025_10_02_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2025_10_02_inserted_at_topic_idx ON realtime.messages_2025_10_02 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- TOC entry 4014 (class 1259 OID 17530)
-- Name: subscription_subscription_id_entity_filters_key; Type: INDEX; Schema: realtime; Owner: -
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_key ON realtime.subscription USING btree (subscription_id, entity, filters);


--
-- TOC entry 3988 (class 1259 OID 16523)
-- Name: bname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- TOC entry 3991 (class 1259 OID 16545)
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- TOC entry 4045 (class 1259 OID 17918)
-- Name: idx_iceberg_namespaces_bucket_id; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX idx_iceberg_namespaces_bucket_id ON storage.iceberg_namespaces USING btree (bucket_id, name);


--
-- TOC entry 4048 (class 1259 OID 17939)
-- Name: idx_iceberg_tables_namespace_id; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX idx_iceberg_tables_namespace_id ON storage.iceberg_tables USING btree (namespace_id, name);


--
-- TOC entry 4033 (class 1259 OID 17828)
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- TOC entry 3992 (class 1259 OID 17874)
-- Name: idx_name_bucket_level_unique; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX idx_name_bucket_level_unique ON storage.objects USING btree (name COLLATE "C", bucket_id, level);


--
-- TOC entry 3993 (class 1259 OID 17793)
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- TOC entry 3994 (class 1259 OID 17876)
-- Name: idx_objects_lower_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_lower_name ON storage.objects USING btree ((path_tokens[level]), lower(name) text_pattern_ops, bucket_id, level);


--
-- TOC entry 4038 (class 1259 OID 17877)
-- Name: idx_prefixes_lower_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_prefixes_lower_name ON storage.prefixes USING btree (bucket_id, level, ((string_to_array(name, '/'::text))[level]), lower(name) text_pattern_ops);


--
-- TOC entry 3995 (class 1259 OID 16546)
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- TOC entry 3996 (class 1259 OID 17875)
-- Name: objects_bucket_id_level_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX objects_bucket_id_level_idx ON storage.objects USING btree (bucket_id, level, name COLLATE "C");


--
-- TOC entry 4007 (class 1259 OID 16773)
-- Name: supabase_functions_hooks_h_table_id_h_name_idx; Type: INDEX; Schema: supabase_functions; Owner: -
--

CREATE INDEX supabase_functions_hooks_h_table_id_h_name_idx ON supabase_functions.hooks USING btree (hook_table_id, hook_name);


--
-- TOC entry 4008 (class 1259 OID 16772)
-- Name: supabase_functions_hooks_request_id_idx; Type: INDEX; Schema: supabase_functions; Owner: -
--

CREATE INDEX supabase_functions_hooks_request_id_idx ON supabase_functions.hooks USING btree (request_id);


--
-- TOC entry 4234 (class 0 OID 0)
-- Name: messages_2025_09_28_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_09_28_inserted_at_topic_idx;


--
-- TOC entry 4235 (class 0 OID 0)
-- Name: messages_2025_09_28_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_09_28_pkey;


--
-- TOC entry 4236 (class 0 OID 0)
-- Name: messages_2025_09_29_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_09_29_inserted_at_topic_idx;


--
-- TOC entry 4237 (class 0 OID 0)
-- Name: messages_2025_09_29_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_09_29_pkey;


--
-- TOC entry 4238 (class 0 OID 0)
-- Name: messages_2025_09_30_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_09_30_inserted_at_topic_idx;


--
-- TOC entry 4239 (class 0 OID 0)
-- Name: messages_2025_09_30_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_09_30_pkey;


--
-- TOC entry 4240 (class 0 OID 0)
-- Name: messages_2025_10_01_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_01_inserted_at_topic_idx;


--
-- TOC entry 4241 (class 0 OID 0)
-- Name: messages_2025_10_01_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_01_pkey;


--
-- TOC entry 4242 (class 0 OID 0)
-- Name: messages_2025_10_02_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2025_10_02_inserted_at_topic_idx;


--
-- TOC entry 4243 (class 0 OID 0)
-- Name: messages_2025_10_02_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2025_10_02_pkey;


--
-- TOC entry 4297 (class 2620 OID 19023)
-- Name: users on_auth_user_created; Type: TRIGGER; Schema: auth; Owner: -
--

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();


--
-- TOC entry 4316 (class 2620 OID 18656)
-- Name: appointments appointment_audit_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER appointment_audit_trigger AFTER INSERT OR DELETE OR UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.log_appointment_changes();


--
-- TOC entry 4317 (class 2620 OID 18689)
-- Name: appointments appointment_business_rules_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER appointment_business_rules_trigger BEFORE INSERT OR UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.validate_appointment_business_rules();


--
-- TOC entry 4309 (class 2620 OID 18377)
-- Name: admins update_admins_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_admins_updated_at BEFORE UPDATE ON public.admins FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4318 (class 2620 OID 18654)
-- Name: appointments update_appointments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_appointments_updated_at BEFORE UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4319 (class 2620 OID 18795)
-- Name: clinical_notes update_clinical_note_editor_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_clinical_note_editor_trigger BEFORE UPDATE ON public.clinical_notes FOR EACH ROW EXECUTE FUNCTION public.update_clinical_note_editor();


--
-- TOC entry 4320 (class 2620 OID 18807)
-- Name: clinical_notes update_clinical_notes_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_clinical_notes_updated_at BEFORE UPDATE ON public.clinical_notes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4313 (class 2620 OID 18515)
-- Name: medication_approvals update_medication_approvals_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medication_approvals_updated_at BEFORE UPDATE ON public.medication_approvals FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4321 (class 2620 OID 18913)
-- Name: medication_dosages update_medication_dosages_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medication_dosages_updated_at BEFORE UPDATE ON public.medication_dosages FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4314 (class 2620 OID 18516)
-- Name: medication_orders update_medication_orders_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medication_orders_updated_at BEFORE UPDATE ON public.medication_orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4311 (class 2620 OID 18513)
-- Name: medications update_medications_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_medications_updated_at BEFORE UPDATE ON public.medications FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4310 (class 2620 OID 18378)
-- Name: patient_assignments update_patient_assignments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patient_assignments_updated_at BEFORE UPDATE ON public.patient_assignments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4312 (class 2620 OID 18514)
-- Name: patient_medication_preferences update_patient_medication_preferences_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patient_medication_preferences_updated_at BEFORE UPDATE ON public.patient_medication_preferences FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4307 (class 2620 OID 18375)
-- Name: patients update_patients_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_patients_updated_at BEFORE UPDATE ON public.patients FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4306 (class 2620 OID 18374)
-- Name: profiles update_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4315 (class 2620 OID 18653)
-- Name: provider_schedules update_provider_schedules_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_provider_schedules_updated_at BEFORE UPDATE ON public.provider_schedules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4308 (class 2620 OID 18376)
-- Name: providers update_providers_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_providers_updated_at BEFORE UPDATE ON public.providers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4303 (class 2620 OID 17486)
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: -
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- TOC entry 4298 (class 2620 OID 17884)
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- TOC entry 4299 (class 2620 OID 17872)
-- Name: objects objects_delete_delete_prefix; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER objects_delete_delete_prefix AFTER DELETE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- TOC entry 4300 (class 2620 OID 17870)
-- Name: objects objects_insert_create_prefix; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER objects_insert_create_prefix BEFORE INSERT ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.objects_insert_prefix_trigger();


--
-- TOC entry 4301 (class 2620 OID 17871)
-- Name: objects objects_update_create_prefix; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER objects_update_create_prefix BEFORE UPDATE ON storage.objects FOR EACH ROW WHEN (((new.name <> old.name) OR (new.bucket_id <> old.bucket_id))) EXECUTE FUNCTION storage.objects_update_prefix_trigger();


--
-- TOC entry 4304 (class 2620 OID 17880)
-- Name: prefixes prefixes_create_hierarchy; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER prefixes_create_hierarchy BEFORE INSERT ON storage.prefixes FOR EACH ROW WHEN ((pg_trigger_depth() < 1)) EXECUTE FUNCTION storage.prefixes_insert_trigger();


--
-- TOC entry 4305 (class 2620 OID 17869)
-- Name: prefixes prefixes_delete_hierarchy; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER prefixes_delete_hierarchy AFTER DELETE ON storage.prefixes FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- TOC entry 4302 (class 2620 OID 17781)
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- TOC entry 4253 (class 2606 OID 17966)
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4257 (class 2606 OID 18055)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4256 (class 2606 OID 18043)
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- TOC entry 4255 (class 2606 OID 18030)
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4262 (class 2606 OID 18221)
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4244 (class 2606 OID 17999)
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 4259 (class 2606 OID 18102)
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4260 (class 2606 OID 18175)
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- TOC entry 4261 (class 2606 OID 18116)
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4254 (class 2606 OID 17994)
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4258 (class 2606 OID 18083)
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 4266 (class 2606 OID 18334)
-- Name: admins admins_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4284 (class 2606 OID 18636)
-- Name: appointment_history appointment_history_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment_history
    ADD CONSTRAINT appointment_history_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4279 (class 2606 OID 18620)
-- Name: appointments appointments_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.patient_assignments(id);


--
-- TOC entry 4280 (class 2606 OID 18610)
-- Name: appointments appointments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4281 (class 2606 OID 18615)
-- Name: appointments appointments_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4282 (class 2606 OID 18949)
-- Name: appointments appointments_rescheduled_from_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_rescheduled_from_id_fkey FOREIGN KEY (rescheduled_from_id) REFERENCES public.appointments(id);


--
-- TOC entry 4283 (class 2606 OID 18954)
-- Name: appointments appointments_rescheduled_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_rescheduled_to_id_fkey FOREIGN KEY (rescheduled_to_id) REFERENCES public.appointments(id);


--
-- TOC entry 4293 (class 2606 OID 18848)
-- Name: auth_trigger_logs auth_trigger_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_trigger_logs
    ADD CONSTRAINT auth_trigger_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- TOC entry 4285 (class 2606 OID 18720)
-- Name: clinical_notes clinical_notes_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4286 (class 2606 OID 18725)
-- Name: clinical_notes clinical_notes_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4287 (class 2606 OID 18730)
-- Name: clinical_notes clinical_notes_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clinical_notes
    ADD CONSTRAINT clinical_notes_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4272 (class 2606 OID 18466)
-- Name: medication_approvals medication_approvals_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_preference_id_fkey FOREIGN KEY (preference_id) REFERENCES public.patient_medication_preferences(id) ON DELETE CASCADE;


--
-- TOC entry 4273 (class 2606 OID 18471)
-- Name: medication_approvals medication_approvals_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_approvals
    ADD CONSTRAINT medication_approvals_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4294 (class 2606 OID 18905)
-- Name: medication_dosages medication_dosages_medication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_dosages
    ADD CONSTRAINT medication_dosages_medication_id_fkey FOREIGN KEY (medication_id) REFERENCES public.medications(id) ON DELETE CASCADE;


--
-- TOC entry 4274 (class 2606 OID 18489)
-- Name: medication_orders medication_orders_approval_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_approval_id_fkey FOREIGN KEY (approval_id) REFERENCES public.medication_approvals(id) ON DELETE CASCADE;


--
-- TOC entry 4275 (class 2606 OID 18499)
-- Name: medication_orders medication_orders_medication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_medication_id_fkey FOREIGN KEY (medication_id) REFERENCES public.medications(id) ON DELETE CASCADE;


--
-- TOC entry 4276 (class 2606 OID 18494)
-- Name: medication_orders medication_orders_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medication_orders
    ADD CONSTRAINT medication_orders_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4267 (class 2606 OID 18355)
-- Name: patient_assignments patient_assignments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT patient_assignments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4268 (class 2606 OID 18360)
-- Name: patient_assignments patient_assignments_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_assignments
    ADD CONSTRAINT patient_assignments_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4269 (class 2606 OID 18914)
-- Name: patient_medication_preferences patient_medication_preferences_medication_dosage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_medication_dosage_id_fkey FOREIGN KEY (medication_dosage_id) REFERENCES public.medication_dosages(id) ON DELETE SET NULL;


--
-- TOC entry 4270 (class 2606 OID 18450)
-- Name: patient_medication_preferences patient_medication_preferences_medication_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_medication_id_fkey FOREIGN KEY (medication_id) REFERENCES public.medications(id) ON DELETE CASCADE;


--
-- TOC entry 4271 (class 2606 OID 18445)
-- Name: patient_medication_preferences patient_medication_preferences_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patient_medication_preferences
    ADD CONSTRAINT patient_medication_preferences_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- TOC entry 4264 (class 2606 OID 18297)
-- Name: patients patients_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4263 (class 2606 OID 18279)
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 4278 (class 2606 OID 18582)
-- Name: provider_availability_overrides provider_availability_overrides_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_availability_overrides
    ADD CONSTRAINT provider_availability_overrides_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4277 (class 2606 OID 18565)
-- Name: provider_schedules provider_schedules_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_schedules
    ADD CONSTRAINT provider_schedules_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4265 (class 2606 OID 18315)
-- Name: providers providers_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4295 (class 2606 OID 18935)
-- Name: visit_addendums visit_addendums_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_addendums
    ADD CONSTRAINT visit_addendums_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(id) ON DELETE CASCADE;


--
-- TOC entry 4296 (class 2606 OID 18930)
-- Name: visit_addendums visit_addendums_visit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_addendums
    ADD CONSTRAINT visit_addendums_visit_id_fkey FOREIGN KEY (visit_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4291 (class 2606 OID 18775)
-- Name: visit_interactions visit_interactions_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_interactions
    ADD CONSTRAINT visit_interactions_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4292 (class 2606 OID 18770)
-- Name: visit_interactions visit_interactions_clinical_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_interactions
    ADD CONSTRAINT visit_interactions_clinical_note_id_fkey FOREIGN KEY (clinical_note_id) REFERENCES public.clinical_notes(id) ON DELETE CASCADE;


--
-- TOC entry 4288 (class 2606 OID 18750)
-- Name: visit_medication_adjustments visit_medication_adjustments_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- TOC entry 4289 (class 2606 OID 18745)
-- Name: visit_medication_adjustments visit_medication_adjustments_clinical_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_clinical_note_id_fkey FOREIGN KEY (clinical_note_id) REFERENCES public.clinical_notes(id) ON DELETE CASCADE;


--
-- TOC entry 4290 (class 2606 OID 18755)
-- Name: visit_medication_adjustments visit_medication_adjustments_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_medication_adjustments
    ADD CONSTRAINT visit_medication_adjustments_preference_id_fkey FOREIGN KEY (preference_id) REFERENCES public.patient_medication_preferences(id) ON DELETE CASCADE;


--
-- TOC entry 4250 (class 2606 OID 17913)
-- Name: iceberg_namespaces iceberg_namespaces_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_namespaces
    ADD CONSTRAINT iceberg_namespaces_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_analytics(id) ON DELETE CASCADE;


--
-- TOC entry 4251 (class 2606 OID 17934)
-- Name: iceberg_tables iceberg_tables_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_analytics(id) ON DELETE CASCADE;


--
-- TOC entry 4252 (class 2606 OID 17929)
-- Name: iceberg_tables iceberg_tables_namespace_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.iceberg_tables
    ADD CONSTRAINT iceberg_tables_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES storage.iceberg_namespaces(id) ON DELETE CASCADE;


--
-- TOC entry 4245 (class 2606 OID 16535)
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4249 (class 2606 OID 17857)
-- Name: prefixes prefixes_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT "prefixes_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4246 (class 2606 OID 17803)
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4247 (class 2606 OID 17823)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 4248 (class 2606 OID 17818)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- TOC entry 4475 (class 0 OID 16488)
-- Dependencies: 273
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4496 (class 0 OID 18161)
-- Dependencies: 321
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4487 (class 0 OID 17959)
-- Dependencies: 312
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4474 (class 0 OID 16481)
-- Dependencies: 272
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4491 (class 0 OID 18048)
-- Dependencies: 316
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4490 (class 0 OID 18036)
-- Dependencies: 315
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4489 (class 0 OID 18023)
-- Dependencies: 314
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4497 (class 0 OID 18211)
-- Dependencies: 322
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4473 (class 0 OID 16470)
-- Dependencies: 271
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4494 (class 0 OID 18090)
-- Dependencies: 319
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4495 (class 0 OID 18108)
-- Dependencies: 320
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4476 (class 0 OID 16496)
-- Dependencies: 274
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4488 (class 0 OID 17989)
-- Dependencies: 313
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4493 (class 0 OID 18075)
-- Dependencies: 318
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4492 (class 0 OID 18066)
-- Dependencies: 317
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4472 (class 0 OID 16458)
-- Dependencies: 269
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4524 (class 3256 OID 18395)
-- Name: patient_assignments Admins can manage all assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all assignments" ON public.patient_assignments USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4535 (class 3256 OID 18533)
-- Name: medication_orders Admins can manage all medication orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all medication orders" ON public.medication_orders USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4526 (class 3256 OID 18524)
-- Name: medications Admins can manage all medications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all medications" ON public.medications USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4516 (class 3256 OID 18387)
-- Name: patients Admins can manage all patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all patients" ON public.patients USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4519 (class 3256 OID 18390)
-- Name: providers Admins can manage all providers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all providers" ON public.providers USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4521 (class 3256 OID 18392)
-- Name: admins Admins can update own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can update own data" ON public.admins FOR UPDATE USING ((profile_id = auth.uid()));


--
-- TOC entry 4557 (class 3256 OID 18798)
-- Name: clinical_notes Admins can view all clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all clinical notes" ON public.clinical_notes FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))));


--
-- TOC entry 4533 (class 3256 OID 18531)
-- Name: medication_approvals Admins can view all medication approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all medication approvals" ON public.medication_approvals FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4529 (class 3256 OID 18527)
-- Name: patient_medication_preferences Admins can view all medication preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all medication preferences" ON public.patient_medication_preferences FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE (admins.profile_id = auth.uid()))));


--
-- TOC entry 4512 (class 3256 OID 18383)
-- Name: profiles Admins can view all profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all profiles" ON public.profiles USING ((EXISTS ( SELECT 1
   FROM public.admins
  WHERE ((admins.profile_id = auth.uid()) AND (admins.active = true)))));


--
-- TOC entry 4575 (class 3256 OID 18946)
-- Name: visit_addendums Admins can view all visit addendums; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all visit addendums" ON public.visit_addendums FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))));


--
-- TOC entry 4560 (class 3256 OID 18803)
-- Name: visit_interactions Admins can view all visit interactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all visit interactions" ON public.visit_interactions FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = auth.uid()) AND (profiles.role = 'admin'::text)))));


--
-- TOC entry 4520 (class 3256 OID 18391)
-- Name: admins Admins can view own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view own data" ON public.admins FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4572 (class 3256 OID 18854)
-- Name: auth_trigger_logs Allow admins to read logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow admins to read logs" ON public.auth_trigger_logs FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.profiles p
  WHERE ((p.id = auth.uid()) AND (p.role = 'admin'::text)))));


--
-- TOC entry 4568 (class 3256 OID 18835)
-- Name: profiles Allow auth trigger and service role; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow auth trigger and service role" ON public.profiles USING (true);


--
-- TOC entry 4570 (class 3256 OID 18837)
-- Name: provider_schedules Allow auth trigger and service role; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow auth trigger and service role" ON public.provider_schedules USING (true);


--
-- TOC entry 4569 (class 3256 OID 18836)
-- Name: providers Allow auth trigger and service role; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow auth trigger and service role" ON public.providers USING (true);


--
-- TOC entry 4571 (class 3256 OID 18853)
-- Name: auth_trigger_logs Allow trigger function to write logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Allow trigger function to write logs" ON public.auth_trigger_logs FOR INSERT WITH CHECK (true);


--
-- TOC entry 4525 (class 3256 OID 18523)
-- Name: medications Anyone can view active medications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can view active medications" ON public.medications FOR SELECT USING ((active = true));


--
-- TOC entry 4527 (class 3256 OID 18525)
-- Name: patient_medication_preferences Patients can manage own medication preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can manage own medication preferences" ON public.patient_medication_preferences USING ((EXISTS ( SELECT 1
   FROM public.patients
  WHERE ((patients.profile_id = auth.uid()) AND (patients.id = patient_medication_preferences.patient_id)))));


--
-- TOC entry 4514 (class 3256 OID 18385)
-- Name: patients Patients can update own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can update own data" ON public.patients FOR UPDATE USING ((profile_id = auth.uid()));


--
-- TOC entry 4522 (class 3256 OID 18393)
-- Name: patient_assignments Patients can view own assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view own assignments" ON public.patient_assignments FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.patients
  WHERE ((patients.id = patient_assignments.patient_id) AND (patients.profile_id = auth.uid())))));


--
-- TOC entry 4513 (class 3256 OID 18384)
-- Name: patients Patients can view own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view own data" ON public.patients FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4532 (class 3256 OID 18530)
-- Name: medication_approvals Patients can view own medication approvals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view own medication approvals" ON public.medication_approvals FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patients pt
     JOIN public.patient_medication_preferences pmp ON ((pt.id = pmp.patient_id)))
  WHERE ((pt.profile_id = auth.uid()) AND (pmp.id = medication_approvals.preference_id)))));


--
-- TOC entry 4534 (class 3256 OID 18532)
-- Name: medication_orders Patients can view own medication orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view own medication orders" ON public.medication_orders FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.patients
  WHERE ((patients.profile_id = auth.uid()) AND (patients.id = medication_orders.patient_id)))));


--
-- TOC entry 4556 (class 3256 OID 18797)
-- Name: clinical_notes Patients can view their clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their clinical notes" ON public.clinical_notes FOR SELECT TO authenticated USING ((patient_id IN ( SELECT p.id
   FROM (public.patients p
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4564 (class 3256 OID 18820)
-- Name: clinical_notes Patients can view their own clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their own clinical notes" ON public.clinical_notes FOR SELECT USING ((patient_id IN ( SELECT p.id
   FROM public.patients p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4567 (class 3256 OID 18825)
-- Name: visit_interactions Patients can view their own visit interactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their own visit interactions" ON public.visit_interactions FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4574 (class 3256 OID 18944)
-- Name: visit_addendums Patients can view their visit addendums; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their visit addendums" ON public.visit_addendums FOR SELECT TO authenticated USING ((visit_id IN ( SELECT a.id
   FROM ((public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4559 (class 3256 OID 18801)
-- Name: visit_interactions Patients can view their visit interactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Patients can view their visit interactions" ON public.visit_interactions FOR SELECT TO authenticated USING ((appointment_id IN ( SELECT a.id
   FROM ((public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4562 (class 3256 OID 18818)
-- Name: clinical_notes Providers can create clinical notes for their patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create clinical notes for their patients" ON public.clinical_notes FOR INSERT WITH CHECK ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4537 (class 3256 OID 18544)
-- Name: medication_orders Providers can create orders for assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create orders for assigned patients" ON public.medication_orders FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = medication_orders.patient_id)))));


--
-- TOC entry 4566 (class 3256 OID 18823)
-- Name: visit_interactions Providers can create visit interactions for their appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can create visit interactions for their appointments" ON public.visit_interactions FOR INSERT WITH CHECK ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.providers p ON ((a.provider_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4573 (class 3256 OID 18943)
-- Name: visit_addendums Providers can manage addendums for their patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can manage addendums for their patients" ON public.visit_addendums TO authenticated USING ((provider_id IN ( SELECT p.id
   FROM (public.providers p
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4530 (class 3256 OID 18528)
-- Name: medication_approvals Providers can manage approvals for assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can manage approvals for assigned patients" ON public.medication_approvals USING ((EXISTS ( SELECT 1
   FROM ((public.providers p
     JOIN public.patient_assignments pa ON ((p.id = pa.provider_id)))
     JOIN public.patient_medication_preferences pmp ON ((pa.patient_id = pmp.patient_id)))
  WHERE ((p.profile_id = auth.uid()) AND (pmp.id = medication_approvals.preference_id)))));


--
-- TOC entry 4555 (class 3256 OID 18796)
-- Name: clinical_notes Providers can manage clinical notes for their patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can manage clinical notes for their patients" ON public.clinical_notes TO authenticated USING ((provider_id IN ( SELECT p.id
   FROM (public.providers p
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4558 (class 3256 OID 18799)
-- Name: visit_interactions Providers can manage visit interactions for their patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can manage visit interactions for their patients" ON public.visit_interactions TO authenticated USING ((appointment_id IN ( SELECT a.id
   FROM ((public.appointments a
     JOIN public.providers p ON ((a.provider_id = p.id)))
     JOIN public.profiles pr ON ((p.profile_id = pr.id)))
  WHERE (pr.id = auth.uid()))));


--
-- TOC entry 4538 (class 3256 OID 18545)
-- Name: medication_orders Providers can update assigned patient orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update assigned patient orders" ON public.medication_orders FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = medication_orders.patient_id)))));


--
-- TOC entry 4539 (class 3256 OID 18546)
-- Name: patient_medication_preferences Providers can update assigned patient preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update assigned patient preferences" ON public.patient_medication_preferences FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = patient_medication_preferences.patient_id)))));


--
-- TOC entry 4518 (class 3256 OID 18389)
-- Name: providers Providers can update own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update own data" ON public.providers FOR UPDATE USING ((profile_id = auth.uid()));


--
-- TOC entry 4563 (class 3256 OID 18819)
-- Name: clinical_notes Providers can update their own clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can update their own clinical notes" ON public.clinical_notes FOR UPDATE USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4536 (class 3256 OID 18534)
-- Name: medication_orders Providers can view assigned patient orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view assigned patient orders" ON public.medication_orders FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = medication_orders.patient_id)))));


--
-- TOC entry 4528 (class 3256 OID 18526)
-- Name: patient_medication_preferences Providers can view assigned patient preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view assigned patient preferences" ON public.patient_medication_preferences FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((pa.provider_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = patient_medication_preferences.patient_id)))));


--
-- TOC entry 4515 (class 3256 OID 18386)
-- Name: patients Providers can view assigned patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view assigned patients" ON public.patients FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.patient_assignments pa
     JOIN public.providers p ON ((p.id = pa.provider_id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.patient_id = patients.id) AND (pa.active = true)))));


--
-- TOC entry 4517 (class 3256 OID 18388)
-- Name: providers Providers can view own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view own data" ON public.providers FOR SELECT USING ((profile_id = auth.uid()));


--
-- TOC entry 4523 (class 3256 OID 18394)
-- Name: patient_assignments Providers can view their assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their assignments" ON public.patient_assignments FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.providers
  WHERE ((providers.id = patient_assignments.provider_id) AND (providers.profile_id = auth.uid())))));


--
-- TOC entry 4561 (class 3256 OID 18817)
-- Name: clinical_notes Providers can view their own clinical notes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their own clinical notes" ON public.clinical_notes FOR SELECT USING ((provider_id IN ( SELECT p.id
   FROM public.providers p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4565 (class 3256 OID 18821)
-- Name: visit_interactions Providers can view their own visit interactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Providers can view their own visit interactions" ON public.visit_interactions FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.providers p ON ((a.provider_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4581 (class 3256 OID 19008)
-- Name: admins Service role can manage admins; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage admins" ON public.admins USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = profile_id)));


--
-- TOC entry 4586 (class 3256 OID 19021)
-- Name: admins Service role can manage all admins; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage all admins" ON public.admins USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4584 (class 3256 OID 19019)
-- Name: patients Service role can manage all patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage all patients" ON public.patients USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4583 (class 3256 OID 19018)
-- Name: profiles Service role can manage all profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage all profiles" ON public.profiles USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4585 (class 3256 OID 19020)
-- Name: providers Service role can manage all providers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage all providers" ON public.providers USING ((auth.role() = 'service_role'::text));


--
-- TOC entry 4579 (class 3256 OID 19006)
-- Name: patients Service role can manage patients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage patients" ON public.patients USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = profile_id)));


--
-- TOC entry 4577 (class 3256 OID 19004)
-- Name: profiles Service role can manage profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage profiles" ON public.profiles USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = id)));


--
-- TOC entry 4580 (class 3256 OID 19007)
-- Name: providers Service role can manage providers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage providers" ON public.providers USING (((current_setting('role'::text) = 'service_role'::text) OR (auth.uid() = profile_id)));


--
-- TOC entry 4582 (class 3256 OID 19009)
-- Name: provider_schedules Service role can manage schedules; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage schedules" ON public.provider_schedules USING ((current_setting('role'::text) = 'service_role'::text));


--
-- TOC entry 4576 (class 3256 OID 18998)
-- Name: profiles Users can update own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING ((auth.uid() = id));


--
-- TOC entry 4578 (class 3256 OID 19005)
-- Name: profiles Users can view own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING ((auth.uid() = id));


--
-- TOC entry 4551 (class 3256 OID 18681)
-- Name: appointments admin_full_appointments_access; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_full_appointments_access ON public.appointments USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4736 (class 0 OID 0)
-- Dependencies: 4551
-- Name: POLICY admin_full_appointments_access ON appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY admin_full_appointments_access ON public.appointments IS 'Admins have full access to all appointment data';


--
-- TOC entry 4553 (class 3256 OID 18686)
-- Name: appointment_history admin_view_all_appointment_history; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_view_all_appointment_history ON public.appointment_history USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4545 (class 3256 OID 18674)
-- Name: provider_availability_overrides admin_view_all_overrides; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_view_all_overrides ON public.provider_availability_overrides USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4531 (class 3256 OID 18670)
-- Name: provider_schedules admin_view_all_schedules; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_view_all_schedules ON public.provider_schedules USING ((EXISTS ( SELECT 1
   FROM public.admins a
  WHERE ((a.profile_id = auth.uid()) AND (a.active = true)))));


--
-- TOC entry 4501 (class 0 OID 18320)
-- Dependencies: 328
-- Name: admins; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.admins ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4554 (class 3256 OID 18687)
-- Name: appointment_history appointment_history_readonly; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY appointment_history_readonly ON public.appointment_history FOR INSERT WITH CHECK (false);


--
-- TOC entry 4737 (class 0 OID 0)
-- Dependencies: 4554
-- Name: POLICY appointment_history_readonly ON appointment_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY appointment_history_readonly ON public.appointment_history IS 'History is maintained by system triggers only';


--
-- TOC entry 4510 (class 0 OID 18839)
-- Dependencies: 345
-- Name: auth_trigger_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.auth_trigger_logs ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4508 (class 0 OID 18702)
-- Dependencies: 342
-- Name: clinical_notes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.clinical_notes ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4504 (class 0 OID 18455)
-- Dependencies: 334
-- Name: medication_approvals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medication_approvals ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4505 (class 0 OID 18476)
-- Dependencies: 335
-- Name: medication_orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medication_orders ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4502 (class 0 OID 18418)
-- Dependencies: 332
-- Name: medications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.medications ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4547 (class 3256 OID 18676)
-- Name: appointments patient_booking_restrictions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_booking_restrictions ON public.appointments FOR INSERT WITH CHECK (((patient_id IN ( SELECT p.id
   FROM public.patients p
  WHERE (p.profile_id = auth.uid()))) AND (provider_id IN ( SELECT pa.provider_id
   FROM (public.patient_assignments pa
     JOIN public.patients p ON ((pa.patient_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.active = true)))) AND ((appointment_date > CURRENT_DATE) OR ((appointment_date = CURRENT_DATE) AND (start_time > LOCALTIME))) AND (appointment_date <= (CURRENT_DATE + '90 days'::interval)) AND (booked_by = 'patient'::text)));


--
-- TOC entry 4738 (class 0 OID 0)
-- Dependencies: 4547
-- Name: POLICY patient_booking_restrictions ON appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY patient_booking_restrictions ON public.appointments IS 'Enforces business rules for patient appointment booking';


--
-- TOC entry 4503 (class 0 OID 18431)
-- Dependencies: 333
-- Name: patient_medication_preferences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.patient_medication_preferences ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4548 (class 3256 OID 18678)
-- Name: appointments patient_no_delete_appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_no_delete_appointments ON public.appointments FOR DELETE USING (false);


--
-- TOC entry 4546 (class 3256 OID 18675)
-- Name: appointments patient_own_appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_own_appointments ON public.appointments USING ((patient_id IN ( SELECT p.id
   FROM public.patients p
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4739 (class 0 OID 0)
-- Dependencies: 4546
-- Name: POLICY patient_own_appointments ON appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY patient_own_appointments ON public.appointments IS 'Patients can only access their own appointments';


--
-- TOC entry 4552 (class 3256 OID 18682)
-- Name: appointment_history patient_view_own_appointment_history; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_view_own_appointment_history ON public.appointment_history FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.patients p ON ((a.patient_id = p.id)))
  WHERE (p.profile_id = auth.uid()))));


--
-- TOC entry 4544 (class 3256 OID 18672)
-- Name: provider_availability_overrides patient_view_provider_overrides; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_view_provider_overrides ON public.provider_availability_overrides FOR SELECT USING ((provider_id IN ( SELECT pa.provider_id
   FROM (public.patient_assignments pa
     JOIN public.patients p ON ((pa.patient_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.active = true)))));


--
-- TOC entry 4541 (class 3256 OID 18668)
-- Name: provider_schedules patient_view_provider_schedules; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY patient_view_provider_schedules ON public.provider_schedules FOR SELECT USING ((provider_id IN ( SELECT pa.provider_id
   FROM (public.patient_assignments pa
     JOIN public.patients p ON ((pa.patient_id = p.id)))
  WHERE ((p.profile_id = auth.uid()) AND (pa.active = true)))));


--
-- TOC entry 4499 (class 0 OID 18284)
-- Dependencies: 326
-- Name: patients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4498 (class 0 OID 18267)
-- Dependencies: 325
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4507 (class 0 OID 18570)
-- Dependencies: 337
-- Name: provider_availability_overrides; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.provider_availability_overrides ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4550 (class 3256 OID 18680)
-- Name: appointments provider_no_delete_appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_no_delete_appointments ON public.appointments FOR DELETE USING (false);


--
-- TOC entry 4549 (class 3256 OID 18679)
-- Name: appointments provider_own_appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_own_appointments ON public.appointments USING ((provider_id IN ( SELECT pr.id
   FROM public.providers pr
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4740 (class 0 OID 0)
-- Dependencies: 4549
-- Name: POLICY provider_own_appointments ON appointments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY provider_own_appointments ON public.appointments IS 'Providers can manage appointments with their patients';


--
-- TOC entry 4543 (class 3256 OID 18671)
-- Name: provider_availability_overrides provider_own_overrides_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_own_overrides_policy ON public.provider_availability_overrides USING ((provider_id IN ( SELECT pr.id
   FROM public.providers pr
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4540 (class 3256 OID 18667)
-- Name: provider_schedules provider_own_schedule_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_own_schedule_policy ON public.provider_schedules USING ((provider_id IN ( SELECT pr.id
   FROM public.providers pr
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4506 (class 0 OID 18547)
-- Dependencies: 336
-- Name: provider_schedules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.provider_schedules ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4542 (class 3256 OID 18684)
-- Name: appointment_history provider_view_appointment_history; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provider_view_appointment_history ON public.appointment_history FOR SELECT USING ((appointment_id IN ( SELECT a.id
   FROM (public.appointments a
     JOIN public.providers pr ON ((a.provider_id = pr.id)))
  WHERE (pr.profile_id = auth.uid()))));


--
-- TOC entry 4500 (class 0 OID 18302)
-- Dependencies: 327
-- Name: providers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4511 (class 0 OID 18920)
-- Dependencies: 347
-- Name: visit_addendums; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.visit_addendums ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4509 (class 0 OID 18760)
-- Dependencies: 344
-- Name: visit_interactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.visit_interactions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4480 (class 0 OID 17613)
-- Dependencies: 300
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4477 (class 0 OID 16509)
-- Dependencies: 275
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4484 (class 0 OID 17892)
-- Dependencies: 309
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4485 (class 0 OID 17903)
-- Dependencies: 310
-- Name: iceberg_namespaces; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.iceberg_namespaces ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4486 (class 0 OID 17919)
-- Dependencies: 311
-- Name: iceberg_tables; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.iceberg_tables ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4479 (class 0 OID 16551)
-- Dependencies: 277
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4478 (class 0 OID 16524)
-- Dependencies: 276
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4483 (class 0 OID 17847)
-- Dependencies: 308
-- Name: prefixes; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.prefixes ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4481 (class 0 OID 17794)
-- Dependencies: 306
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4482 (class 0 OID 17808)
-- Dependencies: 307
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

-- Completed on 2025-09-30 16:14:41 UTC

--
-- PostgreSQL database dump complete
--

